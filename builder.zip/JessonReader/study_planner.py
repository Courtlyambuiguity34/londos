"""Study timetable, focus/break timer and gentle local reminders."""
import datetime as dt
import json
import math
import os
from pathlib import Path
import shutil
import sqlite3
import subprocess
import time
import uuid
from PyQt5.QtCore import Qt, QTimer, QDateTime, QDate, pyqtSignal
from PyQt5.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QGridLayout, QLabel, QPushButton,
    QLineEdit, QSpinBox, QComboBox, QDateTimeEdit, QDateEdit, QCheckBox, QTableWidget,
    QTableWidgetItem, QHeaderView, QAbstractItemView, QProgressBar, QFileDialog, QGroupBox,
    QScrollArea)
from study_schedule import (default_data, read_plan, write_plan, ReminderLedger,
                            collect_reminders, occurrence, occurrence_token)


class StudyPlannerTab(QWidget):
    reminder = pyqtSignal(str, str)
    timerChanged = pyqtSignal(str)
    musicPauseRequested = pyqtSignal()

    def __init__(self, storage_path, parent=None, clock=time.monotonic, now=dt.datetime.now):
        super().__init__(parent)
        self.storage_path = Path(storage_path)
        self._clock, self._now = clock, now
        self._error = ''
        self._corrupt = False
        try: self.data = read_plan(self.storage_path)
        except (OSError, ValueError, TypeError, KeyError):
            self.data = default_data(); self._corrupt = True
            self._error = 'Could not read the saved plan. It will be backed up before any replacement is saved.'
        self.ledger = None
        try: self.ledger = ReminderLedger(self.storage_path.with_suffix('.reminders.sqlite3'))
        except (OSError, sqlite3.Error): self._error = 'Reminder storage is unavailable. Check folder permissions.'
        self._running = False; self._deadline = None
        timer = self.data.get('timer', {})
        self.mode = timer.get('mode', 'Focus') if timer.get('mode') in ('Focus', 'Break') else 'Focus'
        try:
            self._full_seconds = max(1, min(14400, int(timer.get('full_seconds', self.data['settings']['focus_minutes'] * 60))))
            self._remaining = max(0, min(self._full_seconds, float(timer.get('remaining', self._full_seconds))))
        except (ValueError, TypeError): self._full_seconds = self._remaining = 1500
        self._topic = str(timer.get('topic', ''))[:200]
        self._build_ui()
        self._refresh_table(); self._render_timer(); self._refresh_progress()
        self.tickTimer = QTimer(self); self.tickTimer.setInterval(250); self.tickTimer.timeout.connect(self._tick); self.tickTimer.start()
        self.reminderTimer = QTimer(self); self.reminderTimer.setInterval(30000); self.reminderTimer.timeout.connect(self.check_reminders); self.reminderTimer.start()
        QTimer.singleShot(500, self.check_reminders)

    def _build_ui(self):
        root = QVBoxLayout(self); root.setContentsMargins(12, 12, 12, 12)
        heading = QLabel('Study Planner'); heading.setStyleSheet('font-size:22px;font-weight:bold;'); root.addWidget(heading)
        note = QLabel('Choose one useful goal. Read with your music, take a short break, then return when ready.')
        note.setWordWrap(True); root.addWidget(note)
        scroll = QScrollArea(); scroll.setWidgetResizable(True); content = QWidget(); body = QVBoxLayout(content); scroll.setWidget(content); root.addWidget(scroll, 1)
        focus = QGroupBox('Focus and rest'); grid = QGridLayout(focus)
        self.topicEdit = QLineEdit(self._topic); self.topicEdit.setPlaceholderText('This session: e.g. revise groundwater equations'); self.topicEdit.setMaxLength(200)
        grid.addWidget(self.topicEdit, 0, 0, 1, 6)
        self.timerLabel = QLabel(); self.timerLabel.setAlignment(Qt.AlignCenter); self.timerLabel.setStyleSheet('font-size:36px;font-weight:bold;')
        grid.addWidget(self.timerLabel, 1, 0, 1, 3)
        self.startButton = QPushButton('Start'); self.startButton.clicked.connect(self.toggle_timer)
        reset = QPushButton('Reset focus'); reset.clicked.connect(self.reset_focus)
        rest = QPushButton('Take a break'); rest.clicked.connect(self.start_break)
        for column, button in enumerate((self.startButton, reset, rest), 3): grid.addWidget(button, 1, column)
        settings = self.data['settings']
        self.focusMinutes = self._spin(1, 240, settings['focus_minutes'])
        self.breakMinutes = self._spin(1, 60, settings['break_minutes'])
        self.goalMinutes = self._spin(1, 1440, settings['goal_minutes'])
        for column, title, control in ((0,'Focus minutes',self.focusMinutes),(2,'Break minutes',self.breakMinutes),(4,'Daily goal',self.goalMinutes)):
            grid.addWidget(QLabel(title), 2, column); grid.addWidget(control, 2, column+1)
        self.pauseMusic = QCheckBox('Pause music when a focus block ends'); self.pauseMusic.setChecked(settings['pause_music'])
        self.sound = QCheckBox('Play a gentle reminder sound'); self.sound.setChecked(settings['sound'])
        grid.addWidget(self.pauseMusic, 3, 0, 1, 3); grid.addWidget(self.sound, 3, 3, 1, 3)
        self.progress = QProgressBar(); grid.addWidget(self.progress, 4, 0, 1, 6)
        body.addWidget(focus)
        schedule = QGroupBox('Timetable builder'); layout = QGridLayout(schedule)
        self.subjectEdit = QLineEdit(); self.subjectEdit.setPlaceholderText('Subject or topic'); self.subjectEdit.setMaxLength(200)
        self.whenEdit = QDateTimeEdit(QDateTime.currentDateTime().addSecs(300)); self.whenEdit.setCalendarPopup(True); self.whenEdit.setDisplayFormat('ddd dd MMM yyyy HH:mm')
        self.lengthSpin = self._spin(1, 240, 25)
        self.repeatBox = QComboBox(); self.repeatBox.addItems(['Once', 'Daily', 'Weekly'])
        self.untilEdit = QDateEdit(QDate.currentDate().addDays(28)); self.untilEdit.setCalendarPopup(True); self.untilEdit.setDisplayFormat('dd MMM yyyy')
        self.leadSpin = self._spin(0, 60, settings['reminder_minutes'])
        for row, label, widget in ((0,'Subject',self.subjectEdit),(1,'Starts (PC local time)',self.whenEdit),(2,'Duration, minutes',self.lengthSpin),(3,'Repeat',self.repeatBox),(4,'Repeat until',self.untilEdit),(5,'Remind before, minutes',self.leadSpin)):
            layout.addWidget(QLabel(label), row, 0); layout.addWidget(widget, row, 1)
        self.notesEdit = QLineEdit(); self.notesEdit.setPlaceholderText('Page numbers or a small goal (optional)'); self.notesEdit.setMaxLength(500)
        layout.addWidget(QLabel('Reading goal'), 6, 0); layout.addWidget(self.notesEdit, 6, 1)
        buttons = QHBoxLayout()
        for label, action in (('Add session', self.add_session), ('Update selected', self.update_session), ('New entry', self.clear_selection)):
            button = QPushButton(label); button.clicked.connect(action); buttons.addWidget(button)
        layout.addLayout(buttons, 7, 0, 1, 2)
        self.sessionTable = QTableWidget(0, 5); self.sessionTable.setHorizontalHeaderLabels(['Starts', 'Subject', 'Minutes', 'Repeat', 'State'])
        self.sessionTable.setSelectionBehavior(QAbstractItemView.SelectRows); self.sessionTable.setSelectionMode(QAbstractItemView.SingleSelection)
        self.sessionTable.setEditTriggers(QAbstractItemView.NoEditTriggers); self.sessionTable.setMinimumHeight(185)
        self.sessionTable.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeToContents)
        self.sessionTable.horizontalHeader().setSectionResizeMode(1, QHeaderView.Stretch)
        self.sessionTable.itemSelectionChanged.connect(self._select_row)
        layout.addWidget(self.sessionTable, 0, 2, 8, 1)
        row = QHBoxLayout()
        for label, action in (('Start selected', self.start_selected), ('Done / skip occurrence', self.complete_selected), ('Snooze 10 min', self.snooze_selected), ('Delete selected', self.delete_selected)):
            button = QPushButton(label); button.clicked.connect(action); row.addWidget(button)
        layout.addLayout(row, 8, 0, 1, 3); body.addWidget(schedule)
        footer = QHBoxLayout()
        self.backgroundButton = QPushButton(); self.backgroundButton.clicked.connect(self.toggle_background)
        if os.name != 'nt':
            self.backgroundButton.setEnabled(False); self.backgroundButton.setToolTip('Available in the Windows app')
        self._background_label(); footer.addWidget(self.backgroundButton)
        export = QPushButton('Export timetable CSV'); export.clicked.connect(self.export_csv); footer.addWidget(export)
        body.addLayout(footer)
        info = QLabel('Background reminders use a task for your Windows account. Keep Jesson.exe at a stable location. Your PC must be on and you must be signed in; overdue sessions are checked on return. Focus timers reopen paused.')
        info.setWordWrap(True); body.addWidget(info)
        self.alertLabel = QLabel(self._error or 'Your study plan is stored locally on this computer.'); self.alertLabel.setWordWrap(True); self.alertLabel.setTextFormat(Qt.PlainText); body.addWidget(self.alertLabel)
        body.addStretch()
        for control in (self.focusMinutes, self.breakMinutes, self.goalMinutes, self.leadSpin): control.valueChanged.connect(self.save_settings)
        self.pauseMusic.toggled.connect(self.save_settings); self.sound.toggled.connect(self.save_settings)
        self.topicEdit.editingFinished.connect(self._save)

    @staticmethod
    def _spin(low, high, value):
        control = QSpinBox(); control.setRange(low, high); control.setValue(value); return control

    def _snapshot_timer(self):
        remaining = max(0, self._deadline-self._clock()) if self._running else self._remaining
        self.data['timer'] = {'mode':self.mode,'remaining':remaining,'full_seconds':self._full_seconds,'topic':self.topicEdit.text()}

    def _save(self):
        self._snapshot_timer()
        try:
            if self._corrupt and self.storage_path.exists():
                backup = self.storage_path.with_name(self.storage_path.name + '.backup-' + uuid.uuid4().hex[:8])
                shutil.copy2(self.storage_path, backup); self._corrupt = False
            write_plan(self.storage_path, self.data)
            return True
        except OSError:
            self.alertLabel.setText('Could not save the study plan. Check the folder permissions before closing Jesson.'); return False

    def save_settings(self, *unused):
        settings = self.data['settings']
        settings.update(focus_minutes=self.focusMinutes.value(), break_minutes=self.breakMinutes.value(),
                        goal_minutes=self.goalMinutes.value(), reminder_minutes=self.leadSpin.value(),
                        pause_music=self.pauseMusic.isChecked(), sound=self.sound.isChecked())
        if not self._running and self._remaining == self._full_seconds:
            minutes = self.focusMinutes.value() if self.mode == 'Focus' else self.breakMinutes.value()
            self._remaining = self._full_seconds = minutes * 60
            self._render_timer()
        self._save(); self._refresh_progress()

    def _render_timer(self):
        remaining = max(0, self._deadline-self._clock()) if self._running else self._remaining
        seconds = math.ceil(remaining)
        text = f'{self.mode}  {seconds//60:02d}:{seconds%60:02d}'
        self.timerLabel.setText(text); self.timerChanged.emit(text)
        self.startButton.setText('Pause' if self._running else 'Start / resume')

    def _tick(self):
        if getattr(self, '_progress_day', None) != self._now().date(): self._refresh_progress()
        if self._running and self._clock() >= self._deadline:
            self._finish_block()
        self._render_timer()

    def toggle_timer(self):
        if self._running:
            self._remaining = max(0, self._deadline-self._clock()); self._running = False
        else:
            if self._remaining <= 0:
                self._remaining = self.data['settings']['focus_minutes' if self.mode == 'Focus' else 'break_minutes']*60
                self._full_seconds = self._remaining
            self._deadline = self._clock()+self._remaining; self._running = True
        self._save(); self._render_timer()

    def reset_focus(self):
        self._running = False; self.mode = 'Focus'
        self._full_seconds = self._remaining = self.focusMinutes.value()*60
        self._save(); self._render_timer()

    def start_break(self):
        self._running = False; self.mode = 'Break'
        self._full_seconds = self._remaining = self.breakMinutes.value()*60
        self.toggle_timer()

    def _finish_block(self):
        if not self._running: return
        self._running = False
        if self.mode == 'Focus':
            self.data['history'].append({'ended':self._now().isoformat(), 'seconds':self._full_seconds, 'topic':self.topicEdit.text()})
            self.data['history'] = self.data['history'][-2000:]
            if self.pauseMusic.isChecked(): self.musicPauseRequested.emit()
            title, message = 'Focus block complete', 'Take a short stretch, look away from the screen, and rest your eyes. Start your break when ready.'
            self.mode = 'Break'; self._full_seconds = self._remaining = self.breakMinutes.value()*60
        else:
            title, message = 'Break complete', 'Choose one small reading goal and start another focus block when you are ready.'
            self.mode = 'Focus'; self._full_seconds = self._remaining = self.focusMinutes.value()*60
        self._save(); self._refresh_progress(); self.alertLabel.setText(title + ': ' + message)
        self.reminder.emit(title, message)

    def _refresh_progress(self):
        self._progress_day = self._now().date()
        today = self._progress_day.isoformat()
        seconds = sum(max(0, float(row.get('seconds',0))) for row in self.data['history'] if isinstance(row,dict) and str(row.get('ended','')).startswith(today))
        minutes = int(seconds//60); target = self.goalMinutes.value()
        self.progress.setRange(0,target); self.progress.setValue(min(minutes,target))
        self.progress.setFormat(f'{minutes} completed focus minutes today / {target} minute goal')

    def _selected(self):
        row = self.sessionTable.currentRow()
        item = self.sessionTable.item(row, 0) if row >= 0 else None
        key = item.data(Qt.UserRole) if item else None
        return next((entry for entry in self.data['sessions'] if entry['id']==key),None)

    def _entry(self, key=None):
        subject = self.subjectEdit.text().strip()
        if not subject: raise ValueError('Enter a subject or reading goal first.')
        start = self.whenEdit.dateTime().toPyDateTime().replace(tzinfo=None)
        repeat = self.repeatBox.currentText()
        until = self.untilEdit.date().toPyDate()
        if repeat != 'Once' and until < start.date(): raise ValueError('Repeat-until date must be on or after the first session.')
        return {'id':key or uuid.uuid4().hex,'subject':subject,'start':start.isoformat(timespec='seconds'),
                'minutes':self.lengthSpin.value(),'repeat':repeat,'until':until.isoformat() if repeat!='Once' else None,
                'notes':self.notesEdit.text().strip(),'completed':False}

    def add_session(self):
        try: entry = self._entry()
        except ValueError as error: self.alertLabel.setText(str(error)); return
        self.data['sessions'].append(entry)
        self._save(); self._refresh_table(); self.alertLabel.setText('Session added. Reminders use your computer’s local time.')
        self.check_reminders()

    def update_session(self):
        selected = self._selected()
        if not selected: self.alertLabel.setText('Select a timetable row first.'); return
        try: entry = self._entry(selected['id'])
        except ValueError as error: self.alertLabel.setText(str(error)); return
        index = self.data['sessions'].index(selected); self.data['sessions'][index] = entry
        self._save(); self._refresh_table()

    def delete_selected(self):
        selected = self._selected()
        if selected:
            self.data['sessions'].remove(selected); self._save(); self._refresh_table()

    def clear_selection(self):
        self.sessionTable.clearSelection(); self.sessionTable.setCurrentCell(-1,-1)
        self.subjectEdit.clear(); self.notesEdit.clear()

    def _select_row(self):
        entry = self._selected()
        if not entry: return
        self.subjectEdit.setText(entry['subject']); self.notesEdit.setText(entry.get('notes',''))
        self.whenEdit.setDateTime(QDateTime(dt.datetime.fromisoformat(entry['start'])))
        self.lengthSpin.setValue(entry['minutes']); self.repeatBox.setCurrentText(entry.get('repeat','Once'))
        if entry.get('until'): self.untilEdit.setDate(QDate.fromString(entry['until'],'yyyy-MM-dd'))

    def _refresh_table(self):
        selected = self._selected() if hasattr(self,'sessionTable') else None
        self.sessionTable.blockSignals(True)
        self.sessionTable.setRowCount(0)
        for row, entry in enumerate(sorted(self.data['sessions'],key=lambda value:value['start'])):
            self.sessionTable.insertRow(row)
            start = dt.datetime.fromisoformat(entry['start'])
            state = 'Completed' if entry.get('completed') else 'Planned'
            current = occurrence(entry,self._now(),self.leadSpin.value())
            if current and self.ledger:
                try:
                    if self.ledger.is_done(occurrence_token(entry,current)): state='Occurrence done'
                    elif current < self._now(): state='Started / overdue'
                except sqlite3.Error: pass
            values = (start.strftime('%d %b %H:%M'),entry['subject'],str(entry['minutes']),entry.get('repeat','Once'),state)
            for column,value in enumerate(values):
                item = QTableWidgetItem(value); item.setData(Qt.UserRole,entry['id']); self.sessionTable.setItem(row,column,item)
            if selected and selected['id']==entry['id']: self.sessionTable.selectRow(row)
        self.sessionTable.blockSignals(False)

    def start_selected(self):
        entry = self._selected()
        if not entry: self.alertLabel.setText('Select a timetable session first.'); return
        self._running=False; self.mode='Focus'; self._remaining=self._full_seconds=entry['minutes']*60
        self.topicEdit.setText(entry['subject'] + (' — '+entry.get('notes','') if entry.get('notes') else ''))
        self.toggle_timer()

    def _selected_occurrence(self):
        entry = self._selected()
        if not entry: self.alertLabel.setText('Select a timetable session first.'); return None,None
        start = occurrence(entry,self._now(),self.leadSpin.value()) or dt.datetime.fromisoformat(entry['start'])
        return entry, occurrence_token(entry,start)

    def complete_selected(self):
        entry, token = self._selected_occurrence()
        if not entry or not self.ledger: return
        try: self.ledger.complete(token)
        except sqlite3.Error: self.alertLabel.setText('Could not save reminder state.'); return
        if entry.get('repeat','Once')=='Once': entry['completed']=True
        self._save(); self._refresh_table()

    def snooze_selected(self):
        entry, token = self._selected_occurrence()
        if not entry or not self.ledger: return
        if entry.get('completed') or occurrence(entry,self._now(),self.leadSpin.value()) is None:
            self.alertLabel.setText('Snooze is available when an incomplete session reminder is due.'); return
        try: self.ledger.snooze(token,self._now()+dt.timedelta(minutes=10))
        except sqlite3.Error: self.alertLabel.setText('Could not save snooze.'); return
        self.alertLabel.setText('Reminder snoozed for 10 minutes.')

    def check_reminders(self):
        if not self.ledger: return
        try: due = collect_reminders(self.data,self.ledger,self._now())
        except (sqlite3.Error,ValueError): self.alertLabel.setText('Could not check study reminders.'); return
        if due:
            message='\n'.join(f'{entry["subject"]} — {start:%a %H:%M} ({entry["minutes"]} min)' for entry,start in due[:12])
            self.alertLabel.setText('Study reminder: '+message); self.reminder.emit('Time for your study plan',message)
            self._refresh_table()

    def _background_label(self):
        self.backgroundButton.setText('Disable background reminders' if self.data['settings'].get('background_reminders') else 'Enable reminders after closing Jesson')

    def toggle_background(self):
        import study_reminder_agent as agent
        try:
            if self.data['settings'].get('background_reminders'):
                self.data['settings']['background_reminders']=False
                if not self._save(): return
                agent.remove_task(self.storage_path)
                self.alertLabel.setText('Background reminders disabled. In-app reminders remain available.')
            else:
                agent.register_task(self.storage_path)
                self.data['settings']['background_reminders']=True
                if not self._save(): return
                agent.start_task(self.storage_path)
                self.alertLabel.setText('Background reminders enabled for this Windows account, including after Jesson closes.')
        except (OSError,RuntimeError,subprocess.SubprocessError) as error: self.alertLabel.setText(str(error))
        finally: self._background_label()

    def export_csv(self):
        import csv
        path,_=QFileDialog.getSaveFileName(self,'Export timetable','','CSV (*.csv)')
        if not path: return
        try:
            with open(path,'w',newline='',encoding='utf-8-sig') as stream:
                writer=csv.writer(stream); writer.writerow(['Subject','Starts (local time)','Minutes','Repeat','Repeat until','Reading goal'])
                for entry in sorted(self.data['sessions'],key=lambda value:value['start']):
                    # Prevent spreadsheet formula interpretation of user text.
                    safe=lambda value: "'"+value if value.lstrip().startswith(('=','+','-','@')) or value.startswith(('\t','\r','\n')) else value
                    writer.writerow([safe(entry['subject']),entry['start'],entry['minutes'],entry['repeat'],entry.get('until') or '',safe(entry.get('notes',''))])
            self.alertLabel.setText('Timetable exported.')
        except OSError: self.alertLabel.setText('Could not export timetable. Check the chosen folder.')

    def shutdown(self):
        if self._running: self._remaining=max(0,self._deadline-self._clock())
        self._running=False; self.tickTimer.stop(); self.reminderTimer.stop(); self._save()
