"""Download and verify the portable x64 VLC runtime once, for Windows packaging."""
import hashlib
import argparse
import os
from pathlib import Path
import shutil
import tempfile
import urllib.request
import zipfile

VLC_VERSION = '3.0.24'
URL = f'https://download.videolan.org/pub/videolan/vlc/{VLC_VERSION}/win64/vlc-{VLC_VERSION}-win64.zip'
SHA256 = 'fcf30850371ad10c9373cc4f0f4501e7dee49e3e9ae9f20c72fb2661a1ca6323'


from vlc_runtime_config import valid_runtime, find_runtime, runtime_problems, RUNTIME_NAMES


def extract_verified(archive, destination):
    h = hashlib.sha256()
    with open(archive, 'rb') as source:
        for block in iter(lambda: source.read(1024*1024), b''): h.update(block)
    digest = h.hexdigest()
    if digest != SHA256:
        raise ValueError('VLC archive checksum mismatch; runtime was not installed.')
    destination = Path(destination).resolve()
    with zipfile.ZipFile(archive) as bundle:
        for item in bundle.infolist():
            target = (destination / item.filename).resolve()
            if not target.is_relative_to(destination):
                raise ValueError('Unsafe VLC archive path')
        bundle.extractall(destination)
    runtime = destination / f'vlc-{VLC_VERSION}'
    if not valid_runtime(runtime):
        raise ValueError('VLC archive lacks the required runtime files.')
    return runtime


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--offline', action='store_true', help='Never download VLC; require a manual runtime folder.')
    args = parser.parse_args()
    root = Path(__file__).resolve().parent
    existing = find_runtime(root)
    if existing:
        print(f'Using existing {existing.name}; VLC download skipped.')
        print('Keep the complete plugin tree from the same VLC distribution for broad codec support.')
        return 0
    partial = next((root / name for name in RUNTIME_NAMES if (root / name).exists()), None)
    if partial:
        print(f'Incomplete or incompatible {partial.name}; no automatic download or overwrite.')
        for problem in runtime_problems(partial): print('  ' + problem)
        return 1
    if args.offline:
        print('Offline mode: provide vlc_runtime with matching x64 DLLs and plugins. Nothing downloaded.')
        return 1
    target = root / 'vlc-runtime'
    print(f'Downloading portable VLC {VLC_VERSION} x64 from VideoLAN; verifying SHA-256.')
    try:
        with tempfile.TemporaryDirectory(prefix='jesson-vlc-', dir=root) as temp:
            archive = Path(temp) / 'vlc.zip'
            with urllib.request.urlopen(URL, timeout=60) as response, archive.open('wb') as output:
                shutil.copyfileobj(response, output, 1024*1024)
            runtime = extract_verified(archive, Path(temp) / 'extracted')
            shutil.copytree(runtime, target)
        print('VLC runtime and full plugin tree ready; no system installation required.')
        return 0
    except Exception as error:
        print(f'VLC preparation failed ({type(error).__name__}). Check network access and retry.')
        return 1


if __name__ == '__main__':
    raise SystemExit(main())
