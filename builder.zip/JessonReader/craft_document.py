"""Python/PyQt document enhancements informed by WordCraft's public UX model.

The code is an independent Python implementation.  It keeps Jesson's complete
writer feature set while adding ordered DOCX import and one searchable command
surface for keyboard-first study sessions.
"""

from pathlib import Path

from docx import Document
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.table import Table
from docx.text.paragraph import Paragraph
from PyQt5.QtCore import Qt, QTimer
from PyQt5.QtGui import QColor, QFont, QKeySequence, QTextBlockFormat, QTextCharFormat, QTextCursor
from PyQt5.QtWidgets import (
    QAbstractItemView,
    QDialog,
    QLabel,
    QLineEdit,
    QListWidget,
    QListWidgetItem,
    QMessageBox,
    QPushButton,
    QShortcut,
    QVBoxLayout,
)


class DocumentCommandPalette(QDialog):
    """Search and execute the same safe methods already exposed by the ribbon."""

    def __init__(self, writer, commands):
        super().__init__(writer)
        self.writer = writer
        self.commands = list(commands)
        self.setWindowTitle("Document commands")
        self.setModal(False)
        self.resize(540, 430)
        layout = QVBoxLayout(self)
        title = QLabel("Search document tools")
        title.setStyleSheet("font-size:17px;font-weight:700;color:#1f2937;")
        layout.addWidget(title)
        self.query = QLineEdit()
        self.query.setPlaceholderText("Try “comment”, “page”, “save”, “find”…")
        self.query.setClearButtonEnabled(True)
        layout.addWidget(self.query)
        self.results = QListWidget()
        self.results.setSelectionMode(QAbstractItemView.SingleSelection)
        layout.addWidget(self.results, 1)
        hint = QLabel("Enter runs the selected command · Esc closes")
        hint.setStyleSheet("color:#6b7280;")
        layout.addWidget(hint)
        self.query.textChanged.connect(self.refresh)
        self.query.returnPressed.connect(self.run_current)
        self.results.itemDoubleClicked.connect(lambda _item: self.run_current())
        self.refresh("")

    def refresh(self, query):
        terms = [term.casefold() for term in query.split() if term.strip()]
        self.results.clear()
        for index, (label, shortcut, _callback, keywords) in enumerate(self.commands):
            haystack = f"{label} {shortcut} {keywords}".casefold()
            if all(term in haystack for term in terms):
                text = label + (f"\n{shortcut}" if shortcut else "")
                item = QListWidgetItem(text)
                item.setData(Qt.UserRole, index)
                self.results.addItem(item)
        if self.results.count():
            self.results.setCurrentRow(0)

    def run_current(self):
        item = self.results.currentItem()
        if item is None:
            return
        index = item.data(Qt.UserRole)
        if not isinstance(index, int) or not 0 <= index < len(self.commands):
            return
        callback = self.commands[index][2]
        self.hide()
        QTimer.singleShot(0, self.writer._safe(callback))

    def show_palette(self):
        self.query.clear()
        self.refresh("")
        self.show()
        self.raise_()
        self.activateWindow()
        self.query.setFocus()


class CraftDocumentWorkspaceMixin:
    """Add ordered DOCX fidelity and a command palette to Jesson Writer."""

    def __init__(self):
        self._command_palette = None
        super().__init__()
        self._install_document_workspace()

    def _install_document_workspace(self):
        commands = [
            ("New document", "Ctrl+N", self.new_document, "file blank"),
            ("Open document", "Ctrl+O", self.load_document, "file docx html text pdf"),
            ("Save", "Ctrl+S", self.save_document, "file write"),
            ("Save as", "Ctrl+Shift+S", self.save_as_document, "file copy format"),
            ("Print", "Ctrl+P", self.print_document, "paper printer"),
            ("Print preview", "", self.print_preview, "paper pages"),
            ("Export PDF", "", self._export_pdf_direct, "save portable"),
            ("Find", "Ctrl+F", lambda: self.open_find(False), "search text"),
            ("Find and replace", "Ctrl+H", lambda: self.open_find(True), "search change"),
            ("Spelling", "F7", self.open_spelling, "proof review"),
            ("Add comment", "Ctrl+Alt+M", self.add_comment, "review note"),
            ("Insert table", "", self.prompt_insert_table, "rows columns"),
            ("Insert image", "", self.insert_image, "picture illustration"),
            ("Insert table of contents", "", self.insert_toc, "toc headings reference"),
            ("Page setup", "", self.page_setup_dialog, "margins orientation paper layout"),
            ("Fit page width", "", self.fit_page_width, "zoom view"),
            (
                "Toggle navigation",
                "",
                lambda: self.toggle_nav(not self.sideTabs.isVisible() or self.sideTabs.currentIndex() != 0),
                "headings panel",
            ),
            (
                "Toggle comments",
                "",
                lambda: self.toggle_comments_panel(not self.sideTabs.isVisible() or self.sideTabs.currentIndex() != 1),
                "review panel",
            ),
            ("Read aloud", "", self.read_aloud, "speech accessibility focus"),
            ("Stop reading", "", self.stop_reading, "speech accessibility"),
            ("Document statistics", "", self.show_statistics, "words characters reading"),
            ("Recover autosave", "", self.recover_autosave, "restore crash recovery"),
        ]
        self.documentCommands = commands
        self._command_palette = DocumentCommandPalette(self, commands)

        self._attach_document_command_search()

        for sequence in ("Alt+Q", "Ctrl+Shift+P"):
            shortcut = QShortcut(QKeySequence(sequence), self)
            shortcut.setContext(Qt.WidgetWithChildrenShortcut)
            shortcut.activated.connect(self.open_command_palette)

    def _attach_document_command_search(self):
        """Attach after the final page canvas creates its title label."""
        if getattr(self, "commandSearchButton", None) is not None:
            return
        title = getattr(self, "documentTitle", None)
        if title is not None and title.parentWidget() is not None:
            layout = title.parentWidget().layout()
            self.commandSearchButton = QPushButton("Search tools  Alt+Q")
            self.commandSearchButton.setToolTip("Search every document command")
            self.commandSearchButton.setStyleSheet(
                "QPushButton{background:white;color:#374151;border:0;border-radius:4px;"
                "padding:5px 12px;text-align:left;min-width:165px;}"
                "QPushButton:hover{background:#edf3f9;}"
            )
            self.commandSearchButton.clicked.connect(self.open_command_palette)
            layout.insertWidget(max(1, layout.count() - 1), self.commandSearchButton)

    def open_command_palette(self):
        self._command_palette.show_palette()

    # -------------------------------------------------------------- DOCX I/O
    def _load_document_path(self, path):
        if not str(path).lower().endswith(".docx"):
            return super()._load_document_path(path)
        old_html = self.textEdit.toHtml()
        old_file = self.current_file
        old_format = self.current_format
        try:
            source = Document(path)
            self._import_docx(source)
            self.current_file = str(path)
            self.current_format = "docx"
            self.doc_title = source.core_properties.title or Path(path).stem
            self.textEdit.moveCursor(QTextCursor.Start)
            self.textEdit.document().setModified(False)
            self._update_document_status()
            return True
        except Exception as exc:
            self.textEdit.setHtml(old_html)
            self.current_file = old_file
            self.current_format = old_format
            self.textEdit.document().setModified(False)
            QMessageBox.warning(self, "Open Error", f"The DOCX could not be imported: {exc}")
            return False

    def _import_docx(self, source):
        self.textEdit.clear()
        qdocument = self.textEdit.document()
        cursor = QTextCursor(qdocument)
        first = True
        blocks = list(source.iter_inner_content())
        for block in blocks:
            if isinstance(block, Paragraph):
                if not first:
                    cursor.movePosition(QTextCursor.End)
                    cursor.insertBlock()
                self._insert_docx_paragraph(cursor, block)
            elif isinstance(block, Table):
                if not first:
                    cursor.movePosition(QTextCursor.End)
                    cursor.insertBlock()
                self._insert_docx_table(cursor, block)
                cursor = QTextCursor(qdocument)
                cursor.movePosition(QTextCursor.End)
            first = False
        if source.sections:
            self._import_docx_section(source.sections[0])
        self._apply_page_setup()

    def _insert_docx_paragraph(self, cursor, paragraph):
        block_format = QTextBlockFormat()
        alignment = paragraph.alignment
        alignments = {
            WD_ALIGN_PARAGRAPH.LEFT: Qt.AlignLeft,
            WD_ALIGN_PARAGRAPH.CENTER: Qt.AlignHCenter,
            WD_ALIGN_PARAGRAPH.RIGHT: Qt.AlignRight,
            WD_ALIGN_PARAGRAPH.JUSTIFY: Qt.AlignJustify,
            WD_ALIGN_PARAGRAPH.DISTRIBUTE: Qt.AlignJustify,
        }
        if alignment in alignments:
            block_format.setAlignment(alignments[alignment])
        pf = paragraph.paragraph_format
        if pf.left_indent is not None:
            block_format.setLeftMargin(self._emu_to_px(pf.left_indent))
        if pf.right_indent is not None:
            block_format.setRightMargin(self._emu_to_px(pf.right_indent))
        if pf.first_line_indent is not None:
            block_format.setTextIndent(self._emu_to_px(pf.first_line_indent))
        if pf.space_before is not None:
            block_format.setTopMargin(self._emu_to_px(pf.space_before))
        if pf.space_after is not None:
            block_format.setBottomMargin(self._emu_to_px(pf.space_after))
        if isinstance(pf.line_spacing, float):
            block_format.setLineHeight(pf.line_spacing * 100, QTextBlockFormat.ProportionalHeight)
        cursor.setBlockFormat(block_format)

        run_count = 0
        for item in paragraph.iter_inner_content():
            runs = getattr(item, "runs", None) or [item]
            for run in runs:
                cursor.insertText(run.text, self._docx_char_format(run, paragraph))
                run_count += 1
        if run_count == 0 and paragraph.text:
            cursor.insertText(paragraph.text)

    def _docx_char_format(self, run, paragraph):
        result = QTextCharFormat()
        style_font = getattr(getattr(paragraph, "style", None), "font", None)
        family = run.font.name or (style_font.name if style_font is not None else None)
        size = run.font.size or (style_font.size if style_font is not None else None)
        bold = run.bold if run.bold is not None else (style_font.bold if style_font is not None else None)
        italic = run.italic if run.italic is not None else (style_font.italic if style_font is not None else None)
        underline = run.underline if run.underline is not None else (
            style_font.underline if style_font is not None else None
        )
        if family:
            result.setFontFamily(family)
        if size is not None:
            result.setFontPointSize(float(size.pt))
        if bold is not None:
            result.setFontWeight(QFont.Bold if bold else QFont.Normal)
        if italic is not None:
            result.setFontItalic(bool(italic))
        if underline is not None:
            result.setFontUnderline(bool(underline))
        color = run.font.color.rgb
        if color is not None:
            result.setForeground(QColor("#" + str(color)))
        if run.font.subscript:
            result.setVerticalAlignment(QTextCharFormat.AlignSubScript)
        elif run.font.superscript:
            result.setVerticalAlignment(QTextCharFormat.AlignSuperScript)
        return result

    def _insert_docx_table(self, cursor, source_table):
        rows = len(source_table.rows)
        columns = len(source_table.columns)
        if not rows or not columns:
            return
        table = cursor.insertTable(rows, columns)
        table_format = table.format()
        table_format.setBorder(0.8)
        table_format.setCellPadding(6)
        table_format.setCellSpacing(0)
        table.setFormat(table_format)
        for row_index, source_row in enumerate(source_table.rows):
            for column_index, source_cell in enumerate(source_row.cells[:columns]):
                cell_cursor = table.cellAt(row_index, column_index).firstCursorPosition()
                for paragraph_index, paragraph in enumerate(source_cell.paragraphs):
                    if paragraph_index:
                        cell_cursor.insertBlock()
                    self._insert_docx_paragraph(cell_cursor, paragraph)

    def _import_docx_section(self, section):
        width = self._emu_to_px(section.page_width)
        height = self._emu_to_px(section.page_height)
        self._orient = "Landscape" if width > height else "Portrait"
        portrait = (min(width, height), max(width, height))
        paper_sizes = {"A4": (794, 1123), "Letter": (816, 1056), "Legal": (816, 1344)}
        self._paper = min(
            paper_sizes,
            key=lambda name: abs(paper_sizes[name][0] - portrait[0])
            + abs(paper_sizes[name][1] - portrait[1]),
        )
        self._margins_px = tuple(
            max(0, self._emu_to_px(value))
            for value in (section.top_margin, section.left_margin, section.bottom_margin, section.right_margin)
        )
        self.header_text = "\n".join(p.text for p in section.header.paragraphs).strip()
        self.footer_text = "\n".join(p.text for p in section.footer.paragraphs).strip()

    @staticmethod
    def _emu_to_px(value):
        if value is None:
            return 0.0
        return float(value) * 96.0 / 914400.0

