"""Opt-in real libVLC decode checks; dummy audio output is intentional in CI."""
import os
from pathlib import Path
import subprocess
from types import SimpleNamespace
import pytest
from PyQt5.QtTest import QTest
from test_reader import reader, app, no_modal_notifications
import vlc_backend

pytestmark = pytest.mark.skipif(os.environ.get('JESSON_TEST_NATIVE_VLC') != '1', reason='Requires native libVLC and ffmpeg')


@pytest.mark.parametrize('extension', ['mp3', 'flac', 'wav'])
def test_first_two_tracks_decode_with_vlc(app, tmp_path, monkeypatch, extension):
    import vlc
    real_instance = vlc.Instance
    facade = SimpleNamespace(State=vlc.State, Instance=lambda *args: real_instance(*args, '--aout=dummy'))
    monkeypatch.setattr(vlc_backend, 'load_vlc', lambda: facade)
    widget = reader.ReliableMusicPlayerTab()
    try:
        assert widget.mediaPlayer._player is not None
        for index in range(2):
            path = tmp_path / f'track-{index}.{extension}'
            subprocess.run(['ffmpeg', '-v', 'error', '-f', 'lavfi', '-i', 'sine=frequency=440:duration=4', '-y', str(path)], check=True)
            item = reader.QListWidgetItem(path.name); item.setData(reader.Qt.UserRole, str(path))
            widget.playlistView.addItem(item)
        widget._sync_playlist_from_view()
        for index in range(2):
            widget.play_selected(widget.playlistView.item(index))
            QTest.qWait(1100)
            assert widget.playlist.currentIndex() == index
            assert widget.mediaPlayer.state() == reader.QMediaPlayer.PlayingState
            assert widget.mediaPlayer.duration() >= 3900
            assert widget.mediaPlayer.position() > 100
            assert widget.mediaPlayer.error_code == reader.QMediaPlayer.NoError
        widget.toggle_play_pause()
        assert widget.mediaPlayer.state() == reader.QMediaPlayer.PausedState
        widget.toggle_play_pause(); QTest.qWait(200)
        assert widget.mediaPlayer.state() == reader.QMediaPlayer.PlayingState
        widget.mediaPlayer.setPosition(2000); QTest.qWait(500)
        assert widget.mediaPlayer.position() >= 1900
    finally:
        widget.mediaPlayer.release(); widget.close(); widget.deleteLater(); app.processEvents()
