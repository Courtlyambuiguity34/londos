import importlib.util
import os
from pathlib import Path
import struct
import sys
import wave

os.environ.setdefault('QT_QPA_PLATFORM', 'offscreen')
os.environ.setdefault('QTWEBENGINE_DISABLE_SANDBOX', '1')  # headless container test only
os.environ.setdefault('LOCALAPPDATA', str(Path(__file__).parent / '.data'))
os.environ.setdefault('XDG_CACHE_HOME', str(Path(__file__).parent / '.cache'))
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import Jesson_Reader as reader
from PyQt5.QtTest import QTest
import pytest


@pytest.fixture(scope='session')
def app():
    application = reader.QApplication.instance() or reader.QApplication([])
    yield application


@pytest.fixture(autouse=True)
def no_modal_notifications(monkeypatch):
    messages = []
    def notify(*args, **kwargs):
        messages.append(str(args[2])); return reader.QMessageBox.Ok
    for name in ('warning', 'critical', 'information'):
        monkeypatch.setattr(reader.QMessageBox, name, notify)
    yield
    assert not messages, messages


@pytest.fixture
def writer(app):
    widget = reader.WordDocumentTab()
    widget.resize(1300, 800); widget.show(); app.processEvents()
    yield widget
    widget._autosave_timer.stop()
    widget.textEdit.document().setModified(False)
    widget.close(); widget.deleteLater(); app.processEvents()


def test_typing_format_undo_and_zoom(writer, app):
    writer.textEdit.setFocus()
    QTest.keyClicks(writer.textEdit, 'Exam preparation')
    writer.textEdit.selectAll()
    writer.boldBtn.click()
    assert writer.textEdit.textCursor().charFormat().fontWeight() >= reader.QFont.Bold
    writer.textEdit.undo()
    assert writer.textEdit.toPlainText() == 'Exam preparation'
    assert writer.textEdit.textCursor().charFormat().fontWeight() < reader.QFont.Bold
    before = writer.textEdit.toHtml()
    pages = writer._page_count()
    writer._set_page_zoom(160); app.processEvents()
    assert writer.textEdit.toHtml() == before
    assert writer._page_count() == pages
    assert writer.pageCanvas.transform().m11() == pytest.approx(1.6)


def test_pdf_has_all_pages_headers_and_footers(writer, tmp_path, app):
    writer.textEdit.setPlainText('\n'.join(f'Revision line {i}' for i in range(130)))
    writer.header_text = 'Jesson revision'
    writer.footer_text = 'Page {page} of {pages}'
    app.processEvents()
    path = tmp_path / 'revision.pdf'
    writer._write_document(path)
    with reader.fitz.open(path) as pdf:
        assert len(pdf) == writer._page_count() >= 3
        text = '\n'.join(page.get_text() for page in pdf)
        assert 'Revision line 0' in text and 'Revision line 129' in text
        for index, page in enumerate(pdf):
            assert 'Jesson revision' in page.get_text()
            assert f'Page {index + 1} of {len(pdf)}' in page.get_text()


def test_native_save_restores_comments_and_page_setup(writer, tmp_path):
    writer.textEdit.setPlainText('Revision notes')
    cursor = writer.textEdit.textCursor()
    cursor.setPosition(0); cursor.setPosition(8, reader.QTextCursor.KeepAnchor)
    fmt = reader.QTextCharFormat(); fmt.setProperty(reader.P_CMT, 1)
    cursor.mergeCharFormat(fmt)
    writer.comments = {1: {'text': 'Review this', 'author': 'Student', 'resolved': False}}
    writer.header_text = 'Study notes'
    writer._orient = 'Landscape'; writer._apply_page_setup()
    path = tmp_path / 'notes.html'
    writer._write_document(path)
    writer.comments.clear(); writer.header_text = ''; writer._orient = 'Portrait'
    assert writer._load_path(str(path))
    assert writer._orient == 'Landscape'
    assert writer.header_text == 'Study notes'
    assert writer.comments[1]['text'] == 'Review this'
    assert writer._scan(reader.P_CMT)
    assert not writer.textEdit.document().isModified()


def test_docx_export_keeps_tables_and_text(writer, tmp_path):
    writer.textEdit.setPlainText('Study heading')
    cursor = writer.textEdit.textCursor(); cursor.movePosition(reader.QTextCursor.End)
    table = cursor.insertTable(2, 2)
    table.cellAt(0, 0).firstCursorPosition().insertText('Topic')
    table.cellAt(1, 0).firstCursorPosition().insertText('Chemistry')
    path = tmp_path / 'notes.docx'; writer._write_document(path)
    document = reader.Document(path)
    assert 'Study heading' in '\n'.join(p.text for p in document.paragraphs)
    assert document.tables[0].cell(1, 0).text == 'Chemistry'


def test_cancel_open_and_new_preserve_unsaved_content(writer, monkeypatch):
    writer.textEdit.setPlainText('Do not lose my revision')
    writer.textEdit.document().setModified(True)
    writer.comments = {7: {'text': 'Keep this', 'author': 'Student', 'resolved': False}}
    monkeypatch.setattr(reader.QMessageBox, 'question', lambda *a, **k: reader.QMessageBox.Cancel)
    writer.new_document(); writer.load_document()
    assert writer.textEdit.toPlainText() == 'Do not lose my revision'
    assert 7 in writer.comments


def test_existing_writer_commands_remain_available(writer):
    for name in ['insert_table_formula', 'recalculate_current_table', 'insert_equation',
                 'insert_bookmark', 'add_comment', 'toggle_tracking', 'reject_all_changes',
                 'insert_chart', 'insert_toc', 'mm_finish', 'read_aloud', 'recover_autosave']:
        assert callable(getattr(writer, name))


@pytest.fixture
def music(app, tmp_path):
    widget = reader.ReliableMusicPlayerTab()
    for index in range(3):
        path = tmp_path / f'track-{index}.wav'
        with wave.open(str(path), 'wb') as handle:
            handle.setparams((1, 2, 22050, 0, 'NONE', 'not compressed'))
            handle.writeframes(struct.pack('<h', 200) * 22050 * 3)
        item = reader.QListWidgetItem(path.name); item.setData(reader.Qt.UserRole, str(path))
        widget.playlistView.addItem(item)
    widget._sync_playlist_from_view()
    yield widget
    widget.mediaPlayer.stop(); widget.close(); widget.deleteLater(); app.processEvents()


@pytest.mark.parametrize('index', [0, 1])
def test_first_two_tracks_decode_and_advance_position(music, index):
    assert music.mediaPlayer.isAvailable()
    music.play_selected(music.playlistView.item(index)); QTest.qWait(550)
    assert music.playlist.currentIndex() == index
    assert music.mediaPlayer.duration() == 3000
    assert music.mediaPlayer.position() > 100
    assert music.mediaPlayer.state() == reader.QMediaPlayer.PlayingState
    assert music.mediaPlayer.error() == reader.QMediaPlayer.NoError


def test_rapid_selection_cannot_replay_an_old_delayed_click(music):
    music.play_selected(music.playlistView.item(1))
    music.play_selected(music.playlistView.item(0)); QTest.qWait(250)
    assert music.playlist.currentIndex() == 0
    assert music.mediaPlayer.currentMedia().canonicalUrl().toLocalFile() == music._paths_in_view()[0]


def test_missing_track_does_not_shift_indexes_or_skip(music):
    missing = music.playlistView.item(0).data(reader.Qt.UserRole)
    Path(missing).unlink()
    music._sync_playlist_from_view()
    assert music.playlist.mediaCount() == music.playlistView.count()
    music.play_selected(music.playlistView.item(0)); QTest.qWait(100)
    assert music.playlist.currentIndex() == 0
    assert not music._play_requested
    music.play_selected(music.playlistView.item(1)); QTest.qWait(250)
    assert music.playlist.currentIndex() == 1


def test_filtered_reordered_queue_keeps_selected_path(music):
    item = music.playlistView.takeItem(1); music.playlistView.insertItem(0, item)
    music.queueSearch.setText('track-1')
    music.play_selected(item); QTest.qWait(200)
    assert music.playlist.currentIndex() == 0
    assert music.mediaPlayer.currentMedia().canonicalUrl().toLocalFile() == item.data(reader.Qt.UserRole)
    assert music.playlist.mediaCount() == 3


def test_media_error_stays_on_selected_track(music):
    music.play_selected(music.playlistView.item(0))
    music.handle_media_error(reader.QMediaPlayer.FormatError)
    assert music.playlist.currentIndex() == 0
    assert not music._play_requested
    assert 'Cannot play' in music.trackSub.text()


def test_unknown_icon_filename_and_frozen_location(app, tmp_path, monkeypatch):
    icon = tmp_path / 'my-forgotten-name.ICO'
    reader.Image.new('RGB', (64, 64), '#2857a4').save(icon, format='ICO')
    (tmp_path / 'jesson_app.ico').write_text('invalid image')
    monkeypatch.setattr(reader, '__file__', str(tmp_path / 'reader.py'))
    monkeypatch.setattr(reader.sys, 'frozen', True, raising=False)
    monkeypatch.setattr(reader.sys, 'executable', str(tmp_path / 'JessonReader.exe'))
    monkeypatch.delenv('JESSON_ICON', raising=False)
    assert reader.discover_icon_path() == str(icon)
    assert not reader.reader_icon().pixmap(32, 32).isNull()


def test_fallback_icon_is_renderable(app, tmp_path, monkeypatch):
    monkeypatch.setattr(reader, '__file__', str(tmp_path / 'reader.py'))
    monkeypatch.chdir(tmp_path)
    monkeypatch.setattr(reader.sys, '_MEIPASS', str(tmp_path), raising=False)
    monkeypatch.delenv('JESSON_ICON', raising=False)
    assert not reader.reader_icon().pixmap(32, 32).isNull()


def test_autosave_keeps_unsaved_state_and_recovers_comments(writer, tmp_path):
    writer.textEdit.insertPlainText('Study recovery')
    cursor = writer.textEdit.textCursor(); cursor.select(reader.QTextCursor.Document)
    fmt = reader.QTextCharFormat(); fmt.setProperty(reader.P_CMT, 2); cursor.mergeCharFormat(fmt)
    writer.comments = {2: {'text': 'Keep my notes', 'author': 'Student', 'resolved': False,
                          'time': reader.datetime.datetime.now()}}
    writer._autosave_path = tmp_path / 'recovery.html'
    writer._autosave_tick()
    assert writer.textEdit.document().isModified()
    assert writer.current_file is None
    assert writer._load_path(str(writer._autosave_path))
    assert writer.comments[2]['text'] == 'Keep my notes'


def test_proxy_page_accepts_mouse_focus_and_typing(writer, app):
    left = writer._margins_px[1]; top = writer._margins_px[0]
    point = writer.pageCanvas.mapFromScene(reader.QPointF(left + 15, top + 8))
    QTest.mouseClick(writer.pageCanvas.viewport(), reader.Qt.LeftButton, pos=point)
    focus = app.focusWidget()
    assert focus is not None
    QTest.keyClicks(focus, 'Type on the page')
    assert 'Type on the page' in writer.textEdit.toPlainText()


def test_gemini_failures_are_sanitized_and_clients_closed(app, monkeypatch):
    from google import genai
    closed = []
    class Client:
        def __init__(self, **kwargs):
            self.models = self
        def generate_content(self, **kwargs):
            raise RuntimeError('PRIVATE-KEY-SENTINEL server response')
        def close(self):
            closed.append(True)
    monkeypatch.setattr(genai, 'Client', Client)
    monkeypatch.setenv('GEMINI_KEY_SLOT', '1')
    worker = reader.GeminiWorker(['PRIVATE-KEY-SENTINEL'], 'study')
    errors = []; worker.error.connect(errors.append)
    worker.run()
    assert errors and 'SENTINEL' not in errors[0]
    assert closed == [True]


def test_mail_merge_preview_preserves_page_margins(writer):
    writer._mm_set_html('<p>Dear Student,</p><p>Your revision notes.</p>')
    fmt = writer.textEdit.document().rootFrame().frameFormat()
    assert fmt.topMargin() == writer._margins_px[0]
    assert fmt.leftMargin() == writer._margins_px[1]


def test_document_status_during_initialization(app, monkeypatch):
    original = reader.WordDocumentTab._update_document_status
    early_updates = []
    def inspect_status(self, *args):
        if not hasattr(self, 'documentTitle'):
            early_updates.append(True)
        return original(self, *args)
    monkeypatch.setattr(reader.WordDocumentTab, '_update_document_status', inspect_status)
    widget = reader.WordDocumentTab()
    try:
        assert widget.documentTitle is not None
        widget.textEdit.setPlainText('Revision notes')
        widget.textEdit.document().setModified(True)
        app.processEvents()
        assert 'Unsaved' in widget.documentTitle.text()
        assert 'Words: 2' in widget.wordCountLabel.text()
        title = widget.documentTitle
        del widget.documentTitle
        widget._update_document_status()
        widget.documentTitle = title
        widget._update_document_status()
    finally:
        widget._autosave_timer.stop()
        widget.textEdit.document().setModified(False)
        widget.close()
        widget.deleteLater()
        app.processEvents()
