import sys
import importlib.util
from pathlib import Path

spec = importlib.util.spec_from_file_location('package_check', Path(__file__).resolve().parents[1] / 'ensure_build_packages.py')
check = importlib.util.module_from_spec(spec)
spec.loader.exec_module(check)


def test_only_missing_selected(monkeypatch):
    def version(name):
        if name == 'absent':
            raise check.metadata.PackageNotFoundError(name)
        return '1.0'
    monkeypatch.setattr(check.metadata, 'version', version)
    assert check.missing_requirements(['present==2.0', 'absent>=1']) == ['absent>=1']


def test_no_download_when_present(monkeypatch):
    monkeypatch.setattr(sys, 'argv', ['ensure_build_packages.py'])
    monkeypatch.setattr(check.metadata, 'version', lambda name: '1.0')
    monkeypatch.setattr(check.subprocess, 'call', lambda *a, **k: (_ for _ in ()).throw(AssertionError('unexpected pip')))
    assert check.main() == 0


def test_install_preserves_existing_constraints(monkeypatch):
    monkeypatch.setattr(sys, 'argv', ['ensure_build_packages.py'])
    monkeypatch.setattr(check, 'missing_requirements', lambda requirements: ['absent==1'])
    calls = []
    def install(command):
        constraints = Path(command[command.index('--constraint') + 1]).read_text()
        assert 'pip==' in constraints
        assert command[-1] == 'absent==1'
        assert '--upgrade' not in command
        calls.append(command)
        return 1
    monkeypatch.setattr(check.subprocess, 'call', install)
    assert check.main() == 1
    assert len(calls) == 1
