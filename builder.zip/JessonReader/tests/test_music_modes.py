from pathlib import Path
import pytest
from test_reader import reader, app
from test_requested_fixes import fake_vlc


@pytest.fixture
def player(app,tmp_path,monkeypatch):
    native=fake_vlc(monkeypatch)
    widget=reader.ReliableMusicPlayerTab()
    widget._favorite_paths=set(); widget._favorites_file=tmp_path/'favorites.json'
    for index in range(4):
        path=tmp_path/f'song-{index}.mp3'; path.write_bytes(b'test fixture; playback backend mocked')
        item=reader.QListWidgetItem(path.name); item.setData(reader.Qt.UserRole,str(path)); widget.playlistView.addItem(item)
    widget._sync_playlist_from_view(); widget._apply_favorite_marks()
    yield widget,native
    widget.mediaPlayer.release(); widget.close(); widget.deleteLater(); app.processEvents()


def play(widget,index):
    widget.play_selected(widget.playlistView.item(index)); widget.mediaPlayer._poll()


def finish(widget,native):
    native.status='ended'; widget.mediaPlayer._poll(); widget.mediaPlayer._poll()


def favourites(widget,*indexes):
    widget._favorite_paths={widget._path_at(index) for index in indexes}; widget._apply_favorite_marks()


def test_repeat_cycle_and_repeat_one_with_shuffle(player):
    widget,native=player
    assert widget._repeat_mode=='off'
    widget.btnRepeat.click(); assert widget._repeat_mode=='all'
    widget.btnRepeat.click(); assert widget._repeat_mode=='one'
    assert '1' in widget.btnRepeat.text() and 'One song' in widget.btnRepeat.toolTip()
    widget.btnShuffle.click(); play(widget,1)
    for unused in range(3):
        finish(widget,native)
        assert widget.playlist.currentIndex()==1 and widget._play_requested
    widget.btnNext.click(); widget.mediaPlayer._poll()
    assert widget.playlist.currentIndex()!=1
    selected=widget.playlist.currentIndex(); finish(widget,native)
    assert widget.playlist.currentIndex()==selected
    widget.btnRepeat.click(); assert widget._repeat_mode=='off'


def test_favourites_are_actual_playback_scope_for_all_controls(player):
    widget,native=player
    favourites(widget,1,3); play(widget,0)
    widget.favoritesBtn.click(); widget.mediaPlayer._poll()
    assert widget.playlist.currentIndex()==1
    widget.btnNext.click(); widget.mediaPlayer._poll(); assert widget.playlist.currentIndex()==3
    widget.btnPrev.click(); widget.mediaPlayer._poll(); assert widget.playlist.currentIndex()==1
    finish(widget,native); assert widget.playlist.currentIndex()==3
    finish(widget,native); assert not widget._play_requested
    assert widget.playlist.mediaCount()==4


def test_repeat_all_wraps_only_favourites(player):
    widget,native=player
    favourites(widget,1,3); widget.favoritesBtn.click(); widget.btnRepeat.click()
    play(widget,3); finish(widget,native)
    assert widget.playlist.currentIndex()==1
    widget.btnPrev.click(); assert widget.playlist.currentIndex()==3


def test_single_favourite_repeat_one_and_repeat_all(player):
    widget,native=player
    favourites(widget,2); widget.favoritesBtn.click(); play(widget,2)
    widget.btnRepeat.click(); finish(widget,native)
    assert widget.playlist.currentIndex()==2 and widget._play_requested
    widget.btnRepeat.click(); finish(widget,native)
    assert widget.playlist.currentIndex()==2 and widget._play_requested


def test_empty_favourites_stop_and_do_not_resume_hidden_track(player):
    widget,native=player
    play(widget,0); widget.favoritesBtn.click()
    assert not widget._play_requested
    for action in (widget.btnPlay.click,widget.btnNext.click,widget.btnPrev.click): action()
    assert not widget._play_requested and widget.mediaPlayer.state()==reader.QMediaPlayer.StoppedState
    assert 'No favourites' in widget.trackSub.text()


def test_removing_current_favourite_switches_then_stops_if_empty(player):
    widget,native=player
    favourites(widget,1,3); widget.favoritesBtn.click(); play(widget,1)
    widget.favBtn.click(); widget.mediaPlayer._poll()
    assert widget.playlist.currentIndex()==3 and widget._play_requested
    widget.favBtn.click(); assert not widget._play_requested
    assert widget._eligible_indexes()==[]


def test_shuffle_round_has_no_repeats_and_previous_follows_history(player,monkeypatch):
    import random
    monkeypatch.setattr(random,'choice',lambda options:options[-1])
    widget,native=player
    favourites(widget,0,2,3); widget.favoritesBtn.click(); widget.btnShuffle.click(); play(widget,0)
    widget.btnNext.click(); assert widget.playlist.currentIndex()==3
    widget.btnNext.click(); assert widget.playlist.currentIndex()==2
    widget.btnPrev.click(); assert widget.playlist.currentIndex()==3
    widget.btnNext.click(); assert widget.playlist.currentIndex()==2
    finish(widget,native); assert not widget._play_requested
    widget.btnRepeat.click(); widget.btnPlay.click(); widget.btnNext.click()
    assert widget.playlist.currentIndex() in (0,3)


def test_error_never_repeats_or_skips(player):
    widget,native=player
    widget.btnRepeat.click(); widget.btnRepeat.click(); play(widget,0)
    native.status='error'; widget.mediaPlayer._poll()
    assert widget.playlist.currentIndex()==0 and not widget._play_requested
    assert 'Cannot play' in widget.trackSub.text()


def test_search_is_visual_and_favourites_toggle_off_restores_queue(player):
    widget,native=player
    favourites(widget,1,3); widget.favoritesBtn.click(); widget.queueSearch.setText('song-1')
    play(widget,1); finish(widget,native)
    assert widget.playlist.currentIndex()==3
    widget.favoritesBtn.click(); widget.queueSearch.clear(); play(widget,1)
    widget.btnNext.click(); assert widget.playlist.currentIndex()==2


def test_arrow_shortcuts_use_favourite_scope(player):
    widget,native=player
    favourites(widget,0,3); widget.favoritesBtn.click(); play(widget,0)
    shortcut=next(s for s in widget.findChildren(reader.QShortcut) if s.key()==reader.QKeySequence(reader.Qt.Key_Right))
    shortcut.activated.emit(); assert widget.playlist.currentIndex()==3


def test_play_after_exhausted_shuffle_starts_a_fresh_round(player):
    widget,native=player
    widget.btnShuffle.click(); play(widget,0)
    for unused in range(4): finish(widget,native)
    assert not widget._play_requested
    widget.btnPlay.click()
    assert len(widget._shuffle_seen)==1
    widget.btnNext.click(); assert len(widget._shuffle_seen)==2
