import datetime as dt
import json
from pathlib import Path
import sys
from concurrent.futures import ThreadPoolExecutor
import pytest
from test_reader import reader, app
from study_schedule import default_data, write_plan, read_plan, occurrence, occurrence_token, ReminderLedger, collect_reminders
from study_planner import StudyPlannerTab
import study_reminder_agent as agent


def entry(start, repeat='Once', **extra):
    return dict(id='one',subject='Revision',start=start.isoformat(),minutes=25,repeat=repeat,until=None,completed=False,**extra)


def test_daily_weekly_occurrences_and_end_date():
    start=dt.datetime(2026,10,8,10)
    daily=entry(start,'Daily'); weekly=entry(start,'Weekly')
    assert occurrence(daily,start-dt.timedelta(minutes=6),5) is None
    assert occurrence(daily,start-dt.timedelta(minutes=5),5)==start
    assert occurrence(daily,start+dt.timedelta(days=3,hours=2))==start+dt.timedelta(days=3)
    assert occurrence(weekly,start+dt.timedelta(days=8))==start+dt.timedelta(days=7)
    weekly['until']='2026-10-14'
    assert occurrence(weekly,start+dt.timedelta(days=8)) is None


def test_app_and_agent_claim_only_once_and_snooze(tmp_path):
    now=dt.datetime(2026,10,8,10)
    data=default_data(); data['sessions']=[entry(now)]
    ledger_path=tmp_path/'state.sqlite3'
    ledgers=[ReminderLedger(ledger_path),ReminderLedger(ledger_path)]
    with ThreadPoolExecutor(max_workers=2) as pool:
        results=list(pool.map(lambda ledger: collect_reminders(data,ledger,now),ledgers))
    assert sum(len(result) for result in results)==1
    token=occurrence_token(data['sessions'][0],now)
    ledgers[0].snooze(token,now+dt.timedelta(minutes=10))
    assert collect_reminders(data,ledgers[1],now+dt.timedelta(minutes=9))==[]
    assert len(collect_reminders(data,ledgers[1],now+dt.timedelta(minutes=10)))==1
    ledgers[0].complete(token)
    assert collect_reminders(data,ledgers[1],now+dt.timedelta(minutes=11))==[]


def test_repeat_notifies_on_next_occurrence_and_catches_overdue(tmp_path):
    now=dt.datetime(2026,10,8,10)
    data=default_data(); data['sessions']=[entry(now,'Daily')]
    ledger=ReminderLedger(tmp_path/'state.sqlite3')
    assert len(collect_reminders(data,ledger,now+dt.timedelta(hours=4)))==1
    assert len(collect_reminders(data,ledger,now+dt.timedelta(days=1)))==1
    assert collect_reminders(data,ledger,now+dt.timedelta(days=1))==[]


def test_focus_pause_resume_break_and_reload(app,tmp_path):
    time=[0.0]
    path=tmp_path/'plan.json'
    planner=StudyPlannerTab(path,clock=lambda:time[0],now=lambda:dt.datetime(2026,10,8,10))
    alerts=[]; music=[]
    planner.reminder.connect(lambda title,body:alerts.append(title))
    planner.musicPauseRequested.connect(lambda:music.append(True))
    planner.focusMinutes.setValue(1); planner.breakMinutes.setValue(1); planner.pauseMusic.setChecked(True)
    planner.toggle_timer(); time[0]=20; planner.toggle_timer()
    assert planner._remaining==40 and not planner._running
    time[0]=500; planner.toggle_timer(); time[0]=540; planner._tick(); planner._tick()
    assert alerts==['Focus block complete'] and music==[True]
    assert planner.mode=='Break' and not planner._running
    assert len(planner.data['history'])==1
    assert planner.data['history'][0]['seconds']==60
    planner.toggle_timer(); time[0]=555; planner.shutdown()
    restored=StudyPlannerTab(path)
    assert restored.mode=='Break' and restored._remaining==45 and not restored._running
    restored.shutdown(); restored.deleteLater(); planner.deleteLater()


def test_timetable_roundtrip_update_complete(app,tmp_path):
    path=tmp_path/'plan.json'; planner=StudyPlannerTab(path)
    planner.subjectEdit.setText('Hydrology'); planner.repeatBox.setCurrentText('Weekly')
    planner.notesEdit.setText('Read pages 12–20'); planner.add_session()
    assert len(read_plan(path)['sessions'])==1
    planner.sessionTable.selectRow(0); planner.subjectEdit.setText('Hydrology equations'); planner.update_session()
    assert read_plan(path)['sessions'][0]['subject']=='Hydrology equations'
    planner.sessionTable.selectRow(0); planner.start_selected()
    assert planner._running and 'Hydrology equations' in planner.topicEdit.text()
    planner.shutdown(); planner.deleteLater()


def test_corrupt_plan_preserved_before_replacement(app,tmp_path):
    path=tmp_path/'plan.json'; path.write_text('broken json')
    planner=StudyPlannerTab(path); planner.subjectEdit.setText('Safe new entry'); planner.add_session()
    backups=list(tmp_path.glob('plan.json.backup-*'))
    assert len(backups)==1 and backups[0].read_text()=='broken json'
    assert read_plan(path)['sessions'][0]['subject']=='Safe new entry'
    planner.shutdown(); planner.deleteLater()


def test_background_task_xml_current_account_no_three_day_cutoff(tmp_path,monkeypatch):
    import xml.etree.ElementTree as ET
    monkeypatch.setattr(sys,'frozen',True,raising=False)
    monkeypatch.setattr(sys,'executable',r'C:\My Reader\Jesson.exe')
    store=tmp_path/'study plan.json'
    xml=ET.fromstring(agent.task_xml(store,'S-1-5-21-123'))
    ns={'t':'http://schemas.microsoft.com/windows/2004/02/mit/task'}
    assert xml.find('.//t:LogonType',ns).text=='InteractiveToken'
    assert xml.find('.//t:RunLevel',ns).text=='LeastPrivilege'
    assert xml.find('.//t:ExecutionTimeLimit',ns).text=='PT0S'
    assert xml.find('.//t:DisallowStartIfOnBatteries',ns).text=='false'
    assert '--study-reminder-agent' in xml.find('.//t:Arguments',ns).text
    assert 'study plan.json' in xml.find('.//t:Arguments',ns).text


def test_background_enable_disable_flow(app,tmp_path,monkeypatch):
    events=[]
    monkeypatch.setattr(agent,'register_task',lambda path:events.append('register'))
    monkeypatch.setattr(agent,'start_task',lambda path:events.append('start'))
    monkeypatch.setattr(agent,'remove_task',lambda path:events.append('remove'))
    planner=StudyPlannerTab(tmp_path/'plan.json')
    planner.toggle_background()
    assert read_plan(planner.storage_path)['settings']['background_reminders']
    planner.toggle_background()
    assert not read_plan(planner.storage_path)['settings']['background_reminders']
    assert events==['register','start','remove']
    planner.shutdown(); planner.deleteLater()


def test_main_window_study_controls_preserve_reading_state(app,tmp_path,monkeypatch):
    monkeypatch.setattr(reader,'app_data_dir',lambda:str(tmp_path))
    monkeypatch.setattr(reader.RefinedThemesTab,'SETTINGS_FILE',tmp_path/'appearance.json')
    window=reader.MainWindow(); window.show(); app.processEvents()
    try:
        assert window.tabs.count()==11
        window.tabs.setCurrentWidget(window.docTab); app.processEvents()
        assert not window.docTab.wordTabs.isHidden()
        original_text=window.docTab.textEdit.toPlainText()
        window.readingFocusButton.setChecked(True); app.processEvents()
        assert window.tabs.tabBar().isHidden() and window.docTab.wordTabs.isHidden()
        assert not window.studyMusicButton.isHidden()
        window.readingFocusButton.setChecked(False); app.processEvents()
        assert not window.tabs.tabBar().isHidden() and not window.docTab.wordTabs.isHidden()
        assert window.docTab.textEdit.toPlainText()==original_text
        window.studyPlannerTab.focusMinutes.setValue(1)
        window.studyPlannerTab.toggle_timer(); window.tabs.setCurrentWidget(window.pdfViewerTab)
        assert window.studyPlannerTab._running
        assert 'Focus' in window.studyTimerLabel.text()
    finally:
        window.docTab.textEdit.document().setModified(False)
        window.close(); window.deleteLater(); app.processEvents()


def test_background_registration_error_is_visible_and_not_enabled(app,tmp_path,monkeypatch):
    def reject(path): raise RuntimeError('Windows refused the task')
    monkeypatch.setattr(agent,'register_task',reject)
    planner=StudyPlannerTab(tmp_path/'plan.json')
    planner.toggle_background()
    assert not planner.data['settings']['background_reminders']
    assert 'Windows refused' in planner.alertLabel.text()
    planner.shutdown(); planner.deleteLater()


def test_completed_session_does_not_claim_successful_snooze(app,tmp_path):
    planner=StudyPlannerTab(tmp_path/'plan.json',now=lambda:dt.datetime(2026,10,8,10))
    item=entry(dt.datetime(2026,10,8,9)); item['completed']=True
    planner.data['sessions']=[item]; planner._refresh_table(); planner.sessionTable.selectRow(0)
    planner.snooze_selected()
    assert 'available when' in planner.alertLabel.text()
    planner.shutdown(); planner.deleteLater()


def test_lightweight_agent_entry_does_not_start_qt():
    import subprocess
    source=Path(__file__).resolve().parents[1]/'Jesson_Reader.py'
    result=subprocess.run([sys.executable,str(source),'--study-reminder-agent','--help'],capture_output=True,text=True,timeout=10)
    assert result.returncode==0 and '--store' in result.stdout
    assert 'QStandardPaths' not in result.stderr


def test_background_agent_loop_claims_reminder_then_stops_when_disabled(tmp_path,monkeypatch):
    from types import SimpleNamespace
    now=dt.datetime.now().replace(microsecond=0)
    store=tmp_path/'plan.json'; data=default_data(); data['settings']['background_reminders']=True
    data['sessions']=[entry(now)]; write_plan(store,data)
    monkeypatch.setattr(agent,'os',SimpleNamespace(name='nt'))
    monkeypatch.setattr(sys,'argv',['reader','--study-reminder-agent','--store',str(store)])
    closed=[]; messages=[]
    def create_mutex(*args): return 123
    def close_handle(handle): closed.append(handle)
    kernel=SimpleNamespace(CreateMutexW=create_mutex,CloseHandle=close_handle)
    monkeypatch.setattr(agent.ctypes,'WinDLL',lambda *a,**k:kernel,raising=False)
    monkeypatch.setattr(agent.ctypes,'get_last_error',lambda:0,raising=False)
    monkeypatch.setattr(agent.ctypes,'windll',SimpleNamespace(user32=SimpleNamespace(MessageBoxW=lambda *a:messages.append(a))),raising=False)
    def stop_after_poll(seconds):
        data['settings']['background_reminders']=False; write_plan(store,data)
    monkeypatch.setattr(agent.time,'sleep',stop_after_poll)
    assert agent.main()==0
    assert len(messages)==1 and 'Revision' in messages[0][1]
    assert closed==[123]
