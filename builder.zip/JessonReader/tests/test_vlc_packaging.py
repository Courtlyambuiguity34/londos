from pathlib import Path
import importlib.util
import sys
import pytest

spec = importlib.util.spec_from_file_location('windows_builder', Path(__file__).resolve().parents[1] / 'build_app.py')
build = importlib.util.module_from_spec(spec); spec.loader.exec_module(build)


def test_windows_requires_native_runtime(monkeypatch, tmp_path):
    monkeypatch.setattr(build, '__file__', str(tmp_path / 'build_app.py'))
    monkeypatch.setattr(sys, 'platform', 'win32')
    monkeypatch.setattr(sys, 'argv', ['build_app.py', '--onefile', '--name', 'Jesson'])
    monkeypatch.setattr(build, 'find_icon', lambda root: None)
    monkeypatch.setattr(build.subprocess, 'call', lambda *a, **k: pytest.fail('must stop before building'))
    with pytest.raises(SystemExit) as error: build.main()
    assert error.value.code == 2


def test_windows_includes_complete_vlc_runtime(monkeypatch, tmp_path):
    runtime = tmp_path / 'vlc-runtime'; (runtime / 'plugins').mkdir(parents=True)
    for name in ('libvlc.dll', 'libvlccore.dll'): (runtime / name).write_bytes(b'fixture')
    monkeypatch.setattr(build, '__file__', str(tmp_path / 'build_app.py'))
    monkeypatch.setattr(sys, 'platform', 'win32')
    monkeypatch.setattr(sys, 'argv', ['build_app.py', '--onefile', '--name', 'Jesson'])
    monkeypatch.setattr(build, 'find_icon', lambda root: None)
    calls = []
    monkeypatch.setattr(build.subprocess, 'call', lambda command, **kw: calls.append(command) or 0)
    assert build.main() == 0
    command = calls[0]
    assert any(str(runtime) in value and value.endswith('vlc-runtime') for value in command)
    assert command[command.index('--hidden-import') + 1] == 'vlc'
    assert '--onefile' in command
    assert '--noupx' in command
    assert '--collect-submodules' not in command
