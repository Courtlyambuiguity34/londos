import importlib.util
from pathlib import Path
import sys
import pytest

spec = importlib.util.spec_from_file_location("reader_build", Path(__file__).resolve().parents[1] / "build_app.py")
build = importlib.util.module_from_spec(spec)
spec.loader.exec_module(build)


def test_requested_single_file_name(monkeypatch):
    calls = []
    monkeypatch.setattr(sys, "argv", ["build_app.py", "--onefile", "--name", "builder"])
    monkeypatch.setattr(build, "find_icon", lambda folder: None)
    monkeypatch.setattr(build.subprocess, "call", lambda command, **kwargs: calls.append(command) or 7)
    assert build.main() == 7
    assert calls[0][calls[0].index("--name") + 1] == "builder"
    assert "--onefile" in calls[0]
    assert "--windowed" in calls[0]


def test_default_name_preserved(monkeypatch):
    calls = []
    monkeypatch.setattr(sys, "argv", ["build_app.py"])
    monkeypatch.setattr(build, "find_icon", lambda folder: None)
    monkeypatch.setattr(build.subprocess, "call", lambda command, **kwargs: calls.append(command) or 0)
    assert build.main() == 0
    assert calls[0][calls[0].index("--name") + 1] == "JessonReader"
    assert "--onedir" in calls[0]


@pytest.mark.parametrize("name", ["../outside", "", "bad/name", "x" * 61])
def test_invalid_output_name_rejected(monkeypatch, name):
    monkeypatch.setattr(sys, "argv", ["build_app.py", "--name", name])
    monkeypatch.setattr(build.subprocess, "call", lambda *a, **kw: pytest.fail("must not build"))
    with pytest.raises(SystemExit) as error:
        build.main()
    assert error.value.code == 2
