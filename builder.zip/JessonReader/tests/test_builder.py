import importlib.util
from pathlib import Path
import sys
import pytest

spec = importlib.util.spec_from_file_location("reader_build", Path(__file__).resolve().parents[1] / "build_app.py")
build = importlib.util.module_from_spec(spec)
spec.loader.exec_module(build)


def test_requested_single_file_name(monkeypatch):
    calls = []
    monkeypatch.setattr(sys, "argv", ["build_app.py", "--onefile", "--name", "builder"])
    monkeypatch.setattr(build, "find_icon", lambda folder: None)
    monkeypatch.setattr(build.subprocess, "call", lambda command, **kwargs: calls.append(command) or 7)
    assert build.main() == 7
    assert calls[0][calls[0].index("--name") + 1] == "builder"
    assert "--onefile" in calls[0]
    assert "--windowed" in calls[0]


def test_default_name_preserved(monkeypatch):
    calls = []
    monkeypatch.setattr(sys, "argv", ["build_app.py"])
    monkeypatch.setattr(build, "find_icon", lambda folder: None)
    monkeypatch.setattr(build.subprocess, "call", lambda command, **kwargs: calls.append(command) or 0)
    assert build.main() == 0
    assert calls[0][calls[0].index("--name") + 1] == "JessonReader"
    assert "--onedir" in calls[0]


@pytest.mark.parametrize("name", ["../outside", "", "bad/name", "x" * 61])
def test_invalid_output_name_rejected(monkeypatch, name):
    monkeypatch.setattr(sys, "argv", ["build_app.py", "--name", name])
    monkeypatch.setattr(build.subprocess, "call", lambda *a, **kw: pytest.fail("must not build"))
    with pytest.raises(SystemExit) as error:
        build.main()
    assert error.value.code == 2


def test_lossless_distribution_zip(monkeypatch, tmp_path):
    folder = tmp_path / 'reader'; folder.mkdir()
    monkeypatch.setattr(build, '__file__', str(folder / 'build_app.py'))
    monkeypatch.setattr(sys, 'argv', ['build_app.py', '--name', 'Jesson', '--zip'])
    monkeypatch.setattr(build, 'find_icon', lambda root: None)
    def fake_build(command, **kwargs):
        output = folder / 'dist' / 'Jesson' / '_internal'
        output.mkdir(parents=True)
        (output.parent / 'Jesson.exe').write_bytes(b'application')
        (output / 'resource.dat').write_bytes(b'keep all resources')
        return 0
    monkeypatch.setattr(build.subprocess, 'call', fake_build)
    assert build.main() == 0
    with build.zipfile.ZipFile(folder / 'dist' / 'Jesson-portable.zip') as archive:
        assert archive.read('Jesson/Jesson.exe') == b'application'
        assert archive.read('Jesson/_internal/resource.dat') == b'keep all resources'
