from pathlib import Path
import sys
import struct
import pytest
import prepare_vlc
import vlc_runtime_config as config
import vlc_backend


def pe_bytes(machine=0x8664):
    data=bytearray(140); data[:2]=b'MZ'; struct.pack_into('<I',data,0x3c,128)
    data[128:132]=b'PE\x00\x00'; struct.pack_into('<H',data,132,machine)
    return data


def make_runtime(root):
    root.mkdir()
    for name in ('libvlc.dll','libvlccore.dll'): (root/name).write_bytes(pe_bytes())
    for category in ('access','audio_output','codec','demux'):
        folder=root/'plugins'/category; folder.mkdir(parents=True)
        (folder/'sample.dll').write_bytes(pe_bytes())
    return root


@pytest.mark.parametrize('name',['vlc_runtime','vlc-runtime'])
def test_manual_runtime_skips_download_and_is_found_at_runtime(tmp_path,monkeypatch,name):
    runtime=make_runtime(tmp_path/name)
    monkeypatch.setattr(prepare_vlc,'__file__',str(tmp_path/'prepare_vlc.py'))
    monkeypatch.setattr(sys,'argv',['prepare_vlc.py','--offline'])
    monkeypatch.setattr(prepare_vlc.urllib.request,'urlopen',lambda *a,**k:pytest.fail('must not download'))
    assert prepare_vlc.main()==0
    assert config.find_runtime(tmp_path)==runtime
    monkeypatch.setattr(sys,'_MEIPASS',str(tmp_path),raising=False)
    assert vlc_backend.runtime_directory()==runtime


def test_incomplete_or_32bit_runtime_fails_without_download(tmp_path,monkeypatch):
    runtime=make_runtime(tmp_path/'vlc_runtime')
    (runtime/'libvlc.dll').write_bytes(pe_bytes(0x14c))
    monkeypatch.setattr(prepare_vlc,'__file__',str(tmp_path/'prepare_vlc.py'))
    monkeypatch.setattr(sys,'argv',['prepare_vlc.py'])
    monkeypatch.setattr(prepare_vlc.urllib.request,'urlopen',lambda *a,**k:pytest.fail('must not download'))
    assert prepare_vlc.main()==1
    assert (runtime/'libvlc.dll').read_bytes()==pe_bytes(0x14c)
    assert not config.valid_runtime(runtime)


def test_empty_plugins_not_accepted(tmp_path):
    runtime=make_runtime(tmp_path/'vlc_runtime')
    (runtime/'plugins'/'codec'/'sample.dll').unlink()
    assert any('codec' in problem for problem in config.runtime_problems(runtime))


def test_offline_missing_packages_cannot_call_pip(monkeypatch):
    import ensure_build_packages as check
    monkeypatch.setattr(sys,'argv',['ensure_build_packages.py','--offline'])
    monkeypatch.setattr(check,'missing_requirements',lambda requirements:['python-vlc'])
    monkeypatch.setattr(check.subprocess,'call',lambda *a,**k:pytest.fail('offline must not run pip'))
    assert check.main()==1
