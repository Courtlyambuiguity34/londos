import os
import struct
import wave
from types import SimpleNamespace
import pytest
from PyQt5.QtTest import QTest
from test_reader import reader, app
import vlc_backend

pytestmark=pytest.mark.skipif(os.environ.get('JESSON_TEST_NATIVE_VLC')!='1',reason='Requires native libVLC')


def test_actual_vlc_end_repeats_one_then_advances_within_favourites(app,tmp_path,monkeypatch):
    import vlc
    constructor=vlc.Instance
    monkeypatch.setattr(vlc_backend,'load_vlc',lambda:SimpleNamespace(State=vlc.State,Instance=lambda *args:constructor(*args,'--aout=dummy')))
    widget=reader.ReliableMusicPlayerTab(); widget._favorite_paths=set()
    starts=[]
    try:
        for index in range(4):
            path=tmp_path/f'clip-{index}.wav'
            with wave.open(str(path),'wb') as handle:
                handle.setparams((1,2,22050,0,'NONE','not compressed'))
                handle.writeframes(struct.pack('<h',150)*11025)
            item=reader.QListWidgetItem(path.name);item.setData(reader.Qt.UserRole,str(path));widget.playlistView.addItem(item)
            if index in (1,3):widget._favorite_paths.add(widget._norm(str(path)))
        widget._sync_playlist_from_view();widget._apply_favorite_marks();widget.favoritesBtn.click()
        widget.btnRepeat.click();widget.btnRepeat.click()
        widget.mediaPlayer.currentMediaChanged.connect(lambda media:starts.append(media.canonicalUrl().toLocalFile()))
        widget.play_selected(widget.playlistView.item(1))
        for unused in range(50):
            QTest.qWait(100)
            if len(starts)>=2:break
        assert len(starts)>=2 and all(path.endswith('clip-1.wav') for path in starts)
        widget.btnRepeat.click()
        for unused in range(60):
            QTest.qWait(100)
            if not widget._play_requested:break
        assert any(path.endswith('clip-3.wav') for path in starts)
        assert all(path.endswith(('clip-1.wav','clip-3.wav')) for path in starts)
        assert not widget._play_requested
        assert widget.mediaPlayer.error_code==reader.QMediaPlayer.NoError
    finally:
        widget.mediaPlayer.release();widget.close();widget.deleteLater();app.processEvents()
