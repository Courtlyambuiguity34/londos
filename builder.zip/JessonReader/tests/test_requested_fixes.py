from pathlib import Path
from types import SimpleNamespace
import pytest
from test_reader import reader, app, writer, no_modal_notifications
from PyQt5.QtTest import QTest
import vlc_backend
import prepare_vlc


def test_imported_docx_font_selection_and_sync(writer, tmp_path, app):
    path = tmp_path / 'font.docx'
    doc = reader.Document(); doc.add_paragraph('Revision notes'); doc.save(path)
    assert writer._load_path(str(path))
    writer.textEdit.selectAll()
    writer.fontCombo.setCurrentFont(reader.QFont('DejaVu Sans Mono'))
    assert writer.textEdit.textCursor().charFormat().fontFamily() == 'DejaVu Sans Mono'
    html = writer.textEdit.toHtml()
    writer.sync_format_controls(writer.textEdit.currentCharFormat())
    assert writer.textEdit.toHtml() == html
    assert writer.textEdit.hasFocus()
    writer.textEdit.undo()
    assert 'Revision notes' in writer.textEdit.toPlainText()


def test_table_replacement_reads_single_digit_and_recalculates(writer, tmp_path, monkeypatch):
    path = tmp_path / 'numbers.docx'
    doc = reader.Document(); table = doc.add_table(rows=4, cols=1)
    for cell, text in zip(table.column_cells(0), ['Values', '1', '2', 'old result']): cell.text = text
    doc.save(path); assert writer._load_path(str(path))
    cursor = writer.textEdit.document().find('1'); writer.textEdit.setTextCursor(cursor)
    table = cursor.currentTable()
    assert writer._cell_text(table.cellAt(1, 0)) == '1'
    assert writer._cell_text(table.cellAt(2, 0)) == '2'
    target = table.cellAt(3, 0)
    writer.textEdit.setTextCursor(target.firstCursorPosition())
    writer.formulaEntry.setText('=A2+A3'); writer.apply_formula_bar()
    assert writer._cell_text(target) == '3'
    monkeypatch.setattr(reader.QMessageBox, 'information', lambda *a: reader.QMessageBox.Ok)
    for unused in range(5):
        writer.recalculate_current_table()
        assert writer._cell_text(target) == '3'
    writer._set_cell_text(table.cellAt(1, 0), '10')
    writer.recalculate_current_table()
    assert writer._cell_text(target) == '12'
    writer.textEdit.undo()
    assert writer._cell_text(target) == '3'


def pdf_widget(app):
    widget = reader.PolishedPDFViewerTab()
    widget.resize(1000, 700); widget.show()
    widget.pdf_doc = reader.fitz.open()
    widget.pdf_doc.new_page(width=400, height=550)
    widget.current_page = 0; widget.render(); app.processEvents()
    return widget


def test_pdf_existing_notes_click_edit_and_persist(app, tmp_path, monkeypatch):
    widget = pdf_widget(app)
    try:
        page = widget.pdf_doc[0]
        note = page.add_text_annot(reader.fitz.Point(40, 70), 'Existing revision note')
        widget.render(); app.processEvents()
        assert len(widget._note_cards) == 1
        assert 'Existing revision note' in widget._note_cards[0].text()
        def edit(dialog):
            dialog.findChild(reader.QTextEdit).setPlainText('Edited sticky note')
            return reader.QDialog.Accepted
        monkeypatch.setattr(reader.QDialog, 'exec_', edit)
        widget._note_cards[0].click()
        assert 'Edited sticky note' in widget._note_cards[0].text()
        path = tmp_path / 'annotated.pdf'; widget.pdf_doc.save(path)
        with reader.fitz.open(path) as reopened:
            saved_page = reopened[0]
            assert next(saved_page.annots()).info['content'] == 'Edited sticky note'
        monkeypatch.setattr(reader.QDialog, 'exec_', lambda self: 2)
        widget._note_cards[0].click()
        assert not widget._note_cards
    finally:
        widget.pdf_doc.close(); widget.pdf_doc = None
        widget.close(); widget.deleteLater(); app.processEvents()


def test_pdf_click_placement_and_rotated_mapping(app, monkeypatch):
    widget = pdf_widget(app)
    try:
        widget.pdf_doc[0].set_rotation(90); widget.render(); app.processEvents()
        left, top, width, height = widget._image_bounds()
        point = reader.QPoint(int(left + width/2), int(top + height/2))
        mapped = widget._page_point(point)
        assert mapped.x == pytest.approx(200, abs=2)
        assert mapped.y == pytest.approx(275, abs=2)
        def edit(dialog):
            dialog.findChild(reader.QTextEdit).setPlainText('Placed on this page')
            return reader.QDialog.Accepted
        monkeypatch.setattr(reader.QDialog, 'exec_', edit)
        widget.add_note()
        QTest.mouseClick(widget.pageLabel, reader.Qt.LeftButton, pos=point)
        assert not widget._place_note
        assert len(widget._note_cards) == 1
        assert 'Placed on this page' in widget._note_cards[0].text()
        widget.set_zoom(1.5); app.processEvents()
        assert len(widget._note_cards) == 1
    finally:
        widget.pdf_doc.close(); widget.pdf_doc = None
        widget.close(); widget.deleteLater(); app.processEvents()


class NativePlayer:
    def __init__(self): self.status = 'playing'; self.time = 450; self.length = 3000
    def set_media(self, media): pass
    def play(self): self.status = 'playing'; return 0
    def stop(self): self.status = 'stopped'
    def set_pause(self, flag): self.status = 'paused'
    def audio_set_volume(self, volume): self.volume = volume
    def set_time(self, time): self.time = time
    def get_state(self): return self.status
    def get_length(self): return self.length
    def get_time(self): return self.time
    def release(self): self.released = True


def fake_vlc(monkeypatch):
    player = NativePlayer()
    instance = SimpleNamespace(media_player_new=lambda: player,
        media_new_path=lambda path: SimpleNamespace(release=lambda: None), release=lambda: None)
    module = SimpleNamespace(Instance=lambda *args: instance,
        State=SimpleNamespace(Playing='playing', Paused='paused', Error='error', Ended='ended'))
    monkeypatch.setattr(vlc_backend, 'load_vlc', lambda: module)
    return player


def test_vlc_controls_and_end_only_once(app, monkeypatch, tmp_path):
    native = fake_vlc(monkeypatch)
    player = vlc_backend.VLCMediaPlayer()
    statuses = []; errors = []
    player.mediaStatusChanged.connect(statuses.append); player.error.connect(errors.append)
    try:
        player.setMedia(reader.QMediaContent(reader.QUrl.fromLocalFile(str(tmp_path / 'song.mp3'))))
        player.setVolume(66); assert native.volume == 66
        player.play(); player._poll()
        assert player.state() == reader.QMediaPlayer.PlayingState
        assert player.duration() == 3000 and player.position() == 450
        player.pause(); assert player.state() == reader.QMediaPlayer.PausedState
        player.setPosition(700); assert native.time == 700
        player.play(); native.status = 'ended'; player._poll(); player._poll()
        assert statuses == [reader.QMediaPlayer.EndOfMedia]
        assert not errors
    finally: player.release()
    assert native.released


def test_vlc_error_does_not_skip_queue(app, monkeypatch, tmp_path):
    native = fake_vlc(monkeypatch)
    widget = reader.ReliableMusicPlayerTab()
    try:
        for name in ('first.mp3', 'second.flac'):
            path = tmp_path / name; path.write_bytes(b'fake media')
            item = reader.QListWidgetItem(name); item.setData(reader.Qt.UserRole, str(path))
            widget.playlistView.addItem(item)
        widget._sync_playlist_from_view()
        widget.play_selected(widget.playlistView.item(0))
        native.status = 'error'; widget.mediaPlayer._poll()
        assert widget.playlist.currentIndex() == 0
        assert not widget._play_requested
        widget.play_selected(widget.playlistView.item(1)); widget.mediaPlayer._poll()
        assert widget.playlist.currentIndex() == 1
        assert widget.mediaPlayer.state() == reader.QMediaPlayer.PlayingState
    finally:
        widget.mediaPlayer.release(); widget.close(); widget.deleteLater()


def test_vlc_checksum_rejection(tmp_path):
    archive = tmp_path / 'bad.zip'; archive.write_bytes(b'not official')
    with pytest.raises(ValueError, match='checksum'):
        prepare_vlc.extract_verified(archive, tmp_path / 'unpacked')
    assert not (tmp_path / 'unpacked').exists()


def test_unknown_user_icon_included():
    root = Path(__file__).resolve().parents[1]
    import build_app
    assert build_app.find_icon(root).name == 'neon_orbital_ai_icon_ecosystem.ico'


def test_overlapping_pdf_notes_remain_accessible(app, monkeypatch):
    widget = pdf_widget(app)
    try:
        page = widget.pdf_doc[0]
        page.add_text_annot(reader.fitz.Point(54, 72), 'First note')
        page.add_text_annot(reader.fitz.Point(54, 72), 'Second note')
        widget.render(); app.processEvents()
        assert widget.noteList.count() == 2
        opened = []
        monkeypatch.setattr(widget, '_edit_note', lambda xref: opened.append(xref))
        for index in range(2): widget.noteList.itemClicked.emit(widget.noteList.item(index))
        assert len(set(opened)) == 2
    finally:
        widget.pdf_doc.close(); widget.pdf_doc = None
        widget.close(); widget.deleteLater(); app.processEvents()
