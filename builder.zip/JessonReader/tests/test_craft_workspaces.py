"""Focused checks for Jesson's independent PdfCraft/WordCraft-inspired UX."""

from pathlib import Path

from docx import Document
from docx.enum.section import WD_ORIENT
from docx.shared import Inches, Pt
from PyQt5.QtCore import Qt
from PyQt5.QtTest import QTest

from test_reader import app, no_modal_notifications, reader, writer


def test_docx_import_preserves_block_order_format_and_page_furniture(writer, tmp_path):
    path = tmp_path / "ordered.docx"
    source = Document()
    source.core_properties.title = "Ordered revision"
    before = source.add_paragraph()
    run = before.add_run("Before table")
    run.bold = True
    run.font.name = "DejaVu Sans Mono"
    run.font.size = Pt(15)
    table = source.add_table(rows=2, cols=2)
    table.cell(0, 0).text = "Topic"
    table.cell(1, 0).text = "Hydrology"
    source.add_paragraph("After table")
    section = source.sections[0]
    section.orientation = WD_ORIENT.LANDSCAPE
    section.page_width, section.page_height = section.page_height, section.page_width
    section.left_margin = Inches(0.7)
    section.header.paragraphs[0].text = "Revision header"
    section.footer.paragraphs[0].text = "Revision footer"
    source.save(path)

    assert writer._load_path(str(path))
    plain = writer.textEdit.toPlainText()
    assert plain.index("Before table") < plain.index("Topic") < plain.index("After table")
    found = writer.textEdit.document().find("Before table")
    assert found.charFormat().fontWeight() >= reader.QFont.Bold
    assert found.charFormat().fontPointSize() == 15
    assert found.charFormat().fontFamily() == "DejaVu Sans Mono"
    assert writer._orient == "Landscape"
    assert writer.header_text == "Revision header"
    assert writer.footer_text == "Revision footer"
    assert writer.doc_title == "Ordered revision"
    assert not writer.textEdit.document().isModified()


def test_document_command_search_exposes_existing_tools(writer):
    assert len(writer.documentCommands) >= 20
    assert writer.commandSearchButton.isVisible()
    assert "Alt+Q" in writer.commandSearchButton.text()
    writer._command_palette.refresh("comment")
    labels = [writer._command_palette.results.item(i).text() for i in range(writer._command_palette.results.count())]
    assert labels == ["Add comment\nCtrl+Alt+M", "Toggle comments"]
    writer._command_palette.refresh("recover autosave")
    assert writer._command_palette.results.count() == 1
    assert writer._command_palette.results.item(0).text() == "Recover autosave"


def make_pdf(path):
    document = reader.fitz.open()
    for number, text in enumerate(("Water cycle exam", "Energy revision", "Water resources"), start=1):
        page = document.new_page(width=420, height=560)
        page.insert_text((55, 75), f"Page {number}: {text}")
    document.save(path)
    document.close()


def pdf_workspace(app, path):
    widget = reader.PolishedPDFViewerTab()
    widget.resize(1100, 760)
    widget.show()
    assert widget.load_pdf_path(path)
    QTest.qWait(30)
    app.processEvents()
    return widget


def close_pdf(widget, app):
    widget._thumbnail_timer.stop()
    if widget.pdf_doc is not None:
        widget.pdf_doc.close()
        widget.pdf_doc = None
    widget.close()
    widget.deleteLater()
    app.processEvents()


def test_pdf_workspace_thumbnails_search_read_mode_and_copy(app, tmp_path):
    path = tmp_path / "study.pdf"
    make_pdf(path)
    widget = pdf_workspace(app, path)
    try:
        assert widget.thumbnailList.count() == 3
        assert [widget._craft_sidebar.tabText(i) for i in range(widget._craft_sidebar.count())] == [
            "Pages", "Outline", "Page notes", "Search"
        ]
        assert all(not widget.thumbnailList.item(i).icon().isNull() for i in range(3))
        widget.search.setText("Water")
        widget.search_document()
        app.processEvents()
        assert widget.searchResults.count() == 2
        assert widget._craft_sidebar.tabBar().tabRect(0).x() >= 0
        assert widget.current_page == 0
        assert widget._search_overlays
        widget.next_search_result()
        assert widget.current_page == 2
        widget.copy_page_text()
        assert "Water resources" in reader.QApplication.clipboard().text()
        widget.set_read_mode(True)
        assert not widget._craft_sidebar.isVisible()
        assert not widget.status.isVisible()
        widget.set_read_mode(False)
        assert widget._craft_sidebar.isVisible()
    finally:
        close_pdf(widget, app)


def test_pdf_atomic_in_place_save_and_reopen(app, tmp_path):
    path = tmp_path / "editable.pdf"
    make_pdf(path)
    widget = pdf_workspace(app, path)
    try:
        widget.rotate(90)
        assert widget._pdf_dirty
        assert widget._save_pdf_to(path)
        assert not widget._pdf_dirty
        assert widget.pdf_doc is not None
        assert widget.pdf_doc[0].rotation == 90
        with reader.fitz.open(path) as reopened:
            assert len(reopened) == 3
            assert reopened[0].rotation == 90
    finally:
        close_pdf(widget, app)


def test_bad_pdf_does_not_replace_current_document(app, tmp_path, monkeypatch):
    good = tmp_path / "good.pdf"
    bad = tmp_path / "bad.pdf"
    make_pdf(good)
    bad.write_bytes(b"not a pdf")
    widget = pdf_workspace(app, good)
    try:
        monkeypatch.setattr(reader.QMessageBox, "warning", lambda *args, **kwargs: reader.QMessageBox.Ok)
        assert not widget.load_pdf_path(bad)
        assert Path(widget.path) == good
        assert widget.pdf_doc is not None
        assert len(widget.pdf_doc) == 3
    finally:
        close_pdf(widget, app)
