"""Convert an image supplied locally by the owner to a multi-resolution ICO."""
import argparse
from pathlib import Path
from PIL import Image, ImageOps


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('image', help='Path to your supplied PNG/JPEG icon artwork')
    parser.add_argument('--output', default='jesson_app.ico')
    args = parser.parse_args()
    target = Path(args.output)
    if target.exists():
        parser.error('Output already exists; choose another filename to preserve it.')
    with Image.open(args.image) as original:
        artwork = ImageOps.contain(original.convert('RGBA'), (256, 256), Image.Resampling.LANCZOS)
        canvas = Image.new('RGBA', (256, 256), (0, 0, 0, 0))
        canvas.alpha_composite(artwork, ((256 - artwork.width) // 2, (256 - artwork.height) // 2))
        canvas.save(target, format='ICO', sizes=[(n, n) for n in (16, 24, 32, 48, 64, 128, 256)])
    print(f'Created {target.name}; keep it beside Jesson_Reader.py before packaging.')


if __name__ == '__main__':
    main()
