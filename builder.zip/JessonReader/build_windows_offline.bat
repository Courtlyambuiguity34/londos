@echo off
call "%~dp0build_windows.bat" --offline
exit /b %errorlevel%
