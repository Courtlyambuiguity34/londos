"""Install absent build distributions without replacing installed packages."""
from importlib import metadata
import argparse
from pathlib import Path
import re
import subprocess
import sys
import tempfile


def read_requirements(path):
    items = []
    for line in path.read_text().splitlines():
        line = line.strip()
        if not line or line.startswith('#'):
            continue
        if line.startswith('-r '):
            items.extend(read_requirements(path.parent / line[3:].strip()))
        else:
            items.append(line)
    return items


def missing_requirements(requirements):
    missing = []
    for requirement in requirements:
        name = re.match(r'[A-Za-z0-9_.-]+', requirement).group()
        try:
            version = metadata.version(name)
            print(f'Installed: {name} {version} (retained; requested {requirement})')
        except metadata.PackageNotFoundError:
            print(f'Missing: {name}')
            missing.append(requirement)
    return missing


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--offline', action='store_true', help='Only check packages; never install or download.')
    args = parser.parse_args()
    root = Path(__file__).resolve().parent
    missing = missing_requirements(read_requirements(root / 'requirements-build.txt'))
    if not missing:
        print('All requested distributions are present. No downloads needed.')
        return 0
    if args.offline:
        print('Offline mode: missing packages must be installed manually before building.')
        return 1
    # Pip may need absent dependencies too. Constrain every existing distribution
    # so it cannot silently upgrade or downgrade this shared Python environment.
    with tempfile.TemporaryDirectory(prefix='jesson-build-') as directory:
        constraints = Path(directory) / 'installed.txt'
        rows = []
        for distribution in metadata.distributions():
            name = distribution.metadata.get('Name')
            if name and re.fullmatch(r'[A-Za-z0-9_.-]+', name):
                rows.append(f'{name}=={distribution.version}')
        constraints.write_text('\n'.join(sorted(set(rows))) + '\n')
        result = subprocess.call([sys.executable, '-m', 'pip', 'install',
                                  '--constraint', str(constraints), *missing])
    if result:
        print('Installation failed. Existing packages were constrained to their current versions; resolve reported compatibility conflicts manually.')
    return result


if __name__ == '__main__':
    raise SystemExit(main())
