"""Local timetable persistence and deduplicated reminders shared with the agent."""
import datetime as dt
import json
import math
from pathlib import Path
import os
import sqlite3
import tempfile
from contextlib import contextmanager

DEFAULT_SETTINGS = {'focus_minutes': 25, 'break_minutes': 5, 'goal_minutes': 90,
                    'reminder_minutes': 5, 'pause_music': False, 'sound': False,
                    'background_reminders': False}


def default_data():
    return {'version': 1, 'settings': dict(DEFAULT_SETTINGS), 'sessions': [], 'history': [], 'timer': {}}


def read_plan(path):
    path = Path(path)
    if not path.exists(): return default_data()
    if path.stat().st_size > 5_000_000: raise ValueError('Study plan is too large')
    data = json.loads(path.read_text(encoding='utf-8'))
    if not isinstance(data, dict) or data.get('version') != 1: raise ValueError('Unsupported study plan format')
    if not isinstance(data.get('settings'), dict) or not isinstance(data.get('sessions'), list):
        raise ValueError('Invalid study plan')
    settings = dict(DEFAULT_SETTINGS); settings.update(data['settings'])
    for key, low, high in (('focus_minutes', 1, 240), ('break_minutes', 1, 60),
                           ('goal_minutes', 1, 1440), ('reminder_minutes', 0, 60)):
        settings[key] = max(low, min(high, int(settings[key])))
    for key in ('pause_music', 'sound', 'background_reminders'):
        settings[key] = settings[key] is True
    data['settings'] = settings
    seen_ids = set()
    for session in data['sessions']:
        if not isinstance(session, dict): raise ValueError('Invalid timetable entry')
        if not isinstance(session.get('id'), str) or not session['id']: raise ValueError('Entry ID missing')
        if not isinstance(session.get('subject'), str) or not session['subject'].strip(): raise ValueError('Subject missing')
        if session['id'] in seen_ids: raise ValueError('Duplicate entry ID')
        seen_ids.add(session['id'])
        session['minutes'] = int(session['minutes'])
        session['notes'] = str(session.get('notes', ''))[:500]
        session['completed'] = session.get('completed') is True
        session.setdefault('repeat', 'Once')
        start = dt.datetime.fromisoformat(session['start'])
        if start.tzinfo is not None: raise ValueError('Timetable uses local PC wall-clock times')
        if not 1 <= int(session['minutes']) <= 240: raise ValueError('Invalid session length')
        if session.get('repeat', 'Once') not in ('Once', 'Daily', 'Weekly'): raise ValueError('Invalid repetition')
        if session.get('until') and dt.date.fromisoformat(session['until']) < start.date():
            raise ValueError('Repeat end precedes session start')
    data.setdefault('history', [])
    data.setdefault('timer', {})
    if not isinstance(data['history'], list) or not isinstance(data['timer'], dict):
        raise ValueError('Invalid focus history')
    cleaned = []
    for row in data['history']:
        if not isinstance(row, dict): continue
        try:
            dt.datetime.fromisoformat(row['ended'])
            seconds = float(row['seconds'])
            if not math.isfinite(seconds) or not 0 <= seconds <= 14400: continue
        except (KeyError, ValueError, TypeError): continue
        cleaned.append({'ended':row['ended'],'seconds':seconds,'topic':str(row.get('topic',''))[:200]})
    data['history'] = cleaned[-2000:]
    return data


def write_plan(path, data):
    path = Path(path); path.parent.mkdir(parents=True, exist_ok=True)
    fd, temporary = tempfile.mkstemp(prefix='study-', suffix='.json', dir=path.parent)
    try:
        with os.fdopen(fd, 'w', encoding='utf-8') as stream:
            json.dump(data, stream, indent=2, ensure_ascii=False)
        os.replace(temporary, path)
    finally:
        if os.path.exists(temporary): os.unlink(temporary)


def occurrence(session, now, advance_minutes=0):
    if session.get('completed'): return None
    start = dt.datetime.fromisoformat(session['start'])
    horizon = now + dt.timedelta(minutes=advance_minutes)
    if start > horizon: return None
    repeat = session.get('repeat', 'Once')
    if repeat != 'Once':
        days = 1 if repeat == 'Daily' else 7
        count = (horizon - start) // dt.timedelta(days=days)
        start += dt.timedelta(days=days * count)
    if session.get('until') and start.date() > dt.date.fromisoformat(session['until']): return None
    return start


def occurrence_token(session, start):
    return session['id'] + '|' + start.isoformat(timespec='seconds')


class ReminderLedger:
    def __init__(self, path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with self.connect() as db:
            db.execute('CREATE TABLE IF NOT EXISTS reminders (token TEXT PRIMARY KEY, fired TEXT, snooze TEXT, done INTEGER NOT NULL DEFAULT 0)')

    @contextmanager
    def connect(self):
        connection = sqlite3.connect(self.path, timeout=3)
        try:
            with connection:
                yield connection
        finally:
            connection.close()

    def claim(self, token, now):
        # The foreground app and closed-app agent compete atomically; only one alerts.
        with self.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            row = db.execute('SELECT fired,snooze,done FROM reminders WHERE token=?', (token,)).fetchone()
            if row:
                fired, snooze, done = row
                if done or (not snooze and fired) or (snooze and dt.datetime.fromisoformat(snooze) > now):
                    return False
                db.execute('UPDATE reminders SET fired=?,snooze=NULL WHERE token=?', (now.isoformat(), token))
            else:
                db.execute('INSERT INTO reminders(token,fired) VALUES(?,?)', (token, now.isoformat()))
            return True

    def snooze(self, token, until):
        with self.connect() as db:
            db.execute('INSERT INTO reminders(token,snooze) VALUES(?,?) ON CONFLICT(token) DO UPDATE SET snooze=excluded.snooze,done=0', (token, until.isoformat()))

    def complete(self, token):
        with self.connect() as db:
            db.execute('INSERT INTO reminders(token,done) VALUES(?,1) ON CONFLICT(token) DO UPDATE SET done=1,snooze=NULL', (token,))

    def is_done(self, token):
        with self.connect() as db:
            row = db.execute('SELECT done FROM reminders WHERE token=?', (token,)).fetchone()
            return bool(row and row[0])


def collect_reminders(data, ledger, now):
    reminders = []
    lead = data['settings'].get('reminder_minutes', 5)
    for session in data['sessions']:
        start = occurrence(session, now, lead)
        if start is None: continue
        token = occurrence_token(session, start)
        if ledger.claim(token, now): reminders.append((session, start))
    return reminders
