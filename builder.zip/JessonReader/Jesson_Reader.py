import sys
import math
import os
import threading
import time
import datetime
import json
import re
import urllib.parse
from pathlib import Path

# External libs used optionally for recording
try:
    import imageio
    import numpy as np
    IMAGEIO_AVAILABLE = True
except Exception:
    IMAGEIO_AVAILABLE = False

import pymupdf as fitz # PyMuPDF for PDF support
import sympy as sp
from PyQt5.QtWidgets import (QApplication, QMainWindow, QTabWidget, QWidget,
                             QVBoxLayout, QHBoxLayout, QPushButton, QTextEdit, QListWidget,
                             QFileDialog, QLineEdit, QComboBox, QSlider, QProgressBar,
                             QTableWidget, QTableWidgetItem, QListWidgetItem, QGridLayout,
                             QHeaderView, QMessageBox, QLabel, QCheckBox, QScrollArea,
                             QToolBar, QAction, QColorDialog, QFontComboBox, QSpinBox,
                             QMenuBar, QMenu, QDoubleSpinBox, QAbstractSpinBox,
                             QGraphicsView, QGraphicsScene, QGraphicsPathItem, QGraphicsTextItem, QGraphicsRectItem, QStyleOptionGraphicsItem,
                             QSplitter, QTextBrowser, QToolButton, QInputDialog, QDialog,
                             QFormLayout, QDialogButtonBox, QShortcut, QStatusBar, QPlainTextEdit, QTreeWidget, QTreeWidgetItem, QSizePolicy, QCompleter)
from PyQt5.QtMultimedia import QMediaPlayer, QMediaPlaylist, QMediaContent
from PyQt5.QtCore import Qt, QUrl, QFileInfo, QTimer, QSize, QSizeF, QPoint, QPointF, QRectF, QEvent, QThread, pyqtSignal
from PyQt5.QtGui import (QPixmap, QImage, QPalette, QColor, QBrush, QIcon, QPainter, QPen, QPainterPath, QFont, QKeySequence, QTextCursor, QTextCharFormat, QTextBlockFormat, QTextListFormat, QTextFormat, QTextTableFormat, QTextLength, QTextFrameFormat)
from PyQt5.QtTextToSpeech import QTextToSpeech
from PyQt5.QtWebEngineWidgets import QWebEngineView, QWebEngineSettings, QWebEngineProfile, QWebEnginePage

from docx import Document
from PyQt5.QtPrintSupport import QPrinter, QPrintDialog, QPrintPreviewDialog
from PyQt5.QtSvg import QSvgGenerator
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.shared import Pt, RGBColor
from docx.shared import Inches
from PIL import Image  # For image handling if needed
import io
import ast
import statistics


def safe_eval(expression):
    try:
        allowed_names = {
            "math": math,
            "sqrt": math.sqrt,
            "log": math.log,
            "sin": math.sin,
            "cos": math.cos,
            "tan": math.tan,
            "exp": math.exp,
            "pi": math.pi,
            "e": math.e,
            "radians": math.radians,
            "asin": math.asin,
            "acos": math.acos,
            "atan": math.atan,
            "log10": math.log10,
        }
        return eval(expression, {"__builtins__": {}}, allowed_names)
    except Exception:
        return None
def qimage_to_numpy(qimage: QImage):
    # Convert QImage to format RGB888 and then to numpy array shape (h, w, 3)
    img = qimage.convertToFormat(QImage.Format_RGBA8888)
    width = img.width()
    height = img.height()
    ptr = img.bits()
    ptr.setsize(img.byteCount())
    arr = np.frombuffer(ptr, np.uint8).reshape((height, width, 4))
    # drop alpha or convert as needed — convert RGBA to RGB
    rgb = arr[..., :3]
    return rgb

def format_time(seconds):
    m = seconds // 60
    s = seconds % 60
    return f"{m:02d}:{s:02d}"


def app_data_dir():
    """Return a writable per-user folder for persistent app/browser data."""
    base = os.getenv("LOCALAPPDATA") or os.getenv("APPDATA") or os.path.expanduser("~")
    path = os.path.join(base, "JessonAssistant")
    os.makedirs(path, exist_ok=True)
    return path


def setup_web_engine_page(browser, profile_name="DefaultProfile", parent=None):
    """Attach a persistent WebEngine profile and permission-aware page to a browser."""
    safe_name = re.sub(r'[^A-Za-z0-9_.-]+', '_', profile_name) or "DefaultProfile"
    storage = os.path.join(app_data_dir(), "browser_profiles", safe_name)
    cache = os.path.join(storage, "cache")
    os.makedirs(cache, exist_ok=True)
    profile = QWebEngineProfile(safe_name, browser)
    profile.setPersistentStoragePath(storage)
    profile.setCachePath(cache)
    profile.setPersistentCookiesPolicy(QWebEngineProfile.ForcePersistentCookies)
    settings = profile.settings()
    for attr_name in ("JavascriptEnabled", "PluginsEnabled", "LocalStorageEnabled", "PdfViewerEnabled", "ScreenCaptureEnabled"):
        attr = getattr(QWebEngineSettings, attr_name, None)
        if attr is not None:
            settings.setAttribute(attr, True)
    page = QWebEnginePage(profile, browser)

    def ask_permission(origin, feature):
        host = origin.host() or origin.toString()
        answer = QMessageBox.question(
            parent or browser,
            "Website permission",
            f"Allow {host} to use the requested browser feature?",
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.No,
        )
        policy = (QWebEnginePage.PermissionGrantedByUser
                  if answer == QMessageBox.Yes else QWebEnginePage.PermissionDeniedByUser)
        page.setFeaturePermission(origin, feature, policy)

    page.featurePermissionRequested.connect(ask_permission)
    browser.setPage(page)
    return profile, page


class GeminiWorker(QThread):
    """Runs one Gemini request off the UI thread.

    Uses the current `google-genai` SDK (falls back to the deprecated
    `google-generativeai` if that is all that is installed) and a list of
    currently supported model IDs. Override the model with the GEMINI_MODEL
    environment variable if Google retires one again.
    """
    finished = pyqtSignal(str)
    error = pyqtSignal(str)
    # Newest first. gemini-2.0-flash (shut down 1 Jun 2026) and gemini-1.5-flash (retired 2025) are gone.
    MODELS = ("gemini-3.7-flash", "gemini-3.6-flash", "gemini-3.5-flash", "gemini-3.1-flash-lite", "gemini-2.5-flash")
    MAX_CONTEXT_CHARS = 1500000

    def __init__(self, api_keys, prompt, context_text="", history=None):
        super().__init__()
        self.api_keys = api_keys
        self.prompt = prompt
        self.context_text = context_text
        self.history = list(history or [])     # [("user", text), ("model", text), ...]

    def _system_text(self):
        base = ("You are a careful study assistant. When Context Material is provided, base your answers on it, "
                "say so if the material does not contain the answer, and never invent facts. Use clear headings and short bullet points.")
        ctx = (self.context_text or "").strip()
        if not ctx:
            return base
        note = ""
        if len(ctx) > self.MAX_CONTEXT_CHARS:
            ctx = ctx[:self.MAX_CONTEXT_CHARS]; note = "\n[The material was truncated because it is very long.]"
        return base + "\n\nContext Material:\n" + ctx + note

    def _call_new(self, genai, types, key, model_name):
        try:
            http = types.HttpOptions(timeout=45000)
        except Exception:
            http = None
        client = genai.Client(api_key=key, http_options=http) if http else genai.Client(api_key=key)
        self._client = client
        contents = [types.Content(role=r, parts=[types.Part(text=t)]) for r, t in self.history]
        contents.append(types.Content(role="user", parts=[types.Part(text=self.prompt)]))
        resp = client.models.generate_content(
            model=model_name, contents=contents,
            config=types.GenerateContentConfig(system_instruction=self._system_text()))
        return getattr(resp, "text", "") or ""

    def _call_old(self, legacy, key, model_name):
        legacy.configure(api_key=key)
        model = legacy.GenerativeModel(model_name, system_instruction=self._system_text())
        chat = model.start_chat(history=[{"role": r, "parts": [t]} for r, t in self.history])
        return getattr(chat.send_message(self.prompt), "text", "") or ""

    def run(self):
        if not self.api_keys:
            self.error.emit("No Gemini API key is configured."); return
        try:
            from google import genai
            from google.genai import types
        except ImportError:
            self.error.emit("Install google-genai to enable Gemini."); return
        model = (os.environ.get("GEMINI_MODEL") or os.environ.get("LONDOS_AI_GEMINI_MODEL") or "gemini-2.5-flash").strip()
        try:
            slot = int(os.environ.get("GEMINI_KEY_SLOT", "1")) - 1
            if not 0 <= slot < len(self.api_keys):
                raise ValueError()
        except ValueError:
            self.error.emit("GEMINI_KEY_SLOT must select an available key, starting at 1."); return
        self._client = None
        try:
            text = self._call_new(genai, types, self.api_keys[slot], model)
            if text:
                self.finished.emit(text)
            else:
                self.error.emit("Gemini returned no text. Try a different study prompt.")
        except Exception as exc:
            code = getattr(exc, "code", None)
            message = {400: "Gemini rejected the request or model configuration.",
                       401: "Gemini authentication failed. Check your selected key.",
                       403: "Gemini denied access. Check key restrictions and permissions.",
                       404: "This Gemini model is unavailable. Set GEMINI_MODEL to a supported model.",
                       429: "Gemini rate limit or quota reached. Wait or review your account quota."}.get(code,
                           "Gemini could not complete the request. Check network access and model settings.")
            self.error.emit(message)
        finally:
            if self._client is not None:
                try:
                    self._client.close()
                except Exception:
                    pass


class AIStudyAssistantTab(QWidget):
    """V3 study assistant rebuilt to match the improved application's visual language."""

    _STYLE = """
        AIStudyAssistantTab { background:#f6f7fb; }
        #aiTop { background:#ffffff; border-bottom:1px solid #e5e7eb; }
        #aiCard { background:#ffffff; border:1px solid #e5e7eb; border-radius:12px; }
        #aiTitle { color:#111827; font-size:18px; font-weight:bold; }
        #aiSub { color:#6b7280; font-size:12px; }
        #aiChat { background:#ffffff; border:1px solid #e5e7eb; border-radius:10px; padding:8px; }
        #aiPrompt { background:#ffffff; border:1px solid #d1d5db; border-radius:10px; padding:8px; }
        #aiBtn { background:#6366f1; color:white; border:none; border-radius:8px; padding:7px 14px; font-weight:bold; }
        #aiGhost { background:#f3f4f6; color:#374151; border:1px solid #d1d5db; border-radius:8px; padding:7px 12px; }
        #aiStatus { color:#6b7280; font-size:11px; }
    """

    def __init__(self):
        super().__init__()
        self.api_keys = []
        self.context_text = ""
        self.chat_turns = []
        self.worker = None
        self.config_file = os.path.join(app_data_dir(), "gemini_config.json")
        self.load_config()
        if not self.api_keys:
            names = ["GEMINI_API_KEY"] + [f"GEMINI_API_KEY_{i}" for i in range(1, 6)]
            self.api_keys = list(dict.fromkeys(os.environ[n].strip() for n in names if os.environ.get(n, "").strip()))
        self.init_ui()

    def load_config(self):
        try:
            with open(self.config_file, 'r', encoding='utf-8') as fh:
                self.api_keys = json.load(fh).get("api_keys", [])
        except Exception:
            self.api_keys = []

    def save_config(self):
        try:
            with open(self.config_file, 'w', encoding='utf-8') as fh:
                json.dump({"api_keys": self.api_keys}, fh, indent=2)
        except Exception as exc:
            QMessageBox.warning(self, "Save Error", str(exc))

    def init_ui(self):
        self.setStyleSheet(self._STYLE)
        root = QVBoxLayout(self); root.setContentsMargins(16,16,16,16); root.setSpacing(12)

        head = QWidget(); head.setObjectName("aiTop")
        hl = QVBoxLayout(head); hl.setContentsMargins(14,10,14,10)
        title = QLabel("Jesson Study Assistant"); title.setObjectName("aiTitle")
        sub = QLabel("Load study material, ask questions, summarize it, or generate revision material."); sub.setObjectName("aiSub")
        hl.addWidget(title); hl.addWidget(sub); root.addWidget(head)

        config = QWidget(); config.setObjectName("aiCard")
        cl = QVBoxLayout(config); cl.setContentsMargins(12,12,12,12); cl.setSpacing(8)
        row = QHBoxLayout()
        row.addWidget(QLabel("Gemini API keys (one per line / comma-separated):"))
        self.saveKeyBtn = QPushButton("Save keys"); self.saveKeyBtn.setObjectName("aiGhost")
        row.addStretch(); row.addWidget(self.saveKeyBtn); cl.addLayout(row)
        self.apiKeyInput = QPlainTextEdit(); self.apiKeyInput.setMaximumHeight(62)
        self.apiKeyInput.setPlaceholderText("AIza...\nAIza...")
        self.apiKeyInput.setPlainText("\n".join(self.api_keys)); cl.addWidget(self.apiKeyInput)
        root.addWidget(config)

        context_row = QHBoxLayout()
        self.loadContextBtn = QPushButton("📂 Load PDF / DOCX / TXT"); self.loadContextBtn.setObjectName("aiGhost")
        self.clearContextBtn = QPushButton("Clear context"); self.clearContextBtn.setObjectName("aiGhost")
        self.contextStatusLabel = QLabel("Context: none"); self.contextStatusLabel.setObjectName("aiStatus")
        context_row.addWidget(self.loadContextBtn); context_row.addWidget(self.clearContextBtn)
        context_row.addWidget(self.contextStatusLabel, 1); root.addLayout(context_row)

        presets = QHBoxLayout()
        self.summarizeBtn = QPushButton("Summarize"); self.quizBtn = QPushButton("Quiz / Flashcards"); self.conceptsBtn = QPushButton("Key Concepts")
        for b in (self.summarizeBtn, self.quizBtn, self.conceptsBtn): b.setObjectName("aiGhost"); presets.addWidget(b)
        presets.addStretch(); root.addLayout(presets)

        self.chatHistory = QTextBrowser(); self.chatHistory.setObjectName("aiChat"); self.chatHistory.setOpenExternalLinks(True)
        root.addWidget(self.chatHistory, 1)

        prompt_row = QHBoxLayout()
        self.promptInput = QTextEdit(); self.promptInput.setObjectName("aiPrompt"); self.promptInput.setMaximumHeight(90)
        self.promptInput.setPlaceholderText("Ask a question about your loaded material…")
        self.sendBtn = QPushButton("Send"); self.sendBtn.setObjectName("aiBtn"); self.sendBtn.setMinimumHeight(42)
        self.clearChatBtn = QPushButton("Clear chat"); self.clearChatBtn.setObjectName("aiGhost")
        btns = QVBoxLayout(); btns.addWidget(self.sendBtn); btns.addWidget(self.clearChatBtn)
        prompt_row.addWidget(self.promptInput, 1); prompt_row.addLayout(btns); root.addLayout(prompt_row)

        self.saveKeyBtn.clicked.connect(self.on_save_keys)
        self.loadContextBtn.clicked.connect(self.load_context_file)
        self.clearContextBtn.clicked.connect(self.clear_context)
        self.summarizeBtn.clicked.connect(lambda: self.send_preset_prompt("Provide a comprehensive but clear summary of the loaded study material."))
        self.quizBtn.clicked.connect(lambda: self.send_preset_prompt("Create a 10-question revision quiz from the loaded material, then provide an answer key."))
        self.conceptsBtn.clicked.connect(lambda: self.send_preset_prompt("Extract and explain the core concepts, definitions, formulas, and relationships in the loaded material."))
        self.sendBtn.clicked.connect(self.send_prompt)
        self.clearChatBtn.clicked.connect(self.chatHistory.clear)

    def get_parsed_keys(self):
        return [k.strip() for k in re.split(r'[\n,;]+', self.apiKeyInput.toPlainText()) if k.strip()]

    def on_save_keys(self):
        self.api_keys = self.get_parsed_keys(); self.save_config()
        QMessageBox.information(self, "Keys saved", f"Saved {len(self.api_keys)} API key(s) locally on this PC.")

    def clear_context(self):
        self.context_text = ""; self.contextStatusLabel.setText("Context: none")
        self.append_to_chat("System", "Context cleared.", "#6b7280")

    def load_context_file(self):
        path, _ = QFileDialog.getOpenFileName(self, "Open Study Material", "", "Documents (*.pdf *.docx *.txt)")
        if not path: return
        try:
            if path.lower().endswith('.txt'):
                with open(path, 'r', encoding='utf-8') as fh: text = fh.read()
            elif path.lower().endswith('.docx'):
                doc = Document(path); text = '\n'.join(p.text for p in doc.paragraphs)
            else:
                pdf = fitz.open(path); text = '\n'.join(page.get_text("text") for page in pdf); pdf.close()
            if not text.strip():
                QMessageBox.warning(self, "No text", "No extractable text was found in that file."); return
            self.context_text = text
            self.contextStatusLabel.setText(f"Context: {QFileInfo(path).fileName()} · {len(text):,} chars")
            self.append_to_chat("System", f"Loaded {QFileInfo(path).fileName()} as study context.", "#6b7280")
        except Exception as exc:
            QMessageBox.warning(self, "Load Error", str(exc))

    def append_to_chat(self, role, text, color="#111827"):
        safe = str(text).replace('&','&amp;').replace('<','&lt;').replace('>','&gt;').replace('\n','<br>')
        self.chatHistory.append(f'<div style="margin:6px 0 12px"><b style="color:{color}">{role}</b><br>{safe}</div>')

    def send_preset_prompt(self, prompt):
        self.promptInput.setPlainText(prompt); self.send_prompt()

    def send_prompt(self):
        prompt = self.promptInput.toPlainText().strip()
        if not prompt: return
        keys = self.get_parsed_keys()
        if not keys:
            QMessageBox.warning(self, "API key missing", "Enter at least one Gemini API key first."); return
        self.append_to_chat("You", prompt, "#4f46e5")
        self.promptInput.clear(); self.sendBtn.setEnabled(False); self.sendBtn.setText("Thinking…")
        history = list(getattr(self, "chat_turns", []))[-12:]
        self.worker = GeminiWorker(keys, prompt, self.context_text, history)
        self.worker.finished.connect(lambda text, p=prompt: self._remember_turn(p, text))
        self.worker.finished.connect(self.on_response); self.worker.error.connect(self.on_error); self.worker.start()

    def _remember_turn(self, prompt, reply):
        self.chat_turns = (list(getattr(self, "chat_turns", [])) + [("user", prompt), ("model", reply)])[-24:]

    def on_response(self, text):
        self.append_to_chat("Jesson AI", text, "#059669"); self.sendBtn.setEnabled(True); self.sendBtn.setText("Send")

    def on_error(self, message):
        self.append_to_chat("System Error", message, "#dc2626"); self.sendBtn.setEnabled(True); self.sendBtn.setText("Send")


class MusicPlayerTab(QWidget):
    """Modern music player with a dark player card + sidebar playlist."""

    SUPPORTED_FORMATS = {
        'mp3','wav','ogg','flac','m4a','aac','wma','opus',
        'oga','webm','mp4','aiff','ape','mka','ac3','dts'
    }

    # ── stylesheet applied only to this tab ──────────────────────────────────
    _STYLE = """
        MusicPlayerTab {
            background: #121212;
        }
        /* Player card */
        #playerCard {
            background: #1e1e2e;
            border-radius: 16px;
        }
        #trackTitle {
            color: #ffffff;
            font-size: 18px;
            font-weight: bold;
        }
        #trackSub {
            color: #a0a0c0;
            font-size: 12px;
        }
        #timeLabel {
            color: #a0a0c0;
            font-size: 11px;
        }
        /* Seek slider */
        #seekSlider::groove:horizontal {
            height: 4px;
            background: #3a3a5c;
            border-radius: 2px;
        }
        #seekSlider::sub-page:horizontal {
            background: #7c6af7;
            border-radius: 2px;
        }
        #seekSlider::handle:horizontal {
            background: #ffffff;
            width: 12px; height: 12px;
            margin: -4px 0;
            border-radius: 6px;
        }
        /* Volume slider */
        #volSlider::groove:horizontal {
            height: 3px; background: #3a3a5c; border-radius: 2px;
        }
        #volSlider::sub-page:horizontal {
            background: #7c6af7; border-radius: 2px;
        }
        #volSlider::handle:horizontal {
            background: #ffffff; width: 10px; height: 10px;
            margin: -4px 0; border-radius: 5px;
        }
        /* Control buttons */
        #btnPrev, #btnNext {
            background: transparent; color: #c0c0e0;
            border: none; font-size: 20px; padding: 4px 10px;
            border-radius: 8px;
        }
        #btnPrev:hover, #btnNext:hover { background: #2a2a4a; }
        #btnPlay {
            background: #7c6af7; color: white;
            border: none; font-size: 22px;
            border-radius: 26px; min-width: 52px; min-height: 52px;
            max-width: 52px; max-height: 52px;
        }
        #btnPlay:hover { background: #9580ff; }
        #btnStop {
            background: transparent; color: #c0c0e0;
            border: none; font-size: 18px; padding: 4px 8px;
            border-radius: 8px;
        }
        #btnStop:hover { background: #2a2a4a; }
        #btnShuffle, #btnRepeat {
            background: transparent; color: #606080;
            border: none; font-size: 16px; padding: 4px 8px;
            border-radius: 8px;
        }
        #btnShuffle[active="true"], #btnRepeat[active="true"] {
            color: #7c6af7;
        }
        #btnShuffle:hover, #btnRepeat:hover { color: #a090ff; }
        /* Playlist panel */
        #playlistPanel {
            background: #181828;
            border-radius: 12px;
        }
        #playlistHeader {
            color: #ffffff; font-size: 13px; font-weight: bold;
        }
        #playlistView {
            background: transparent;
            border: none;
            color: #c0c0e0;
            font-size: 13px;
        }
        #playlistView::item { padding: 6px 8px; border-radius: 6px; }
        #playlistView::item:selected { background: #2d2d4e; color: #ffffff; }
        #playlistView::item:hover { background: #252540; }
        /* Playlist action buttons */
        #btnAdd { background: #7c6af7; color: white; border: none;
                  border-radius: 6px; padding: 5px 14px; font-size: 12px; }
        #btnAdd:hover { background: #9580ff; }
        #btnRemove, #btnSave, #btnLoad {
            background: #2a2a4a; color: #c0c0e0;
            border: none; border-radius: 6px; padding: 5px 12px; font-size: 12px;
        }
        #btnRemove:hover, #btnSave:hover, #btnLoad:hover { background: #3a3a5e; }
        #volIcon { color: #a0a0c0; font-size: 14px; }
        #trackCount { color: #606080; font-size: 11px; }
    """

    def __init__(self):
        super().__init__()
        self.failed_files = []
        self._shuffle_on = False
        self._repeat_on  = False
        self.init_ui()

    def init_ui(self):
        self.setStyleSheet(self._STYLE)
        self.setObjectName("MusicPlayerTab")

        root = QHBoxLayout(self)
        root.setContentsMargins(16, 16, 16, 16)
        root.setSpacing(16)

        # ── LEFT: Player card ─────────────────────────────────────────────
        card = QWidget(); card.setObjectName("playerCard")
        card.setFixedWidth(320)
        cl = QVBoxLayout(card)
        cl.setContentsMargins(24, 28, 24, 24)
        cl.setSpacing(14)

        # Album art placeholder
        self.albumArt = QLabel()
        self.albumArt.setFixedSize(200, 200)
        self.albumArt.setAlignment(Qt.AlignCenter)
        self.albumArt.setStyleSheet(
            "background:#2a2a4a; border-radius:12px; color:#606080; font-size:48px;")
        self.albumArt.setText("♪")
        cl.addWidget(self.albumArt, 0, Qt.AlignCenter)

        # Track info
        self.trackTitle = QLabel("No track playing")
        self.trackTitle.setObjectName("trackTitle")
        self.trackTitle.setAlignment(Qt.AlignCenter)
        self.trackTitle.setWordWrap(True)
        self.trackSub = QLabel("—")
        self.trackSub.setObjectName("trackSub")
        self.trackSub.setAlignment(Qt.AlignCenter)
        cl.addWidget(self.trackTitle)
        cl.addWidget(self.trackSub)

        # Seek bar
        self.seekSlider = QSlider(Qt.Horizontal)
        self.seekSlider.setObjectName("seekSlider")
        self.seekSlider.setRange(0, 0)

        timeRow = QHBoxLayout()
        self.elapsedLabel = QLabel("0:00"); self.elapsedLabel.setObjectName("timeLabel")
        self.totalLabel   = QLabel("0:00"); self.totalLabel.setObjectName("timeLabel")
        timeRow.addWidget(self.elapsedLabel)
        timeRow.addStretch()
        timeRow.addWidget(self.totalLabel)

        cl.addWidget(self.seekSlider)
        cl.addLayout(timeRow)

        # Transport controls
        ctrl = QHBoxLayout(); ctrl.setSpacing(8)
        self.btnShuffle = QPushButton("⇄"); self.btnShuffle.setObjectName("btnShuffle")
        self.btnShuffle.setFixedSize(36, 36)
        self.btnPrev = QPushButton("⏮"); self.btnPrev.setObjectName("btnPrev")
        self.btnPrev.setFixedSize(42, 42)
        self.btnPlay = QPushButton("▶"); self.btnPlay.setObjectName("btnPlay")
        self.btnNext = QPushButton("⏭"); self.btnNext.setObjectName("btnNext")
        self.btnNext.setFixedSize(42, 42)
        self.btnRepeat = QPushButton("↻"); self.btnRepeat.setObjectName("btnRepeat")
        self.btnRepeat.setFixedSize(36, 36)
        for b in [self.btnShuffle, self.btnPrev, self.btnPlay, self.btnNext, self.btnRepeat]:
            ctrl.addWidget(b, 0, Qt.AlignVCenter)
        cl.addLayout(ctrl)

        # Volume row
        volRow = QHBoxLayout(); volRow.setSpacing(8)
        volIcon = QLabel("🔈"); volIcon.setObjectName("volIcon")
        self.volumeSlider = QSlider(Qt.Horizontal)
        self.volumeSlider.setObjectName("volSlider")
        self.volumeSlider.setRange(0, 100); self.volumeSlider.setValue(80)
        volHigh = QLabel("🔊"); volHigh.setObjectName("volIcon")
        volRow.addWidget(volIcon); volRow.addWidget(self.volumeSlider); volRow.addWidget(volHigh)
        cl.addLayout(volRow)
        cl.addStretch()

        # ── RIGHT: Playlist panel ─────────────────────────────────────────
        panel = QWidget(); panel.setObjectName("playlistPanel")
        pl = QVBoxLayout(panel)
        pl.setContentsMargins(16, 16, 16, 16); pl.setSpacing(10)

        hdr = QHBoxLayout()
        hdrLbl = QLabel("Queue"); hdrLbl.setObjectName("playlistHeader")
        self.trackCountLabel = QLabel("0 tracks"); self.trackCountLabel.setObjectName("trackCount")
        hdr.addWidget(hdrLbl); hdr.addStretch(); hdr.addWidget(self.trackCountLabel)
        pl.addLayout(hdr)

        self.playlistView = QListWidget()
        self.playlistView.setObjectName("playlistView")
        self.playlistView.setSelectionMode(QListWidget.SingleSelection)
        self.playlistView.setDragDropMode(QListWidget.InternalMove)
        pl.addWidget(self.playlistView)

        actions = QHBoxLayout(); actions.setSpacing(8)
        self.btnAdd    = QPushButton("＋ Add");    self.btnAdd.setObjectName("btnAdd")
        self.btnRemove = QPushButton("Remove");  self.btnRemove.setObjectName("btnRemove")
        self.btnSave   = QPushButton("Save");    self.btnSave.setObjectName("btnSave")
        self.btnLoad   = QPushButton("Load");    self.btnLoad.setObjectName("btnLoad")
        for b in [self.btnAdd, self.btnRemove, self.btnSave, self.btnLoad]:
            actions.addWidget(b)
        pl.addLayout(actions)

        # YouTube Music shortcut
        yt_layout = QHBoxLayout()
        self.btnYouTubeMusic = QPushButton("▶  YouTube Music")
        self.btnYouTubeMusic.setStyleSheet(
            "QPushButton { background: #ff0000; color: white; border: none; "
            "border-radius: 8px; padding: 7px 14px; font-size: 12px; font-weight: bold; }"
            "QPushButton:hover { background: #cc0000; }")
        self.btnYouTubeMusic.setToolTip("Open YouTube Music in the browser")
        yt_layout.addWidget(self.btnYouTubeMusic)
        yt_layout.addStretch()
        pl.addLayout(yt_layout)

        root.addWidget(card)
        root.addWidget(panel, 1)

        # ── Backend ───────────────────────────────────────────────────────
        from vlc_backend import VLCMediaPlayer
        self.mediaPlayer = VLCMediaPlayer(self)
        self.playlist    = QMediaPlaylist()
        self.mediaPlayer.setPlaylist(self.playlist)
        self.mediaPlayer.setVolume(80)

        self.progressTimer = QTimer()
        self.progressTimer.timeout.connect(self._sync_seek)

        # Connections
        self.btnAdd.clicked.connect(self.add_music)
        self.btnRemove.clicked.connect(self.remove_music)
        self.btnSave.clicked.connect(self.save_playlist)
        self.btnLoad.clicked.connect(self.load_playlist)
        self.btnPlay.clicked.connect(self.toggle_play_pause)
        self.btnPrev.clicked.connect(self.playlist.previous)
        self.btnNext.clicked.connect(self.playlist.next)
        self.btnShuffle.clicked.connect(self._toggle_shuffle)
        self.btnRepeat.clicked.connect(self._toggle_repeat)
        self.btnYouTubeMusic.clicked.connect(self._open_youtube_music)
        self.playlistView.itemDoubleClicked.connect(self.play_selected)

        self.volumeSlider.valueChanged.connect(self.mediaPlayer.setVolume)
        self.seekSlider.sliderPressed.connect(self.progressTimer.stop)
        self.seekSlider.sliderReleased.connect(self._on_seek_released)
        self.seekSlider.sliderMoved.connect(self._update_elapsed_label)

        self.mediaPlayer.durationChanged.connect(self.on_duration_changed)
        self.mediaPlayer.positionChanged.connect(self.on_position_changed)
        self.mediaPlayer.currentMediaChanged.connect(self.on_media_changed)
        self.mediaPlayer.stateChanged.connect(self._on_state_changed)

        # Space = play/pause
        QShortcut(QKeySequence(Qt.Key_Space), self).activated.connect(self.toggle_play_pause)
        # Arrow keys skip track
        QShortcut(QKeySequence(Qt.Key_Right), self).activated.connect(self.playlist.next)
        QShortcut(QKeySequence(Qt.Key_Left),  self).activated.connect(self.playlist.previous)

    def _open_youtube_music(self):
        """Open YouTube Music in the app's Search/Browser tab if available, else system browser."""
        try:
            # Try to find the main window and switch to Search tab
            main = self.window()
            if hasattr(main, 'tabs') and hasattr(main, 'searchTab'):
                main.searchTab.browser.load(QUrl("https://music.youtube.com"))
                # Switch to the search/browser tab
                for i in range(main.tabs.count()):
                    if main.tabs.widget(i) is main.searchTab:
                        main.tabs.setCurrentIndex(i)
                        break
                return
        except Exception:
            pass
        # Fallback: open in system browser
        try:
            from PyQt5.QtGui import QDesktopServices
            QDesktopServices.openUrl(QUrl("https://music.youtube.com"))
        except Exception:
            import webbrowser
            webbrowser.open("https://music.youtube.com")

    # ── helpers ───────────────────────────────────────────────────────────────
    def _ms_to_str(self, ms):
        s = ms // 1000
        return f"{s//60}:{s%60:02d}"

    def _sync_seek(self):
        if self.mediaPlayer.state() == QMediaPlayer.PlayingState:
            if not self.seekSlider.isSliderDown():
                self.seekSlider.setValue(self.mediaPlayer.position())

    def _on_seek_released(self):
        self.mediaPlayer.setPosition(self.seekSlider.value())
        self.progressTimer.start(500)

    def _update_elapsed_label(self, pos):
        self.elapsedLabel.setText(self._ms_to_str(pos))

    def _on_state_changed(self, state):
        if state == QMediaPlayer.PlayingState:
            self.btnPlay.setText("⏸")
        else:
            self.btnPlay.setText("▶")

    def _toggle_shuffle(self):
        self._shuffle_on = not self._shuffle_on
        self.btnShuffle.setProperty("active", "true" if self._shuffle_on else "false")
        self.btnShuffle.style().unpolish(self.btnShuffle)
        self.btnShuffle.style().polish(self.btnShuffle)
        mode = QMediaPlaylist.Random if self._shuffle_on else (
            QMediaPlaylist.Loop if self._repeat_on else QMediaPlaylist.Sequential)
        self.playlist.setPlaybackMode(mode)

    def _toggle_repeat(self):
        self._repeat_on = not self._repeat_on
        self.btnRepeat.setProperty("active", "true" if self._repeat_on else "false")
        self.btnRepeat.style().unpolish(self.btnRepeat)
        self.btnRepeat.style().polish(self.btnRepeat)
        mode = QMediaPlaylist.Loop if self._repeat_on else (
            QMediaPlaylist.Random if self._shuffle_on else QMediaPlaylist.Sequential)
        self.playlist.setPlaybackMode(mode)

    def _update_track_count(self):
        n = self.playlistView.count()
        self.trackCountLabel.setText(f"{n} track{'s' if n != 1 else ''}")

    # ── public slots ──────────────────────────────────────────────────────────
    def toggle_play_pause(self):
        if self.mediaPlayer.state() == QMediaPlayer.PlayingState:
            self.mediaPlayer.pause()
        elif self.mediaPlayer.state() == QMediaPlayer.PausedState:
            self.mediaPlayer.play()
        else:
            if self.playlistView.count() > 0:
                self.playlist.setCurrentIndex(0)
                self.mediaPlayer.play()

    def add_music(self):
        exts = ' '.join(f'*.{e}' for e in self.SUPPORTED_FORMATS)
        files, _ = QFileDialog.getOpenFileNames(
            self, "Add Audio Files", "", f"Audio Files ({exts});;All Files (*.*)")
        added = 0
        errors = []
        for f in files:
            if not os.path.exists(f):
                errors.append(f); continue
            try:
                self.playlist.addMedia(QMediaContent(QUrl.fromLocalFile(f)))
                name = QFileInfo(f).fileName()
                item = QListWidgetItem(f"  {name}")
                item.setData(Qt.UserRole, f)
                item.setToolTip(f)
                self.playlistView.addItem(item)
                added += 1
            except Exception as e:
                errors.append(f"{os.path.basename(f)}: {e}")
        self._update_track_count()
        if errors:
            QMessageBox.warning(self, "Some files failed",
                                "\n".join(errors[:5]) + (f"\n…and {len(errors)-5} more" if len(errors)>5 else ""))

    def remove_music(self):
        sel = self.playlistView.selectedItems()
        if sel:
            idx = self.playlistView.row(sel[0])
            self.playlistView.takeItem(idx)
            self.playlist.removeMedia(idx)
            self._update_track_count()

    def save_playlist(self):
        f, _ = QFileDialog.getSaveFileName(self, "Save Playlist", "", "M3U (*.m3u)")
        if f:
            with open(f, 'w') as fh:
                for i in range(self.playlist.mediaCount()):
                    fh.write(self.playlist.media(i).canonicalUrl().toLocalFile() + '\n')

    def load_playlist(self):
        f, _ = QFileDialog.getOpenFileName(self, "Load Playlist", "", "M3U (*.m3u)")
        if f:
            self.playlist.clear(); self.playlistView.clear()
            with open(f) as fh:
                for line in fh:
                    path = line.strip()
                    if path:
                        item = QListWidgetItem(f"  {QFileInfo(path).fileName()}")
                        item.setData(Qt.UserRole, path)
                        self.playlistView.addItem(item)
                        self.playlist.addMedia(QMediaContent(QUrl.fromLocalFile(path)))
            self._update_track_count()

    def play_selected(self, item):
        self.playlist.setCurrentIndex(self.playlistView.row(item))
        self.mediaPlayer.play()

    # Old methods kept for compatibility with toggle_shuffle / toggle_repeat
    def toggle_shuffle(self, state):
        pass   # handled by _toggle_shuffle
    def toggle_repeat(self, state):
        pass   # handled by _toggle_repeat

    def on_duration_changed(self, duration):
        self.seekSlider.setRange(0, duration)
        self.totalLabel.setText(self._ms_to_str(duration))
        self.progressTimer.start(500)

    def on_position_changed(self, position):
        if not self.seekSlider.isSliderDown():
            self.seekSlider.setValue(position)
        self.elapsedLabel.setText(self._ms_to_str(position))

    def on_media_changed(self, media):
        if media.isNull():
            self.trackTitle.setText("No track playing")
            self.trackSub.setText("—")
            self.albumArt.setText("♪")
            self.albumArt.setStyleSheet(
                "background:#2a2a4a; border-radius:12px; color:#606080; font-size:48px;")
            return
        path = media.canonicalUrl().toLocalFile()
        name = QFileInfo(path).completeBaseName()
        ext  = QFileInfo(path).suffix().lower()

        # Try to extract embedded album art and metadata via mutagen
        art_loaded = False
        artist_str = ""
        try:
            import mutagen
            from mutagen.mp3  import MP3
            from mutagen.mp4  import MP4
            from mutagen.flac import FLAC
            from mutagen.id3  import ID3, APIC
            from mutagen.oggvorbis import OggVorbis

            if ext == 'mp3':
                tags = ID3(path)
                # Title
                if 'TIT2' in tags: name = str(tags['TIT2'])
                if 'TPE1' in tags: artist_str = str(tags['TPE1'])
                # Art
                for tag in tags.values():
                    if isinstance(tag, APIC):
                        img = QImage(); img.loadFromData(tag.data)
                        pix = QPixmap.fromImage(img).scaled(
                            200, 200, Qt.KeepAspectRatioByExpanding, Qt.SmoothTransformation)
                        # crop to square
                        size = min(pix.width(), pix.height())
                        pix = pix.copy((pix.width()-size)//2, (pix.height()-size)//2, size, size)
                        self.albumArt.setPixmap(pix.scaled(200,200, Qt.KeepAspectRatio, Qt.SmoothTransformation))
                        self.albumArt.setStyleSheet("border-radius:12px;")
                        art_loaded = True; break
            elif ext in ('m4a', 'mp4', 'aac'):
                tags = MP4(path)
                if '\xa9nam' in tags: name = tags['\xa9nam'][0]
                if '\xa9ART' in tags: artist_str = tags['\xa9ART'][0]
                if 'covr' in tags:
                    cover = tags['covr'][0]
                    img = QImage(); img.loadFromData(bytes(cover))
                    pix = QPixmap.fromImage(img).scaled(200,200, Qt.KeepAspectRatio, Qt.SmoothTransformation)
                    self.albumArt.setPixmap(pix)
                    self.albumArt.setStyleSheet("border-radius:12px;")
                    art_loaded = True
            elif ext == 'flac':
                tags = FLAC(path)
                if 'title'  in tags: name = tags['title'][0]
                if 'artist' in tags: artist_str = tags['artist'][0]
                if tags.pictures:
                    img = QImage(); img.loadFromData(tags.pictures[0].data)
                    pix = QPixmap.fromImage(img).scaled(200,200, Qt.KeepAspectRatio, Qt.SmoothTransformation)
                    self.albumArt.setPixmap(pix)
                    self.albumArt.setStyleSheet("border-radius:12px;")
                    art_loaded = True
        except Exception:
            pass  # mutagen not installed or file has no tags — fall through

        if not art_loaded:
            self.albumArt.setPixmap(QPixmap())
            self.albumArt.setText("♪")
            self.albumArt.setStyleSheet(
                "background:#2a2a4a; border-radius:12px; color:#606080; font-size:48px;")

        self.trackTitle.setText(name)
        sub = artist_str if artist_str else ext.upper()
        self.trackSub.setText(sub)

        idx = self.playlist.currentIndex()
        if 0 <= idx < self.playlistView.count():
            self.playlistView.setCurrentRow(idx)

    def handle_media_error(self, error):
        if error != QMediaPlayer.NoError:
            media = self.mediaPlayer.currentMedia()
            name = "Unknown"
            if not media.isNull():
                name = os.path.basename(media.canonicalUrl().toLocalFile())
            msgs = {
                QMediaPlayer.ResourceError: "Missing codec. Install K-Lite Codec Pack.",
                QMediaPlayer.FormatError:   "Unsupported format.",
                QMediaPlayer.NetworkError:  "Network error.",
                QMediaPlayer.AccessDeniedError: "Access denied.",
            }
            msg = msgs.get(error, f"Playback error (code {error}).")
            QMessageBox.critical(self, "Playback Error", f"{name}\n\n{msg}")
            if self.playlist.mediaCount() > 1:
                self.playlist.next()

    def update_time_label(self): pass   # no-op, handled by on_position_changed
    def update_progress(self):   pass   # no-op, handled by _sync_seek


class TTSTab(QWidget):
    """Modern Text-to-Speech tab with card layout."""

    _STYLE = """
        TTSTab { background: #f8f9fb; }
        #ttsCard { background: #ffffff; border-radius: 12px;
                   border: 1px solid #e5e7eb; }
        #controlCard { background: #ffffff; border-radius: 12px;
                       border: 1px solid #e5e7eb; }
        #sectionLabel { color: #6b7280; font-size: 11px; font-weight: bold;
                        letter-spacing: 1px; }
        #textEdit { border: 1px solid #e5e7eb; border-radius: 8px;
                    font-size: 14px; padding: 10px; background: #fafafa; }
        #textEdit:focus { border-color: #6366f1; }
        QComboBox { border: 1px solid #d1d5db; border-radius: 6px;
                    padding: 4px 10px; background: white; min-height: 28px; }
        QComboBox::drop-down { border: none; }
        #sliderLabel { color: #374151; font-size: 12px; min-width: 60px; }
        #valueLabel  { color: #6366f1; font-size: 12px; min-width: 32px; }
        QSlider::groove:horizontal { height: 4px; background: #e5e7eb; border-radius: 2px; }
        QSlider::sub-page:horizontal { background: #6366f1; border-radius: 2px; }
        QSlider::handle:horizontal { background: #6366f1; width: 14px; height: 14px;
                                     margin: -5px 0; border-radius: 7px; }
        #btnStart  { background: #6366f1; color: white; border: none; border-radius: 8px;
                     padding: 9px 22px; font-size: 13px; font-weight: bold; }
        #btnStart:hover  { background: #4f46e5; }
        #btnPause  { background: #f3f4f6; color: #374151; border: 1px solid #d1d5db;
                     border-radius: 8px; padding: 9px 22px; font-size: 13px; }
        #btnPause:hover  { background: #e5e7eb; }
        #btnStop   { background: #fee2e2; color: #dc2626; border: 1px solid #fca5a5;
                     border-radius: 8px; padding: 9px 22px; font-size: 13px; }
        #btnStop:hover   { background: #fecaca; }
        #btnLoad   { background: #f3f4f6; color: #374151; border: 1px solid #d1d5db;
                     border-radius: 6px; padding: 6px 14px; font-size: 12px; }
        #btnLoad:hover   { background: #e5e7eb; }
        #statusBar { color: #6b7280; font-size: 12px; font-style: italic; }
    """

    def __init__(self):
        super().__init__()
        self.is_paused = False
        self.init_ui()

    def init_ui(self):
        self.setStyleSheet(self._STYLE)
        root = QHBoxLayout(self)
        root.setContentsMargins(20, 20, 20, 20)
        root.setSpacing(16)

        # ── LEFT: Text area ───────────────────────────────────────────────
        left = QWidget(); left.setObjectName("ttsCard")
        ll = QVBoxLayout(left); ll.setContentsMargins(16, 16, 16, 16); ll.setSpacing(10)

        hdr = QHBoxLayout()
        title = QLabel("TEXT"); title.setObjectName("sectionLabel")
        self.btnLoad = QPushButton("📂 Load File"); self.btnLoad.setObjectName("btnLoad")
        hdr.addWidget(title); hdr.addStretch(); hdr.addWidget(self.btnLoad)
        ll.addLayout(hdr)

        self.textEdit = QTextEdit()
        self.textEdit.setObjectName("textEdit")
        self.textEdit.setPlaceholderText("Paste or type text here, or load a .txt / .docx file…")
        ll.addWidget(self.textEdit)

        self.statusLabel = QLabel("Ready")
        self.statusLabel.setObjectName("statusBar")
        ll.addWidget(self.statusLabel)

        # ── RIGHT: Controls card ──────────────────────────────────────────
        right = QWidget(); right.setObjectName("controlCard")
        right.setFixedWidth(260)
        rl = QVBoxLayout(right); rl.setContentsMargins(18, 18, 18, 18); rl.setSpacing(16)

        # Voice
        voice_lbl = QLabel("VOICE"); voice_lbl.setObjectName("sectionLabel")
        self.voiceCombo = QComboBox()
        rl.addWidget(voice_lbl); rl.addWidget(self.voiceCombo)

        # Sliders helper
        def make_slider(label_text, min_val, max_val, default, unit=""):
            row = QHBoxLayout(); row.setSpacing(8)
            lbl = QLabel(label_text); lbl.setObjectName("sliderLabel")
            sl = QSlider(Qt.Horizontal); sl.setRange(min_val, max_val); sl.setValue(default)
            val_lbl = QLabel(f"{default}{unit}"); val_lbl.setObjectName("valueLabel")
            sl.valueChanged.connect(lambda v, l=val_lbl, u=unit: l.setText(f"{v}{u}"))
            row.addWidget(lbl); row.addWidget(sl); row.addWidget(val_lbl)
            return sl, row

        settings_lbl = QLabel("SETTINGS"); settings_lbl.setObjectName("sectionLabel")
        rl.addWidget(settings_lbl)
        self.rateSlider,   rate_row   = make_slider("Rate",   -100, 100,  0)
        self.pitchSlider,  pitch_row  = make_slider("Pitch",  -100, 100,  0)
        self.volumeSlider, volume_row = make_slider("Volume",    0, 100, 80, "%")
        rl.addLayout(rate_row)
        rl.addLayout(pitch_row)
        rl.addLayout(volume_row)

        rl.addStretch()

        # Buttons
        btn_lbl = QLabel("PLAYBACK"); btn_lbl.setObjectName("sectionLabel")
        rl.addWidget(btn_lbl)
        self.startBtn = QPushButton("▶  Read"); self.startBtn.setObjectName("btnStart")
        self.pauseResumeBtn = QPushButton("⏸  Pause"); self.pauseResumeBtn.setObjectName("btnPause")
        self.stopBtn  = QPushButton("⏹  Stop");  self.stopBtn.setObjectName("btnStop")
        rl.addWidget(self.startBtn)
        rl.addWidget(self.pauseResumeBtn)
        rl.addWidget(self.stopBtn)

        root.addWidget(left, 1)
        root.addWidget(right)

        # ── TTS engine ────────────────────────────────────────────────────
        self.ttsEngine = QTextToSpeech()
        self.voices = self.ttsEngine.availableVoices()
        for voice in self.voices:
            self.voiceCombo.addItem(voice.name())
        if self.voices:
            self.ttsEngine.setVoice(self.voices[0])

        self.voiceCombo.currentIndexChanged.connect(self.change_voice)
        self.rateSlider.valueChanged.connect(lambda v: self.ttsEngine.setRate(v / 100.0))
        self.pitchSlider.valueChanged.connect(lambda v: self.ttsEngine.setPitch(v / 100.0))
        self.volumeSlider.valueChanged.connect(lambda v: self.ttsEngine.setVolume(v / 100.0))
        self.ttsEngine.setVolume(0.8)

        self.btnLoad.clicked.connect(self.load_text)
        self.startBtn.clicked.connect(self.start_reading)
        self.pauseResumeBtn.clicked.connect(self.pause_resume_reading)
        self.stopBtn.clicked.connect(self.stop_reading)
        self.ttsEngine.stateChanged.connect(self.on_state_changed)

    def load_text(self):
        file, _ = QFileDialog.getOpenFileName(self, "Open Text File", "", "Text Files (*.txt *.docx)")
        if file:
            try:
                if file.endswith('.txt'):
                    with open(file, 'r', encoding='utf-8') as f:
                        text = f.read()
                elif file.endswith('.docx'):
                    doc = Document(file)
                    text = '\n'.join([p.text for p in doc.paragraphs])
                self.textEdit.setPlainText(text)
                self.statusLabel.setText(f"Loaded: {os.path.basename(file)}")
            except Exception as e:
                QMessageBox.warning(self, "Error", f"Failed to load file: {str(e)}")

    def change_voice(self, index):
        self.ttsEngine.stop()
        if 0 <= index < len(self.voices):
            self.ttsEngine.setVoice(self.voices[index])

    def start_reading(self):
        text = self.textEdit.toPlainText().strip()
        if text:
            self.ttsEngine.say(text)
            self.pauseResumeBtn.setText("⏸  Pause")
            self.is_paused = False
            self.statusLabel.setText("Speaking…")

    def pause_resume_reading(self):
        if self.ttsEngine.state() == QTextToSpeech.Speaking:
            self.ttsEngine.pause()
            self.pauseResumeBtn.setText("▶  Resume")
            self.is_paused = True
            self.statusLabel.setText("Paused")
        elif self.is_paused:
            self.ttsEngine.resume()
            self.pauseResumeBtn.setText("⏸  Pause")
            self.is_paused = False
            self.statusLabel.setText("Speaking…")

    def stop_reading(self):
        self.ttsEngine.stop()
        self.pauseResumeBtn.setText("⏸  Pause")
        self.is_paused = False
        self.statusLabel.setText("Stopped")

    def on_state_changed(self, state):
        if state == QTextToSpeech.State.Ready:
            self.statusLabel.setText("Ready")
        elif state == QTextToSpeech.State.BackendError:
            QMessageBox.warning(self, "TTS Error", "An error occurred in text-to-speech.")
            self.statusLabel.setText("Error")



class CalculatorTab(QWidget):
    """Modern calculator: keyboard-driven display + styled button grid,
    plus Symbolic and Unit Converter sub-tabs."""

    _STYLE = """
        CalculatorTab { background: #1a1a2e; }
        /* Display */
        #calcDisplay {
            background: #0f0f1a;
            color: #ffffff;
            font-size: 32px;
            font-weight: bold;
            border: none;
            border-radius: 10px;
            padding: 16px 20px;
            text-align: right;
        }
        #exprDisplay {
            background: transparent;
            color: #7070a0;
            font-size: 13px;
            border: none;
            padding: 2px 20px;
        }
        #historyList {
            background: #0f0f1a;
            color: #8080b0;
            border: none;
            border-radius: 8px;
            font-size: 12px;
            max-height: 80px;
        }
        /* Button categories */
        QPushButton[btnType="digit"] {
            background: #2a2a4a; color: #ffffff;
            font-size: 18px; font-weight: bold;
            border: none; border-radius: 10px;
        }
        QPushButton[btnType="digit"]:hover  { background: #3a3a5e; }
        QPushButton[btnType="digit"]:pressed { background: #1e1e38; }

        QPushButton[btnType="op"] {
            background: #1e3a5a; color: #80c8ff;
            font-size: 18px; font-weight: bold;
            border: none; border-radius: 10px;
        }
        QPushButton[btnType="op"]:hover  { background: #2a4e7a; }
        QPushButton[btnType="op"]:pressed { background: #162c42; }

        QPushButton[btnType="fn"] {
            background: #2a1e4a; color: #c080ff;
            font-size: 13px; font-weight: 600;
            border: none; border-radius: 10px;
        }
        QPushButton[btnType="fn"]:hover  { background: #3a2e5e; }
        QPushButton[btnType="fn"]:pressed { background: #1e1238; }

        QPushButton[btnType="mem"] {
            background: #1e2e1e; color: #80e080;
            font-size: 12px;
            border: none; border-radius: 10px;
        }
        QPushButton[btnType="mem"]:hover  { background: #2e422e; }

        QPushButton[btnType="clear"] {
            background: #4a1e1e; color: #ff8080;
            font-size: 16px; font-weight: bold;
            border: none; border-radius: 10px;
        }
        QPushButton[btnType="clear"]:hover  { background: #5e2a2a; }

        QPushButton[btnType="eq"] {
            background: #7c6af7; color: #ffffff;
            font-size: 22px; font-weight: bold;
            border: none; border-radius: 10px;
        }
        QPushButton[btnType="eq"]:hover  { background: #9580ff; }
        QPushButton[btnType="eq"]:pressed { background: #5a4bc0; }
    """

    def __init__(self):
        super().__init__()
        self.memory = 0
        self.current_expression = ""
        self.history = []
        self._just_calculated = False
        self.init_unit_converter()
        self.init_symbolic_calculator()
        self.init_ui()

    # ── main UI ──────────────────────────────────────────────────────────────
    def init_ui(self):
        self.setStyleSheet(self._STYLE)
        self.setObjectName("CalculatorTab")

        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)

        self.sub_tabs = QTabWidget()
        self.sub_tabs.setStyleSheet("""
            QTabWidget::pane { border: none; background: #1a1a2e; }
            QTabBar { background: #1a1a2e; }
            QTabBar::tab {
                background: #1a1a2e; color: #606080;
                padding: 8px 20px; border: none;
                border-bottom: 2px solid transparent; font-size: 12px;
                min-width: 100px;
            }
            QTabBar::tab:selected { color: #7c6af7; border-bottom: 2px solid #7c6af7; }
            QTabBar::tab:hover { color: #a090ff; }
        """)
        self.sub_tabs.tabBar().setElideMode(Qt.ElideNone)
        self.sub_tabs.tabBar().setExpanding(False)
        outer.addWidget(self.sub_tabs)

        # ── Numeric tab ──────────────────────────────────────────────────────
        num_widget = QWidget()
        num_widget.setStyleSheet("background: #1a1a2e;")
        nl = QVBoxLayout(num_widget)
        nl.setContentsMargins(16, 16, 16, 16)
        nl.setSpacing(8)

        # Expression line (small, shows running expression)
        self.exprDisplay = QLineEdit()
        self.exprDisplay.setObjectName("exprDisplay")
        self.exprDisplay.setReadOnly(True)
        self.exprDisplay.setAlignment(Qt.AlignRight)

        # Main display
        self.display = QLineEdit()
        self.display.setObjectName("calcDisplay")
        self.display.setReadOnly(True)
        self.display.setAlignment(Qt.AlignRight)
        self.display.setText("0")
        self.display.setMinimumHeight(72)

        # History list
        self.historyList = QListWidget()
        self.historyList.setObjectName("historyList")
        self.historyList.setMaximumHeight(80)
        self.historyList.itemClicked.connect(
            lambda item: self._load_history(item.text()))

        nl.addWidget(self.exprDisplay)
        nl.addWidget(self.display)
        nl.addWidget(self.historyList)
        nl.addSpacing(4)

        # Button grid
        grid = QGridLayout()
        grid.setSpacing(8)

        # (label, row, col, colspan, btnType, action)
        buttons = [
            # Row 0: mem
            ("MC",  0,0,1,"mem","MC"), ("MR",  0,1,1,"mem","MR"),
            ("M+",  0,2,1,"mem","M+"), ("M−",  0,3,1,"mem","M-"),
            ("⌫",   0,4,1,"clear","BS"),
            # Row 1
            ("sin", 1,0,1,"fn","sin"), ("cos",1,1,1,"fn","cos"),
            ("tan", 1,2,1,"fn","tan"), ("(",  1,3,1,"op","("),
            (")",   1,4,1,"op",")"),
            # Row 2
            ("asin",2,0,1,"fn","asin"), ("acos",2,1,1,"fn","acos"),
            ("atan",2,2,1,"fn","atan"), ("√",  2,3,1,"fn","sqrt"),
            ("xʸ",  2,4,1,"fn","x^y"),
            # Row 3
            ("log", 3,0,1,"fn","log10"), ("ln",3,1,1,"fn","ln"),
            ("π",   3,2,1,"fn","pi"),    ("e", 3,3,1,"fn","e"),
            ("exp", 3,4,1,"fn","exp"),
            # Row 4: digits + ops
            ("7",4,0,1,"digit","7"),("8",4,1,1,"digit","8"),("9",4,2,1,"digit","9"),
            ("÷",4,3,1,"op","/"),("+/−",4,4,1,"fn","neg"),
            # Row 5
            ("4",5,0,1,"digit","4"),("5",5,1,1,"digit","5"),("6",5,2,1,"digit","6"),
            ("×",5,3,1,"op","*"),  ("C",5,4,1,"clear","C"),
            # Row 6
            ("1",6,0,1,"digit","1"),("2",6,1,1,"digit","2"),("3",6,2,1,"digit","3"),
            ("−",6,3,1,"op","-"),  ("=",6,4,2,"eq","="),
            # Row 7
            ("0",7,0,2,"digit","0"),(".",7,2,1,"digit","."),
            ("+",7,3,1,"op","+"),
        ]

        for label, row, col, span, btype, action in buttons:
            btn = QPushButton(label)
            btn.setProperty("btnType", btype)
            btn.setMinimumHeight(52)
            btn.clicked.connect(lambda _, a=action: self._handle_action(a))
            grid.addWidget(btn, row, col, 1, span)

        nl.addLayout(grid)

        self.sub_tabs.addTab(num_widget, "Numeric")

        # ── Symbolic / Unit sub-tabs ──────────────────────────────────────
        sym_widget = QWidget(); sym_widget.setLayout(self.symbolic_layout)
        unit_widget = QWidget(); unit_widget.setLayout(self.unit_layout)
        self.sub_tabs.addTab(sym_widget,  "Symbolic")
        self.sub_tabs.addTab(unit_widget, "Unit Converter")

        # ── Keyboard handling ─────────────────────────────────────────────
        self.setFocusPolicy(Qt.StrongFocus)

    # ── keyboard input ────────────────────────────────────────────────────────
    def keyPressEvent(self, event):
        key = event.key()
        text = event.text()
        # digits and operators typed directly
        if text in "0123456789.+-*/()":
            self._handle_action(text)
        elif key in (Qt.Key_Return, Qt.Key_Enter):
            self._handle_action("=")
        elif key == Qt.Key_Backspace:
            self._handle_action("BS")
        elif key == Qt.Key_Delete or text.lower() == 'c':
            self._handle_action("C")
        elif text == '^':
            self._handle_action("x^y")
        elif text == '%':
            self._handle_action("%")
        else:
            super().keyPressEvent(event)

    # ── action dispatcher ─────────────────────────────────────────────────────
    def _handle_action(self, action):
        if action == "=":
            self._calculate()
        elif action == "C":
            self.current_expression = ""
            self._just_calculated = False
            self.display.setText("0")
            self.exprDisplay.setText("")
        elif action == "BS":
            if self._just_calculated:
                self.current_expression = ""
                self.display.setText("0")
                self._just_calculated = False
            else:
                self.current_expression = self.current_expression[:-1]
                self.display.setText(self.current_expression or "0")
        elif action == "neg":
            try:
                val = float(self.display.text())
                val = -val
                self.current_expression = str(int(val) if val == int(val) else val)
                self.display.setText(self.current_expression)
            except Exception:
                pass
        elif action == "%":
            try:
                val = float(self.display.text()) / 100
                self.current_expression = str(val)
                self.display.setText(self.current_expression)
            except Exception:
                pass
        elif action in ("MC","MR","M+","M-"):
            self._handle_memory(action)
        elif action in ("sin","cos","tan","asin","acos","atan",
                        "sqrt","ln","log10","exp","pi","e","x^y"):
            self._handle_function(action)
        else:
            # digit or operator
            if self._just_calculated and action in "0123456789.":
                self.current_expression = action
                self._just_calculated = False
            elif self._just_calculated and action in "+-*/^":
                # chain operator on result
                self._just_calculated = False
                self.current_expression += action
            else:
                if self.display.text() in {"0", "Error"} and action not in "+-*/^.()":
                    self.current_expression = action
                else:
                    self.current_expression += action
            self.display.setText(self.current_expression)
            self.exprDisplay.setText("")

    def _handle_function(self, func):
        cur = self.current_expression or "0"
        func_map = {
            "sqrt":  f"math.sqrt({cur})",
            "x^y":   f"({cur})**",
            "ln":    f"math.log({cur})",
            "log10": f"math.log10({cur})",
            "sin":   f"math.sin(math.radians({cur}))",
            "cos":   f"math.cos(math.radians({cur}))",
            "tan":   f"math.tan(math.radians({cur}))",
            "exp":   f"math.exp({cur})",
            "asin":  f"math.degrees(math.asin({cur}))",
            "acos":  f"math.degrees(math.acos({cur}))",
            "atan":  f"math.degrees(math.atan({cur}))",
            "pi":    "math.pi",
            "e":     "math.e",
        }
        self.current_expression = func_map.get(func, cur)
        self.display.setText(self.current_expression)
        self._just_calculated = False

    def _handle_memory(self, action):
        try:
            cur = float(self.display.text()) if self.display.text() not in {"Error","0"} else 0
        except ValueError:
            cur = 0
        if action == "MC":  self.memory = 0
        elif action == "MR":
            self.current_expression = str(int(self.memory) if self.memory == int(self.memory) else self.memory)
            self.display.setText(self.current_expression)
        elif action == "M+": self.memory += cur
        elif action == "M-": self.memory -= cur

    def _load_history(self, text):
        """Click a history entry to restore its result."""
        if "=" in text:
            result = text.split("=")[-1].strip()
            self.current_expression = result
            self.display.setText(result)

    def _calculate(self):
        expr = self.current_expression
        self.exprDisplay.setText(expr + " =")
        result = safe_eval(expr)
        if result is not None:
            # Format nicely: int if whole number
            if isinstance(result, float) and result.is_integer():
                result_str = str(int(result))
            else:
                result_str = f"{result:.10g}"
            self.display.setText(result_str)
            entry = f"{expr} = {result_str}"
            self.history.append(entry)
            self.historyList.insertItem(0, entry)
            if len(self.history) > 20:
                self.history.pop(0)
                self.historyList.takeItem(self.historyList.count() - 1)
            self.current_expression = result_str
            self._just_calculated = True
        else:
            self.display.setText("Error")
            self.exprDisplay.setText("")
            self.current_expression = ""
            self._just_calculated = False

    # Keep these so the old shortcut wiring still works
    def calculate(self):
        self._calculate()

    def on_button_click(self):
        pass
    def append_to_expression(self, text):
        self._handle_action(text)
    def handle_function(self, func):
        self._handle_function(func)
    def on_mem_or_clear_click(self):
        pass



    def init_symbolic_calculator(self):
        self.symbolic_layout = QVBoxLayout()
        self.symbolic_layout.setContentsMargins(16, 16, 16, 16)
        self.symbolic_layout.setSpacing(10)

        # Input row
        input_row = QHBoxLayout()
        self.sym_input = QLineEdit()
        self.sym_input.setObjectName("calcDisplay")
        self.sym_input.setPlaceholderText("e.g.  x**3 + 2*x   or   sin(x)/x")
        self.sym_input.setStyleSheet(
            "QLineEdit { background:#0f0f1a; color:#ffffff; border:none; "
            "border-radius:8px; padding:10px 14px; font-size:14px; }")
        self.sym_input.returnPressed.connect(lambda: self.sym_compute('eval'))
        input_row.addWidget(self.sym_input)
        self.symbolic_layout.addLayout(input_row)

        # Result display
        self.sym_result = QTextEdit()
        self.sym_result.setReadOnly(True)
        self.sym_result.setFixedHeight(70)
        self.sym_result.setStyleSheet(
            "QTextEdit { background:#0a0a14; color:#a0e0a0; border:none; "
            "border-radius:8px; padding:8px 14px; font-size:13px; font-family:monospace; }")
        self.symbolic_layout.addWidget(self.sym_result)

        # Operation buttons - grouped by category
        categories = [
            ("Algebra",   [("Factor","factor"),("Expand","expand"),("Simplify","simplify"),("Solve","solve")]),
            ("Calculus",  [("Diff","diff"),("Integrate","int"),("Limit","limit"),("Series","series")]),
            ("Evaluate",  [("Eval","eval"),("Substitute","subs"),("Matrix","matrix"),("Plot","plot")]),
        ]
        for cat_name, ops in categories:
            cat_lbl = QLabel(cat_name.upper())
            cat_lbl.setStyleSheet("color:#606080; font-size:10px; font-weight:bold; "
                                  "letter-spacing:1px; margin-top:4px;")
            self.symbolic_layout.addWidget(cat_lbl)
            row = QHBoxLayout(); row.setSpacing(6)
            for label, mode in ops:
                btn = QPushButton(label)
                btn.setProperty("btnType", "fn")
                btn.setMinimumHeight(36)
                btn.clicked.connect(lambda _, m=mode: self.sym_compute(m))
                row.addWidget(btn)
            self.symbolic_layout.addLayout(row)

        self.symbolic_layout.addStretch()

    def sym_compute(self, mode):
        expr_str = self.sym_input.text()
        if not expr_str:
            return

        try:
            if mode in ['diff', 'int', 'limit', 'series', 'subs', 'plot']:
                x = sp.symbols('x')
                expr = sp.sympify(expr_str)
                if mode == 'diff':
                    result = sp.diff(expr, x)
                elif mode == 'int':
                    result = sp.integrate(expr, x)
                elif mode == 'limit':
                    result = sp.limit(expr, x, 0)  # Example to 0, can prompt for value
                elif mode == 'series':
                    result = expr.series(x, 0, 10)
                elif mode == 'subs':
                    text, ok = QInputDialog.getText(self, "Substitute", "Enter var=value (e.g., x=2):")
                    if ok and text:
                        try:
                            var, val = map(str.strip, text.split('=', 1))
                            result = expr.subs({sp.symbols(var): sp.sympify(val)})
                        except Exception:
                            result = "Invalid substitution input."
                elif mode == 'plot':
                    sp.plot(expr)
                    result = "Plot displayed in separate window."
            elif mode == 'matrix':
                rows, ok = QInputDialog.getInt(self, "Matrix", "Enter rows:")
                if ok:
                    cols = rows  # Square for simplicity
                    matrix_str, ok = QInputDialog.getText(self, "Matrix", "Enter elements as [[1,2],[3,4]]:")
                    if ok:
                        try:
                            mat_list = ast.literal_eval(matrix_str)
                            mat = sp.Matrix(mat_list)
                            result = mat.det()  # Example det, can expand
                        except Exception as e:
                            result = f"Invalid matrix input: {e}"
            elif mode == 'factor':
                expr = sp.sympify(expr_str)
                result = sp.factor(expr)
            elif mode == 'expand':
                expr = sp.sympify(expr_str)
                result = sp.expand(expr)
            else:
                expr = sp.sympify(expr_str)
                if mode == 'eval':
                    result = expr.evalf()
                elif mode == 'simplify':
                    result = sp.simplify(expr)
                elif mode == 'solve':
                    x = sp.symbols('x')
                    result = sp.solve(expr, x)
            self.sym_result.setText(str(result))
        except Exception as e:
            self.sym_result.setText(f"Error: {str(e)}")

    def init_unit_converter(self):
        self.unit_layout = QVBoxLayout()
        self.unit_layout.setContentsMargins(24, 20, 24, 20)
        self.unit_layout.setSpacing(14)

        # Category pill selector
        cat_lbl = QLabel("CATEGORY")
        cat_lbl.setStyleSheet("color:#606080; font-size:10px; font-weight:bold; letter-spacing:1px;")
        self.categoryCombo = QComboBox()
        self.categoryCombo.addItems(["Length","Mass","Volume","Temperature","Time","Speed",
                                     "Area","Energy","Pressure","Force","Power","Angle",
                                     "Frequency","Electric Current","Voltage","Resistance"])
        self.categoryCombo.setStyleSheet(
            "QComboBox { background:#252540; color:#e0e0f0; border:1px solid #3a3a5c; "
            "border-radius:8px; padding:6px 12px; font-size:13px; min-height:32px; }"
            "QComboBox::drop-down { border:none; width:24px; }"
            "QComboBox QAbstractItemView { background:#252540; color:#e0e0f0; "
            "selection-background-color:#7c6af7; border:1px solid #3a3a5c; }")

        # Value input
        val_lbl = QLabel("VALUE")
        val_lbl.setStyleSheet("color:#606080; font-size:10px; font-weight:bold; letter-spacing:1px;")
        self.valueInput = QDoubleSpinBox()
        self.valueInput.setRange(-1e12, 1e12)
        self.valueInput.setDecimals(6)
        self.valueInput.setStyleSheet(
            "QDoubleSpinBox { background:#0f0f1a; color:#ffffff; border:none; "
            "border-radius:8px; padding:10px 14px; font-size:18px; font-weight:bold; }")
        self.valueInput.setButtonSymbols(QAbstractSpinBox.NoButtons)

        # From / To row
        conv_row = QHBoxLayout(); conv_row.setSpacing(12)

        from_col = QVBoxLayout(); from_col.setSpacing(4)
        from_lbl = QLabel("FROM")
        from_lbl.setStyleSheet("color:#606080; font-size:10px; font-weight:bold; letter-spacing:1px;")
        self.fromUnitCombo = QComboBox()
        self._style_unit_combo(self.fromUnitCombo)
        from_col.addWidget(from_lbl); from_col.addWidget(self.fromUnitCombo)

        arrow = QLabel("→")
        arrow.setStyleSheet("color:#7c6af7; font-size:24px; font-weight:bold;")
        arrow.setAlignment(Qt.AlignCenter)

        to_col = QVBoxLayout(); to_col.setSpacing(4)
        to_lbl = QLabel("TO")
        to_lbl.setStyleSheet("color:#606080; font-size:10px; font-weight:bold; letter-spacing:1px;")
        self.toUnitCombo = QComboBox()
        self._style_unit_combo(self.toUnitCombo)
        to_col.addWidget(to_lbl); to_col.addWidget(self.toUnitCombo)

        conv_row.addLayout(from_col, 1)
        conv_row.addWidget(arrow)
        conv_row.addLayout(to_col, 1)

        # Convert button
        self.convertBtn = QPushButton("Convert")
        self.convertBtn.setProperty("btnType","eq")
        self.convertBtn.setMinimumHeight(44)

        # Result display
        self.resultLabel = QLabel("—")
        self.resultLabel.setAlignment(Qt.AlignCenter)
        self.resultLabel.setStyleSheet(
            "background:#0f0f1a; color:#a0e0ff; border-radius:10px; "
            "padding:14px; font-size:22px; font-weight:bold;")

        self.categoryCombo.currentIndexChanged.connect(self.update_units)
        self.convertBtn.clicked.connect(self.perform_conversion)
        self.valueInput.valueChanged.connect(self.perform_conversion)

        self.unit_layout.addWidget(cat_lbl)
        self.unit_layout.addWidget(self.categoryCombo)
        self.unit_layout.addWidget(val_lbl)
        self.unit_layout.addWidget(self.valueInput)
        self.unit_layout.addLayout(conv_row)
        self.unit_layout.addWidget(self.convertBtn)
        self.unit_layout.addWidget(self.resultLabel)
        self.unit_layout.addStretch()

        self.update_units(0)

    def _style_unit_combo(self, combo):
        combo.setStyleSheet(
            "QComboBox { background:#252540; color:#e0e0f0; border:1px solid #3a3a5c; "
            "border-radius:8px; padding:8px 12px; font-size:14px; min-height:36px; }"
            "QComboBox::drop-down { border:none; width:24px; }"
            "QComboBox QAbstractItemView { background:#252540; color:#e0e0f0; "
            "selection-background-color:#7c6af7; border:1px solid #3a3a5c; }")



    def update_units(self, index):
        category = self.categoryCombo.currentText()
        self.fromUnitCombo.clear()
        self.toUnitCombo.clear()

        units_dict = {
            "Length": ['mm', 'cm', 'm', 'km', 'inch', 'foot', 'yard', 'mile'],
            "Mass": ['mg', 'g', 'kg', 'tonne', 'oz', 'lb', 'ton'],
            "Volume": ['ml', 'l', 'm³', 'fl oz', 'pint', 'gallon'],
            "Temperature": ['C', 'F', 'K'],
            "Time": ['ms', 's', 'min', 'h', 'day'],
            "Speed": ['m/s', 'km/h', 'mph', 'ft/s'],
            "Area": ['mm²', 'cm²', 'm²', 'km²', 'sq inch', 'sq foot', 'sq yard', 'acre'],
            "Energy": ['J', 'kJ', 'cal', 'kcal', 'Wh', 'kWh'],
            "Pressure": ['Pa', 'kPa', 'bar', 'atm', 'psi', 'mmHg'],
            "Force": ['N', 'kN', 'lbf', 'kgf'],
            "Power": ['W', 'kW', 'hp', 'MW'],
            "Angle": ['deg', 'rad', 'grad'],
            "Frequency": ['Hz', 'kHz', 'MHz', 'GHz'],
            "Electric Current": ['A', 'mA', 'kA'],
            "Voltage": ['V', 'mV', 'kV'],
            "Resistance": ['ohm', 'kohm', 'Mohm']
        }

        units = units_dict.get(category, [])
        self.fromUnitCombo.addItems(units)
        self.toUnitCombo.addItems(units)
        if units:
            self.toUnitCombo.setCurrentIndex(1 if len(units) > 1 else 0)

    def perform_conversion(self):
        category = self.categoryCombo.currentText()
        from_unit = self.fromUnitCombo.currentText()
        to_unit = self.toUnitCombo.currentText()
        value = self.valueInput.value()

        if from_unit == to_unit:
            result = value
        else:
            if category == "Temperature":
                result = self.convert_temperature(value, from_unit, to_unit)
            elif category == "Angle":
                result = self.convert_angle(value, from_unit, to_unit)
            else:
                base_value = value * self.get_conversion_factor(from_unit, category)
                result = base_value / self.get_conversion_factor(to_unit, category)

        self.resultLabel.setText(f"{result:.8g} {to_unit}")

    def get_conversion_factor(self, unit, category):
        factors = {
            "Length": {'mm': 0.001, 'cm': 0.01, 'm': 1, 'km': 1000, 'inch': 0.0254, 'foot': 0.3048, 'yard': 0.9144, 'mile': 1609.34},
            "Mass": {'mg': 1e-6, 'g': 0.001, 'kg': 1, 'tonne': 1000, 'oz': 0.0283495, 'lb': 0.453592, 'ton': 907.185},
            "Volume": {'ml': 1e-6, 'l': 0.001, 'm³': 1, 'fl oz': 2.95735e-5, 'pint': 0.000473176, 'gallon': 0.00378541},
            "Time": {'ms': 0.001, 's': 1, 'min': 60, 'h': 3600, 'day': 86400},
            "Speed": {'m/s': 1, 'km/h': 1/3.6, 'mph': 0.44704, 'ft/s': 0.3048},
            "Area": {'mm²': 1e-6, 'cm²': 1e-4, 'm²': 1, 'km²': 1e6, 'sq inch': 0.00064516, 'sq foot': 0.092903, 'sq yard': 0.836127, 'acre': 4046.86},
            "Energy": {'J': 1, 'kJ': 1000, 'cal': 4.184, 'kcal': 4184, 'Wh': 3600, 'kWh': 3.6e6},
            "Pressure": {'Pa': 1, 'kPa': 1000, 'bar': 100000, 'atm': 101325, 'psi': 6894.76, 'mmHg': 133.322},
            "Force": {'N': 1, 'kN': 1000, 'lbf': 4.44822, 'kgf': 9.80665},
            "Power": {'W': 1, 'kW': 1000, 'hp': 745.7, 'MW': 1e6},
            "Frequency": {'Hz': 1, 'kHz': 1000, 'MHz': 1e6, 'GHz': 1e9},
            "Electric Current": {'A': 1, 'mA': 0.001, 'kA': 1000},
            "Voltage": {'V': 1, 'mV': 0.001, 'kV': 1000},
            "Resistance": {'ohm': 1, 'kohm': 1000, 'Mohm': 1e6}
        }
        return factors.get(category, {}).get(unit, 1)

    def convert_temperature(self, value, from_unit, to_unit):
        if from_unit == 'C':
            if to_unit == 'F':
                return value * 9/5 + 32
            elif to_unit == 'K':
                return value + 273.15
        elif from_unit == 'F':
            if to_unit == 'C':
                return (value - 32) * 5/9
            elif to_unit == 'K':
                return (value - 32) * 5/9 + 273.15
        elif from_unit == 'K':
            if to_unit == 'C':
                return value - 273.15
            elif to_unit == 'F':
                return (value - 273.15) * 9/5 + 32
        return value

    def convert_angle(self, value, from_unit, to_unit):
        if from_unit == 'deg':
            if to_unit == 'rad':
                return math.radians(value)
            elif to_unit == 'grad':
                return value * 10/9
        elif from_unit == 'rad':
            if to_unit == 'deg':
                return math.degrees(value)
            elif to_unit == 'grad':
                return math.degrees(value) * 10/9
        elif from_unit == 'grad':
            if to_unit == 'deg':
                return value * 9/10
            elif to_unit == 'rad':
                return math.radians(value * 9/10)
        return value

class DocumentTab(QWidget):
    """Word-inspired rich-text editor with a scrollable ribbon and centered page canvas."""

    _STYLE = """
        DocumentTab { background:#e9edf3; }
        #titleStrip { background:#2b579a; color:white; border:none; }
        #docTitle { color:white; font-size:13px; font-weight:bold; }
        #ribbonScroll { background:#ffffff; border:none; border-bottom:1px solid #cfd6df; }
        #ribbon { background:#ffffff; }
        #groupLabel { color:#6b7280; font-size:9px; }
        #toolBtn { background:transparent; color:#1f2937; border:none; border-radius:4px; padding:5px 9px; min-height:28px; }
        #toolBtn:hover { background:#eaf2fb; }
        #toolBtn:pressed { background:#dbeafe; }
        #separator { color:#d1d5db; }
        QFontComboBox, QSpinBox, QComboBox { border:1px solid #cfd6df; border-radius:4px; background:white; padding:3px 6px; min-height:26px; }
        #pageArea { background:#d8dde5; border:none; }
        #pageFrame { background:white; border:1px solid #c9ced6; }
        #editor { background:#ffffff; color:#111827; border:none; font-size:12pt; selection-background-color:#bdd7ee; }
        #bottomBar { background:#f7f7f7; border-top:1px solid #d1d5db; }
        #wordCount, #zoomLabel { color:#4b5563; font-size:11px; }
    """

    def __init__(self):
        super().__init__()
        self.current_file = None
        self.current_format = None
        self._zoom = 100
        self.init_ui()

    def init_ui(self):
        self.setStyleSheet(self._STYLE)
        root = QVBoxLayout(self); root.setContentsMargins(0,0,0,0); root.setSpacing(0)

        title_strip = QWidget(); title_strip.setObjectName("titleStrip")
        tsl = QHBoxLayout(title_strip); tsl.setContentsMargins(10,5,10,5)
        title = QLabel("Jesson Writer"); title.setObjectName("docTitle")
        tsl.addWidget(title); tsl.addStretch(); root.addWidget(title_strip)

        # Scrollable Word-style ribbon. Horizontal scrollbar appears on narrow screens.
        self.ribbonScroll = QScrollArea(); self.ribbonScroll.setObjectName("ribbonScroll")
        self.ribbonScroll.setWidgetResizable(True); self.ribbonScroll.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.ribbonScroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded); self.ribbonScroll.setFixedHeight(88)
        ribbon = QWidget(); ribbon.setObjectName("ribbon")
        rib = QHBoxLayout(ribbon); rib.setContentsMargins(8,5,8,3); rib.setSpacing(4)

        def tool(label, tip, slot, checkable=False):
            b=QPushButton(label); b.setObjectName("toolBtn"); b.setToolTip(tip); b.setCheckable(checkable); b.clicked.connect(slot); return b
        def sep():
            x=QLabel("│"); x.setObjectName("separator"); return x
        def group(label, widgets):
            box=QWidget(); lay=QVBoxLayout(box); lay.setContentsMargins(2,0,2,0); lay.setSpacing(1)
            row=QHBoxLayout(); row.setSpacing(2)
            for w in widgets: row.addWidget(w)
            lay.addLayout(row)
            gl=QLabel(label); gl.setObjectName("groupLabel"); gl.setAlignment(Qt.AlignCenter); lay.addWidget(gl)
            return box

        self.newBtn=tool("＋ New","New document",self.new_document)
        self.openBtn=tool("📂 Open","Open document",self.load_document)
        self.saveBtn=tool("💾 Save","Save document (Ctrl+S)",self.save_document)
        self.undoBtn=tool("↶","Undo",self.text_undo); self.redoBtn=tool("↷","Redo",self.text_redo)
        rib.addWidget(group("File", [self.newBtn,self.openBtn,self.saveBtn])); rib.addWidget(sep())
        rib.addWidget(group("History", [self.undoBtn,self.redoBtn])); rib.addWidget(sep())

        self.fontCombo=QFontComboBox(); self.fontCombo.setFixedWidth(150); self.fontCombo.currentFontChanged.connect(self.set_font)
        self.sizeSpin=QSpinBox(); self.sizeSpin.setRange(6,96); self.sizeSpin.setValue(12); self.sizeSpin.setFixedWidth(55); self.sizeSpin.valueChanged.connect(self.set_font_size)
        self.boldBtn=tool("B","Bold (Ctrl+B)",self.set_bold,True); self.boldBtn.setStyleSheet("font-weight:bold")
        self.italicBtn=tool("I","Italic (Ctrl+I)",self.set_italic,True); self.italicBtn.setStyleSheet("font-style:italic")
        self.underlineBtn=tool("U̲","Underline (Ctrl+U)",self.set_underline,True)
        self.textColorBtn=tool("A▾","Text color",self.set_text_color)
        self.highlightBtn=tool("🖍","Highlight",self.set_highlight_color)
        rib.addWidget(group("Font", [self.fontCombo,self.sizeSpin,self.boldBtn,self.italicBtn,self.underlineBtn,self.textColorBtn,self.highlightBtn])); rib.addWidget(sep())

        self.leftBtn=tool("≡←","Align left",lambda:self.set_alignment(Qt.AlignLeft))
        self.centerBtn=tool("≡↔","Center",lambda:self.set_alignment(Qt.AlignCenter))
        self.rightBtn=tool("→≡","Align right",lambda:self.set_alignment(Qt.AlignRight))
        self.justifyBtn=tool("☰","Justify",lambda:self.set_alignment(Qt.AlignJustify))
        self.bulletBtn=tool("• List","Bullets",self.insert_bullet_list)
        self.numberBtn=tool("1. List","Numbering",self.insert_numbered_list)
        self.indentLessBtn=tool("⇤","Decrease indent",lambda:self.adjust_indent(-1))
        self.indentMoreBtn=tool("⇥","Increase indent",lambda:self.adjust_indent(1))
        rib.addWidget(group("Paragraph", [self.leftBtn,self.centerBtn,self.rightBtn,self.justifyBtn,self.bulletBtn,self.numberBtn,self.indentLessBtn,self.indentMoreBtn])); rib.addWidget(sep())

        self.tableBtn=tool("⊞ Table","Insert table",self.prompt_insert_table)
        self.imageBtn=tool("🖼 Image","Insert image",self.insert_image)
        self.dateBtn=tool("📅 Date","Insert current date",self.insert_date)
        self.lineBtn=tool("― Line","Insert horizontal line",lambda:self.textEdit.textCursor().insertHtml('<hr>'))
        rib.addWidget(group("Insert", [self.tableBtn,self.imageBtn,self.dateBtn,self.lineBtn])); rib.addWidget(sep())

        self.zoomOutBtn=tool("−","Zoom out",lambda:self.change_zoom(-10)); self.zoomInBtn=tool("＋","Zoom in",lambda:self.change_zoom(10))
        rib.addWidget(group("View", [self.zoomOutBtn,self.zoomInBtn])); rib.addStretch()
        ribbon.setMinimumWidth(ribbon.sizeHint().width()); self.ribbonScroll.setWidget(ribbon); root.addWidget(self.ribbonScroll)

        # Centered page-like writing surface.
        page_scroll=QScrollArea(); page_scroll.setObjectName("pageArea"); page_scroll.setWidgetResizable(True)
        page_host=QWidget(); page_l=QHBoxLayout(page_host); page_l.setContentsMargins(24,24,24,24); page_l.addStretch()
        self.pageFrame=QWidget(); self.pageFrame.setObjectName("pageFrame"); self.pageFrame.setMinimumWidth(720); self.pageFrame.setMaximumWidth(920)
        pf=QVBoxLayout(self.pageFrame); pf.setContentsMargins(68,58,68,58)
        self.textEdit=QTextEdit(); self.textEdit.setObjectName("editor"); self.textEdit.setAcceptRichText(True)
        self.textEdit.document().setDocumentMargin(0); self.textEdit.setPlaceholderText("Start writing…")
        pf.addWidget(self.textEdit); page_l.addWidget(self.pageFrame,1); page_l.addStretch(); page_scroll.setWidget(page_host)
        root.addWidget(page_scroll,1)

        bottom=QWidget(); bottom.setObjectName("bottomBar"); bl=QHBoxLayout(bottom); bl.setContentsMargins(12,4,12,4)
        self.wordCountLabel=QLabel("Words: 0 · Characters: 0"); self.wordCountLabel.setObjectName("wordCount")
        self.zoomLabel=QLabel("100%"); self.zoomLabel.setObjectName("zoomLabel")
        bl.addWidget(self.wordCountLabel); bl.addStretch(); bl.addWidget(self.zoomLabel); root.addWidget(bottom)

        self.textEdit.textChanged.connect(self.update_word_count)
        self.textEdit.currentCharFormatChanged.connect(self.sync_format_controls)
        QShortcut(QKeySequence.Bold,self).activated.connect(self.set_bold)
        QShortcut(QKeySequence.Italic,self).activated.connect(self.set_italic)
        QShortcut(QKeySequence.Underline,self).activated.connect(self.set_underline)
        QShortcut(QKeySequence.Save,self).activated.connect(self.save_document)
        QShortcut(QKeySequence.Undo,self).activated.connect(self.text_undo)
        QShortcut(QKeySequence.Redo,self).activated.connect(self.text_redo)

    def text_undo(self): self.textEdit.undo()
    def text_redo(self): self.textEdit.redo()

    def new_document(self):
        if self.textEdit.document().isModified():
            ans=QMessageBox.question(self,"New document","Discard unsaved changes?",QMessageBox.Yes|QMessageBox.No,QMessageBox.No)
            if ans!=QMessageBox.Yes: return
        self.textEdit.clear(); self.current_file=None; self.current_format=None

    def merge_char_format(self, fmt):
        cursor=self.textEdit.textCursor()
        if not cursor.hasSelection(): self.textEdit.mergeCurrentCharFormat(fmt)
        else: cursor.mergeCharFormat(fmt)
        self.textEdit.mergeCurrentCharFormat(fmt)

    def set_bold(self):
        fmt=QTextCharFormat(); current=self.textEdit.currentCharFormat().fontWeight()
        fmt.setFontWeight(QFont.Normal if current>=QFont.Bold else QFont.Bold); self.merge_char_format(fmt)
    def set_italic(self):
        fmt=QTextCharFormat(); fmt.setFontItalic(not self.textEdit.currentCharFormat().fontItalic()); self.merge_char_format(fmt)
    def set_underline(self):
        fmt=QTextCharFormat(); fmt.setFontUnderline(not self.textEdit.currentCharFormat().fontUnderline()); self.merge_char_format(fmt)
    def set_font(self,font):
        fmt=QTextCharFormat(); fmt.setFontFamily(font.family()); self.merge_char_format(fmt)
        self.textEdit.setFocus()
    def set_font_size(self,size):
        if size<=0:return
        fmt=QTextCharFormat(); fmt.setFontPointSize(float(size)); self.merge_char_format(fmt)
    def set_text_color(self):
        c=QColorDialog.getColor(parent=self)
        if c.isValid(): fmt=QTextCharFormat(); fmt.setForeground(c); self.merge_char_format(fmt)
    def set_highlight_color(self):
        c=QColorDialog.getColor(Qt.yellow,self,"Highlight color")
        if c.isValid(): fmt=QTextCharFormat(); fmt.setBackground(c); self.merge_char_format(fmt)

    def set_alignment(self,alignment): self.textEdit.setAlignment(alignment)
    def insert_bullet_list(self): self.textEdit.textCursor().createList(QTextListFormat.ListDisc)
    def insert_numbered_list(self): self.textEdit.textCursor().createList(QTextListFormat.ListDecimal)
    def adjust_indent(self,delta):
        cur=self.textEdit.textCursor(); block=cur.blockFormat(); block.setIndent(max(0,block.indent()+delta)); cur.setBlockFormat(block)

    def sync_format_controls(self,fmt):
        controls = [self.boldBtn, self.italicBtn, self.underlineBtn, self.fontCombo, self.sizeSpin]
        blockers = [QSignalBlocker(control) for control in controls]
        self.boldBtn.setChecked(fmt.fontWeight()>=QFont.Bold)
        self.italicBtn.setChecked(fmt.fontItalic())
        self.underlineBtn.setChecked(fmt.fontUnderline())
        if fmt.fontFamily(): self.fontCombo.setCurrentFont(QFont(fmt.fontFamily()))
        if fmt.fontPointSize()>0: self.sizeSpin.setValue(int(round(fmt.fontPointSize())))

    def update_word_count(self):
        text=self.textEdit.toPlainText(); words=len(text.split()) if text.strip() else 0
        self.wordCountLabel.setText(f"Words: {words:,} · Characters: {len(text):,}")

    def change_zoom(self,delta):
        target=max(50,min(200,self._zoom+delta)); diff=target-self._zoom
        steps=abs(diff)//10
        for _ in range(steps): self.textEdit.zoomIn(1) if diff>0 else self.textEdit.zoomOut(1)
        self._zoom=target; self.zoomLabel.setText(f"{self._zoom}%")

    def insert_date(self): self.textEdit.textCursor().insertText(datetime.datetime.now().strftime("%d %B %Y"))

    def prompt_insert_table(self):
        dialog=QDialog(self); dialog.setWindowTitle("Insert Table"); layout=QFormLayout(dialog)
        rows=QSpinBox(); rows.setRange(1,50); rows.setValue(3); cols=QSpinBox(); cols.setRange(1,20); cols.setValue(3)
        layout.addRow("Rows:",rows); layout.addRow("Columns:",cols)
        buttons=QDialogButtonBox(QDialogButtonBox.Ok|QDialogButtonBox.Cancel); buttons.accepted.connect(dialog.accept); buttons.rejected.connect(dialog.reject); layout.addRow(buttons)
        if dialog.exec_()==QDialog.Accepted: self.insert_table(rows.value(),cols.value())

    def insert_table(self,rows,cols):
        cursor=self.textEdit.textCursor(); table=cursor.insertTable(rows,cols); tf=table.format(); tf.setBorder(1); table.setFormat(tf)

    def insert_image(self):
        path,_=QFileDialog.getOpenFileName(self,"Select Image","","Images (*.png *.jpg *.jpeg *.bmp *.gif)")
        if path: self.textEdit.textCursor().insertImage(path)

    def load_document(self):
        path,_=QFileDialog.getOpenFileName(self,"Open Document","","Documents (*.docx *.html *.htm *.txt *.pdf)")
        if not path:return
        try:
            low=path.lower()
            if low.endswith(('.html','.htm')):
                self.textEdit.setHtml(Path(path).read_text(encoding='utf-8')); self.current_format='html'
            elif low.endswith('.txt'):
                self.textEdit.setPlainText(Path(path).read_text(encoding='utf-8')); self.current_format='txt'
            elif low.endswith('.docx'):
                doc=Document(path); chunks=[]
                for p in doc.paragraphs:
                    runs=[]
                    for r in p.runs:
                        txt=r.text.replace('&','&amp;').replace('<','&lt;').replace('>','&gt;')
                        style=[]
                        if r.bold: style.append('font-weight:bold')
                        if r.italic: style.append('font-style:italic')
                        if r.underline: style.append('text-decoration:underline')
                        if r.font.size: style.append(f'font-size:{r.font.size.pt}pt')
                        if r.font.name: style.append(f'font-family:{r.font.name}')
                        runs.append(f'<span style="{";".join(style)}">{txt}</span>')
                    chunks.append('<p>'+''.join(runs)+'</p>')
                self.textEdit.setHtml(''.join(chunks)); self.current_format='docx'
            else:
                pdf=fitz.open(path); self.textEdit.setPlainText('\n\n'.join(page.get_text('text') for page in pdf)); pdf.close(); self.current_format='pdf'
            self.current_file=path; self.textEdit.document().setModified(False)
        except Exception as exc: QMessageBox.warning(self,"Open Error",str(exc))

    def _export_docx(self,path):
        doc=Document()
        qdoc=self.textEdit.document(); block=qdoc.begin()
        while block.isValid():
            p=doc.add_paragraph(); it=block.begin()
            while not it.atEnd():
                frag=it.fragment()
                if frag.isValid():
                    run=p.add_run(frag.text()); fmt=frag.charFormat()
                    run.bold=fmt.fontWeight()>=QFont.Bold; run.italic=fmt.fontItalic(); run.underline=fmt.fontUnderline()
                    if fmt.fontFamily(): run.font.name=fmt.fontFamily()
                    if fmt.fontPointSize()>0:
                        from docx.shared import Pt
                        run.font.size=Pt(fmt.fontPointSize())
                it+=1
            block=block.next()
        doc.save(path)

    def save_document(self):
        path,chosen=QFileDialog.getSaveFileName(self,"Save Document","","Word Document (*.docx);;HTML Document (*.html);;Plain Text (*.txt);;PDF (*.pdf)")
        if not path:return
        try:
            if 'docx' in chosen.lower() or path.lower().endswith('.docx'): self._export_docx(path)
            elif 'html' in chosen.lower() or path.lower().endswith(('.html','.htm')): Path(path).write_text(self.textEdit.toHtml(),encoding='utf-8')
            elif 'txt' in chosen.lower() or path.lower().endswith('.txt'): Path(path).write_text(self.textEdit.toPlainText(),encoding='utf-8')
            else:
                printer_html=self.textEdit.document().toHtml(); pdf=fitz.open(); page=pdf.new_page(width=595,height=842)
                # PyMuPDF insert_htmlbox preserves substantially more formatting than plain insert_text.
                rect=fitz.Rect(54,54,541,788)
                if hasattr(page, 'insert_htmlbox'):
                    page.insert_htmlbox(rect,printer_html)
                else:
                    page.insert_textbox(rect,self.textEdit.toPlainText(),fontsize=11)
                pdf.save(path); pdf.close()
            self.current_file=path; self.textEdit.document().setModified(False); QMessageBox.information(self,"Saved","Document saved successfully.")
        except Exception as exc: QMessageBox.warning(self,"Save Error",str(exc))



class PDFViewerTab(QWidget):
    """PDF viewer with dark toolbar and smooth zoom."""

    _STYLE = """
        PDFViewerTab { background: #2a2a35; }
        #toolbar { background: #1e1e2e; border-bottom: 1px solid #3a3a5c; padding: 6px 10px; }
        #navBtn {
            background: #2a2a4a; color: #c0c0e0; border: 1px solid #3a3a5c;
            border-radius: 6px; padding: 5px 12px; font-size: 13px; min-width: 70px;
        }
        #navBtn:hover   { background: #3a3a5c; color: #fff; }
        #navBtn:disabled { background: #1a1a2e; color: #505070; }
        #loadBtn {
            background: #7c6af7; color: white; border: none;
            border-radius: 6px; padding: 5px 16px; font-size: 13px; font-weight: bold;
        }
        #loadBtn:hover { background: #9580ff; }
        #ocrBtn {
            background: #1e4a3a; color: #60d0a0; border: 1px solid #3a6a5a;
            border-radius: 6px; padding: 5px 12px; font-size: 12px;
        }
        #ocrBtn:hover { background: #2a6a50; }
        #pageLabel { color: #a0a0c0; font-size: 13px; min-width: 90px; text-align: center; }
        QSpinBox#pageJump {
            background: #2a2a4a; color: #c0c0e0; border: 1px solid #3a3a5c;
            border-radius: 6px; padding: 3px 8px; min-height: 26px; max-width: 90px;
        }
        #zoomBtn {
            background: #2a2a4a; color: #c0c0e0; border: 1px solid #3a3a5c;
            border-radius: 6px; padding: 4px 10px; font-size: 14px; min-width: 28px;
        }
        #zoomBtn:hover { background: #3a3a5c; color: #fff; }
        #fitBtn {
            background: #2a2a4a; color: #a0a0c0; border: 1px solid #3a3a5c;
            border-radius: 6px; padding: 4px 10px; font-size: 12px;
        }
        #fitBtn:hover { background: #3a3a5c; }
        #fitBtn:checked { background: #7c6af7; color: white; border-color: #7c6af7; }
        QSlider#zoomSlider::groove:horizontal { height: 3px; background: #3a3a5c; border-radius: 2px; }
        QSlider#zoomSlider::sub-page:horizontal { background: #7c6af7; border-radius: 2px; }
        QSlider#zoomSlider::handle:horizontal {
            background: #7c6af7; width: 12px; height: 12px; margin: -5px 0; border-radius: 6px;
        }
        #zoomLabel { color: #a0a0c0; font-size: 11px; min-width: 40px; }
        #scrollArea { background: #2a2a35; border: none; }
        #extractedText { background: #1a1a2e; color: #c0c0e0; border: none;
                         font-size: 13px; padding: 12px; }
    """

    def __init__(self):
        super().__init__()
        self.pdf_doc = None
        self.current_page = 0
        self.extracted_text = ""
        self.scale_factor = 1.0
        self.fit_to_page_enabled = False
        self.init_ui()

    def init_ui(self):
        self.setStyleSheet(self._STYLE)
        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        tb = QWidget(); tb.setObjectName("toolbar")
        tl = QHBoxLayout(tb); tl.setContentsMargins(10, 4, 10, 4); tl.setSpacing(6)

        self.loadBtn = QPushButton("📂 Open PDF"); self.loadBtn.setObjectName("loadBtn")
        self.prevBtn = QPushButton("◀ Prev");     self.prevBtn.setObjectName("navBtn")
        self.nextBtn = QPushButton("Next ▶");     self.nextBtn.setObjectName("navBtn")
        self.pageLabel = QLabel("— / —");         self.pageLabel.setObjectName("pageLabel")
        self.pageJumpInput = QSpinBox();           self.pageJumpInput.setObjectName("pageJump")
        self.pageJumpInput.setMinimum(1); self.pageJumpInput.setPrefix("p ")
        self.ocrBtn    = QPushButton("⊞ Extract Text"); self.ocrBtn.setObjectName("ocrBtn")
        self.fitBtn    = QPushButton("Fit");             self.fitBtn.setObjectName("fitBtn")
        self.fitBtn.setCheckable(True)
        self.zoomOutBtn = QPushButton("−");              self.zoomOutBtn.setObjectName("zoomBtn")
        self.zoomInBtn  = QPushButton("+");              self.zoomInBtn.setObjectName("zoomBtn")
        self.resetZoomBtn = QPushButton("100%");         self.resetZoomBtn.setObjectName("zoomBtn")
        self.zoomSlider = QSlider(Qt.Horizontal); self.zoomSlider.setObjectName("zoomSlider")
        self.zoomSlider.setRange(25, 400); self.zoomSlider.setValue(100); self.zoomSlider.setFixedWidth(110)
        self.zoomLabel = QLabel("100%"); self.zoomLabel.setObjectName("zoomLabel")
        self.zoomSlider.valueChanged.connect(lambda v: self.zoomLabel.setText(f"{v}%"))

        for w in [self.loadBtn, self.prevBtn, self.pageLabel, self.nextBtn,
                  self.pageJumpInput, self.ocrBtn]:
            tl.addWidget(w)
        tl.addStretch()
        for w in [self.fitBtn, self.zoomOutBtn, self.zoomSlider,
                  self.zoomLabel, self.zoomInBtn, self.resetZoomBtn]:
            tl.addWidget(w)
        root.addWidget(tb)

        self.scrollArea = QScrollArea(); self.scrollArea.setObjectName("scrollArea")
        self.pageImage = QLabel(); self.pageImage.setAlignment(Qt.AlignCenter)
        self.pageImage.setStyleSheet("background:#2a2a35;")
        self.scrollArea.setWidget(self.pageImage)
        self.scrollArea.setWidgetResizable(True)
        self.pageImage.installEventFilter(self)
        root.addWidget(self.scrollArea, 1)

        self.textView = QTextEdit(); self.textView.setObjectName("extractedText")
        self.textView.setReadOnly(True); self.textView.hide()
        self.textView.setMaximumHeight(200)
        root.addWidget(self.textView)

        self.loadBtn.clicked.connect(self.load_pdf)
        self.prevBtn.clicked.connect(self.prev_page)
        self.nextBtn.clicked.connect(self.next_page)
        self.ocrBtn.clicked.connect(self.extract_text_with_ocr)
        self.fitBtn.toggled.connect(self.toggle_fit_to_page)
        self.zoomInBtn.clicked.connect(lambda: self.adjust_zoom(1.15))
        self.zoomOutBtn.clicked.connect(lambda: self.adjust_zoom(0.87))
        self.resetZoomBtn.clicked.connect(self.reset_zoom)
        self.zoomSlider.valueChanged.connect(self.slider_zoom_changed)
        self.pageJumpInput.editingFinished.connect(self.jump_to_page)
        QShortcut(QKeySequence(Qt.Key_Left),  self).activated.connect(self.prev_page)
        QShortcut(QKeySequence(Qt.Key_Right), self).activated.connect(self.next_page)


    def load_pdf(self):
        file_path, _ = QFileDialog.getOpenFileName(
            self, "Open PDF", "", "PDF Files (*.pdf)"
        )
        if file_path:
            try:
                self.pdf_doc = fitz.open(file_path)
                self.current_page = 0
                total = len(self.pdf_doc)
                self.pageLabel.setText(f"Page: 1/{total}")
                self.pageJumpInput.setMaximum(total)
                self.pageJumpInput.setValue(1)
                self.scale_factor = 1.0
                self.zoomSlider.setValue(100)
                self.show_page()
                self.extracted_text = ""
                self.textView.setPlainText("")
                self.textView.hide()
            except fitz.FileDataError as fde:
                QMessageBox.warning(self, "PDF Error", f"Corrupted or invalid PDF: {str(fde)}")
            except Exception as e:
                QMessageBox.warning(self, "Load Error", f"Failed to load PDF: {str(e)}")

    def show_page(self):
        """Render the current page to a pixmap and display scaled according to
        scale_factor or fit-to-page setting.
        """
        if self.pdf_doc:
            page = self.pdf_doc[self.current_page]
            base_dpi = 150
            zoom = self.scale_factor
            mat = fitz.Matrix(base_dpi/72 * zoom, base_dpi/72 * zoom)
            pix = page.get_pixmap(matrix=mat)
            img_format = QImage.Format_RGBA8888 if pix.alpha else QImage.Format_RGB888
            img = QImage(pix.samples, pix.width, pix.height, pix.stride, img_format).copy()
            qpix = QPixmap.fromImage(img)

            if self.fit_to_page_enabled and self.scrollArea.viewport().size().width() > 0:
                viewport_size = self.scrollArea.viewport().size()
                qpix = qpix.scaled(viewport_size, Qt.KeepAspectRatio, Qt.SmoothTransformation)

            self.pageImage.setPixmap(qpix)
            total = len(self.pdf_doc)
            self.pageLabel.setText(f"Page: {self.current_page + 1}/{total}")
            self.pageJumpInput.blockSignals(True)
            self.pageJumpInput.setValue(self.current_page + 1)
            self.pageJumpInput.blockSignals(False)

    def prev_page(self):
        if self.current_page > 0:
            self.current_page -= 1
            self.show_page()

    def next_page(self):
        if self.pdf_doc and self.current_page < len(self.pdf_doc) - 1:
            self.current_page += 1
            self.show_page()

    def jump_to_page(self):
        if self.pdf_doc:
            target = self.pageJumpInput.value() - 1
            target = max(0, min(target, len(self.pdf_doc) - 1))
            self.current_page = target
            self.show_page()

    def extract_text_with_ocr(self):
        if self.pdf_doc:
            text = ""
            ocr_failed_pages = []
            for page_num in range(len(self.pdf_doc)):
                page = self.pdf_doc.load_page(page_num)
                plain_text = page.get_text("text")
                if '\ufffd' in plain_text or len(plain_text.strip()) < 10:
                    try:
                        tp = page.get_textpage_ocr(flags=fitz.TEXT_PRESERVE_WHITESPACE, language="eng")
                        page_text = page.get_text("text", textpage=tp)
                    except RuntimeError as re:
                        if "tesseract" in str(re).lower():
                            QMessageBox.warning(self, "OCR Error", "Tesseract OCR engine not found or not installed properly. Please install Tesseract and ensure it's in your PATH.")
                            return
                        else:
                            ocr_failed_pages.append(page_num + 1)
                            page_text = plain_text
                    except Exception as ocr_err:
                        ocr_failed_pages.append(page_num + 1)
                        page_text = plain_text
                else:
                    page_text = plain_text
                text += f"Page {page_num+1}:\n{page_text}\n\n"
            if ocr_failed_pages:
                QMessageBox.warning(self, "OCR Warning", f"OCR failed on pages: {', '.join(map(str, ocr_failed_pages))}. Fell back to plain text extraction.")
            self.extracted_text = text
            self.textView.setPlainText(text)
            self.textView.show()

    def toggle_fit_to_page(self, enabled: bool):
        self.fit_to_page_enabled = enabled
        if enabled:
            # When fitting to page, we ignore manual zoom scaling until the user disables fit
            self.show_page()
        else:
            # restore zoom-based rendering
            self.show_page()

    def adjust_zoom(self, factor):
        """Adjust zoom by multiplier factor (e.g., 1.1 for +10%)"""
        self.scale_factor *= factor
        # clamp
        self.scale_factor = max(0.25, min(5.0, self.scale_factor))
        # update slider to reflect percent
        self.zoomSlider.blockSignals(True)
        self.zoomSlider.setValue(int(self.scale_factor * 100))
        self.zoomSlider.blockSignals(False)
        self.fitBtn.setChecked(False)
        self.fit_to_page_enabled = False
        self.show_page()

    def reset_zoom(self):
        self.scale_factor = 1.0
        self.zoomSlider.setValue(100)
        self.fitBtn.setChecked(False)
        self.fit_to_page_enabled = False
        self.show_page()

    def slider_zoom_changed(self, percent):
        self.scale_factor = percent / 100.0
        self.fitBtn.setChecked(False)
        self.fit_to_page_enabled = False
        self.show_page()

    # Event filter to capture wheel events on pageImage for zooming
    def eventFilter(self, obj, event):
        if obj is self.pageImage and event.type() == QEvent.Wheel:
            # Zoom with Ctrl+wheels or plain wheel — you can change behavior as desired
            delta = event.angleDelta().y()
            if delta > 0:
                self.adjust_zoom(1.08)
            else:
                self.adjust_zoom(0.92)
            return True
        return super().eventFilter(obj, event)

# ---------------------------------------------------------------------------
# VideoConferenceTab: embed web clients (Zoom/Meet/custom) and local recording
# ---------------------------------------------------------------------------

class VideoConferenceTab(QWidget):
    """Modern video conference tab with dark UI — in-app browser + recording panel."""

    _STYLE = """
        VideoConferenceTab { background: #0f0f1a; }
        #topBar { background: #1a1a2e; border-bottom: 1px solid #2a2a4a; padding: 8px 12px; }
        #platformCombo {
            background: #252540; color: #c0c0e0; border: 1px solid #3a3a5c;
            border-radius: 8px; padding: 5px 12px; min-height: 30px; min-width: 140px;
        }
        #urlInput {
            background: #252540; color: #e0e0f0; border: 1px solid #3a3a5c;
            border-radius: 8px; padding: 5px 14px; font-size: 13px; min-height: 30px;
        }
        #urlInput:focus { border-color: #7c6af7; }
        #joinBtn {
            background: #7c6af7; color: white; border: none;
            border-radius: 8px; padding: 6px 20px; font-size: 13px; font-weight: bold;
        }
        #joinBtn:hover { background: #9580ff; }
        #extBtn {
            background: #252540; color: #a0a0c0; border: 1px solid #3a3a5c;
            border-radius: 8px; padding: 6px 14px; font-size: 13px;
        }
        #extBtn:hover { background: #3a3a5c; color: #ffffff; }
        #recordPanel {
            background: #1a1a2e; border-top: 1px solid #2a2a4a; padding: 10px 16px;
        }
        #recLabel { color: #8080a0; font-size: 12px; }
        #recStatus { color: #60c060; font-size: 12px; font-style: italic; }
        #recStatusErr { color: #ff6060; font-size: 12px; font-style: italic; }
        QComboBox#resCombo {
            background: #252540; color: #c0c0e0; border: 1px solid #3a3a5c;
            border-radius: 6px; padding: 3px 10px; min-height: 26px;
        }
        QSpinBox#fpsSpin {
            background: #252540; color: #c0c0e0; border: 1px solid #3a3a5c;
            border-radius: 6px; padding: 3px 8px; min-height: 26px;
        }
        QCheckBox#audioChk { color: #a0a0c0; font-size: 12px; }
        #recordBtn {
            background: #c0392b; color: white; border: none;
            border-radius: 8px; padding: 6px 18px; font-size: 13px; font-weight: bold;
            min-width: 130px;
        }
        #recordBtn:hover { background: #e74c3c; }
        #recordBtn:disabled { background: #3a2a2a; color: #806060; }
        #saveRecBtn {
            background: #252540; color: #a0a0c0; border: 1px solid #3a3a5c;
            border-radius: 8px; padding: 6px 14px; font-size: 12px;
        }
        #saveRecBtn:hover { background: #3a3a5c; color: #fff; }
    """

    def __init__(self):
        super().__init__()
        self.recording = False
        self.rec_writer = None
        self.record_timer = QTimer()
        self.record_timer.timeout.connect(self.capture_frame)
        self.recording_fps = 10
        self.record_resolution = None
        self.record_audio_only = False
        self.record_filepath = None
        self.init_ui()

    def init_ui(self):
        self.setStyleSheet(self._STYLE)
        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        # ── Top bar ────────────────────────────────────────────────────────
        top = QWidget(); top.setObjectName("topBar")
        tl = QHBoxLayout(top); tl.setContentsMargins(12, 4, 12, 4); tl.setSpacing(8)

        self.platformCombo = QComboBox(); self.platformCombo.setObjectName("platformCombo")
        self.platformCombo.addItems(["Zoom (web)", "Google Meet", "MS Teams", "YouTube (Lectures)", "Custom URL"])

        self.meetingInput = QLineEdit(); self.meetingInput.setObjectName("urlInput")
        self.meetingInput.setPlaceholderText("Paste meeting URL / room ID, or a YouTube lecture search…")

        self.joinBtn = QPushButton("▶  Join In-App"); self.joinBtn.setObjectName("joinBtn")
        self.externalBtn = QPushButton("↗  Open Browser"); self.externalBtn.setObjectName("extBtn")

        tl.addWidget(QLabel("Platform:")); tl.addWidget(self.platformCombo)
        tl.addWidget(self.meetingInput, 1)
        tl.addWidget(self.joinBtn); tl.addWidget(self.externalBtn)
        root.addWidget(top)

        # ── Web view ───────────────────────────────────────────────────────
        self.webView = QWebEngineView()
        self.webProfile, self.webPage = setup_web_engine_page(self.webView, "VideoConferenceProfile", self)
        self.webView.setHtml(self._splash_html())
        root.addWidget(self.webView, 1)

        # ── Recording panel ────────────────────────────────────────────────
        rec_panel = QWidget(); rec_panel.setObjectName("recordPanel")
        rl = QHBoxLayout(rec_panel); rl.setContentsMargins(12, 6, 12, 6); rl.setSpacing(12)

        rec_lbl = QLabel("⬤  REC"); rec_lbl.setObjectName("recLabel")

        self.resCombo = QComboBox(); self.resCombo.setObjectName("resCombo")
        self.resCombo.addItems(["View Size", "640×360 (SD)", "1280×720 (HD)", "1920×1080 (FHD)"])

        self.fpsSpin = QSpinBox(); self.fpsSpin.setObjectName("fpsSpin")
        self.fpsSpin.setRange(1, 60); self.fpsSpin.setValue(10); self.fpsSpin.setSuffix(" fps")

        self.audioOnlyCheck = QCheckBox("Audio only"); self.audioOnlyCheck.setObjectName("audioChk")

        self.recordBtn = QPushButton("⏺  Start Recording"); self.recordBtn.setObjectName("recordBtn")
        self.recordBtn.setEnabled(IMAGEIO_AVAILABLE)

        self.recStatusLabel = QLabel(
            "Ready" if IMAGEIO_AVAILABLE else "Install imageio+numpy to enable recording")
        self.recStatusLabel.setObjectName("recStatus")

        self.saveBtn = QPushButton("💾 Save…"); self.saveBtn.setObjectName("saveRecBtn")
        self.saveBtn.setEnabled(False)

        for w in [rec_lbl, QLabel("Res:"), self.resCombo,
                  QLabel("FPS:"), self.fpsSpin, self.audioOnlyCheck,
                  self.recordBtn, self.recStatusLabel]:
            rl.addWidget(w)
        rl.addStretch()
        rl.addWidget(self.saveBtn)
        root.addWidget(rec_panel)

        # Connections
        self.joinBtn.clicked.connect(self.join_in_app)
        self.externalBtn.clicked.connect(self.open_external)
        self.recordBtn.clicked.connect(self.toggle_recording)
        self.saveBtn.clicked.connect(self.save_recording_as)

    def _splash_html(self):
        return """
        <html><body style="margin:0;background:#0f0f1a;display:flex;
              align-items:center;justify-content:center;height:100vh;
              font-family:sans-serif;color:#606080;flex-direction:column;">
          <div style="font-size:64px;margin-bottom:20px">📹</div>
          <div style="font-size:18px;margin-bottom:8px;color:#a0a0c0">
            Video Conference</div>
          <div style="font-size:13px">Paste a meeting link above and click
            <b style="color:#7c6af7">Join In-App</b></div>
        </body></html>"""

    def get_url_for_platform(self, platform, text):
        if platform.startswith("Zoom"):
            return text if text.startswith("http") else f"https://zoom.us/j/{text}"
        elif platform.startswith("Google Meet"):
            return text if text.startswith("http") else f"https://meet.google.com/{text}"
        elif platform.startswith("MS Teams"):
            return text if text.startswith("http") else f"https://teams.microsoft.com/l/meetup-join/{text}"
        elif platform.startswith("YouTube"):
            return text if text.startswith("http") else (f"https://www.youtube.com/results?search_query={urllib.parse.quote_plus(text)}" if text else "https://www.youtube.com")
        return text if text.startswith("http") else f"https://{text}"

    def join_in_app(self):
        txt = self.meetingInput.text().strip()
        if not txt and not self.platformCombo.currentText().startswith("YouTube"):
            QMessageBox.information(self, "No link", "Please paste a meeting link or ID."); return
        self.webView.load(QUrl(self.get_url_for_platform(self.platformCombo.currentText(), txt)))

    def open_external(self):
        txt = self.meetingInput.text().strip()
        if not txt and not self.platformCombo.currentText().startswith("YouTube"):
            QMessageBox.information(self, "No link", "Please paste a meeting link or ID."); return
        url = self.get_url_for_platform(self.platformCombo.currentText(), txt)
        try:
            from PyQt5.QtGui import QDesktopServices
            QDesktopServices.openUrl(QUrl(url))
        except Exception:
            if sys.platform.startswith('win'):   os.startfile(url)
            elif sys.platform == 'darwin':       os.system(f"open '{url}'")
            else:                                os.system(f"xdg-open '{url}'")

    def toggle_recording(self):
        if not IMAGEIO_AVAILABLE:
            QMessageBox.warning(self, "Unavailable", "Install imageio & numpy first."); return
        if not self.recording:
            self.record_audio_only = self.audioOnlyCheck.isChecked()
            if self.record_audio_only:
                QMessageBox.information(self, "Audio-only not supported",
                    "Full audio capture requires FFmpeg integration.\n"
                    "Please uncheck 'Audio only' to record the screen instead.")
                return
            self.recording_fps = self.fpsSpin.value()
            rt = self.resCombo.currentText()
            if "×" in rt:
                parts = rt.replace("(","").replace(")","").split()
                dims = parts[0].split("×")
                try: self.record_resolution = (int(dims[0]), int(dims[1]))
                except Exception: self.record_resolution = None
            else:
                self.record_resolution = None
            ts = datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
            self.record_filepath = os.path.join(os.path.expanduser("~"), f"meeting_{ts}.mp4")
            self.rec_writer = None
            self.recording = True
            self.recordBtn.setText("⏹  Stop Recording")
            self.recStatusLabel.setText("● Recording…")
            interval_ms = max(33, int(1000 / self.recording_fps))
            self.record_timer.start(interval_ms)
        else:
            self.record_timer.stop()
            if self.rec_writer:
                try: self.rec_writer.close()
                except Exception: pass
            self.recording = False
            self.recordBtn.setText("⏺  Start Recording")
            if self.record_filepath and os.path.exists(self.record_filepath):
                self.recStatusLabel.setText(f"Saved → {os.path.basename(self.record_filepath)}")
                self.saveBtn.setEnabled(True)
            else:
                self.recStatusLabel.setText("No frames captured")

    def capture_frame(self, init=False):
        if not IMAGEIO_AVAILABLE or self.record_audio_only: return
        try:
            qpix = self.webView.grab()
            if qpix.isNull(): return
            if self.record_resolution:
                qpix = qpix.scaled(self.record_resolution[0], self.record_resolution[1],
                                   Qt.KeepAspectRatio, Qt.SmoothTransformation)
            arr = qimage_to_numpy(qpix.toImage())
            if self.rec_writer is None:
                try:
                    self.rec_writer = imageio.get_writer(
                        self.record_filepath, fps=self.recording_fps, codec='libx264', quality=8)
                except Exception:
                    self.rec_writer = imageio.get_writer(self.record_filepath, fps=self.recording_fps)
            self.rec_writer.append_data(arr)
        except Exception as e:
            self.record_timer.stop()
            if self.rec_writer:
                try: self.rec_writer.close()
                except Exception: pass
            self.recording = False
            self.recordBtn.setText("⏺  Start Recording")
            self.recStatusLabel.setText(f"Error: {e}")
            QMessageBox.warning(self, "Recording Error", str(e))

    def save_recording_as(self):
        if not self.record_filepath or not os.path.exists(self.record_filepath):
            QMessageBox.information(self, "No recording", "Nothing recorded yet."); return
        dst, _ = QFileDialog.getSaveFileName(self, "Save Recording", "", "MP4 (*.mp4);;All (*)")
        if dst:
            try:
                import shutil; shutil.copy(self.record_filepath, dst)
                QMessageBox.information(self, "Saved", "Recording saved.")
            except Exception as e:
                QMessageBox.warning(self, "Error", str(e))

class DrawingCanvas(QGraphicsView):
    def __init__(self):
        super().__init__()
        self.scene=QGraphicsScene(self); self.setScene(self.scene)
        self.setRenderHint(QPainter.Antialiasing); self.setRenderHint(QPainter.SmoothPixmapTransform)
        self.setViewportUpdateMode(QGraphicsView.SmartViewportUpdate); self.setTransformationAnchor(QGraphicsView.AnchorUnderMouse)
        self.setDragMode(QGraphicsView.NoDrag); self.setStyleSheet("background:#ffffff;border:none;")
        self.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded); self.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        self.canvas_pixmap=QPixmap(2000,1500); self.canvas_pixmap.fill(Qt.white)
        self.image_item=self.scene.addPixmap(self.canvas_pixmap); self.scene.setSceneRect(0,0,2000,1500)
        self.drawing=False; self.brushSize=2; self.brushColor=Qt.black; self.startPoint=QPointF(); self.endPoint=QPointF(); self.drawing_mode='Pencil'
        self.current_path=QPainterPath(); self.preview_item=QGraphicsPathItem(); self.preview_item.setZValue(1); self.scene.addItem(self.preview_item)
        self.pen=QPen(self.brushColor,self.brushSize,Qt.SolidLine,Qt.RoundCap,Qt.RoundJoin); self.preview_item.setPen(self.pen)
        self.history=[]; self.save_history(); QShortcut(QKeySequence.Undo,self).activated.connect(self.undo)

    def showEvent(self,event):
        super().showEvent(event)
        if not getattr(self,'_fitted',False): self.fitInView(self.scene.sceneRect(),Qt.KeepAspectRatio); self._fitted=True

    def set_drawing_mode(self,mode):
        self.drawing_mode=mode.strip().split()[-1] if mode.strip() else 'Pencil'

    def _effective_pen(self):
        """Return a pen whose committed raster width matches the on-screen brush width.

        The canvas is normally fit-to-view, so scene pixels can be substantially smaller
        than screen pixels.  Without compensating for that scale, a 2 px stroke is
        rasterized onto the 2000x1500 backing pixmap and then downscaled again, which
        makes parts of the ink appear to fade after the vector preview is removed.
        """
        pen = QPen(self.pen)
        scale = abs(self.transform().m11())
        if scale < 0.01:
            scale = 1.0
        pen.setWidthF(max(1.0, float(self.brushSize) / scale))
        pen.setCapStyle(Qt.RoundCap)
        pen.setJoinStyle(Qt.RoundJoin)
        return pen

    def _shape_path(self):
        p=QPainterPath(); a=self.startPoint; b=self.endPoint; mode=self.drawing_mode
        if mode=='Line': p.moveTo(a); p.lineTo(b)
        elif mode=='Rectangle': p.addRect(QRectF(a,b).normalized())
        elif mode=='Ellipse': p.addEllipse(QRectF(a,b).normalized())
        elif mode=='Triangle':
            r=QRectF(a,b).normalized(); p.moveTo(r.center().x(),r.top()); p.lineTo(r.left(),r.bottom()); p.lineTo(r.right(),r.bottom()); p.closeSubpath()
        elif mode=='Arrow':
            p.moveTo(a); p.lineTo(b); ang=math.atan2(b.y()-a.y(),b.x()-a.x()); size=15+self.brushSize
            p1=QPointF(b.x()-size*math.cos(ang-math.pi/6),b.y()-size*math.sin(ang-math.pi/6)); p2=QPointF(b.x()-size*math.cos(ang+math.pi/6),b.y()-size*math.sin(ang+math.pi/6))
            p.moveTo(b); p.lineTo(p1); p.moveTo(b); p.lineTo(p2)
        elif mode=='Star':
            r=QRectF(a,b).normalized(); cx,cy=r.center().x(),r.center().y(); rx,ry=r.width()/2,r.height()/2
            for i in range(10):
                radius=1.0 if i%2==0 else 0.42; ang=-math.pi/2+i*math.pi/5
                pt=QPointF(cx+rx*radius*math.cos(ang),cy+ry*radius*math.sin(ang))
                p.moveTo(pt) if i==0 else p.lineTo(pt)
            p.closeSubpath()
        return p

    def mousePressEvent(self,event):
        if event.button()!=Qt.LeftButton: return super().mousePressEvent(event)
        self.startPoint=self.mapToScene(event.pos()); self.endPoint=self.startPoint
        if self.drawing_mode=='Text':
            text,ok=QInputDialog.getText(self,"Insert Text","Text:")
            if ok and text:
                painter=QPainter(self.canvas_pixmap); painter.setPen(self.pen); painter.setFont(QFont("Arial",max(8,self.brushSize*4))); painter.drawText(self.startPoint,text); painter.end(); self.image_item.setPixmap(self.canvas_pixmap); self.save_history()
            return
        self.drawing=True
        self.preview_item.setPen(self._effective_pen())
        if self.drawing_mode=='Pencil': self.current_path=QPainterPath(self.startPoint); self.preview_item.setPath(self.current_path)

    def mouseMoveEvent(self,event):
        if not self.drawing: return super().mouseMoveEvent(event)
        self.endPoint=self.mapToScene(event.pos())
        if self.drawing_mode=='Pencil': self.current_path.lineTo(self.endPoint); self.preview_item.setPath(self.current_path)
        else: self.preview_item.setPath(self._shape_path())

    def mouseReleaseEvent(self,event):
        if event.button()!=Qt.LeftButton or not self.drawing: return super().mouseReleaseEvent(event)
        self.endPoint=self.mapToScene(event.pos()); self.drawing=False
        painter=QPainter(self.canvas_pixmap)
        painter.setRenderHint(QPainter.Antialiasing, True)
        painter.setRenderHint(QPainter.SmoothPixmapTransform, True)
        painter.setPen(self._effective_pen())
        if self.drawing_mode=='Pencil': painter.drawPath(self.current_path)
        else: painter.drawPath(self._shape_path())
        painter.end(); self.image_item.setPixmap(self.canvas_pixmap); self.preview_item.setPath(QPainterPath()); self.save_history()

    def save_history(self):
        if len(self.history)>=20:self.history.pop(0)
        self.history.append(self.canvas_pixmap.copy())
    def undo(self):
        if len(self.history)>1: self.history.pop(); self.canvas_pixmap=self.history[-1].copy(); self.image_item.setPixmap(self.canvas_pixmap)
    def clear_canvas(self):
        self.canvas_pixmap.fill(Qt.white); self.image_item.setPixmap(self.canvas_pixmap); self.history=[]; self.save_history()
    def save_image(self):
        path,_=QFileDialog.getSaveFileName(self,"Save Drawing","","PNG (*.png);;JPEG (*.jpg)")
        if path:self.canvas_pixmap.save(path)





class NotesAndDrawingTab(QWidget):
    """Modern split-panel: rich notes editor (left) + drawing canvas (right)."""

    _STYLE = """
        NotesAndDrawingTab { background: #f8f9fb; }
        /* Notes panel */
        #notesPanel { background: #ffffff; border-right: 1px solid #e5e7eb; }
        #notesToolbar { background: #f9fafb; border-bottom: 1px solid #e5e7eb; padding: 4px 8px; }
        #ntBtn { background: transparent; color: #374151; border: none;
                 border-radius: 5px; padding: 3px 9px; font-size: 13px; min-height: 24px; }
        #ntBtn:hover { background: #f3f4f6; }
        #notesEdit { border: none; font-size: 14px; background: #ffffff;
                     selection-background-color: #ddd6fe; padding: 8px; }
        #notesFooter { background: #f9fafb; border-top: 1px solid #e5e7eb; padding: 3px 10px; }
        #notesCount { color: #9ca3af; font-size: 11px; }
        #notesSaveBtn  { background: #6366f1; color: white; border: none;
                         border-radius: 5px; padding: 4px 12px; font-size: 12px; }
        #notesSaveBtn:hover { background: #4f46e5; }
        #notesLoadBtn  { background: #f3f4f6; color: #374151; border: 1px solid #d1d5db;
                         border-radius: 5px; padding: 4px 12px; font-size: 12px; }
        #notesLoadBtn:hover { background: #e5e7eb; }
        /* Drawing panel */
        #drawPanel { background: #1e1e2e; }
        #drawToolbar { background: #252535; border-bottom: 1px solid #3a3a5c; padding: 6px 10px; }
        #colorSwatch { border-radius: 12px; min-width: 24px; min-height: 24px;
                       max-width: 24px; max-height: 24px; border: 2px solid #5a5a7a; }
        #drawBtn { background: #2a2a4a; color: #c0c0e0; border: 1px solid #3a3a5c;
                   border-radius: 6px; padding: 4px 10px; font-size: 12px; }
        #drawBtn:hover { background: #3a3a5c; color: #fff; }
        #drawBtnAccent { background: #7c6af7; color: white; border: none;
                         border-radius: 6px; padding: 4px 10px; font-size: 12px; }
        #drawBtnAccent:hover { background: #9580ff; }
        #drawBtnDanger { background: #4a1e1e; color: #ff8080; border: 1px solid #6a2a2a;
                         border-radius: 6px; padding: 4px 10px; font-size: 12px; }
        #drawBtnDanger:hover { background: #5e2a2a; }
        QComboBox#shapeCombo { background: #2a2a4a; color: #c0c0e0; border: 1px solid #3a3a5c;
                               border-radius: 6px; padding: 3px 10px; min-height: 26px; }
        QSpinBox#sizeSpin { background: #2a2a4a; color: #c0c0e0; border: 1px solid #3a3a5c;
                            border-radius: 6px; padding: 3px 6px; max-width: 60px; }
    """

    def __init__(self):
        super().__init__()
        self.init_ui()

    def init_ui(self):
        self.setStyleSheet(self._STYLE)
        splitter = QSplitter(Qt.Horizontal)

        # ── LEFT: Notes ───────────────────────────────────────────────────
        notes_panel = QWidget(); notes_panel.setObjectName("notesPanel")
        nl = QVBoxLayout(notes_panel); nl.setContentsMargins(0, 0, 0, 0); nl.setSpacing(0)

        ntb = QWidget(); ntb.setObjectName("notesToolbar")
        ntl = QHBoxLayout(ntb); ntl.setContentsMargins(8, 2, 8, 2); ntl.setSpacing(2)

        def nt(label, tip, slot):
            b = QPushButton(label); b.setObjectName("ntBtn")
            b.setToolTip(tip); b.clicked.connect(slot); return b

        bold_b = nt("B",  "Bold (Ctrl+B)",
                    lambda: self.notesEdit.setFontWeight(
                        QFont.Normal if self.notesEdit.fontWeight() >= QFont.Bold else QFont.Bold))
        ital_b = nt("I",  "Italic (Ctrl+I)",
                    lambda: self.notesEdit.setFontItalic(not self.notesEdit.fontItalic()))
        undr_b = nt("U̲",  "Underline (Ctrl+U)",
                    lambda: self.notesEdit.setFontUnderline(not self.notesEdit.fontUnderline()))
        bull_b = nt("• List", "Bullet list",
                    lambda: self.notesEdit.insertHtml("<ul><li> </li></ul>"))
        num_b  = nt("1. List","Numbered list",
                    lambda: self.notesEdit.insertHtml("<ol><li> </li></ol>"))
        srch_b = nt("🔍", "Search", self.search_notes)

        for w in [bold_b, ital_b, undr_b, bull_b, num_b, srch_b]:
            ntl.addWidget(w)
        ntl.addStretch()
        nl.addWidget(ntb)

        self.notesEdit = QTextEdit(); self.notesEdit.setObjectName("notesEdit")
        self.notesEdit.setAcceptRichText(True)
        self.notesEdit.setPlaceholderText("Start writing your notes here…")
        self.notesEdit.textChanged.connect(self._update_note_count)
        nl.addWidget(self.notesEdit, 1)

        footer = QWidget(); footer.setObjectName("notesFooter")
        fl = QHBoxLayout(footer); fl.setContentsMargins(10, 4, 10, 4); fl.setSpacing(8)
        self.notesCount = QLabel("0 words"); self.notesCount.setObjectName("notesCount")
        self.notesLoadBtn = QPushButton("📂 Load"); self.notesLoadBtn.setObjectName("notesLoadBtn")
        self.notesSaveBtn = QPushButton("💾 Save"); self.notesSaveBtn.setObjectName("notesSaveBtn")
        fl.addWidget(self.notesCount); fl.addStretch()
        fl.addWidget(self.notesLoadBtn); fl.addWidget(self.notesSaveBtn)
        nl.addWidget(footer)

        # ── RIGHT: Drawing ────────────────────────────────────────────────
        draw_panel = QWidget(); draw_panel.setObjectName("drawPanel")
        dl = QVBoxLayout(draw_panel); dl.setContentsMargins(0, 0, 0, 0); dl.setSpacing(0)

        dtb = QWidget(); dtb.setObjectName("drawToolbar")
        dtl = QHBoxLayout(dtb); dtl.setContentsMargins(10, 4, 10, 4); dtl.setSpacing(6)

        self.colorSwatch = QPushButton(); self.colorSwatch.setObjectName("colorSwatch")
        self.colorSwatch.setStyleSheet("background:#000000; border-radius:12px;"
                                        "border:2px solid #5a5a7a;")
        self.colorSwatch.setFixedSize(24, 24)

        self.sizeSpin = QSpinBox(); self.sizeSpin.setObjectName("sizeSpin")
        self.sizeSpin.setRange(1, 50); self.sizeSpin.setValue(2); self.sizeSpin.setSuffix("px")

        self.shapeCombo = QComboBox(); self.shapeCombo.setObjectName("shapeCombo")
        self.shapeCombo.addItems(["✏ Pencil", "╱ Line", "▭ Rectangle", "◯ Ellipse", "△ Triangle", "★ Star", "➜ Arrow", "T Text"])

        eraserBtn = QPushButton("⌫ Eraser"); eraserBtn.setObjectName("drawBtn")
        eraserBtn.clicked.connect(self.set_eraser)
        undoBtn   = QPushButton("↩ Undo");   undoBtn.setObjectName("drawBtn")
        clearBtn  = QPushButton("🗑 Clear");  clearBtn.setObjectName("drawBtnDanger")
        saveBtn   = QPushButton("💾 Save");   saveBtn.setObjectName("drawBtnAccent")

        for w in [self.colorSwatch, self.sizeSpin, self.shapeCombo,
                  eraserBtn, undoBtn, clearBtn, saveBtn]:
            dtl.addWidget(w)
        dtl.addStretch()
        dl.addWidget(dtb)

        self.canvas = DrawingCanvas()
        dl.addWidget(self.canvas, 1)

        splitter.addWidget(notes_panel)
        splitter.addWidget(draw_panel)
        splitter.setStretchFactor(0, 1)
        splitter.setStretchFactor(1, 2)
        splitter.setSizes([400, 800])

        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)
        root.addWidget(splitter, 1)
        self.setLayout(root)

        # Connections
        self.colorSwatch.clicked.connect(self.choose_color)
        self.sizeSpin.valueChanged.connect(self.change_size)
        self.shapeCombo.currentTextChanged.connect(
            lambda t: self.canvas.set_drawing_mode(t.split()[-1]))
        undoBtn.clicked.connect(self.canvas.undo)
        clearBtn.clicked.connect(self.canvas.clear_canvas)
        saveBtn.clicked.connect(self.canvas.save_image)
        self.notesLoadBtn.clicked.connect(self.load_notes)
        self.notesSaveBtn.clicked.connect(self.save_notes)

        # Keyboard shortcuts for notes
        QShortcut(QKeySequence.Bold,      self.notesEdit).activated.connect(
            lambda: self.notesEdit.setFontWeight(
                QFont.Normal if self.notesEdit.fontWeight() >= QFont.Bold else QFont.Bold))
        QShortcut(QKeySequence.Italic,    self.notesEdit).activated.connect(
            lambda: self.notesEdit.setFontItalic(not self.notesEdit.fontItalic()))
        QShortcut(QKeySequence.Underline, self.notesEdit).activated.connect(
            lambda: self.notesEdit.setFontUnderline(not self.notesEdit.fontUnderline()))

    def _update_note_count(self):
        t = self.notesEdit.toPlainText()
        self.notesCount.setText(f"{len(t.split()) if t.strip() else 0} words")

    def choose_color(self):
        color = QColorDialog.getColor()
        if color.isValid():
            self.canvas.brushColor = color
            self.canvas.pen.setColor(color)
            self.canvas.preview_item.setPen(self.canvas.pen)
            self.colorSwatch.setStyleSheet(
                f"background:{color.name()};border-radius:12px;border:2px solid #5a5a7a;")

    def change_size(self, size):
        self.canvas.brushSize = size
        self.canvas.pen.setWidth(size)
        self.canvas.preview_item.setPen(self.canvas.pen)

    def set_eraser(self):
        self.canvas.brushColor = Qt.white
        self.canvas.pen.setColor(Qt.white)
        self.canvas.preview_item.setPen(self.canvas.pen)
        self.colorSwatch.setStyleSheet(
            "background:white;border-radius:12px;border:2px solid #5a5a7a;")

    def search_notes(self):
        query, ok = QInputDialog.getText(self, "Search Notes", "Search term:")
        if ok and query:
            cursor = self.notesEdit.textCursor()
            cursor.movePosition(QTextCursor.Start)
            self.notesEdit.setTextCursor(cursor)
            if not self.notesEdit.find(query):
                QMessageBox.information(self, "Search", f'"{query}" not found.')

    def load_notes(self):
        path, _ = QFileDialog.getOpenFileName(self, "Load Notes", "", "Text Files (*.txt *.rtf)")
        if path:
            try:
                with open(path, 'r', encoding='utf-8') as f:
                    self.notesEdit.setPlainText(f.read())
            except Exception as e:
                QMessageBox.warning(self, "Error", str(e))

    def save_notes(self):
        path, _ = QFileDialog.getSaveFileName(self, "Save Notes", "", "Text Files (*.txt)")
        if path:
            try:
                with open(path, 'w', encoding='utf-8') as f:
                    f.write(self.notesEdit.toPlainText())
            except Exception as e:
                QMessageBox.warning(self, "Error", str(e))

class SearchTab(QWidget):
    """Persistent multi-profile in-app browser with searchable address bar."""
    _STYLE="""
        SearchTab { background:#1e1e2e; } #navBar { background:#252535; border-bottom:1px solid #3a3a5c; }
        #backBtn,#fwdBtn,#reloadBtn,#homeBtn { background:transparent;color:#a0a0c0;border:none;border-radius:6px;font-size:16px;padding:4px 8px; }
        #backBtn:hover,#fwdBtn:hover,#reloadBtn:hover,#homeBtn:hover { background:#3a3a5c;color:white; }
        #urlBar,#searchBox,#profileCombo { background:#1a1a2e;color:#e0e0f0;border:1px solid #3a3a5c;border-radius:9px;padding:5px 12px;min-height:30px; }
        #searchBtn { background:#7c6af7;color:white;border:none;border-radius:8px;padding:6px 16px;font-weight:bold; }
        #quickBtn { background:#252535;color:#a0a0c0;border:1px solid #3a3a5c;border-radius:6px;padding:4px 10px; }
        #statusBar { background:#181828;color:#707090;font-size:11px;padding:3px 10px; }
    """
    QUICK_LINKS=[("Google","https://www.google.com"),("YouTube","https://www.youtube.com"),("Wikipedia","https://www.wikipedia.org"),("GitHub","https://www.github.com"),("YT Music","https://music.youtube.com")]

    def __init__(self):
        super().__init__(); self.profiles=["DefaultProfile","Personal","Work","Study"]; self.profile=None; self.page=None; self.init_ui()

    def init_ui(self):
        self.setStyleSheet(self._STYLE); root=QVBoxLayout(self); root.setContentsMargins(0,0,0,0); root.setSpacing(0)
        nav=QWidget(); nav.setObjectName("navBar"); nl=QHBoxLayout(nav); nl.setContentsMargins(8,5,8,5); nl.setSpacing(4)
        self.backBtn=QPushButton("◀"); self.backBtn.setObjectName("backBtn"); self.fwdBtn=QPushButton("▶"); self.fwdBtn.setObjectName("fwdBtn")
        self.reloadBtn=QPushButton("↻"); self.reloadBtn.setObjectName("reloadBtn"); self.homeBtn=QPushButton("⌂"); self.homeBtn.setObjectName("homeBtn")
        self.profileCombo=QComboBox(); self.profileCombo.setObjectName("profileCombo"); self.profileCombo.addItems(self.profiles+["+ Add profile…"]); self.profileCombo.setFixedWidth(140)
        self.urlBar=QLineEdit(); self.urlBar.setObjectName("urlBar"); self.urlBar.setPlaceholderText("Enter URL or search term…")
        for w in (self.backBtn,self.fwdBtn,self.reloadBtn,self.homeBtn,self.profileCombo): nl.addWidget(w)
        nl.addWidget(self.urlBar,1); root.addWidget(nav)
        row=QWidget(); rl=QHBoxLayout(row); rl.setContentsMargins(10,6,10,6); rl.setSpacing(6)
        self.searchBox=QLineEdit(); self.searchBox.setObjectName("searchBox"); self.searchBox.setPlaceholderText("Search Google…")
        self.searchBtn=QPushButton("Search"); self.searchBtn.setObjectName("searchBtn"); rl.addWidget(self.searchBox,1); rl.addWidget(self.searchBtn)
        for label,url in self.QUICK_LINKS:
            b=QPushButton(label); b.setObjectName("quickBtn"); b.clicked.connect(lambda _,u=url:self.browser.load(QUrl(u))); rl.addWidget(b)
        quick_scroll=QScrollArea(); quick_scroll.setWidgetResizable(True); quick_scroll.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff); quick_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded); quick_scroll.setFixedHeight(54); row.setMinimumWidth(row.sizeHint().width()); quick_scroll.setWidget(row); root.addWidget(quick_scroll)
        self.browser=QWebEngineView(); self.profile,self.page=setup_web_engine_page(self.browser,"DefaultProfile",self); root.addWidget(self.browser,1)
        self.statusBar=QLabel("Ready"); self.statusBar.setObjectName("statusBar"); root.addWidget(self.statusBar)
        self.searchBtn.clicked.connect(self.perform_search); self.searchBox.returnPressed.connect(self.perform_search); self.urlBar.returnPressed.connect(self.navigate_to_url)
        self.backBtn.clicked.connect(self.browser.back); self.fwdBtn.clicked.connect(self.browser.forward); self.reloadBtn.clicked.connect(self.browser.reload); self.homeBtn.clicked.connect(lambda:self.browser.load(QUrl("https://www.google.com")))
        self.profileCombo.currentIndexChanged.connect(self.on_profile_changed)
        self.browser.urlChanged.connect(lambda u:self.urlBar.setText(u.toString())); self.browser.loadStarted.connect(lambda:self.statusBar.setText("Loading…")); self.browser.loadFinished.connect(lambda ok:self.statusBar.setText(self.browser.title() if ok else "Failed to load"))
        self.browser.load(QUrl("https://www.google.com"))

    def on_profile_changed(self,index):
        selected=self.profileCombo.currentText()
        if selected=="+ Add profile…":
            name,ok=QInputDialog.getText(self,"New browser profile","Profile name:")
            clean=re.sub(r'[^A-Za-z0-9_.-]+','_',name.strip()) if ok else ''
            if not clean: self.profileCombo.setCurrentIndex(0); return
            if clean not in self.profiles: self.profiles.append(clean); self.profileCombo.insertItem(len(self.profiles)-1,clean)
            selected=clean; self.profileCombo.blockSignals(True); self.profileCombo.setCurrentText(clean); self.profileCombo.blockSignals(False)
        current=self.browser.url(); self.profile,self.page=setup_web_engine_page(self.browser,selected,self)
        self.browser.load(current if current.isValid() and current.toString()!='about:blank' else QUrl("https://www.google.com"))

    def perform_search(self):
        q=self.searchBox.text().strip()
        if q:self.browser.load(QUrl("https://www.google.com/search?q="+urllib.parse.quote_plus(q)))
    def navigate_to_url(self):
        text=self.urlBar.text().strip()
        if not text:return
        if text.startswith(('http://','https://')): url=text
        elif '.' in text and ' ' not in text: url='https://'+text
        else: url='https://www.google.com/search?q='+urllib.parse.quote_plus(text)
        self.browser.load(QUrl(url))




class ThemesTab(QWidget):
    """Visual theme picker — click a card to apply, or mix your own."""

    # (name, bg, accent, text, description)
    THEMES = [
        ("☀  Light",     "#f5f5f5", "#0078d4", "#1a1a1a",
         "Clean, minimal — great for daytime use."),
        ("🌙  Dark",      "#2b2b2b", "#6e9fd1", "#f0f0f0",
         "Dark IDE-style — easy on the eyes at night."),
        ("🌊  Ocean",     "#1a2a3a", "#2d7ab5", "#cce8ff",
         "Deep blue ocean with cool tones."),
        ("🌿  Forest",    "#1e2b1e", "#4a7a4a", "#c8e6c8",
         "Dark forest green — calm and focused."),
        ("🔆  Solarized", "#002b36", "#268bd2", "#839496",
         "Classic Solarized dark palette."),
        ("🟣  Violet",    "#1a1a2e", "#7c6af7", "#c0c0e0",
         "Purple/indigo — rich and modern."),
        ("🌸  Rose",      "#1a0a12", "#e05090", "#f0c0d0",
         "Rose-pink accent on a deep dark base."),
        ("🔥  Ember",     "#1a1008", "#e0820a", "#f0d0a0",
         "Warm amber glow — cozy and energising."),
    ]

    def __init__(self, parent):
        super().__init__()
        self._main_parent = parent
        self._active_name = "☀  Light"
        # Store default stylesheet so we can restore Light theme
        self._default_style = ""
        self.init_ui()

    def init_ui(self):
        # ThemesTab itself stays neutral — no per-widget overrides
        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.setSpacing(0)

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QScrollArea.NoFrame)

        container = QWidget()
        root = QVBoxLayout(container)
        root.setContentsMargins(32, 28, 32, 28)
        root.setSpacing(22)

        # ── Header ────────────────────────────────────────────────────────
        hdr = QLabel("Appearance")
        hdr.setFont(QFont("Segoe UI", 18, QFont.Bold))
        sub = QLabel("Choose a theme — changes apply instantly to the app chrome.")
        sub.setStyleSheet("color: #6b7280; font-size: 13px;")
        root.addWidget(hdr)
        root.addWidget(sub)

        # ── Card grid ─────────────────────────────────────────────────────
        presets_lbl = QLabel("Presets")
        presets_lbl.setFont(QFont("Segoe UI", 11, QFont.Bold))
        root.addWidget(presets_lbl)

        self._card_btns = {}
        # Use a flow-style grid: 2 rows × 4 cols
        grid = QGridLayout()
        grid.setSpacing(14)
        grid.setColumnStretch(0, 1); grid.setColumnStretch(1, 1)
        grid.setColumnStretch(2, 1); grid.setColumnStretch(3, 1)

        for i, (name, bg, accent, text_col, desc) in enumerate(self.THEMES):
            card = self._make_card(name, bg, accent, text_col, desc)
            self._card_btns[name] = card
            grid.addWidget(card, i // 4, i % 4)

        root.addLayout(grid)

        # ── Custom colours ────────────────────────────────────────────────
        cust_lbl = QLabel("Custom Colours")
        cust_lbl.setFont(QFont("Segoe UI", 11, QFont.Bold))
        root.addWidget(cust_lbl)

        cust_row = QHBoxLayout()
        cust_row.setSpacing(10)

        self.bgBtn  = QPushButton("🎨  Background")
        self.txtBtn = QPushButton("✏  Text Colour")
        self.wpBtn  = QPushButton("🖼  Wallpaper")
        self.activeLabel = QLabel(f"Active: {self._active_name}")
        self.activeLabel.setStyleSheet("color: #6b7280; font-size: 12px; font-style: italic;")

        for btn in [self.bgBtn, self.txtBtn, self.wpBtn]:
            btn.setStyleSheet(
                "QPushButton { background: #f3f4f6; color: #374151; "
                "border: 1px solid #d1d5db; border-radius: 8px; "
                "padding: 7px 16px; font-size: 12px; }"
                "QPushButton:hover { background: #e5e7eb; }")
            cust_row.addWidget(btn)

        cust_row.addStretch()
        cust_row.addWidget(self.activeLabel)
        root.addLayout(cust_row)
        root.addStretch()

        scroll.setWidget(container)
        outer.addWidget(scroll)

        self.bgBtn.clicked.connect(self.choose_bg_color)
        self.txtBtn.clicked.connect(self.choose_text_color)
        self.wpBtn.clicked.connect(self.set_wallpaper)

    def _make_card(self, name, bg, accent, text_col, desc):
        """Build a theme preview card as a QWidget (not QPushButton) to avoid
        text-clipping issues and allow multi-line layout."""
        card = QWidget()
        card.setMinimumHeight(120)
        card.setCursor(Qt.PointingHandCursor)
        card.setStyleSheet(f"""
            QWidget {{
                background: qlineargradient(x1:0,y1:0,x2:1,y2:1,
                    stop:0 {bg}, stop:1 {accent});
                border-radius: 12px;
                border: 2px solid {accent};
            }}
            QWidget:hover {{ border: 3px solid white; }}
        """)

        vl = QVBoxLayout(card)
        vl.setContentsMargins(16, 16, 16, 16)
        vl.setSpacing(6)

        name_lbl = QLabel(name)
        name_lbl.setStyleSheet(
            f"color: {text_col}; font-size: 14px; font-weight: bold; "
            "background: transparent; border: none;")
        name_lbl.setAlignment(Qt.AlignCenter)

        desc_lbl = QLabel(desc)
        desc_lbl.setWordWrap(True)
        desc_lbl.setStyleSheet(
            f"color: {text_col}; font-size: 11px; opacity: 0.85; "
            "background: transparent; border: none;")
        desc_lbl.setAlignment(Qt.AlignCenter)

        vl.addStretch()
        vl.addWidget(name_lbl)
        vl.addWidget(desc_lbl)
        vl.addStretch()

        # Make the whole card clickable via mouse press event
        card._theme_args = (name, bg, accent, text_col)
        card.mousePressEvent = lambda e, c=card: self._on_card_click(c)
        return card

    def _on_card_click(self, card):
        name, bg, accent, text_col = card._theme_args
        self._apply(name, bg, accent, text_col)

    def _build_stylesheet(self, bg, accent, text):
        """
        Build a stylesheet that ONLY touches the app chrome:
          - QMainWindow background
          - Main tab bar colours + selected underline
          - QStatusBar
          - Thin scrollbars
        It deliberately avoids QPushButton, QLineEdit, QTextEdit, QLabel, etc.
        so every tab's own _STYLE stays fully intact and unbroken.
        """
        return f"""
            QMainWindow {{
                background-color: {bg};
            }}
            QTabWidget#mainTabs::pane {{
                border: none;
                background-color: {bg};
            }}
            QTabWidget#mainTabs > QTabBar {{
                background: {bg};
                border-bottom: 2px solid {accent}55;
            }}
            QTabWidget#mainTabs > QTabBar::tab {{
                background: transparent;
                color: {text};
                padding: 10px 18px;
                border: none;
                border-bottom: 2px solid transparent;
                font-size: 12px;
                min-width: 90px;
            }}
            QTabWidget#mainTabs > QTabBar::tab:selected {{
                color: {accent};
                font-weight: bold;
                border-bottom: 2px solid {accent};
            }}
            QTabWidget#mainTabs > QTabBar::tab:hover {{
                color: {accent};
                opacity: 0.8;
            }}
            QStatusBar {{
                background: {bg};
                color: {text};
                font-size: 11px;
                border-top: 1px solid {accent}33;
            }}
        """

    def _apply(self, name, bg, accent, text):
        self._active_name = name
        self.activeLabel.setText(f"Active: {name}")

        # Highlight selected card, un-highlight others
        for n, card in self._card_btns.items():
            _, c_bg, c_accent, c_text, _ = next(t for t in self.THEMES if t[0] == n)
            border = "3px solid white" if n == name else f"2px solid {c_accent}"
            card.setStyleSheet(f"""
                QWidget {{
                    background: qlineargradient(x1:0,y1:0,x2:1,y2:1,
                        stop:0 {c_bg}, stop:1 {c_accent});
                    border-radius: 12px; border: {border};
                }}
                QWidget:hover {{ border: 3px solid white; }}
            """)

        if name == "☀  Light":
            # Restore the default light style on the MainWindow
            self._main_parent.setStyleSheet(self._default_style)
            # Also restore the tab widget's own stylesheet
            self._main_parent.tabs.setStyleSheet(self._main_parent._tab_style)
        else:
            # Apply chrome-only theme to MainWindow, preserving tab widget own style
            self._main_parent.setStyleSheet(self._build_stylesheet(bg, accent, text))
            # Update tab bar colours to match theme
            self._main_parent.tabs.setStyleSheet(f"""
                QTabWidget::pane {{ border: none; background: {bg}; }}
                QTabBar {{ background: {bg}; border-bottom: 2px solid {accent}55; }}
                QTabBar::tab {{
                    background: transparent; color: {text};
                    padding: 10px 18px; margin-right: 1px;
                    border: none; border-bottom: 2px solid transparent;
                    font-size: 12px; min-width: 90px;
                }}
                QTabBar::tab:selected {{
                    color: {accent}; font-weight: bold;
                    border-bottom: 2px solid {accent};
                }}
                QTabBar::tab:hover {{ color: {accent}; }}
                QTabBar::scroller {{ width: 20px; }}
            """)

    def choose_bg_color(self):
        color = QColorDialog.getColor()
        if color.isValid():
            self._main_parent.setStyleSheet(
                self._main_parent.styleSheet() +
                f" QMainWindow {{ background-color: {color.name()}; }}")
            self.activeLabel.setText("Active: Custom")

    def choose_text_color(self):
        color = QColorDialog.getColor()
        if color.isValid():
            # Only change QStatusBar and QTabBar text — not all widgets
            self._main_parent.setStyleSheet(
                self._main_parent.styleSheet() +
                f" QStatusBar {{ color: {color.name()}; }}"
                f" QTabBar::tab {{ color: {color.name()}; }}")
            self.activeLabel.setText("Active: Custom")

    def set_wallpaper(self):
        path, _ = QFileDialog.getOpenFileName(
            self, "Select Wallpaper", "", "Images (*.png *.jpg *.jpeg)")
        if path:
            palette = self._main_parent.palette()
            img = QImage(path).scaled(
                self._main_parent.size(),
                Qt.KeepAspectRatioByExpanding, Qt.SmoothTransformation)
            palette.setBrush(QPalette.Window, QBrush(QPixmap.fromImage(img)))
            self._main_parent.setPalette(palette)

# ===========================================================================
# Desktop-Pro enhancements
# ===========================================================================

class EnhancedDocumentTab(DocumentTab):
    STYLE_MAP = {
        "Normal": (11, False, False, "#111827"), "Title": (26, True, False, "#1f4e79"),
        "Subtitle": (14, False, True, "#5b6573"), "Heading 1": (20, True, False, "#2f5597"),
        "Heading 2": (16, True, False, "#4472c4"), "Heading 3": (13, True, False, "#5b9bd5"),
        "Quote": (12, False, True, "#666666")
    }
    def __init__(self):
        self.header_text=""; self.footer_text=""; self.footnotes=[]
        super().__init__(); self._upgrade_writer()
    def _upgrade_writer(self):
        self.textEdit.document().setPageSize(QSizeF(595,842))
        self.paper=self.pageFrame
        self.pageFrame.setMinimumWidth(760); self.pageFrame.setMaximumWidth(900)
        # rebuild ribbon additions without disturbing existing controls
        ribbon=self.ribbonScroll.widget(); lay=ribbon.layout()
        self.styleCombo=QComboBox(); self.styleCombo.addItems(self.STYLE_MAP.keys()); self.styleCombo.setFixedWidth(110); self.styleCombo.currentTextChanged.connect(self.apply_named_style)
        lay.insertWidget(0,self.styleCombo)
        def add(text,tip,fn):
            b=QPushButton(text); b.setObjectName('toolBtn'); b.setToolTip(tip); b.clicked.connect(fn); lay.insertWidget(max(0,lay.count()-1),b); return b
        add('▯ New Page','Insert a page break',self.insert_page_break)
        add('¹ Footnote','Insert a footnote',self.insert_footnote)
        add('Header/Footer','Set document header and footer',self.edit_header_footer)
        add('Σ Table','Sum numeric values in the current table column',self.table_sum_column)
        add('🖨 Print','Print document',self.print_document)
        add('Preview','Print preview',self.print_preview)
        ribbon.setMinimumWidth(max(1900,ribbon.sizeHint().width()))
        self.pageStatus=QLabel('Page 1 of 1'); self.pageStatus.setObjectName('wordCount'); self.zoomLabel.parent().layout().insertWidget(1,self.pageStatus)
        self.textEdit.cursorPositionChanged.connect(self.update_page_status); self.textEdit.textChanged.connect(self.update_page_status)
    def apply_named_style(self,name):
        if name not in self.STYLE_MAP:return
        size,bold,italic,color=self.STYLE_MAP[name]; c=self.textEdit.textCursor(); c.select(QTextCursor.BlockUnderCursor)
        fmt=QTextCharFormat(); fmt.setFontPointSize(size); fmt.setFontWeight(QFont.Bold if bold else QFont.Normal); fmt.setFontItalic(italic); fmt.setForeground(QColor(color)); c.mergeCharFormat(fmt)
        bf=c.blockFormat(); bf.setTopMargin(8 if name.startswith('Heading') or name=='Title' else 2); bf.setBottomMargin(5); c.setBlockFormat(bf)
    def insert_page_break(self):
        c=self.textEdit.textCursor(); c.insertBlock(); bf=c.blockFormat(); bf.setPageBreakPolicy(QTextFormat.PageBreak_AlwaysBefore); c.setBlockFormat(bf); self.textEdit.setTextCursor(c); self.update_page_status()
    def update_page_status(self):
        try:
            pages=max(1,int(self.textEdit.document().pageCount())); y=self.textEdit.cursorRect().top()+self.textEdit.verticalScrollBar().value(); p=max(1,min(pages,int(y/842)+1)); self.pageStatus.setText(f'Page {p} of {pages}')
        except Exception: pass
    def insert_footnote(self):
        note,ok=QInputDialog.getMultiLineText(self,'Footnote','Footnote text:')
        if not ok or not note.strip():return
        n=len(self.footnotes)+1; self.footnotes.append(note.strip()); c=self.textEdit.textCursor(); f=QTextCharFormat(); f.setVerticalAlignment(QTextCharFormat.AlignSuperScript); f.setFontPointSize(8); c.insertText(str(n),f)
        end=QTextCursor(self.textEdit.document()); end.movePosition(QTextCursor.End); end.insertHtml(f'<hr><p><sup>{n}</sup> {note}</p>')
    def edit_header_footer(self):
        d=QDialog(self); d.setWindowTitle('Header and Footer'); l=QFormLayout(d); h=QLineEdit(self.header_text); f=QLineEdit(self.footer_text); l.addRow('Header:',h); l.addRow('Footer:',f); b=QDialogButtonBox(QDialogButtonBox.Ok|QDialogButtonBox.Cancel); b.accepted.connect(d.accept); b.rejected.connect(d.reject); l.addRow(b)
        if d.exec_()==QDialog.Accepted:self.header_text=h.text(); self.footer_text=f.text()
    def table_sum_column(self):
        cur=self.textEdit.textCursor(); table=cur.currentTable()
        if not table: QMessageBox.information(self,'Table calculation','Place the cursor inside a table first.'); return
        cell=table.cellAt(cur); col=cell.column(); vals=[]
        for row in range(table.rows()):
            try: vals.append(float(table.cellAt(row,col).firstCursorPosition().block().text().replace(',','').strip()))
            except Exception: pass
        if vals: cur.insertText(f'{sum(vals):g}')
        else: QMessageBox.information(self,'Table calculation','No numeric values found in this column.')
    def _export_docx(self,path):
        doc=Document(); sec=doc.sections[0]
        if self.header_text: sec.header.paragraphs[0].text=self.header_text
        if self.footer_text: sec.footer.paragraphs[0].text=self.footer_text
        qdoc=self.textEdit.document(); block=qdoc.begin()
        while block.isValid():
            p=doc.add_paragraph(); al=block.blockFormat().alignment()
            if al & Qt.AlignCenter:p.alignment=WD_ALIGN_PARAGRAPH.CENTER
            elif al & Qt.AlignRight:p.alignment=WD_ALIGN_PARAGRAPH.RIGHT
            elif al & Qt.AlignJustify:p.alignment=WD_ALIGN_PARAGRAPH.JUSTIFY
            it=block.begin()
            while not it.atEnd():
                frag=it.fragment()
                if frag.isValid():
                    run=p.add_run(frag.text()); fmt=frag.charFormat(); run.bold=fmt.fontWeight()>=QFont.Bold; run.italic=fmt.fontItalic(); run.underline=fmt.fontUnderline()
                    if fmt.fontPointSize()>0:run.font.size=Pt(fmt.fontPointSize())
                    if fmt.fontFamily():run.font.name=fmt.fontFamily()
                    col=fmt.foreground().color()
                    if col.isValid(): run.font.color.rgb=RGBColor(col.red(),col.green(),col.blue())
                it+=1
            block=block.next()
        doc.save(path)
    def print_document(self):
        printer=QPrinter(QPrinter.HighResolution); dlg=QPrintDialog(printer,self)
        if dlg.exec_()==QDialog.Accepted:self.textEdit.document().print_(printer)
    def print_preview(self):
        printer=QPrinter(QPrinter.HighResolution); preview=QPrintPreviewDialog(printer,self); preview.paintRequested.connect(lambda p:self.textEdit.document().print_(p)); preview.exec_()


class EnhancedPDFViewerTab(QWidget):
    def __init__(self):
        super().__init__(); self.pdf_doc=None; self.path=None; self.current_page=0; self.zoom=1.0; self.fit=True; self.init_ui()
    def init_ui(self):
        self.setStyleSheet('EnhancedPDFViewerTab{background:#292a2d;} #bar{background:#202124;} QPushButton{background:#35363a;color:#e8eaed;border:none;border-radius:5px;padding:6px 9px;} QLineEdit,QSpinBox{background:#303134;color:#e8eaed;border:1px solid #5f6368;border-radius:5px;padding:5px;} QTreeWidget{background:#f5f5f5;color:#202124;border:none;}')
        root=QVBoxLayout(self); root.setContentsMargins(0,0,0,0); root.setSpacing(0); bar=QWidget(); bar.setObjectName('bar'); bl=QHBoxLayout(bar); bl.setContentsMargins(8,5,8,5)
        def B(t,fn): b=QPushButton(t); b.clicked.connect(fn); bl.addWidget(b); return b
        B('📂 Open',self.open_pdf); B('💾 Save As',self.save_as); B('🖨 Print',self.print_pdf); B('⟲',lambda:self.rotate(-90)); B('⟳',lambda:self.rotate(90)); B('−',lambda:self.set_zoom(self.zoom/1.15)); B('+',lambda:self.set_zoom(self.zoom*1.15)); B('Fit',self.toggle_fit)
        self.pageSpin=QSpinBox(); self.pageSpin.setMinimum(1); self.pageSpin.valueChanged.connect(self.jump); bl.addWidget(self.pageSpin); self.pageInfo=QLabel('/ 0'); self.pageInfo.setStyleSheet('color:white'); bl.addWidget(self.pageInfo)
        self.search=QLineEdit(); self.search.setPlaceholderText('Find in PDF…'); self.search.setFixedWidth(180); self.search.returnPressed.connect(self.find_next); bl.addWidget(self.search); B('Find',self.find_next); B('Highlight',self.highlight_search); B('Note',self.add_note); root.addWidget(bar)
        split=QSplitter(); self.outline=QTreeWidget(); self.outline.setHeaderLabel('Document outline'); self.outline.setMinimumWidth(190); self.outline.itemClicked.connect(self.outline_clicked); self.scroll=QScrollArea(); self.scroll.setWidgetResizable(True); self.pageLabel=QLabel(); self.pageLabel.setAlignment(Qt.AlignCenter); self.pageLabel.setStyleSheet('background:#3c4043;padding:16px;'); self.scroll.setWidget(self.pageLabel); split.addWidget(self.outline); split.addWidget(self.scroll); split.setStretchFactor(1,1); root.addWidget(split,1)
        self.status=QLabel('Open a PDF'); self.status.setStyleSheet('background:#202124;color:#bdc1c6;padding:4px 8px;'); root.addWidget(self.status)
    def open_pdf(self):
        path,_=QFileDialog.getOpenFileName(self,'Open PDF','','PDF Files (*.pdf)')
        if not path:return
        try:
            if self.pdf_doc:self.pdf_doc.close()
            self.pdf_doc=fitz.open(path); self.path=path; self.current_page=0; self.pageSpin.setMaximum(max(1,len(self.pdf_doc))); self.pageSpin.setValue(1); self.load_outline(); self.render()
        except Exception as e:QMessageBox.warning(self,'PDF Error',str(e))
    def load_outline(self):
        self.outline.clear(); toc=self.pdf_doc.get_toc(simple=True) if self.pdf_doc else []; stack=[]
        if not toc:self.outline.addTopLevelItem(QTreeWidgetItem(['No embedded bookmarks/headings'])); return
        for level,title,page in toc:
            item=QTreeWidgetItem([title]); item.setData(0,Qt.UserRole,max(0,page-1))
            while len(stack)>=level:stack.pop()
            (stack[-1].addChild(item) if stack else self.outline.addTopLevelItem(item)); stack.append(item)
        self.outline.expandToDepth(1)
    def outline_clicked(self,item,col):
        if item.data(0,Qt.UserRole) is None:return
        self.current_page=int(item.data(0,Qt.UserRole)); self.pageSpin.blockSignals(True); self.pageSpin.setValue(self.current_page+1); self.pageSpin.blockSignals(False); self.render()
    def jump(self,n):
        if self.pdf_doc:self.current_page=max(0,min(n-1,len(self.pdf_doc)-1)); self.render()
    def render(self):
        if not self.pdf_doc:return
        p=self.pdf_doc[self.current_page]; pix=p.get_pixmap(matrix=fitz.Matrix(self.zoom*1.6,self.zoom*1.6),alpha=False); img=QImage(pix.samples,pix.width,pix.height,pix.stride,QImage.Format_RGB888).copy(); q=QPixmap.fromImage(img)
        if self.fit and self.scroll.viewport().width()>80:q=q.scaled(self.scroll.viewport().size()-QSize(30,30),Qt.KeepAspectRatio,Qt.SmoothTransformation)
        self.pageLabel.setPixmap(q); self.pageInfo.setText(f'/ {len(self.pdf_doc)}'); self.status.setText(f'{os.path.basename(self.path or "PDF")} · Page {self.current_page+1} · {int(self.zoom*100)}%')
    def set_zoom(self,z):self.zoom=max(.25,min(5,z)); self.fit=False; self.render()
    def toggle_fit(self):self.fit=not self.fit; self.render()
    def rotate(self,d):
        if self.pdf_doc:
            p=self.pdf_doc[self.current_page]; p.set_rotation((p.rotation+d)%360); self.render()
    def find_next(self):
        if not self.pdf_doc:return
        q=self.search.text().strip()
        if not q:return
        for off in range(len(self.pdf_doc)):
            i=(self.current_page+off)%len(self.pdf_doc); hits=self.pdf_doc[i].search_for(q)
            if hits:self.current_page=i; self.pageSpin.blockSignals(True); self.pageSpin.setValue(i+1); self.pageSpin.blockSignals(False); self.render(); self.status.setText(f'Found {len(hits)} match(es) on page {i+1}'); return
        QMessageBox.information(self,'Find','No matches found.')
    def highlight_search(self):
        if not self.pdf_doc:return
        q=self.search.text().strip(); hits=self.pdf_doc[self.current_page].search_for(q) if q else []
        if not hits:QMessageBox.information(self,'Highlight','No matches on this page.'); return
        for r in hits:self.pdf_doc[self.current_page].add_highlight_annot(r)
        self.render(); self.status.setText('Highlight added — Save As to preserve it.')
    def add_note(self):
        if not self.pdf_doc:return
        t,ok=QInputDialog.getMultiLineText(self,'PDF Note','Note text:')
        if ok and t.strip():self.pdf_doc[self.current_page].add_text_annot(fitz.Point(54,72),t.strip()); self.render(); self.status.setText('Note added — Save As to preserve it.')
    def save_as(self):
        if not self.pdf_doc:return
        path,_=QFileDialog.getSaveFileName(self,'Save PDF As','','PDF Files (*.pdf)')
        if path:
            try:self.pdf_doc.save(path,garbage=4,deflate=True); self.status.setText('Saved '+os.path.basename(path))
            except Exception as e:QMessageBox.warning(self,'Save Error',str(e))
    def print_pdf(self):
        if not self.pdf_doc:return
        printer=QPrinter(QPrinter.HighResolution); dlg=QPrintDialog(printer,self)
        if dlg.exec_()!=QDialog.Accepted:return
        painter=QPainter(printer)
        for i,p in enumerate(self.pdf_doc):
            if i:printer.newPage()
            pix=p.get_pixmap(matrix=fitz.Matrix(2,2),alpha=False); img=QImage(pix.samples,pix.width,pix.height,pix.stride,QImage.Format_RGB888).copy(); target=painter.viewport(); sz=img.size(); sz.scale(target.size(),Qt.KeepAspectRatio); painter.setViewport(target.x(),target.y(),sz.width(),sz.height()); painter.setWindow(img.rect()); painter.drawImage(0,0,img)
        painter.end()


class EnhancedCalculatorTab(CalculatorTab):
    def __init__(self):super().__init__(); self._add_programmer(); self._skin()
    def _skin(self):
        self.setStyleSheet(self.styleSheet()+' CalculatorTab,EnhancedCalculatorTab{background:#f3f3f3;} #calcDisplay{background:#f3f3f3;color:#111;font-size:36px;border:none;} #exprDisplay{color:#666;} #historyList{background:#f3f3f3;color:#555;} QPushButton[btnType="digit"]{background:white;color:#111;border:1px solid #e5e5e5;} QPushButton[btnType="op"],QPushButton[btnType="fn"],QPushButton[btnType="mem"],QPushButton[btnType="clear"]{background:#fafafa;color:#222;border:1px solid #e5e5e5;} QPushButton[btnType="eq"]{background:#0067c0;color:white;}')
    def _add_programmer(self):
        w=QWidget(); l=QVBoxLayout(w); self.progInput=QLineEdit(); self.progInput.setPlaceholderText('Integer: 123, 0x7B, 0b1111011…'); l.addWidget(self.progInput); self.prog={}; g=QGridLayout()
        for r,(name,base) in enumerate([('HEX',16),('DEC',10),('OCT',8),('BIN',2)]):
            g.addWidget(QLabel(name),r,0); q=QLineEdit(); q.setReadOnly(True); g.addWidget(q,r,1); self.prog[base]=q
        l.addLayout(g); b=QPushButton('Convert'); b.clicked.connect(self._convert); l.addWidget(b); l.addStretch(); self.progInput.returnPressed.connect(self._convert); self.sub_tabs.addTab(w,'Programmer')
    def _convert(self):
        t=self.progInput.text().strip().lower()
        try:
            n=int(t,16) if t.startswith('0x') else int(t,2) if t.startswith('0b') else int(t,8) if t.startswith('0o') else int(t)
            self.prog[16].setText(hex(n)); self.prog[10].setText(str(n)); self.prog[8].setText(oct(n)); self.prog[2].setText(bin(n))
        except Exception:QMessageBox.warning(self,'Programmer','Enter a valid whole number.')
    def resizeEvent(self,e):
        super().resizeEvent(e); w=self.width(); h=46 if w<850 else 54 if w<1200 else 62
        for b in self.findChildren(QPushButton):
            if b.property('btnType'):b.setMinimumHeight(h)


class EnhancedMusicPlayerTab(MusicPlayerTab):
    def __init__(self):self._favorites=set(); super().__init__(); self._upgrade_music()
    def _upgrade_music(self):
        self.setStyleSheet(self.styleSheet().replace('#7c6af7','#1DB954').replace('#9580ff','#1ed760')+' MusicPlayerTab{background:#121212;} #playerCard{background:#181818;} #playlistPanel{background:#181818;}')
        panel=self.findChild(QWidget,'playlistPanel')
        if panel and panel.layout():
            search=QLineEdit(); search.setPlaceholderText('Search your queue…'); search.setStyleSheet('background:#242424;color:white;border:1px solid #333;border-radius:16px;padding:7px 12px;'); panel.layout().insertWidget(1,search); search.textChanged.connect(self._filter)
            row=QHBoxLayout(); fav=QPushButton('★ Favourite'); clear=QPushButton('Clear Queue'); fav.clicked.connect(self._fav); clear.clicked.connect(self._clear); row.addWidget(fav); row.addWidget(clear); row.addStretch(); panel.layout().insertLayout(2,row)
    def _filter(self,q):
        q=q.lower().strip()
        for i in range(self.playlistView.count()):self.playlistView.item(i).setHidden(q not in self.playlistView.item(i).text().lower())
    def _fav(self):
        s=self.playlistView.selectedItems()
        if not s:return
        item=s[0]; p=item.data(Qt.UserRole)
        if p in self._favorites:self._favorites.remove(p); item.setText(item.text().replace('★  ','').replace('★ ',''))
        else:self._favorites.add(p); item.setText('★  '+item.text().lstrip())
    def _clear(self):self.playlist.clear(); self.playlistView.clear(); self._update_track_count()


class EnhancedVideoConferenceTab(VideoConferenceTab):
    def __init__(self):super().__init__(); self._handoff()
    def _handoff(self):
        top=self.findChild(QWidget,'topBar')
        if top and top.layout():
            b=QPushButton('🌐 Jesson Browser'); b.setObjectName('extBtn'); b.setToolTip('Open the meeting in the Browser tab using its persistent signed-in profile'); b.clicked.connect(self.open_in_browser_tab); top.layout().addWidget(b)
    def open_in_browser_tab(self):
        t=self.meetingInput.text().strip(); p=self.platformCombo.currentText()
        if not t and not p.startswith('YouTube'):QMessageBox.information(self,'No link','Paste a meeting link or ID first.'); return
        url=self.get_url_for_platform(p,t); main=self.window()
        if hasattr(main,'searchTab') and hasattr(main.searchTab,'browser'):main.searchTab.browser.load(QUrl(url)); main.tabs.setCurrentWidget(main.searchTab)
        else:self.open_external()

for _theme in [
 ('🪟  Windows Light','#f3f3f3','#0067c0','#202020','Windows 11-inspired neutral desktop.'),
 ('🌑  Windows Dark','#202020','#60a5fa','#f5f5f5','Dark Windows-style desktop chrome.'),
 ('📝  Office Blue','#f4f6f8','#2b579a','#202124','Microsoft Office-inspired blue chrome.'),
 ('◐  High Contrast','#000000','#ffff00','#ffffff','High contrast for maximum legibility.')]:
    if _theme[0] not in [x[0] for x in ThemesTab.THEMES]:ThemesTab.THEMES.append(_theme)



# ===========================================================================
# QA2 usability refinements from hands-on testing
# ===========================================================================

class PolishedStudyAssistantTab(AIStudyAssistantTab):
    """A cleaner study workspace: sources + actions + conversation, with keys hidden."""
    def __init__(self):
        self.last_response = ""
        super().__init__()

    def init_ui(self):
        self.setStyleSheet("""
            PolishedStudyAssistantTab { background:#f5f7fb; }
            #studyHero { background:#111827; border-radius:14px; }
            #studyTitle { color:white; font-size:20px; font-weight:700; }
            #studySub { color:#cbd5e1; font-size:12px; }
            #studyCard { background:white; border:1px solid #e5e7eb; border-radius:12px; }
            #studySection { color:#6b7280; font-size:10px; font-weight:700; }
            #studyStatus { color:#475569; font-size:12px; }
            #studyPrimary { background:#4f46e5; color:white; border:none; border-radius:9px; padding:9px 14px; font-weight:700; }
            #studyPrimary:hover { background:#4338ca; }
            #studyAction { background:#f8fafc; color:#1f2937; border:1px solid #e2e8f0; border-radius:9px; padding:9px 12px; text-align:left; }
            #studyAction:hover { background:#eef2ff; border-color:#c7d2fe; }
            #studyGhost { background:white; color:#334155; border:1px solid #cbd5e1; border-radius:8px; padding:7px 10px; }
            #studyChat { background:white; border:1px solid #e5e7eb; border-radius:12px; padding:10px; }
            #studyPrompt { background:white; border:1px solid #cbd5e1; border-radius:12px; padding:9px; }
        """)
        root=QVBoxLayout(self); root.setContentsMargins(16,16,16,16); root.setSpacing(12)

        hero=QWidget(); hero.setObjectName('studyHero'); hl=QHBoxLayout(hero); hl.setContentsMargins(18,14,18,14)
        titles=QVBoxLayout(); title=QLabel('Study AI'); title.setObjectName('studyTitle'); sub=QLabel('Turn your own material into explanations, summaries and revision tools.'); sub.setObjectName('studySub')
        titles.addWidget(title); titles.addWidget(sub); hl.addLayout(titles); hl.addStretch()
        self.manageKeysBtn=QPushButton('⚙ API Keys'); self.manageKeysBtn.setObjectName('studyGhost'); self.manageKeysBtn.clicked.connect(self.manage_keys); hl.addWidget(self.manageKeysBtn)
        root.addWidget(hero)

        body=QSplitter(Qt.Horizontal)
        side=QWidget(); side.setObjectName('studyCard'); sl=QVBoxLayout(side); sl.setContentsMargins(13,13,13,13); sl.setSpacing(9)
        src=QLabel('SOURCE'); src.setObjectName('studySection'); sl.addWidget(src)
        self.contextStatusLabel=QLabel('No material loaded'); self.contextStatusLabel.setObjectName('studyStatus'); self.contextStatusLabel.setWordWrap(True); sl.addWidget(self.contextStatusLabel)
        self.loadContextBtn=QPushButton('＋ Add study material'); self.loadContextBtn.setObjectName('studyPrimary'); sl.addWidget(self.loadContextBtn)
        self.clearContextBtn=QPushButton('Remove material'); self.clearContextBtn.setObjectName('studyGhost'); sl.addWidget(self.clearContextBtn)
        sl.addSpacing(8); act=QLabel('CREATE'); act.setObjectName('studySection'); sl.addWidget(act)
        self.summarizeBtn=QPushButton('▤  Summary\n   Clear structured notes'); self.summarizeBtn.setObjectName('studyAction')
        self.quizBtn=QPushButton('?  Quiz & Flashcards\n   Revision questions + answers'); self.quizBtn.setObjectName('studyAction')
        self.conceptsBtn=QPushButton('◇  Key Concepts\n   Definitions, formulas & links'); self.conceptsBtn.setObjectName('studyAction')
        for b in (self.summarizeBtn,self.quizBtn,self.conceptsBtn): sl.addWidget(b)
        sl.addStretch()
        self.exportBtn=QPushButton('⇩ Export latest answer'); self.exportBtn.setObjectName('studyGhost'); self.exportBtn.setEnabled(False); sl.addWidget(self.exportBtn)
        self.exportChatBtn=QPushButton('⇩ Export full study chat'); self.exportChatBtn.setObjectName('studyGhost'); sl.addWidget(self.exportChatBtn)
        side.setMinimumWidth(245); side.setMaximumWidth(330)

        chat=QWidget(); cl=QVBoxLayout(chat); cl.setContentsMargins(0,0,0,0); cl.setSpacing(8)
        self.chatHistory=QTextBrowser(); self.chatHistory.setObjectName('studyChat'); self.chatHistory.setOpenExternalLinks(True); cl.addWidget(self.chatHistory,1)
        prow=QHBoxLayout(); self.promptInput=QTextEdit(); self.promptInput.setObjectName('studyPrompt'); self.promptInput.setMaximumHeight(92); self.promptInput.setPlaceholderText('Ask about the material…')
        self.sendBtn=QPushButton('Send'); self.sendBtn.setObjectName('studyPrimary'); self.sendBtn.setMinimumHeight(42)
        self.clearChatBtn=QPushButton('Clear'); self.clearChatBtn.setObjectName('studyGhost')
        bv=QVBoxLayout(); bv.addWidget(self.sendBtn); bv.addWidget(self.clearChatBtn); prow.addWidget(self.promptInput,1); prow.addLayout(bv); cl.addLayout(prow)
        body.addWidget(side); body.addWidget(chat); body.setStretchFactor(1,1); root.addWidget(body,1)

        # Hidden password-mode backing field keeps inherited send logic compatible.
        self.apiKeyInput=QLineEdit(); self.apiKeyInput.setEchoMode(QLineEdit.Password); self.apiKeyInput.setText(','.join(self.api_keys)); self.apiKeyInput.hide()
        self.saveKeyBtn=QPushButton(); self.saveKeyBtn.hide()
        self.loadContextBtn.clicked.connect(self.load_context_file); self.clearContextBtn.clicked.connect(self.clear_context)
        self.summarizeBtn.clicked.connect(lambda:self.send_preset_prompt('Provide a clear, well-structured summary of the loaded study material with headings, key facts and a short revision checklist.'))
        self.quizBtn.clicked.connect(lambda:self.send_preset_prompt('Create a 10-question revision quiz and 10 concise flashcards from the loaded material. Put the answer key after the questions.'))
        self.conceptsBtn.clicked.connect(lambda:self.send_preset_prompt('Extract and explain the core concepts, definitions, formulas, relationships and common exam traps in the loaded material.'))
        self.sendBtn.clicked.connect(self.send_prompt); self.clearChatBtn.clicked.connect(self.chatHistory.clear)
        self.exportBtn.clicked.connect(self.export_latest); self.exportChatBtn.clicked.connect(self.export_chat)

    def manage_keys(self):
        d=QDialog(self); d.setWindowTitle('Study AI API Keys'); d.resize(470,170); l=QVBoxLayout(d)
        info=QLabel('Keys stay on this PC. Enter one or more keys separated by commas.'); info.setWordWrap(True); l.addWidget(info)
        edit=QLineEdit(); edit.setEchoMode(QLineEdit.Password); edit.setPlaceholderText('AIza… , AIza…'); edit.setText(','.join(self.api_keys)); l.addWidget(edit)
        show=QCheckBox('Show keys while editing'); show.toggled.connect(lambda on: edit.setEchoMode(QLineEdit.Normal if on else QLineEdit.Password)); l.addWidget(show)
        buttons=QDialogButtonBox(QDialogButtonBox.Save|QDialogButtonBox.Cancel); buttons.accepted.connect(d.accept); buttons.rejected.connect(d.reject); l.addWidget(buttons)
        if d.exec_()==QDialog.Accepted:
            self.api_keys=[k.strip() for k in re.split(r'[,;\n]+',edit.text()) if k.strip()]
            self.apiKeyInput.setText(','.join(self.api_keys)); self.save_config(); self.manageKeysBtn.setText(f'⚙ API Keys ({len(self.api_keys)})' if self.api_keys else '⚙ API Keys')

    def clear_context(self):
        self.context_text=''; self.contextStatusLabel.setText('No material loaded'); self.append_to_chat('System','Study material removed.','#64748b')

    def load_context_file(self):
        path,_=QFileDialog.getOpenFileName(self,'Add Study Material','','Documents (*.pdf *.docx *.txt)')
        if not path:return
        try:
            if path.lower().endswith('.txt'): text=Path(path).read_text(encoding='utf-8')
            elif path.lower().endswith('.docx'):
                doc=Document(path); text='\n'.join(p.text for p in doc.paragraphs)
            else:
                pdf=fitz.open(path); text='\n'.join(page.get_text('text') for page in pdf); pdf.close()
            if not text.strip(): QMessageBox.warning(self,'No text','No extractable text was found in that file.'); return
            self.context_text=text; self.contextStatusLabel.setText(f'{QFileInfo(path).fileName()}\n{len(text):,} characters'); self.append_to_chat('System',f'Loaded {QFileInfo(path).fileName()}.','#64748b')
        except Exception as exc: QMessageBox.warning(self,'Load Error',str(exc))

    def on_response(self,text):
        self.last_response=text or ''; self.exportBtn.setEnabled(bool(self.last_response.strip())); super().on_response(text)

    def export_latest(self):
        if not self.last_response.strip():return
        self._export_text(self.last_response,'study-answer')

    def export_chat(self):
        text=self.chatHistory.toPlainText().strip()
        if not text: QMessageBox.information(self,'Export','There is no study conversation to export yet.'); return
        self._export_text(text,'study-chat')

    def _export_text(self,text,default_name):
        path,chosen=QFileDialog.getSaveFileName(self,'Export Study Output',default_name+'.docx','Word Document (*.docx);;Text File (*.txt);;HTML (*.html)')
        if not path:return
        try:
            if path.lower().endswith('.docx') or 'word' in chosen.lower():
                if not path.lower().endswith('.docx'): path += '.docx'
                d=Document(); d.add_heading('Study Output',0)
                for para in text.split('\n'):
                    if para.strip(): d.add_paragraph(para)
                d.save(path)
            elif path.lower().endswith('.html'):
                Path(path).write_text('<html><body><pre>'+text.replace('&','&amp;').replace('<','&lt;')+'</pre></body></html>',encoding='utf-8')
            else: Path(path).write_text(text,encoding='utf-8')
        except Exception as exc: QMessageBox.warning(self,'Export Error',str(exc))


class PolishedCalculatorTab(EnhancedCalculatorTab):
    """Responsive calculator using the original Jesson purple/dark visual identity."""
    CALC_BG = '#1a1a2e'
    PANEL_BG = '#20203a'
    PANEL_DARK = '#16162a'
    BORDER = '#3a3a5c'
    TEXT = '#f4f4ff'
    MUTED = '#9090b5'
    ACCENT = '#7c6af7'
    ACCENT_HOVER = '#9580ff'

    def __init__(self):
        super().__init__()
        self._rebuild_programmer()
        self._polish_numeric()
        self._polish_symbolic()
        self._polish_unit_converter()

    def _polish_numeric(self):
        # Calculator keeps its own palette so global application themes cannot wash it out.
        self.setAutoFillBackground(True)
        self.setStyleSheet(self._STYLE + r'''
            CalculatorTab, EnhancedCalculatorTab, PolishedCalculatorTab {
                background: #1a1a2e;
            }
            #calcDisplay {
                background: #16162a;
                color: #ffffff;
                border: 1px solid #3a3a5c;
                border-radius: 10px;
                font-size: 32px;
                font-weight: bold;
                padding: 14px 18px;
            }
            #exprDisplay {
                color: #8d8db3;
                background: transparent;
            }
            #historyList {
                background: #16162a;
                color: #aaaad0;
                border: 1px solid #30304e;
                border-radius: 8px;
            }
            QPushButton[btnType="digit"] {
                background: #2a2a4a; color: #ffffff;
                border: 1px solid #39395a; border-radius: 10px;
                font-size: 18px; font-weight: bold;
            }
            QPushButton[btnType="digit"]:hover { background: #3a3a5e; }
            QPushButton[btnType="digit"]:pressed { background: #1e1e38; }
            QPushButton[btnType="op"] {
                background: #1e3a5a; color: #80c8ff;
                border: 1px solid #285075; border-radius: 10px;
                font-size: 18px; font-weight: bold;
            }
            QPushButton[btnType="op"]:hover { background: #2a4e7a; }
            QPushButton[btnType="fn"] {
                background: #2a1e4a; color: #d19aff;
                border: 1px solid #49346e; border-radius: 10px;
                font-size: 13px; font-weight: 600;
            }
            QPushButton[btnType="fn"]:hover { background: #3a2e5e; }
            QPushButton[btnType="mem"] {
                background: #1e2e1e; color: #80e080;
                border: 1px solid #315031; border-radius: 10px;
            }
            QPushButton[btnType="clear"] {
                background: #4a1e1e; color: #ff9090;
                border: 1px solid #6b3030; border-radius: 10px;
            }
            QPushButton[btnType="eq"] {
                background: #7c6af7; color: #ffffff;
                border: none; border-radius: 10px;
                font-size: 22px; font-weight: bold;
            }
            QPushButton[btnType="eq"]:hover { background: #9580ff; }
        ''')

        self.sub_tabs.setStyleSheet(r'''
            QTabWidget::pane { border: none; background: #1a1a2e; }
            QTabBar { background: #1a1a2e; }
            QTabBar::tab {
                background: #1a1a2e; color: #77779b;
                padding: 9px 18px; border: none;
                border-bottom: 2px solid transparent;
                min-width: 100px; font-size: 12px;
            }
            QTabBar::tab:selected {
                color: #b9afff; border-bottom: 2px solid #7c6af7; font-weight: 700;
            }
            QTabBar::tab:hover { color: #d4ceff; background: #20203a; }
        ''')
        self.sub_tabs.tabBar().setElideMode(Qt.ElideNone)
        self.sub_tabs.tabBar().setExpanding(False)

        for b in self.findChildren(QPushButton):
            if b.property('btnType'):
                b.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
                b.setMinimumSize(38, 38)
                b.setMaximumHeight(90)

    def _polish_symbolic(self):
        # Dark purple surfaces instead of near-black boxes.
        self.sym_input.setStyleSheet(r'''
            QLineEdit {
                background: #242442; color: #ffffff;
                border: 1px solid #52527a; border-radius: 9px;
                padding: 11px 14px; font-size: 14px;
                selection-background-color: #7c6af7;
            }
            QLineEdit:focus { border: 2px solid #7c6af7; }
        ''')
        self.sym_result.setStyleSheet(r'''
            QTextEdit {
                background: #18182c; color: #b7f7c2;
                border: 1px solid #45456a; border-radius: 9px;
                padding: 10px 14px; font-size: 13px;
                font-family: Consolas, monospace;
            }
        ''')

    def _polish_unit_converter(self):
        self.categoryCombo.setStyleSheet(r'''
            QComboBox { background:#252540; color:#eeeeff; border:1px solid #4a4a72;
                        border-radius:8px; padding:7px 12px; min-height:30px; }
            QComboBox::drop-down { border:none; width:24px; }
            QComboBox QAbstractItemView { background:#252540; color:#eeeeff;
                        selection-background-color:#7c6af7; border:1px solid #4a4a72; }
        ''')
        self.valueInput.setStyleSheet(r'''
            QDoubleSpinBox { background:#20203a; color:#ffffff; border:1px solid #4a4a72;
                             border-radius:8px; padding:10px 14px; font-size:18px; font-weight:bold; }
            QDoubleSpinBox:focus { border:2px solid #7c6af7; }
        ''')
        for combo in (self.fromUnitCombo, self.toUnitCombo):
            combo.setStyleSheet(r'''
                QComboBox { background:#252540; color:#eeeeff; border:1px solid #4a4a72;
                            border-radius:8px; padding:7px 10px; min-height:30px; }
                QComboBox::drop-down { border:none; width:24px; }
                QComboBox QAbstractItemView { background:#252540; color:#eeeeff;
                            selection-background-color:#7c6af7; border:1px solid #4a4a72; }
            ''')
        if hasattr(self, 'resultLabel'):
            self.resultLabel.setStyleSheet('background:#18182c;color:#dcdcff;border:1px solid #45456a;border-radius:8px;padding:10px;font-size:16px;font-weight:600;')

    def _rebuild_programmer(self):
        # Keep the working programmer implementation, but use the calculator's original dark palette.
        for i in range(self.sub_tabs.count()-1, -1, -1):
            if self.sub_tabs.tabText(i) == 'Programmer':
                self.sub_tabs.removeTab(i)

        w = QWidget()
        w.setObjectName('programmerPanel')
        w.setStyleSheet('QWidget#programmerPanel{background:#1a1a2e;}')
        root = QVBoxLayout(w)
        root.setContentsMargins(16, 14, 16, 16)
        root.setSpacing(10)

        top = QHBoxLayout()
        self.baseCombo = QComboBox()
        self.baseCombo.addItems(['DEC', 'HEX', 'OCT', 'BIN'])
        self.baseCombo.setFixedWidth(90)
        self.baseCombo.setStyleSheet(r'''
            QComboBox { background:#252540;color:#eeeeff;border:1px solid #4a4a72;
                        border-radius:8px;padding:7px 10px; }
            QComboBox QAbstractItemView { background:#252540;color:#eeeeff;
                        selection-background-color:#7c6af7; }
        ''')
        self.baseCombo.currentTextChanged.connect(self._prog_refresh)

        self.progInput = QLineEdit()
        self.progInput.setPlaceholderText('0')
        self.progInput.setAlignment(Qt.AlignRight)
        self.progInput.setStyleSheet(r'''
            QLineEdit { font-size:28px;background:#16162a;color:#ffffff;
                        border:1px solid #4a4a72;border-radius:9px;padding:9px 12px; }
            QLineEdit:focus { border:2px solid #7c6af7; }
        ''')
        self.progInput.textChanged.connect(self._prog_refresh)
        top.addWidget(self.baseCombo)
        top.addWidget(self.progInput, 1)
        root.addLayout(top)

        self.prog = {}
        views = QGridLayout()
        views.setHorizontalSpacing(12)
        views.setVerticalSpacing(4)
        for r, (name, base) in enumerate([('HEX',16),('DEC',10),('OCT',8),('BIN',2)]):
            lab = QLabel(name)
            lab.setStyleSheet('color:#8f8fb4;font-size:11px;font-weight:700;')
            val = QLineEdit()
            val.setReadOnly(True)
            val.setStyleSheet('background:#20203a;color:#f0f0ff;border:1px solid #353557;border-radius:6px;padding:6px 9px;font-family:Consolas;font-size:13px;')
            self.prog[base] = val
            views.addWidget(lab, r, 0)
            views.addWidget(val, r, 1)
        root.addLayout(views)

        grid = QGridLayout()
        grid.setSpacing(6)
        keys = [
            ('A',0,0),('B',0,1),('C',0,2),('D',0,3),('E',0,4),('F',0,5),
            ('7',1,0),('8',1,1),('9',1,2),('⌫',1,3),('CE',1,4),('C',1,5),
            ('4',2,0),('5',2,1),('6',2,2),('&',2,3),('|',2,4),('^',2,5),
            ('1',3,0),('2',3,1),('3',3,2),('<<',3,3),('>>',3,4),('NOT',3,5),
            ('0',4,0),('00',4,1),('+',4,2),('-',4,3),('*',4,4),('/',4,5),
        ]
        for text, r, c in keys:
            b = QPushButton(text)
            b.setMinimumHeight(46)
            b.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
            if text in 'ABCDEF' and len(text) == 1:
                style = 'background:#2a1e4a;color:#d19aff;border:1px solid #49346e;'
            elif text in {'⌫','CE','C'}:
                style = 'background:#4a1e1e;color:#ff9898;border:1px solid #6b3030;'
            elif text in {'&','|','^','<<','>>','NOT','+','-','*','/'}:
                style = 'background:#1e3a5a;color:#80c8ff;border:1px solid #285075;'
            else:
                style = 'background:#2a2a4a;color:#ffffff;border:1px solid #39395a;'
            b.setStyleSheet('QPushButton{'+style+'border-radius:8px;font-size:14px;font-weight:600;} QPushButton:hover{background:#3a3a5e;} QPushButton:disabled{background:#202034;color:#55556f;border:1px solid #2c2c45;}')
            b.clicked.connect(lambda _, t=text: self._prog_key(t))
            grid.addWidget(b, r, c)
        root.addLayout(grid, 1)

        self.progStatus = QLabel('Enter a whole number.')
        self.progStatus.setStyleSheet('color:#8f8fb4;font-size:11px;')
        root.addWidget(self.progStatus)
        self.sub_tabs.addTab(w, 'Programmer')
        self._prog_refresh()

    def _prog_parse(self):
        t = self.progInput.text().strip().replace(' ', '')
        if not t:
            return 0
        base = {'DEC':10,'HEX':16,'OCT':8,'BIN':2}[self.baseCombo.currentText()]
        prefixes = {16:'0x',8:'0o',2:'0b'}
        if base in prefixes and t.lower().startswith(prefixes[base]):
            t = t[2:]
        return int(t, base)

    def _prog_refresh(self, *_):
        try:
            n = self._prog_parse()
            self.prog[16].setText(format(n,'X'))
            self.prog[10].setText(str(n))
            self.prog[8].setText(format(n,'o'))
            self.prog[2].setText(format(n,'b'))
            self.progStatus.setText('Live conversion')
            self._set_prog_key_states()
        except Exception:
            for q in self.prog.values():
                q.setText('—')
            self.progStatus.setText('Invalid number for selected base')
            self._set_prog_key_states()

    def _set_prog_key_states(self):
        base = {'DEC':10,'HEX':16,'OCT':8,'BIN':2}[self.baseCombo.currentText()]
        allowed = '0123456789ABCDEF'[:base]
        prog_page = self.sub_tabs.widget(self.sub_tabs.count()-1)
        for b in prog_page.findChildren(QPushButton) if prog_page else []:
            t = b.text()
            if len(t) == 1 and t in '0123456789ABCDEF':
                b.setEnabled(t in allowed)

    def _prog_key(self, key):
        if key in ('C','CE'):
            self.progInput.clear()
            return
        if key == '⌫':
            self.progInput.setText(self.progInput.text()[:-1])
            return
        if key in {'&','|','^','<<','>>','NOT','+','-','*','/'}:
            try:
                n = self._prog_parse()
                if key == 'NOT':
                    self.progInput.setText(str(~n))
                    self.baseCombo.setCurrentText('DEC')
                    return
                other, ok = QInputDialog.getText(self, 'Programmer operation', f'{n} {key} …   Enter second whole number:')
                if not ok:
                    return
                m = int(other.strip(), 0)
                result = {'&': n&m, '|': n|m, '^': n^m, '<<': n<<m, '>>': n>>m,
                          '+': n+m, '-': n-m, '*': n*m, '/': n//m}[key]
                self.baseCombo.setCurrentText('DEC')
                self.progInput.setText(str(result))
            except Exception as exc:
                QMessageBox.warning(self, 'Programmer', str(exc))
            return
        self.progInput.insert(key)

class PolishedDocumentTab(EnhancedDocumentTab):
    """Keeps the white paper but improves the Word-like ribbon and table behavior."""
    def __init__(self):
        super().__init__(); self._polish_ribbon()

    def _polish_ribbon(self):
        self.setStyleSheet(self.styleSheet()+"""
            #titleStrip{background:#2b579a;} #ribbonScroll{background:#fbfbfb;border-bottom:1px solid #c9d1dc;}
            #ribbon{background:#fbfbfb;} #toolBtn{background:transparent;border:1px solid transparent;border-radius:4px;padding:5px 8px;}
            #toolBtn:hover{background:#eaf2fb;border-color:#d7e5f5;} #groupLabel{color:#6b7280;font-size:9px;}
        """)
        root=self.layout(); tabs=QWidget(); tabs.setStyleSheet('background:#ffffff;border-bottom:1px solid #d7dce3;'); tl=QHBoxLayout(tabs); tl.setContentsMargins(10,0,10,0); tl.setSpacing(2)
        for name in ('File','Home','Insert','Layout','Review','View'):
            b=QPushButton(name); b.setFlat(True); b.setStyleSheet('QPushButton{border:none;padding:7px 13px;color:#374151;} QPushButton:hover{background:#eef3f8;}'); tl.addWidget(b)
        tl.addStretch(); root.insertWidget(1,tabs)
        ribbon=self.ribbonScroll.widget(); lay=ribbon.layout()
        # useful paragraph/layout controls kept reachable on the same scrollable ribbon
        line=QComboBox(); line.addItems(['1.0','1.15','1.5','2.0']); line.setToolTip('Line spacing'); line.setFixedWidth(65); line.currentTextChanged.connect(self.set_line_spacing); lay.insertWidget(max(0,lay.count()-1),line)
        clear=QPushButton('Clear Format'); clear.setObjectName('toolBtn'); clear.clicked.connect(self.clear_formatting); lay.insertWidget(max(0,lay.count()-1),clear)
        ribbon.setMinimumWidth(max(2050,ribbon.sizeHint().width()))

    def set_line_spacing(self,value):
        try:
            c=self.textEdit.textCursor(); bf=c.blockFormat(); bf.setLineHeight(float(value)*100,QTextBlockFormat.ProportionalHeight); c.setBlockFormat(bf)
        except Exception: pass

    def clear_formatting(self):
        c=self.textEdit.textCursor(); fmt=QTextCharFormat(); fmt.setFontFamily('Times New Roman'); fmt.setFontPointSize(12); fmt.setForeground(QColor('#111111')); fmt.setFontWeight(QFont.Normal); fmt.setFontItalic(False); fmt.setFontUnderline(False); c.mergeCharFormat(fmt)

    def insert_table(self,rows,cols):
        cursor=self.textEdit.textCursor(); tf=QTextTableFormat(); tf.setBorder(0.8); tf.setBorderStyle(QTextFrameFormat.BorderStyle_Solid); tf.setCellPadding(7); tf.setCellSpacing(0); tf.setWidth(QTextLength(QTextLength.PercentageLength,100)); tf.setAlignment(Qt.AlignHCenter)
        table=cursor.insertTable(rows,cols,tf)
        # Give the first row a subtle header background like Word's default table style.
        for col in range(cols):
            cell=table.cellAt(0,col); cf=cell.format(); cf.setBackground(QColor('#eaf2f8')); cell.setFormat(cf)
        cursor=table.cellAt(0,0).firstCursorPosition(); cursor.insertText('')

    def load_document(self):
        path,_=QFileDialog.getOpenFileName(self,'Open Document','','Documents (*.docx *.html *.htm *.txt *.pdf)')
        if not path:return False
        return self._load_document_path(path)

    def _load_document_path(self, path):
        try:
            low=path.lower()
            if low.endswith(('.html','.htm')): self.textEdit.setHtml(Path(path).read_text(encoding='utf-8')); self.current_format='html'
            elif low.endswith('.txt'): self.textEdit.setPlainText(Path(path).read_text(encoding='utf-8')); self.current_format='txt'
            elif low.endswith('.docx'):
                doc=Document(path); chunks=[]
                for p in doc.paragraphs:
                    runs=[]
                    for r in p.runs:
                        txt=r.text.replace('&','&amp;').replace('<','&lt;').replace('>','&gt;'); style=[]
                        if r.bold: style.append('font-weight:bold')
                        if r.italic: style.append('font-style:italic')
                        if r.underline: style.append('text-decoration:underline')
                        if r.font.size: style.append(f'font-size:{r.font.size.pt}pt')
                        if r.font.name: style.append(f'font-family:{r.font.name}')
                        runs.append(f'<span style="{";".join(style)}">{txt}</span>')
                    chunks.append('<p>'+''.join(runs)+'</p>')
                # append tables so their content is not silently lost
                for t in doc.tables:
                    html=['<table border="1" cellspacing="0" cellpadding="6" width="100%">']
                    for row in t.rows: html.append('<tr>'+''.join('<td>'+c.text.replace('&','&amp;').replace('<','&lt;')+'</td>' for c in row.cells)+'</tr>')
                    html.append('</table>'); chunks.extend(html)
                self.textEdit.setHtml(''.join(chunks)); self.current_format='docx'
            else:
                pdf=fitz.open(path); self.textEdit.setPlainText('\n\n'.join(page.get_text('text') for page in pdf)); pdf.close(); self.current_format='pdf'
            self.current_file=path; self.textEdit.document().setModified(False)
            return True
        except Exception as exc:
            QMessageBox.warning(self,'Open Error',str(exc))
            return False


from pdf_notes import PDFNotesMixin


class PolishedPDFViewerTab(PDFNotesMixin, EnhancedPDFViewerTab):
    def __init__(self):
        super().__init__(); self._add_navigation()

    def _add_navigation(self):
        bar=self.findChild(QWidget,'bar')
        if bar and bar.layout():
            prev=QPushButton('◀ Previous'); nxt=QPushButton('Next ▶'); prev.setToolTip('Previous page (Page Up / Left Arrow)'); nxt.setToolTip('Next page (Page Down / Right Arrow)')
            prev.clicked.connect(lambda:self.step_page(-1)); nxt.clicked.connect(lambda:self.step_page(1)); bar.layout().insertWidget(3,prev); bar.layout().insertWidget(4,nxt)
        QShortcut(QKeySequence(Qt.Key_PageUp),self).activated.connect(lambda:self.step_page(-1)); QShortcut(QKeySequence(Qt.Key_PageDown),self).activated.connect(lambda:self.step_page(1)); QShortcut(QKeySequence(Qt.Key_Left),self).activated.connect(lambda:self.step_page(-1)); QShortcut(QKeySequence(Qt.Key_Right),self).activated.connect(lambda:self.step_page(1))

    def step_page(self,delta):
        if not self.pdf_doc:return
        self.current_page=max(0,min(len(self.pdf_doc)-1,self.current_page+delta)); self.pageSpin.blockSignals(True); self.pageSpin.setValue(self.current_page+1); self.pageSpin.blockSignals(False); self.render()


class PolishedNotesAndDrawingTab(NotesAndDrawingTab):
    def __init__(self):
        super().__init__(); self._upgrade_notes_state()

    def _upgrade_notes_state(self):
        self.notesSaveBtn.setEnabled(bool(self.notesEdit.toPlainText().strip()))
        self.notesEdit.textChanged.connect(lambda:self.notesSaveBtn.setEnabled(bool(self.notesEdit.toPlainText().strip())))
        footer=self.notesSaveBtn.parentWidget(); layout=footer.layout() if footer else None
        self.recentNotes=QComboBox(); self.recentNotes.setToolTip('Recently saved notes'); self.recentNotes.setMinimumWidth(150); self.recentNotes.addItem('Recent notes…',None); self.recentNotes.currentIndexChanged.connect(self._open_recent_note)
        if layout: layout.insertWidget(max(1,layout.count()-2),self.recentNotes)
        # Better list selector: user can choose style or return to no-list mode.
        toolbar=self.notesEdit.parentWidget().layout().itemAt(0).widget() if self.notesEdit.parentWidget() and self.notesEdit.parentWidget().layout() else None
        if toolbar and toolbar.layout():
            combo=QComboBox(); combo.addItems(['No list','• Bullet','○ Circle','▪ Square','1. Numbered','A. Lettered']); combo.setToolTip('List style'); combo.currentTextChanged.connect(self._apply_note_list); toolbar.layout().insertWidget(max(0,toolbar.layout().count()-1),combo)

    def _apply_note_list(self,name):
        cur=self.notesEdit.textCursor()
        if name=='No list':
            bf=cur.blockFormat(); bf.setObjectIndex(-1); cur.setBlockFormat(bf); return
        styles={'• Bullet':QTextListFormat.ListDisc,'○ Circle':QTextListFormat.ListCircle,'▪ Square':QTextListFormat.ListSquare,'1. Numbered':QTextListFormat.ListDecimal,'A. Lettered':QTextListFormat.ListUpperAlpha}
        if name in styles: cur.createList(styles[name])

    def save_notes(self):
        text=self.notesEdit.toPlainText().strip()
        if not text: QMessageBox.information(self,'Save Notes','Write something before saving.'); return
        path,_=QFileDialog.getSaveFileName(self,'Save Notes','','Text Files (*.txt);;HTML Notes (*.html)')
        if not path:return
        try:
            if path.lower().endswith('.html'): Path(path).write_text(self.notesEdit.toHtml(),encoding='utf-8')
            else: Path(path).write_text(self.notesEdit.toPlainText(),encoding='utf-8')
            if self.recentNotes.findData(path)<0:self.recentNotes.addItem(os.path.basename(path),path)
            self.recentNotes.setCurrentIndex(0)
        except Exception as e: QMessageBox.warning(self,'Error',str(e))

    def load_notes(self):
        path,_=QFileDialog.getOpenFileName(self,'Load Notes','','Notes (*.txt *.html *.htm)')
        if not path:return
        self._load_note_path(path)

    def _open_recent_note(self,index):
        path=self.recentNotes.itemData(index)
        if path:self._load_note_path(path); self.recentNotes.setCurrentIndex(0)

    def _load_note_path(self,path):
        try:
            if path.lower().endswith(('.html','.htm')): self.notesEdit.setHtml(Path(path).read_text(encoding='utf-8'))
            else:self.notesEdit.setPlainText(Path(path).read_text(encoding='utf-8'))
            if self.recentNotes.findData(path)<0:self.recentNotes.addItem(os.path.basename(path),path)
        except Exception as e: QMessageBox.warning(self,'Error',str(e))


# ===========================================================================
# QA5 refinements: equation parsing, theme-safe calculator, smooth tap drawing,
# functional Writer menus, persistent recent notes, themed Study dialogs
# ===========================================================================

class QA5CalculatorTab(PolishedCalculatorTab):
    def __init__(self):
        super().__init__()
        try:
            self.sym_input.returnPressed.disconnect()
        except Exception:
            pass
        self.sym_input.returnPressed.connect(self._smart_symbolic_enter)

    def _normalize_math_input(self, text):
        s = (text or '').strip()
        s = s.replace('²','^2').replace('³','^3').replace('×','*').replace('÷','/')
        s = re.sub(r'\bis\s+equal\s+to\b|\bequals\b', '=', s, flags=re.I)
        s = re.sub(r'\b([A-Za-z0-9_()]+)\s+squared\b', r'\1^2', s, flags=re.I)
        s = re.sub(r'\b([A-Za-z0-9_()]+)\s+cubed\b', r'\1^3', s, flags=re.I)
        return s

    def _parse_symbolic(self, raw):
        from sympy.parsing.sympy_parser import parse_expr, standard_transformations, implicit_multiplication_application, convert_xor
        trans = standard_transformations + (implicit_multiplication_application, convert_xor)
        s = self._normalize_math_input(raw)
        if s.count('=') > 1:
            raise ValueError('Use one equals sign only.')
        if '=' in s:
            left, right = s.split('=', 1)
            return sp.Eq(parse_expr(left.strip(), transformations=trans), parse_expr(right.strip(), transformations=trans)), True
        return parse_expr(s, transformations=trans), False

    def _smart_symbolic_enter(self):
        raw = self.sym_input.text().strip()
        if not raw:
            return
        self.sym_compute('solve' if ('=' in raw or re.search(r'\b(equal|equals)\b', raw, re.I)) else 'eval')

    def sym_compute(self, mode):
        raw = self.sym_input.text().strip()
        if not raw:
            return
        try:
            parsed, is_eq = self._parse_symbolic(raw)
            expr = parsed.lhs - parsed.rhs if is_eq else parsed
            symbols = sorted(expr.free_symbols, key=lambda s: s.name)
            x = symbols[0] if symbols else sp.symbols('x')
            if mode == 'solve' or (is_eq and mode == 'eval'):
                result = sp.solve(parsed if is_eq else sp.Eq(expr, 0), x)
                self.sym_result.setPlainText('\n'.join(f'{x} = {sp.simplify(v)}' for v in result) if result else 'No solution found.')
                return
            if mode == 'factor': result = sp.factor(expr)
            elif mode == 'expand': result = sp.expand(expr)
            elif mode == 'simplify': result = sp.simplify(expr)
            elif mode == 'diff': result = sp.diff(expr, x)
            elif mode == 'int': result = sp.integrate(expr, x)
            elif mode == 'limit': result = sp.limit(expr, x, 0)
            elif mode == 'series': result = expr.series(x, 0, 10)
            elif mode == 'eval': result = expr.evalf()
            elif mode == 'subs':
                t, ok = QInputDialog.getText(self, 'Substitute', 'Enter var=value (e.g. x=2):')
                if not ok or not t: return
                var, val = map(str.strip, t.split('=', 1))
                result = expr.subs({sp.symbols(var): self._parse_symbolic(val)[0]})
            elif mode == 'matrix':
                t, ok = QInputDialog.getText(self, 'Matrix', 'Enter elements, e.g. [[1,2],[3,4]]:')
                if not ok: return
                result = sp.Matrix(ast.literal_eval(t)).det()
            elif mode == 'plot':
                sp.plot(expr); result = 'Plot displayed in a separate window.'
            else: result = expr
            self.sym_result.setPlainText(str(result))
        except Exception as exc:
            self.sym_result.setPlainText('Could not understand that expression.\nTry: x^2 + 2x = 3,  2x + 5 = 11,  or sin(x)/x\n\nDetails: ' + str(exc))

    def apply_theme_variant(self, name):
        if name in ('☀  Light','🪟  Windows Light','📝  Office Blue'):
            self._apply_light_palette()
        else:
            self._apply_dark_palette()

    def _apply_light_palette(self):
        self.setStyleSheet('''
            QA5CalculatorTab, CalculatorTab, EnhancedCalculatorTab, PolishedCalculatorTab { background:#f3f3f3; }
            #calcDisplay { background:#ffffff;color:#111827;border:1px solid #c7cdd6;border-radius:10px;padding:14px;font-size:30px;font-weight:700; }
            #exprDisplay { background:#f3f3f3;color:#5f6b7a;border:none;padding:4px 14px; }
            #historyList { background:#ffffff;color:#374151;border:1px solid #d6dbe2;border-radius:8px; }
            QPushButton[btnType="digit"] { background:#ffffff;color:#111827;border:1px solid #d5d9df;border-radius:8px;font-size:17px;font-weight:600; }
            QPushButton[btnType="digit"]:hover { background:#f0f5fb; }
            QPushButton[btnType="op"] { background:#e8f2fb;color:#005a9e;border:1px solid #bfd8ef;border-radius:8px;font-size:17px;font-weight:700; }
            QPushButton[btnType="fn"] { background:#f4f0fb;color:#5b35a8;border:1px solid #d9c9ef;border-radius:8px;font-weight:600; }
            QPushButton[btnType="mem"] { background:#eef7ee;color:#24733b;border:1px solid #cde6d2;border-radius:8px; }
            QPushButton[btnType="clear"] { background:#fff0f0;color:#b42318;border:1px solid #f4c7c7;border-radius:8px;font-weight:700; }
            QPushButton[btnType="eq"] { background:#0067c0;color:white;border:none;border-radius:8px;font-size:20px;font-weight:700; }
        ''')
        self.sub_tabs.setStyleSheet('QTabWidget::pane{border:none;background:#f3f3f3;} QTabBar{background:#f3f3f3;} QTabBar::tab{background:#f3f3f3;color:#4b5563;padding:9px 18px;border:none;border-bottom:2px solid transparent;min-width:100px;} QTabBar::tab:selected{color:#0067c0;border-bottom:2px solid #0067c0;font-weight:700;} QTabBar::tab:hover{background:#e9eef4;color:#005a9e;}')
        self.sym_input.setStyleSheet('QLineEdit{background:#ffffff;color:#111827;border:1px solid #b9c2cc;border-radius:9px;padding:11px 14px;font-size:14px;} QLineEdit:focus{border:2px solid #0067c0;}')
        self.sym_result.setStyleSheet('QTextEdit{background:#ffffff;color:#173b27;border:1px solid #b9c2cc;border-radius:9px;padding:10px 14px;font-size:13px;font-family:Consolas,monospace;}')
        try:
            self.categoryCombo.setStyleSheet('QComboBox{background:white;color:#111827;border:1px solid #b9c2cc;border-radius:8px;padding:7px 10px;}')
            self.valueInput.setStyleSheet('QDoubleSpinBox{background:white;color:#111827;border:1px solid #b9c2cc;border-radius:8px;padding:10px 12px;font-size:18px;}')
            for c in (self.fromUnitCombo,self.toUnitCombo): c.setStyleSheet('QComboBox{background:white;color:#111827;border:1px solid #b9c2cc;border-radius:8px;padding:7px 10px;}')
        except Exception: pass
        self._style_programmer(True)

    def _apply_dark_palette(self):
        try:
            self._polish_numeric(); self._polish_symbolic(); self._polish_unit_converter()
        except Exception: pass
        self._style_programmer(False)

    def _style_programmer(self, light):
        page=None
        for i in range(self.sub_tabs.count()):
            if self.sub_tabs.tabText(i)=='Programmer': page=self.sub_tabs.widget(i); break
        if not page: return
        if light:
            page.setStyleSheet('QWidget#programmerPanel{background:#f3f3f3;} QLabel{color:#374151;}')
            self.baseCombo.setStyleSheet('QComboBox{background:white;color:#111827;border:1px solid #b9c2cc;border-radius:8px;padding:7px 10px;}')
            self.progInput.setStyleSheet('QLineEdit{font-size:28px;background:white;color:#111827;border:1px solid #b9c2cc;border-radius:9px;padding:9px 12px;} QLineEdit:focus{border:2px solid #0067c0;}')
            for v in self.prog.values(): v.setStyleSheet('QLineEdit{background:white;color:#111827;border:1px solid #d4d9df;border-radius:6px;padding:6px 9px;font-family:Consolas;font-size:13px;}')
            for b in page.findChildren(QPushButton):
                t=b.text()
                if t in {'⌫','CE','C'}: style='background:#fff0f0;color:#b42318;border:1px solid #f4c7c7;'
                elif t in {'&','|','^','<<','>>','NOT','+','-','*','/'}: style='background:#e8f2fb;color:#005a9e;border:1px solid #bfd8ef;'
                elif len(t)==1 and t in 'ABCDEF': style='background:#f4f0fb;color:#5b35a8;border:1px solid #d9c9ef;'
                else: style='background:#ffffff;color:#111827;border:1px solid #d5d9df;'
                b.setStyleSheet('QPushButton{'+style+'border-radius:8px;font-size:14px;font-weight:600;} QPushButton:hover{background:#eef3f8;} QPushButton:disabled{background:#e7e9ec;color:#9ca3af;border:1px solid #d8dce1;}')
        else:
            current=self.progInput.text(); base=self.baseCombo.currentText()
            self._rebuild_programmer(); self.baseCombo.setCurrentText(base); self.progInput.setText(current)


class SmoothTapDrawingCanvas(DrawingCanvas):
    def __init__(self):
        super().__init__(); self.tap_draw=True; self._tap_active=False; self.stroke_points=[]
    def set_tap_draw(self, enabled):
        self.tap_draw=bool(enabled)
        if not self.tap_draw and self._tap_active: self._commit_stroke(); self._tap_active=False
    def _smooth_path_from_points(self):
        pts=self.stroke_points
        if not pts: return QPainterPath()
        p=QPainterPath(pts[0])
        if len(pts)==1: return p
        if len(pts)==2: p.lineTo(pts[1]); return p
        for i in range(1,len(pts)-1):
            a,b=pts[i],pts[i+1]; mid=QPointF((a.x()+b.x())/2,(a.y()+b.y())/2); p.quadTo(a,mid)
        p.lineTo(pts[-1]); return p
    def _start_stroke(self,pos):
        self.startPoint=pos; self.endPoint=pos; self.drawing=True; self.stroke_points=[pos]; self.current_path=QPainterPath(pos); self.preview_item.setPen(self._effective_pen()); self.preview_item.setPath(self.current_path)
    def _commit_stroke(self):
        if not self.drawing:return
        path=self._smooth_path_from_points() if self.drawing_mode=='Pencil' else self._shape_path()
        painter=QPainter(self.canvas_pixmap); painter.setRenderHint(QPainter.Antialiasing,True); painter.setPen(self._effective_pen()); painter.drawPath(path); painter.end()
        self.image_item.setPixmap(self.canvas_pixmap); self.preview_item.setPath(QPainterPath()); self.save_history(); self.drawing=False; self.stroke_points=[]
    def mousePressEvent(self,event):
        if event.button()!=Qt.LeftButton: return QGraphicsView.mousePressEvent(self,event)
        pos=self.mapToScene(event.pos())
        if self.drawing_mode=='Text': return DrawingCanvas.mousePressEvent(self,event)
        if self.drawing_mode!='Pencil' or not self.tap_draw:
            self._tap_active=False; return DrawingCanvas.mousePressEvent(self,event)
        if self._tap_active:
            self.stroke_points.append(pos); self._commit_stroke(); self._tap_active=False
        else:
            self._start_stroke(pos); self._tap_active=True
    def mouseMoveEvent(self,event):
        if self.drawing_mode=='Pencil' and self.drawing:
            pos=self.mapToScene(event.pos()); self.endPoint=pos
            if not self.stroke_points or (abs(pos.x()-self.stroke_points[-1].x())+abs(pos.y()-self.stroke_points[-1].y()))>=0.8:
                self.stroke_points.append(pos); self.current_path=self._smooth_path_from_points(); self.preview_item.setPath(self.current_path)
            return
        DrawingCanvas.mouseMoveEvent(self,event)
    def mouseReleaseEvent(self,event):
        if self.drawing_mode=='Pencil' and self.tap_draw and self._tap_active:return
        if self.drawing_mode=='Pencil' and self.drawing and not self.tap_draw:
            self.stroke_points.append(self.mapToScene(event.pos())); self._commit_stroke(); return
        DrawingCanvas.mouseReleaseEvent(self,event)


class QA5NotesAndDrawingTab(PolishedNotesAndDrawingTab):
    def __init__(self):
        super().__init__(); self._recent_file=Path.home()/'.jesson_recent_notes.json'; self._replace_canvas(); self._install_tap_toggle(); self._load_recent_notes_index()
    def _replace_canvas(self):
        old=self.canvas; parent=old.parentWidget(); lay=parent.layout(); idx=lay.indexOf(old); lay.removeWidget(old); old.setParent(None)
        self.canvas=SmoothTapDrawingCanvas(); lay.insertWidget(idx,self.canvas,1)
        for b in parent.findChildren(QPushButton):
            try:
                if 'Undo' in b.text(): b.clicked.disconnect(); b.clicked.connect(self.canvas.undo)
                elif 'Clear' in b.text(): b.clicked.disconnect(); b.clicked.connect(self.canvas.clear_canvas)
                elif b.text()=='💾 Save': b.clicked.disconnect(); b.clicked.connect(self.canvas.save_image)
            except Exception: pass
        self.canvas.set_drawing_mode(self.shapeCombo.currentText().split()[-1]); self.change_size(self.sizeSpin.value())
    def _install_tap_toggle(self):
        tb=self.shapeCombo.parentWidget(); lay=tb.layout() if tb else None
        self.tapDrawCheck=QCheckBox('Tap draw'); self.tapDrawCheck.setChecked(True); self.tapDrawCheck.setToolTip('Click once to start drawing, move the pointer, click again to finish. Turn off for hold-and-drag drawing.'); self.tapDrawCheck.toggled.connect(self.canvas.set_tap_draw)
        if lay: lay.insertWidget(max(0,lay.count()-1),self.tapDrawCheck)
    def _remember_note(self,path):
        path=str(Path(path).resolve()); items=[self.recentNotes.itemData(i) for i in range(1,self.recentNotes.count()) if self.recentNotes.itemData(i)]; items=[path]+[x for x in items if x!=path and Path(x).exists()]
        try:self._recent_file.write_text(json.dumps(items[:15]),encoding='utf-8')
        except Exception:pass
    def _load_recent_notes_index(self):
        try:items=json.loads(self._recent_file.read_text(encoding='utf-8')) if self._recent_file.exists() else []
        except Exception:items=[]
        for p in items:
            if Path(p).exists() and self.recentNotes.findData(p)<0:self.recentNotes.addItem(Path(p).name,p)
        self.recentNotes.setStyleSheet('QComboBox{background:white;color:#374151;border:1px solid #d1d5db;border-radius:5px;padding:4px 8px;min-width:170px;}')
    def save_notes(self):
        text=self.notesEdit.toPlainText().strip()
        if not text: QMessageBox.information(self,'Save Notes','Write something before saving.'); return
        path,_=QFileDialog.getSaveFileName(self,'Save Notes','','Text Files (*.txt);;HTML Notes (*.html)')
        if not path:return
        try:
            Path(path).write_text(self.notesEdit.toHtml() if path.lower().endswith('.html') else self.notesEdit.toPlainText(),encoding='utf-8')
            if self.recentNotes.findData(path)<0:self.recentNotes.addItem(Path(path).name,path)
            self._remember_note(path); self.recentNotes.setCurrentIndex(0); QMessageBox.information(self,'Saved Note','Saved and added to Recent notes:\n'+path)
        except Exception as e: QMessageBox.warning(self,'Error',str(e))
    def _load_note_path(self,path):
        super()._load_note_path(path); self._remember_note(path)


class QA5DocumentTab(PolishedDocumentTab):
    def __init__(self): super().__init__(); self._activate_ribbon_tabs()
    def _action(self,menu,text,fn,shortcut=None):
        a=menu.addAction(text); a.triggered.connect(fn)
        if shortcut:a.setShortcut(QKeySequence(shortcut))
        return a
    def _activate_ribbon_tabs(self):
        ribbon=self.ribbonScroll.widget(); ribbon.setMinimumWidth(ribbon.sizeHint().width())
        menus={}
        m=QMenu(self); self._action(m,'New',self.new_document,'Ctrl+N'); self._action(m,'Open…',self.load_document,'Ctrl+O'); self._action(m,'Save / Save As…',self.save_document,'Ctrl+S'); m.addSeparator(); self._action(m,'Print…',self.print_document,'Ctrl+P'); self._action(m,'Print Preview…',self.print_preview); menus['File']=m
        m=QMenu(self); self._action(m,'Undo',self.text_undo); self._action(m,'Redo',self.text_redo); m.addSeparator(); self._action(m,'Bold',self.set_bold); self._action(m,'Italic',self.set_italic); self._action(m,'Underline',self.set_underline); self._action(m,'Text Color…',self.set_text_color); self._action(m,'Highlight…',self.set_highlight_color); m.addSeparator(); self._action(m,'Bullets',self.insert_bullet_list); self._action(m,'Numbering',self.insert_numbered_list); self._action(m,'Clear Formatting',self.clear_formatting); menus['Home']=m
        m=QMenu(self); self._action(m,'Table…',self.prompt_insert_table); self._action(m,'Image…',self.insert_image); self._action(m,'Date',self.insert_date); self._action(m,'Page Break',self.insert_page_break); self._action(m,'Footnote',self.insert_footnote); self._action(m,'Horizontal Line',lambda:self.textEdit.textCursor().insertHtml('<hr>')); menus['Insert']=m
        m=QMenu(self)
        for v in ('1.0','1.15','1.5','2.0'): self._action(m,'Line spacing '+v,lambda checked=False,x=v:self.set_line_spacing(x))
        m.addSeparator(); self._action(m,'Header / Footer…',self.edit_header_footer); self._action(m,'Increase Indent',lambda:self.adjust_indent(1)); self._action(m,'Decrease Indent',lambda:self.adjust_indent(-1)); menus['Layout']=m
        m=QMenu(self); self._action(m,'Word Count',lambda:QMessageBox.information(self,'Word Count',self.wordCountLabel.text())); self._action(m,'Find…',self._find_text); menus['Review']=m
        m=QMenu(self); self._action(m,'Zoom In',lambda:self.change_zoom(10)); self._action(m,'Zoom Out',lambda:self.change_zoom(-10)); self._action(m,'Reset Zoom',lambda:self.zoomLabel.setText('100%')); menus['View']=m
        for b in self.findChildren(QPushButton):
            if b.text() in menus: b.setMenu(menus[b.text()]); b.setStyleSheet('QPushButton{border:none;padding:7px 13px;color:#374151;background:#fff;} QPushButton:hover{background:#eef3f8;} QPushButton::menu-indicator{image:none;}')
    def _find_text(self):
        q,ok=QInputDialog.getText(self,'Find','Find text:')
        if ok and q and not self.textEdit.find(q): QMessageBox.information(self,'Find','“'+q+'” was not found.')


class QA5StudyAssistantTab(PolishedStudyAssistantTab):
    def manage_keys(self):
        d=QDialog(self); d.setWindowTitle('Study AI API Keys'); d.resize(500,210); d.setStyleSheet('QDialog{background:#f5f7fb;} QLabel{color:#334155;} QLineEdit{background:white;color:#111827;border:1px solid #cbd5e1;border-radius:8px;padding:8px;} QCheckBox{color:#334155;} QPushButton{background:#4f46e5;color:white;border:none;border-radius:8px;padding:7px 14px;} QPushButton:hover{background:#4338ca;}')
        l=QVBoxLayout(d); l.setContentsMargins(18,18,18,18); l.setSpacing(10); title=QLabel('API Keys'); title.setStyleSheet('font-size:18px;font-weight:700;color:#111827;'); l.addWidget(title); info=QLabel('Keys stay on this PC. Add one or more Gemini keys separated by commas or new lines.'); info.setWordWrap(True); l.addWidget(info)
        edit=QLineEdit(); edit.setEchoMode(QLineEdit.Password); edit.setPlaceholderText('AIza… , AIza…'); edit.setText(','.join(self.api_keys)); l.addWidget(edit); show=QCheckBox('Show keys while editing'); show.toggled.connect(lambda on:edit.setEchoMode(QLineEdit.Normal if on else QLineEdit.Password)); l.addWidget(show)
        buttons=QDialogButtonBox(QDialogButtonBox.Save|QDialogButtonBox.Cancel); buttons.accepted.connect(d.accept); buttons.rejected.connect(d.reject); l.addWidget(buttons)
        if d.exec_()==QDialog.Accepted:
            self.api_keys=[k.strip() for k in re.split(r'[,;\n]+',edit.text()) if k.strip()]; self.apiKeyInput.setText(','.join(self.api_keys)); self.save_config(); self.manageKeysBtn.setText(f'⚙ API Keys ({len(self.api_keys)})' if self.api_keys else '⚙ API Keys')




class QA6CalculatorTab(QA5CalculatorTab):
    """QA6: compact responsive Numeric UI + hardened Symbolic operations."""
    def __init__(self):
        super().__init__()
        self._rebuild_numeric_page()

    def _rebuild_numeric_page(self):
        old = self.sub_tabs.widget(0)
        self.sub_tabs.removeTab(0)

        page = QWidget()
        page.setObjectName('numericPanel')
        root = QVBoxLayout(page)
        root.setContentsMargins(16, 14, 16, 16)
        root.setSpacing(8)

        # Reuse the existing display widgets so calculation/history state is preserved.
        self.exprDisplay.setMinimumHeight(24)
        self.exprDisplay.setMaximumHeight(32)
        self.display.setMinimumHeight(68)
        self.display.setMaximumHeight(86)
        self.historyList.setMinimumHeight(52)
        self.historyList.setMaximumHeight(74)
        root.addWidget(self.exprDisplay)
        root.addWidget(self.display)
        root.addWidget(self.historyList)

        # Keep the keypad calculator-like on large screens instead of stretching each row endlessly.
        pad_wrap = QWidget()
        pad_wrap.setObjectName('numericPadWrap')
        pad_outer = QHBoxLayout(pad_wrap)
        pad_outer.setContentsMargins(0, 2, 0, 0)
        pad_outer.addStretch(1)
        pad = QWidget()
        pad.setObjectName('numericPad')
        pad.setMaximumWidth(900)
        pad.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Preferred)
        grid = QGridLayout(pad)
        grid.setSpacing(7)
        grid.setContentsMargins(0, 0, 0, 0)

        buttons = [
            ('MC',0,0,1,'mem','MC'), ('MR',0,1,1,'mem','MR'), ('M+',0,2,1,'mem','M+'), ('M−',0,3,1,'mem','M-'), ('⌫',0,4,1,'clear','BS'),
            ('sin',1,0,1,'fn','sin'), ('cos',1,1,1,'fn','cos'), ('tan',1,2,1,'fn','tan'), ('(',1,3,1,'op','('), (')',1,4,1,'op',')'),
            ('asin',2,0,1,'fn','asin'), ('acos',2,1,1,'fn','acos'), ('atan',2,2,1,'fn','atan'), ('√',2,3,1,'fn','sqrt'), ('xʸ',2,4,1,'fn','x^y'),
            ('log',3,0,1,'fn','log10'), ('ln',3,1,1,'fn','ln'), ('π',3,2,1,'fn','pi'), ('e',3,3,1,'fn','e'), ('exp',3,4,1,'fn','exp'),
            ('7',4,0,1,'digit','7'), ('8',4,1,1,'digit','8'), ('9',4,2,1,'digit','9'), ('÷',4,3,1,'op','/'), ('+/−',4,4,1,'fn','neg'),
            ('4',5,0,1,'digit','4'), ('5',5,1,1,'digit','5'), ('6',5,2,1,'digit','6'), ('×',5,3,1,'op','*'), ('C',5,4,1,'clear','C'),
            ('1',6,0,1,'digit','1'), ('2',6,1,1,'digit','2'), ('3',6,2,1,'digit','3'), ('−',6,3,1,'op','-'), ('=',6,4,2,'eq','='),
            ('0',7,0,2,'digit','0'), ('.',7,2,1,'digit','.'), ('+',7,3,1,'op','+'),
        ]
        for label,row,col,span,btype,action in buttons:
            b=QPushButton(label)
            b.setProperty('btnType',btype)
            b.setMinimumHeight(46)
            b.setMaximumHeight(60)
            b.setSizePolicy(QSizePolicy.Expanding,QSizePolicy.Fixed)
            b.clicked.connect(lambda _,a=action:self._handle_action(a))
            grid.addWidget(b,row,col,1,span)
        for c in range(5): grid.setColumnStretch(c,1)
        pad_outer.addWidget(pad, 8)
        pad_outer.addStretch(1)
        root.addWidget(pad_wrap)
        root.addStretch(1)

        self.numericPage=page
        self.sub_tabs.insertTab(0,page,'Numeric')
        self.sub_tabs.setCurrentIndex(0)
        if old is not None:
            old.deleteLater()
        self._style_numeric_panel(False)

    def _style_numeric_panel(self, light=False):
        if not hasattr(self,'numericPage'): return
        if light:
            self.numericPage.setStyleSheet('QWidget#numericPanel{background:#f3f3f3;} QWidget#numericPadWrap{background:transparent;} QWidget#numericPad{background:transparent;}')
        else:
            self.numericPage.setStyleSheet('QWidget#numericPanel{background:#1a1a2e;} QWidget#numericPadWrap{background:transparent;} QWidget#numericPad{background:transparent;}')

    def apply_theme_variant(self,name):
        super().apply_theme_variant(name)
        self._style_numeric_panel(name in ('☀  Light','🪟  Windows Light','📝  Office Blue'))

    def _choose_symbol(self, expr, title='Variable'):
        symbols=sorted(expr.free_symbols,key=lambda s:s.name)
        if not symbols: return sp.symbols('x')
        if len(symbols)==1: return symbols[0]
        names=[str(s) for s in symbols]
        choice,ok=QInputDialog.getItem(self,title,'Choose variable:',names,0,False)
        return sp.symbols(choice) if ok and choice else symbols[0]

    def _ask_math_value(self,title,label,default='0'):
        text,ok=QInputDialog.getText(self,title,label,text=str(default))
        if not ok: return None
        parsed,is_eq=self._parse_symbolic(text)
        if is_eq: raise ValueError('Enter a value or expression, not an equation.')
        return parsed

    def sym_compute(self, mode):
        raw=self.sym_input.text().strip()
        if not raw:return
        try:
            parsed,is_eq=self._parse_symbolic(raw)
            expr=sp.simplify(parsed.lhs-parsed.rhs) if is_eq else parsed
            var=self._choose_symbol(expr)

            if mode=='solve':
                target=parsed if is_eq else sp.Eq(expr,0)
                result=sp.solve(target,var)
                if isinstance(result,dict): result=[result]
                if not result:
                    out='No solution found.'
                else:
                    out='\n'.join(f'{var} = {sp.simplify(v)}' if not isinstance(v,dict) else str(v) for v in result)
                self.sym_result.setPlainText(out); return
            if is_eq and mode=='eval':
                self.sym_compute('solve'); return
            if mode=='factor': result=sp.factor(expr)
            elif mode=='expand': result=sp.expand(expr)
            elif mode=='simplify': result=sp.simplify(expr)
            elif mode=='diff':
                order,ok=QInputDialog.getInt(self,'Differentiate','Derivative order:',1,1,10,1)
                if not ok:return
                result=sp.diff(expr,var,order)
            elif mode=='int':
                choice,ok=QInputDialog.getItem(self,'Integrate','Integration type:',['Indefinite','Definite'],0,False)
                if not ok:return
                if choice=='Definite':
                    lo=self._ask_math_value('Integrate','Lower limit:','0');
                    if lo is None:return
                    hi=self._ask_math_value('Integrate','Upper limit:','1');
                    if hi is None:return
                    result=sp.integrate(expr,(var,lo,hi))
                else: result=sp.integrate(expr,var)
            elif mode=='limit':
                point=self._ask_math_value('Limit','Approach value:','0')
                if point is None:return
                direction,ok=QInputDialog.getItem(self,'Limit','Direction:',['Both sides','From left (-)','From right (+)'],0,False)
                if not ok:return
                d={ 'Both sides':'+-', 'From left (-)':'-', 'From right (+)':'+' }[direction]
                result=sp.limit(expr,var,point,dir=d)
            elif mode=='series':
                point=self._ask_math_value('Series','Expansion point:','0')
                if point is None:return
                order,ok=QInputDialog.getInt(self,'Series','Number of terms / order:',6,2,30,1)
                if not ok:return
                result=sp.series(expr,var,point,order)
            elif mode=='eval': result=sp.N(expr)
            elif mode=='subs':
                t,ok=QInputDialog.getText(self,'Substitute','Enter var=value (e.g. x=2):')
                if not ok or not t:return
                name,val=map(str.strip,t.split('=',1)); pv,_=self._parse_symbolic(val)
                result=expr.subs(sp.symbols(name),pv)
            elif mode=='matrix':
                t,ok=QInputDialog.getText(self,'Matrix','Enter matrix, e.g. [[1,2],[3,4]]:')
                if not ok:return
                mat=sp.Matrix(ast.literal_eval(t))
                op,ok=QInputDialog.getItem(self,'Matrix','Operation:',['Determinant','Inverse','Rank','Eigenvalues'],0,False)
                if not ok:return
                result={'Determinant':lambda:mat.det(),'Inverse':lambda:mat.inv(),'Rank':lambda:mat.rank(),'Eigenvalues':lambda:mat.eigenvals()}[op]()
            elif mode=='plot':
                if len(expr.free_symbols)>1: raise ValueError('Plot currently supports one variable at a time.')
                sp.plot(expr,(var,-10,10)); result='Plot displayed in a separate window.'
            else: result=expr
            self.sym_result.setPlainText(str(result))
        except Exception as exc:
            self.sym_result.setPlainText('Could not complete that operation.\n\nExamples:\n  x^2 + 2x = 3\n  sin(x)/x\n  2x + 5\n\nDetails: '+str(exc))


class QA6DocumentTab(QA5DocumentTab):
    """QA6: stable empty-document placeholder + table formulas/recalculation."""
    FORMULA_PROPERTY = QTextFormat.UserProperty + 611

    def __init__(self):
        super().__init__()
        self._setup_empty_overlay()
        self._add_table_formula_controls()

    def _setup_empty_overlay(self):
        # QTextEdit's native placeholder participates visually with an empty list block.
        # Use an overlay label instead so bullets/numbering never corrupt the default message.
        self.textEdit.setPlaceholderText('')
        self.emptyHint=QLabel('Start writing…',self.textEdit.viewport())
        self.emptyHint.setStyleSheet('color:#9aa3af;background:transparent;font-size:15px;font-style:italic;')
        self.emptyHint.setAttribute(Qt.WA_TransparentForMouseEvents,True)
        self.emptyHint.adjustSize(); self.emptyHint.move(28,24)
        self.textEdit.textChanged.connect(self._refresh_empty_overlay)
        self.textEdit.cursorPositionChanged.connect(self._refresh_empty_overlay)
        self.textEdit.viewport().installEventFilter(self)
        self._refresh_empty_overlay()

    def eventFilter(self,obj,event):
        if getattr(self,'emptyHint',None) is not None and obj is self.textEdit.viewport() and event.type()==QEvent.Resize:
            self.emptyHint.move(28,24)
        return super().eventFilter(obj,event)

    def _refresh_empty_overlay(self):
        if getattr(self,'emptyHint',None) is None:return
        empty=not self.textEdit.toPlainText().strip()
        # If the user deliberately activated a list on an empty paragraph, show the list marker only,
        # not a placeholder colliding with it.
        has_list=self.textEdit.textCursor().currentList() is not None
        self.emptyHint.setVisible(empty and not has_list)

    def insert_bullet_list(self):
        super().insert_bullet_list(); self._refresh_empty_overlay()
    def insert_numbered_list(self):
        super().insert_numbered_list(); self._refresh_empty_overlay()

    def _add_table_formula_controls(self):
        # Add Formula/Recalculate to the Insert menu.
        for b in self.findChildren(QPushButton):
            if b.text()=='Insert' and b.menu():
                b.menu().addSeparator()
                a=b.menu().addAction('Table Formula…'); a.triggered.connect(self.insert_table_formula)
                a=b.menu().addAction('Recalculate Current Table'); a.triggered.connect(self.recalculate_current_table)
                break
        # Also expose a compact fx button on the scrollable ribbon.
        try:
            ribbon=self.ribbonScroll.widget(); lay=ribbon.layout()
            fx=QPushButton('fx Formula'); fx.setObjectName('toolBtn'); fx.setToolTip('Insert a formula in the current table cell'); fx.clicked.connect(self.insert_table_formula)
            lay.insertWidget(max(0,lay.count()-1),fx)
        except Exception: pass

    def _current_table_cell(self):
        cur=self.textEdit.textCursor(); table=cur.currentTable()
        if not table:return None,None
        cell=table.cellAt(cur.position())
        return table,cell

    def _cell_text(self,cell):
        c=cell.firstCursorPosition(); end=cell.lastCursorPosition().position()
        c.setPosition(max(c.position(),end),QTextCursor.KeepAnchor)
        return c.selectedText().replace('\u2029','\n').strip()

    def _set_cell_text(self,cell,text):
        c=cell.firstCursorPosition(); end=cell.lastCursorPosition().position()
        if end>=c.position(): c.setPosition(end,QTextCursor.KeepAnchor)
        c.beginEditBlock()
        c.removeSelectedText(); c.insertText(str(text))
        c.endEditBlock()

    def _col_to_index(self,letters):
        n=0
        for ch in letters.upper(): n=n*26+(ord(ch)-64)
        return n-1

    def _cell_ref(self,table,ref):
        m=re.fullmatch(r'([A-Za-z]+)([1-9]\d*)',ref.strip())
        if not m: raise ValueError('Invalid cell reference: '+ref)
        col=self._col_to_index(m.group(1)); row=int(m.group(2))-1
        if row<0 or col<0 or row>=table.rows() or col>=table.columns(): raise ValueError('Cell '+ref+' is outside this table.')
        return row,col

    def _numeric_cell(self,table,row,col):
        text=self._cell_text(table.cellAt(row,col)).replace(',','').strip()
        if text=='': return 0.0
        try:return float(text)
        except Exception: raise ValueError(f'Cell {chr(65+col) if col<26 else col+1}{row+1} is not numeric: {text}')

    def _range_values(self,table,start,end):
        r1,c1=self._cell_ref(table,start); r2,c2=self._cell_ref(table,end)
        vals=[]
        for r in range(min(r1,r2),max(r1,r2)+1):
            for c in range(min(c1,c2),max(c1,c2)+1): vals.append(self._numeric_cell(table,r,c))
        return vals

    def _formula_value(self,table,cell,formula):
        expr=formula.strip()
        if expr.startswith('='):expr=expr[1:].strip()
        row,col=cell.row(),cell.column()
        # Word-style shorthands. Resolve them directly so first-row/first-column formulas are safe.
        def directional_replace(m):
            fn=m.group(1).upper(); direction=m.group(2).upper()
            if direction=='ABOVE': vals=[self._numeric_cell(table,r,col) for r in range(0,row)]
            else: vals=[self._numeric_cell(table,row,c) for c in range(0,col)]
            if fn=='SUM': v=sum(vals)
            elif fn in ('AVERAGE','AVG'): v=sum(vals)/len(vals) if vals else 0
            elif fn=='MIN': v=min(vals) if vals else 0
            else: v=max(vals) if vals else 0
            return str(v)
        expr=re.sub(r'\b(SUM|AVERAGE|AVG|MIN|MAX)\(\s*(ABOVE|LEFT)\s*\)',directional_replace,expr,flags=re.I)

        def fn_replace(m):
            fn,a,b=m.group(1).upper(),m.group(2),m.group(3)
            vals=self._range_values(table,a,b)
            if fn=='SUM':v=sum(vals)
            elif fn in ('AVERAGE','AVG'):v=sum(vals)/len(vals) if vals else 0
            elif fn=='MIN':v=min(vals) if vals else 0
            else:v=max(vals) if vals else 0
            return str(v)
        expr=re.sub(r'\b(SUM|AVERAGE|AVG|MIN|MAX)\(\s*([A-Za-z]+\d+)\s*:\s*([A-Za-z]+\d+)\s*\)',fn_replace,expr,flags=re.I)

        def cell_replace(m):
            r,c=self._cell_ref(table,m.group(0)); return str(self._numeric_cell(table,r,c))
        expr=re.sub(r'\b[A-Za-z]+[1-9]\d*\b',cell_replace,expr)
        expr=expr.replace('^','**')
        if not re.fullmatch(r'[0-9eE\.\+\-\*\/\%\(\)\s]+',expr): raise ValueError('Formula contains unsupported characters.')
        value=eval(expr,{'__builtins__':{}},{})
        return value

    def _index_to_col(self,idx):
        if idx<0:return 'A'
        s=''; n=idx+1
        while n:
            n,rem=divmod(n-1,26); s=chr(65+rem)+s
        return s

    def insert_table_formula(self):
        table,cell=self._current_table_cell()
        if not table:
            QMessageBox.information(self,'Table Formula','Place the cursor inside a table cell first.'); return
        current=cell.format().property(self.FORMULA_PROPERTY) or '=SUM(ABOVE)'
        formula,ok=QInputDialog.getText(self,'Table Formula','Formula (examples: =SUM(ABOVE), =A1+B1, =AVERAGE(A1:A4)):',text=str(current))
        if not ok or not formula.strip():return
        try:
            value=self._formula_value(table,cell,formula)
            display=str(int(value)) if isinstance(value,(int,float)) and float(value).is_integer() else f'{float(value):.10g}' if isinstance(value,(int,float)) else str(value)
            self._set_cell_text(cell,display)
            fmt=cell.format(); fmt.setProperty(self.FORMULA_PROPERTY,formula.strip()); cell.setFormat(fmt)
        except Exception as exc: QMessageBox.warning(self,'Formula Error',str(exc))

    def recalculate_current_table(self):
        table,cell=self._current_table_cell()
        if not table:
            QMessageBox.information(self,'Recalculate','Place the cursor inside the table you want to recalculate.'); return
        done=0; errors=[]
        for r in range(table.rows()):
            for c in range(table.columns()):
                tc=table.cellAt(r,c); formula=tc.format().property(self.FORMULA_PROPERTY)
                if not formula:continue
                try:
                    value=self._formula_value(table,tc,str(formula)); display=str(int(value)) if isinstance(value,(int,float)) and float(value).is_integer() else f'{float(value):.10g}' if isinstance(value,(int,float)) else str(value)
                    self._set_cell_text(tc,display); done+=1
                except Exception as exc: errors.append(f'{self._index_to_col(c)}{r+1}: {exc}')
        if errors: QMessageBox.warning(self,'Recalculate',f'Recalculated {done} formula(s).\n\nProblems:\n'+'\n'.join(errors[:8]))
        else: QMessageBox.information(self,'Recalculate',f'Recalculated {done} formula(s).')


class QA5ThemesTab(ThemesTab):
    def _apply(self,name,bg,accent,text):
        super()._apply(name,bg,accent,text)
        if hasattr(self._main_parent,'calcTab') and hasattr(self._main_parent.calcTab,'apply_theme_variant'): self._main_parent.calcTab.apply_theme_variant(name)



# ===========================================================================
# V7 REFINED TABS — clean runtime implementations used by MainWindow
# ===========================================================================

class RefinedMusicPlayerTab(MusicPlayerTab):
    """Music player with persistent favourites and queue/media order kept in sync."""
    FAVORITE_ROLE = Qt.UserRole + 42

    def __init__(self):
        self._favorites_file = Path.home() / '.jesson_reader' / 'music_favorites.json'
        self._favorite_paths = set()
        self._favorites_only = False
        self._load_favorites()
        super().__init__()
        self._upgrade_refined_music()

    def _load_favorites(self):
        try:
            data = json.loads(self._favorites_file.read_text(encoding='utf-8')) if self._favorites_file.exists() else []
            self._favorite_paths = {os.path.normcase(os.path.abspath(p)) for p in data if isinstance(p, str) and p}
        except Exception:
            self._favorite_paths = set()

    def _save_favorites(self):
        try:
            self._favorites_file.parent.mkdir(parents=True, exist_ok=True)
            live = sorted(p for p in self._favorite_paths if os.path.exists(p))
            self._favorites_file.write_text(json.dumps(live, indent=2), encoding='utf-8')
        except Exception:
            pass

    def _norm(self, path):
        return os.path.normcase(os.path.abspath(path)) if path else ''

    def _upgrade_refined_music(self):
        panel = self.findChild(QWidget, 'playlistPanel')
        if not panel or not panel.layout():
            return
        self.queueSearch = QLineEdit(); self.queueSearch.setObjectName('musicQueueSearch')
        self.queueSearch.setPlaceholderText('Search loaded tracks…')
        self.queueSearch.setClearButtonEnabled(True)
        self.queueSearch.setToolTip('Search the currently loaded playlist by song name or file location.')
        self.queueSearch.setStyleSheet('QLineEdit{background:#242424;color:#f5f5f5;border:1px solid #3a3a3a;border-radius:16px;padding:7px 12px;}')
        panel.layout().insertWidget(1, self.queueSearch)

        row = QHBoxLayout(); row.setSpacing(8)
        self.favBtn = QPushButton('☆ Favourite'); self.favBtn.setObjectName('musicSecondaryBtn')
        self.favoritesBtn = QPushButton('★ Favorites'); self.favoritesBtn.setCheckable(True); self.favoritesBtn.setObjectName('musicSecondaryBtn')
        self.clearQueueBtn = QPushButton('Clear Queue'); self.clearQueueBtn.setObjectName('musicSecondaryBtn')
        for b in (self.favBtn, self.favoritesBtn, self.clearQueueBtn):
            b.setStyleSheet('QPushButton{background:#2a2a2a;color:#e5e7eb;border:1px solid #3a3a3a;border-radius:8px;padding:6px 12px;} QPushButton:hover{background:#343434;} QPushButton:checked{background:#423d72;color:white;border-color:#7c6af7;}')
        row.addWidget(self.favBtn); row.addWidget(self.favoritesBtn); row.addWidget(self.clearQueueBtn); row.addStretch()
        panel.layout().insertLayout(2, row)

        self.queueSearch.textChanged.connect(self._filter_queue)
        self.favBtn.clicked.connect(self._toggle_favorite)
        self.favoritesBtn.toggled.connect(self._show_favorites)
        self.clearQueueBtn.clicked.connect(self._clear_queue_safely)
        self.playlistView.currentItemChanged.connect(lambda *_: self._update_favorite_button())
        try:
            self.playlistView.model().rowsMoved.connect(lambda *_: self._sync_playlist_from_view())
        except Exception:
            pass

        for name in ('btnShuffle','btnPrev','btnPlay','btnNext','btnRepeat','btnStop'):
            b = getattr(self, name, None)
            if b:
                b.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)
        self._apply_favorite_marks()

    def _paths_in_view(self):
        return [self.playlistView.item(i).data(Qt.UserRole) for i in range(self.playlistView.count()) if self.playlistView.item(i).data(Qt.UserRole)]

    def _sync_playlist_from_view(self, preserve_path=None):
        """Rebuild QMediaPlaylist from the visible queue order.

        QListWidget supports drag/drop reordering, but QMediaPlaylist does not automatically
        follow that move. Keeping them synchronized prevents row 0/1 from pointing at the
        wrong media item, which was the likely cause of the first tracks appearing loaded but
        not playing reliably.
        """
        if preserve_path is None and self.playlist.currentIndex() >= 0:
            media = self.mediaPlayer.currentMedia()
            if not media.isNull():
                preserve_path = media.canonicalUrl().toLocalFile()
        paths = self._paths_in_view()
        self.mediaPlayer.stop()
        self.playlist.clear()
        for p in paths:
            if p and os.path.exists(p):
                self.playlist.addMedia(QMediaContent(QUrl.fromLocalFile(p)))
        if preserve_path:
            n = self._norm(preserve_path)
            for i, p in enumerate(paths):
                if self._norm(p) == n:
                    self.playlist.setCurrentIndex(i)
                    break

    def _apply_favorite_marks(self):
        for i in range(self.playlistView.count()):
            item = self.playlistView.item(i)
            path = item.data(Qt.UserRole) or ''
            fav = self._norm(path) in self._favorite_paths
            item.setData(self.FAVORITE_ROLE, fav)
            item.setText(('★  ' if fav else '  ') + QFileInfo(path).fileName())
        self._update_favorite_button()
        self._filter_queue(self.queueSearch.text() if hasattr(self, 'queueSearch') else '')

    def _update_favorite_button(self):
        item = self.playlistView.currentItem()
        fav = bool(item and item.data(self.FAVORITE_ROLE))
        if hasattr(self, 'favBtn'):
            self.favBtn.setText('★ Unfavorite' if fav else '☆ Favourite')

    def _filter_queue(self, q):
        """Filter only the tracks already loaded in the current queue.

        Search and Favorites are combined: typing narrows the current queue, while the
        Favorites toggle shows only favorited songs from that same loaded playlist.
        Neither action mutates the QMediaPlaylist or pulls unrelated tracks into the queue.
        """
        q = (q or '').casefold().strip()
        tokens = [t for t in q.split() if t]
        visible = 0
        for i in range(self.playlistView.count()):
            item = self.playlistView.item(i)
            path = item.data(Qt.UserRole) or ''
            filename = QFileInfo(path).fileName() if path else item.text()
            haystack = (' '.join((item.text(), filename, path))).casefold()
            search_ok = all(token in haystack for token in tokens)
            fav_ok = (not self._favorites_only) or bool(item.data(self.FAVORITE_ROLE))
            hide = not (search_ok and fav_ok)
            item.setHidden(hide)
            if not hide:
                visible += 1

        # Make the result state obvious without changing the actual playlist count.
        total = self.playlistView.count()
        if hasattr(self, 'trackCountLabel'):
            if q or self._favorites_only:
                self.trackCountLabel.setText(f'{visible} shown · {total} loaded')
            else:
                self.trackCountLabel.setText(f"{total} track{'s' if total != 1 else ''}")

    def _show_favorites(self, on):
        # Favorites is a FILTER, not a second playlist. Only favorite tracks that
        # are present in the currently loaded queue are shown.
        self._favorites_only = bool(on)
        self._filter_queue(self.queueSearch.text())

    def _toggle_favorite(self):
        item = self.playlistView.currentItem()
        if not item:
            return
        path = item.data(Qt.UserRole) or ''
        key = self._norm(path)
        if not key:
            return
        if key in self._favorite_paths:
            self._favorite_paths.remove(key); fav = False
        else:
            self._favorite_paths.add(key); fav = True
        item.setData(self.FAVORITE_ROLE, fav)
        item.setText(('★  ' if fav else '  ') + QFileInfo(path).fileName())
        self._save_favorites(); self._update_favorite_button(); self._filter_queue(self.queueSearch.text())

    def add_music(self):
        before = self.playlistView.count()
        super().add_music()
        if self.playlistView.count() != before:
            self._apply_favorite_marks()
            self._sync_playlist_from_view()

    def save_playlist(self):
        """Save the current queue as an UTF-8 M3U8 playlist using absolute paths."""
        path, _ = QFileDialog.getSaveFileName(
            self, 'Save Playlist', '', 'M3U8 Playlist (*.m3u8);;M3U Playlist (*.m3u)'
        )
        if not path:
            return
        if not path.lower().endswith(('.m3u', '.m3u8')):
            path += '.m3u8'
        try:
            tracks = self._paths_in_view()
            with open(path, 'w', encoding='utf-8', newline='\n') as fh:
                fh.write('#EXTM3U\n')
                for track in tracks:
                    if not track:
                        continue
                    absolute = os.path.abspath(track)
                    fh.write(f'#EXTINF:-1,{QFileInfo(absolute).completeBaseName()}\n')
                    fh.write(absolute + '\n')
            QMessageBox.information(
                self, 'Playlist Saved',
                f'Saved {len(tracks)} track(s).\n\nThe playlist stores each song\'s file location so the same queue can be restored later.'
            )
        except Exception as exc:
            QMessageBox.warning(self, 'Playlist Save Error', str(exc))

    def load_playlist(self):
        """Restore a saved M3U/M3U8 playlist and its file locations reliably."""
        playlist_path, _ = QFileDialog.getOpenFileName(
            self, 'Load Playlist', '', 'Playlists (*.m3u *.m3u8);;All Files (*.*)'
        )
        if not playlist_path:
            return

        loaded, missing = [], []
        base_dir = os.path.dirname(os.path.abspath(playlist_path))
        try:
            with open(playlist_path, 'r', encoding='utf-8-sig', errors='replace') as fh:
                for raw in fh:
                    entry = raw.strip()
                    if not entry or entry.startswith('#'):
                        continue

                    # Accept both ordinary M3U paths and file:/// URLs.
                    if entry.lower().startswith('file:'):
                        p = QUrl(entry).toLocalFile()
                    else:
                        p = entry
                    if not os.path.isabs(p):
                        p = os.path.abspath(os.path.join(base_dir, p))
                    p = os.path.normpath(p)

                    if os.path.isfile(p):
                        loaded.append(p)
                    else:
                        missing.append(p)
        except Exception as exc:
            QMessageBox.warning(self, 'Playlist Load Error', str(exc))
            return

        self.mediaPlayer.stop()
        self.playlist.clear()
        self.playlistView.clear()

        for p in loaded:
            item = QListWidgetItem('  ' + QFileInfo(p).fileName())
            item.setData(Qt.UserRole, p)
            item.setToolTip(p)
            self.playlistView.addItem(item)
            self.playlist.addMedia(QMediaContent(QUrl.fromLocalFile(p)))

        self._apply_favorite_marks()
        self._update_track_count()
        self._filter_queue(self.queueSearch.text())

        if loaded:
            self.playlistView.setCurrentRow(0)
            self.playlist.setCurrentIndex(0)

        if missing:
            preview = '\n'.join(missing[:6])
            more = f'\n…and {len(missing)-6} more' if len(missing) > 6 else ''
            QMessageBox.warning(
                self, 'Playlist Loaded with Missing Files',
                f'Loaded {len(loaded)} track(s), but {len(missing)} file(s) could not be found:\n\n{preview}{more}'
            )
        elif loaded:
            QMessageBox.information(self, 'Playlist Loaded', f'Loaded {len(loaded)} track(s).')
        else:
            QMessageBox.warning(self, 'Playlist', 'No usable audio files were found in that playlist.')

    def play_selected(self, item):
        path = item.data(Qt.UserRole) or ''
        if not path or not os.path.isfile(path):
            QMessageBox.warning(self, 'Music', 'That audio file can no longer be found on disk.')
            return

        # Always resolve playback from the file path stored on the clicked row.
        # This prevents QListWidget reordering/filtering from drifting away from
        # QMediaPlaylist indexes.
        paths = self._paths_in_view()
        target = self._norm(path)

        # Rebuild if the playlist count/order no longer matches the visible queue model.
        media_paths = []
        for i in range(self.playlist.mediaCount()):
            try:
                media_paths.append(self.playlist.media(i).canonicalUrl().toLocalFile())
            except Exception:
                media_paths.append('')
        if len(media_paths) != len(paths) or any(self._norm(a) != self._norm(b) for a, b in zip(media_paths, paths)):
            self._sync_playlist_from_view()

        idx = next((i for i, p in enumerate(paths) if self._norm(p) == target), -1)
        if idx < 0:
            return

        self.playlistView.setCurrentItem(item)
        self.mediaPlayer.stop()

        # Force an actual media transition even for row 0/1 or when re-clicking
        # the currently selected song. Some Windows Qt multimedia backends do
        # not restart reliably if setCurrentIndex() is called with the same index.
        try:
            self.playlist.setCurrentIndex(-1)
        except Exception:
            pass

        def select_track():
            self.playlist.setCurrentIndex(idx)
            QTimer.singleShot(90, self.mediaPlayer.play)

        QTimer.singleShot(25, select_track)

    def _clear_queue_safely(self):
        self.mediaPlayer.stop(); self.playlist.clear(); self.playlistView.clear(); self._update_track_count()
        self.trackTitle.setText('No track playing'); self.trackSub.setText('—'); self.albumArt.setPixmap(QPixmap()); self.albumArt.setText('♪')
        self._update_favorite_button()

class RefinedDocumentTab(QA6DocumentTab):
    """Word-style ribbon tabs over the proven QA6 writer engine."""
    def __init__(self):
        super().__init__()
        self._doc_zoom=100
        self._build_real_ribbon()

    def _hide_legacy_ribbon(self):
        # Hide only the old tab strip and long one-row ribbon; the page/editor remains intact.
        if hasattr(self,'ribbonScroll'): self.ribbonScroll.hide()
        root=self.layout()
        for i in range(root.count()):
            w=root.itemAt(i).widget()
            if w and w is not getattr(self,'ribbonScroll',None):
                buttons=w.findChildren(QPushButton)
                names={b.text() for b in buttons}
                if {'File','Home','Insert','Layout','Review','View'}.issubset(names):
                    w.hide()

    def _tool(self,text,slot,tip=''):
        b=QPushButton(text); b.setObjectName('wordRibbonTool'); b.setToolTip(tip or text); b.clicked.connect(slot)
        b.setStyleSheet('QPushButton{background:transparent;color:#1f2937;border:1px solid transparent;border-radius:4px;padding:6px 9px;} QPushButton:hover{background:#eaf2fb;border-color:#d6e4f0;}')
        return b

    def _group(self,title,widgets):
        box=QWidget(); vl=QVBoxLayout(box); vl.setContentsMargins(8,5,8,3); vl.setSpacing(4)
        row=QHBoxLayout(); row.setSpacing(4)
        for w in widgets: row.addWidget(w)
        vl.addLayout(row); lab=QLabel(title); lab.setAlignment(Qt.AlignCenter); lab.setStyleSheet('color:#6b7280;font-size:9px;'); vl.addWidget(lab)
        return box

    def _build_real_ribbon(self):
        self._hide_legacy_ribbon()
        root=self.layout()
        wrap=QWidget(); wrap.setObjectName('wordRibbonHost'); v=QVBoxLayout(wrap); v.setContentsMargins(0,0,0,0); v.setSpacing(0)
        top=QHBoxLayout(); top.setContentsMargins(8,0,8,0); top.setSpacing(2)
        fileBtn=QToolButton(); fileBtn.setText('File'); fileBtn.setPopupMode(QToolButton.InstantPopup)
        fm=QMenu(fileBtn)
        for text,fn,sc in [('New',self.new_document,'Ctrl+N'),('Open…',self.load_document,'Ctrl+O'),('Save / Save As…',self.save_document,'Ctrl+S'),('Print…',self.print_document,'Ctrl+P'),('Print Preview…',self.print_preview,None)]:
            a=fm.addAction(text); a.triggered.connect(fn); sc and a.setShortcut(QKeySequence(sc))
        fileBtn.setMenu(fm); fileBtn.setStyleSheet('QToolButton{border:none;padding:8px 14px;color:#2b579a;font-weight:600;} QToolButton:hover{background:#edf3f9;}')
        top.addWidget(fileBtn)
        self.wordTabs=QTabWidget(); self.wordTabs.setDocumentMode(True); self.wordTabs.setObjectName('wordRibbonTabs')
        self.wordTabs.setStyleSheet('QTabWidget::pane{border:0;border-top:1px solid #d8dde5;background:#fbfbfb;} QTabBar::tab{background:white;color:#374151;padding:7px 15px;border:0;border-bottom:2px solid transparent;} QTabBar::tab:selected{color:#2b579a;border-bottom:2px solid #2b579a;font-weight:600;}')
        top.addWidget(self.wordTabs,1)
        topHost=QWidget(); topHost.setLayout(top); v.addWidget(topHost)
        # Each tab has its own actual command surface.
        self._add_home_ribbon(); self._add_insert_ribbon(); self._add_layout_ribbon(); self._add_review_ribbon(); self._add_view_ribbon()
        # QTabWidget content belongs below its own tab bar; topHost already contains it.
        root.insertWidget(1,wrap)

    def _add_home_ribbon(self):
        p=QWidget(); h=QHBoxLayout(p); h.setContentsMargins(8,4,8,4); h.setSpacing(4)
        fontBox=QFontComboBox(); fontBox.setCurrentFont(QFont('Times New Roman')); fontBox.currentFontChanged.connect(self.set_font)
        size=QSpinBox(); size.setRange(8,72); size.setValue(12); size.valueChanged.connect(self.set_font_size)
        styles=QComboBox(); styles.addItems(['Normal','Title','Subtitle','Heading 1','Heading 2','Heading 3','Quote']); styles.currentTextChanged.connect(self.apply_named_style)
        h.addWidget(self._group('Font',[fontBox,size,self._tool('B',self.set_bold),self._tool('I',self.set_italic),self._tool('U',self.set_underline),self._tool('A▾',self.set_text_color),self._tool('🖍',self.set_highlight_color)]))
        h.addWidget(self._group('Styles',[styles]))
        h.addWidget(self._group('Paragraph',[self._tool('• List',self.insert_bullet_list),self._tool('1. List',self.insert_numbered_list),self._tool('⇤',lambda:self.adjust_indent(-1)),self._tool('⇥',lambda:self.adjust_indent(1)),self._tool('Clear',self.clear_formatting)]))
        h.addStretch(); self.wordTabs.addTab(p,'Home')

    def _add_insert_ribbon(self):
        p=QWidget(); h=QHBoxLayout(p); h.setContentsMargins(8,4,8,4)
        h.addWidget(self._group('Pages',[self._tool('New Page',self.insert_page_break)]))
        h.addWidget(self._group('Tables',[self._tool('Table',self.prompt_insert_table),self._tool('fx Formula',self.insert_table_formula),self._tool('Recalculate',self.recalculate_current_table)]))
        h.addWidget(self._group('Illustrations',[self._tool('Image',self.insert_image),self._tool('Line',lambda:self.textEdit.textCursor().insertHtml('<hr>'))]))
        h.addWidget(self._group('Text',[self._tool('Date',self.insert_date),self._tool('Footnote',self.insert_footnote)])); h.addStretch(); self.wordTabs.addTab(p,'Insert')

    def _add_layout_ribbon(self):
        p=QWidget(); h=QHBoxLayout(p); h.setContentsMargins(8,4,8,4)
        ls=QComboBox(); ls.addItems(['1.0','1.15','1.5','2.0']); ls.currentTextChanged.connect(self.set_line_spacing)
        h.addWidget(self._group('Paragraph',[QLabel('Line spacing'),ls,self._tool('Indent −',lambda:self.adjust_indent(-1)),self._tool('Indent +',lambda:self.adjust_indent(1))]))
        h.addWidget(self._group('Page',[self._tool('Header / Footer',self.edit_header_footer),self._tool('Page Break',self.insert_page_break)])); h.addStretch(); self.wordTabs.addTab(p,'Layout')

    def _add_review_ribbon(self):
        p=QWidget(); h=QHBoxLayout(p); h.setContentsMargins(8,4,8,4)
        h.addWidget(self._group('Proofing',[self._tool('Word Count',lambda:QMessageBox.information(self,'Word Count',self.wordCountLabel.text())),self._tool('Find',self._find_text)])); h.addStretch(); self.wordTabs.addTab(p,'Review')

    def _add_view_ribbon(self):
        p=QWidget(); h=QHBoxLayout(p); h.setContentsMargins(8,4,8,4)
        slider=QSlider(Qt.Horizontal); slider.setRange(50,200); slider.setValue(100); slider.setFixedWidth(180); slider.valueChanged.connect(self._set_page_zoom)
        self.zoomValue=QLabel('100%')
        h.addWidget(self._group('Zoom',[self._tool('−',lambda:slider.setValue(max(50,slider.value()-10))),slider,self._tool('+',lambda:slider.setValue(min(200,slider.value()+10))),self.zoomValue]))
        h.addWidget(self._group('Print',[self._tool('Print',self.print_document),self._tool('Preview',self.print_preview),self._tool('Export PDF',self._export_pdf_direct)])); h.addStretch(); self.wordTabs.addTab(p,'View')

    def _export_pdf_direct(self):
        path,_=QFileDialog.getSaveFileName(self,'Export PDF','','PDF (*.pdf)')
        if not path:return
        if not path.lower().endswith('.pdf'):path += '.pdf'
        try:
            printer=QPrinter(QPrinter.HighResolution); printer.setOutputFormat(QPrinter.PdfFormat); printer.setOutputFileName(path); self.textEdit.document().print_(printer)
            QMessageBox.information(self,'Export PDF','PDF exported successfully.')
        except Exception as e:QMessageBox.warning(self,'Export PDF',str(e))

    def _set_page_zoom(self,value):
        delta=value-self._doc_zoom
        steps=int(delta/10)
        if steps>0:self.textEdit.zoomIn(steps)
        elif steps<0:self.textEdit.zoomOut(-steps)
        self._doc_zoom=value; self.zoomValue.setText(f'{value}%')
        # scale page width as well, so zoom affects the sheet rather than font only
        try:self.textEdit.setMinimumWidth(int(760*value/100))
        except Exception:pass


class RefinedVectorCanvas(QGraphicsView):
    """Vector-first whiteboard. Strokes stay vector until export; scene auto-grows."""
    def __init__(self):
        super().__init__(); self.scene=QGraphicsScene(self); self.setScene(self.scene)
        self.setRenderHint(QPainter.Antialiasing,True); self.setViewportUpdateMode(QGraphicsView.BoundingRectViewportUpdate)
        self.setTransformationAnchor(QGraphicsView.AnchorUnderMouse); self.setResizeAnchor(QGraphicsView.AnchorViewCenter)
        self.setBackgroundBrush(QBrush(QColor('#d9dde4')))
        self.board=QGraphicsRectItem(QRectF(0,0,1800,1200)); self.board.setBrush(QBrush(Qt.white)); self.board.setPen(QPen(QColor('#cbd5e1'),1)); self.board.setZValue(-1000); self.scene.addItem(self.board)
        self.scene.setSceneRect(-40,-40,1880,1280)
        self.brushSize=3; self.brushColor=QColor('#111827'); self.mode='Pencil'; self.tap_draw=True; self.drawing=False; self.start=QPointF(); self.path=None; self.preview=None; self.items_history=[]
        self.setMouseTracking(True); self.setDragMode(QGraphicsView.NoDrag)

    def set_drawing_mode(self,mode):
        self.mode=mode
        self.setDragMode(QGraphicsView.ScrollHandDrag if mode=='Pan' else QGraphicsView.NoDrag)

    def _pen(self): return QPen(self.brushColor,self.brushSize,Qt.SolidLine,Qt.RoundCap,Qt.RoundJoin)
    def _ensure_board_contains(self,rect):
        if rect.isNull(): return
        r=self.board.rect(); m=80
        nr=r.united(rect.adjusted(-m,-m,m,m))
        if nr != r:
            self.board.setRect(nr); self.scene.setSceneRect(nr.adjusted(-40,-40,40,40))

    def mousePressEvent(self,e):
        if self.mode=='Pan': return super().mousePressEvent(e)
        if e.button()!=Qt.LeftButton:return super().mousePressEvent(e)
        # tap-draw mode: first click starts a stroke, second click commits it.
        if self.tap_draw and self.drawing and self.preview:
            self._commit_preview(); return
        self.drawing=True; self.start=self.mapToScene(e.pos())
        if self.mode=='Text':
            text,ok=QInputDialog.getText(self,'Insert Text','Text:')
            if ok and text:
                it=QGraphicsTextItem(text); it.setDefaultTextColor(self.brushColor); it.setFont(QFont('Segoe UI',max(10,self.brushSize*4))); it.setPos(self.start); self.scene.addItem(it); self.items_history.append(it); self._ensure_board_contains(it.sceneBoundingRect())
            self.drawing=False; return
        self.path=QPainterPath(self.start); self.preview=QGraphicsPathItem(); self.preview.setPen(self._pen()); self.scene.addItem(self.preview)

    def _commit_preview(self):
        if self.preview:
            self.preview.setPath(self.path); self.items_history.append(self.preview); self._ensure_board_contains(self.preview.sceneBoundingRect())
        self.drawing=False; self.preview=None; self.path=None

    def mouseMoveEvent(self,e):
        if not self.drawing or not self.preview:return super().mouseMoveEvent(e)
        p=self.mapToScene(e.pos())
        if self.mode=='Pencil':
            last=self.path.currentPosition(); mid=QPointF((last.x()+p.x())/2,(last.y()+p.y())/2); self.path.quadTo(last,mid); self.path.lineTo(p)
        else:self.path=self._shape_path(self.start,p,self.mode)
        self.preview.setPath(self.path); self._ensure_board_contains(self.preview.sceneBoundingRect())

    def mouseReleaseEvent(self,e):
        if e.button()==Qt.LeftButton and self.drawing and self.preview and not self.tap_draw:
            self._commit_preview(); return
        super().mouseReleaseEvent(e)

    def _shape_path(self,a,b,mode):
        p=QPainterPath(); r=QRectF(a,b).normalized()
        if mode=='Line':p.moveTo(a);p.lineTo(b)
        elif mode=='Rectangle':p.addRect(r)
        elif mode=='Ellipse':p.addEllipse(r)
        elif mode=='Triangle':p.moveTo(r.center().x(),r.top());p.lineTo(r.left(),r.bottom());p.lineTo(r.right(),r.bottom());p.closeSubpath()
        elif mode=='Arrow':
            p.moveTo(a);p.lineTo(b); ang=math.atan2(b.y()-a.y(),b.x()-a.x()); s=18+self.brushSize
            for off in (-math.pi/6,math.pi/6): p.moveTo(b);p.lineTo(QPointF(b.x()-s*math.cos(ang+off),b.y()-s*math.sin(ang+off)))
        elif mode=='Star':
            cx,cy=r.center().x(),r.center().y(); rx,ry=r.width()/2,r.height()/2
            for i in range(10):
                rr=1 if i%2==0 else .42; ang=-math.pi/2+i*math.pi/5; pt=QPointF(cx+rx*rr*math.cos(ang),cy+ry*rr*math.sin(ang)); p.moveTo(pt) if i==0 else p.lineTo(pt)
            p.closeSubpath()
        return p

    def undo(self):
        if self.items_history:
            it=self.items_history.pop(); self.scene.removeItem(it)
    def clear_canvas(self):
        for it in list(self.items_history): self.scene.removeItem(it)
        self.items_history.clear(); self.board.setRect(QRectF(0,0,1800,1200)); self.scene.setSceneRect(-40,-40,1880,1280)

    def save_image(self):
        path,flt=QFileDialog.getSaveFileName(self,'Export Drawing','','PNG (*.png);;JPEG (*.jpg);;SVG (*.svg);;PDF (*.pdf)')
        if not path:return
        box=QMessageBox(self); box.setWindowTitle('Export Area'); box.setText('What should be exported?'); whole=box.addButton('Whole board',QMessageBox.AcceptRole); content=box.addButton('Drawn content',QMessageBox.ActionRole); box.addButton(QMessageBox.Cancel); box.exec_()
        clicked=box.clickedButton()
        if clicked not in (whole,content):return
        if clicked is content and self.items_history:
            bounds=self.items_history[0].sceneBoundingRect()
            for it in self.items_history[1:]: bounds=bounds.united(it.sceneBoundingRect())
            bounds=bounds.adjusted(-30,-30,30,30)
        else:
            bounds=self.board.rect()
        if path.lower().endswith('.svg'):
            gen=QSvgGenerator(); gen.setFileName(path); gen.setSize(QSize(max(1,int(bounds.width())),max(1,int(bounds.height())))); gen.setViewBox(bounds.toRect()); painter=QPainter(gen); self.scene.render(painter,QRectF(0,0,bounds.width(),bounds.height()),bounds); painter.end(); return
        if path.lower().endswith('.pdf'):
            pr=QPrinter(QPrinter.HighResolution); pr.setOutputFormat(QPrinter.PdfFormat); pr.setOutputFileName(path); painter=QPainter(pr); self.scene.render(painter,QRectF(painter.viewport()),bounds); painter.end(); return
        scale=3
        while scale>1 and (bounds.width()*scale>16000 or bounds.height()*scale>16000): scale-=1
        img=QImage(max(1,int(bounds.width()*scale)),max(1,int(bounds.height()*scale)),QImage.Format_ARGB32)
        if img.isNull():
            QMessageBox.warning(self,'Export Drawing','The drawing is too large to export as an image. Try SVG or PDF.'); return
        img.fill(Qt.white); painter=QPainter(img); painter.setRenderHint(QPainter.Antialiasing,True); self.scene.render(painter,QRectF(0,0,img.width(),img.height()),bounds); painter.end(); img.save(path)


class RefinedNotesAndDrawingTab(QWidget):
    """Notes placeholder overlay + vector drawing board."""
    def __init__(self):
        super().__init__(); self._recent_file=Path.home()/'.jesson_recent_notes.json'; self._build()
    def _build(self):
        root=QHBoxLayout(self); root.setContentsMargins(0,0,0,0); split=QSplitter(Qt.Horizontal); root.addWidget(split)
        left=QWidget(); lv=QVBoxLayout(left); lv.setContentsMargins(8,8,8,8)
        tb=QHBoxLayout();
        for text,fn in [('B',lambda:self.notes.setFontWeight(QFont.Normal if self.notes.fontWeight()>=QFont.Bold else QFont.Bold)),('I',lambda:self.notes.setFontItalic(not self.notes.fontItalic())),('U',lambda:self.notes.setFontUnderline(not self.notes.fontUnderline()))]:
            b=QPushButton(text); b.clicked.connect(fn); tb.addWidget(b)
        self.listStyle=QComboBox(); self.listStyle.addItems(['No list','• Bullet','○ Circle','■ Square','1. Numbered','A. Lettered']); self.listStyle.currentTextChanged.connect(self._set_list); tb.addWidget(self.listStyle); tb.addStretch(); lv.addLayout(tb)
        self.notes=QTextEdit(); self.notes.setAcceptRichText(True); self.notes.setPlaceholderText(''); lv.addWidget(self.notes,1)
        self.hint=QLabel('Start writing your notes here…',self.notes.viewport()); self.hint.setStyleSheet('color:#9ca3af;background:transparent;font-size:14px;font-style:italic;'); self.hint.setAttribute(Qt.WA_TransparentForMouseEvents,True); self.hint.adjustSize(); self.hint.move(14,14)
        self.notes.textChanged.connect(self._note_state); self.notes.cursorPositionChanged.connect(self._note_state)
        foot=QHBoxLayout(); self.recent=QComboBox(); self.recent.setMinimumWidth(180); self.loadBtn=QPushButton('Load'); self.saveBtn=QPushButton('Save'); self.saveBtn.setEnabled(False); foot.addWidget(QLabel('Recent:')); foot.addWidget(self.recent,1); foot.addWidget(self.loadBtn); foot.addWidget(self.saveBtn); lv.addLayout(foot)
        self.loadBtn.clicked.connect(self._load_note); self.saveBtn.clicked.connect(self._save_note); self.recent.activated.connect(self._open_recent); self._load_recents()
        right=QWidget(); rv=QVBoxLayout(right); rv.setContentsMargins(0,0,0,0); bar=QHBoxLayout();
        self.color=QPushButton('Color'); self.tapDraw=QCheckBox('Tap draw'); self.tapDraw.setChecked(True); self.size=QSpinBox(); self.size.setRange(1,40); self.size.setValue(3); self.mode=QComboBox(); self.mode.addItems(['Pencil','Line','Rectangle','Ellipse','Triangle','Star','Arrow','Text','Pan']); undo=QPushButton('Undo'); clear=QPushButton('Clear'); export=QPushButton('Export…')
        for w in [self.color,self.tapDraw,self.size,self.mode,undo,clear,export]:bar.addWidget(w)
        bar.addStretch(); rv.addLayout(bar); self.canvas=RefinedVectorCanvas(); rv.addWidget(self.canvas,1)
        self.color.clicked.connect(self._choose_color); self.tapDraw.toggled.connect(lambda on:setattr(self.canvas,'tap_draw',on)); self.size.valueChanged.connect(lambda v:setattr(self.canvas,'brushSize',v)); self.mode.currentTextChanged.connect(self.canvas.set_drawing_mode); undo.clicked.connect(self.canvas.undo); clear.clicked.connect(self.canvas.clear_canvas); export.clicked.connect(self.canvas.save_image)
        split.addWidget(left); split.addWidget(right); split.setSizes([420,880])
    def _set_list(self,name):
        c=self.notes.textCursor()
        if name=='No list':
            if c.currentList():
                bf=c.blockFormat(); bf.setObjectIndex(-1); c.setBlockFormat(bf)
        else:
            mp={'• Bullet':QTextListFormat.ListDisc,'○ Circle':QTextListFormat.ListCircle,'■ Square':QTextListFormat.ListSquare,'1. Numbered':QTextListFormat.ListDecimal,'A. Lettered':QTextListFormat.ListUpperAlpha}; c.createList(mp[name])
        self._note_state()
    def _note_state(self):
        empty=not self.notes.toPlainText().strip(); has_list=self.notes.textCursor().currentList() is not None
        if getattr(self,'hint',None) is not None: self.hint.setVisible(empty and not has_list)
        self.saveBtn.setEnabled(not empty)
    def resizeEvent(self,e):
        super().resizeEvent(e)
        if getattr(self,'hint',None) is not None: self.hint.move(14,14)
    def _choose_color(self):
        c=QColorDialog.getColor(self.canvas.brushColor,self)
        if c.isValid():self.canvas.brushColor=c
    def _load_recents(self):
        self.recent.clear();
        try:
            paths=json.loads(self._recent_file.read_text(encoding='utf-8')) if self._recent_file.exists() else []
        except Exception:paths=[]
        for p in paths:
            if Path(p).exists():self.recent.addItem(Path(p).name,p)
    def _remember(self,p):
        vals=[self.recent.itemData(i) for i in range(self.recent.count()) if self.recent.itemData(i) and self.recent.itemData(i)!=p]; vals.insert(0,p); vals=vals[:12];
        try:self._recent_file.write_text(json.dumps(vals),encoding='utf-8')
        except Exception:pass
        self._load_recents()
    def _save_note(self):
        if not self.notes.toPlainText().strip():return
        p,_=QFileDialog.getSaveFileName(self,'Save Notes','','HTML Notes (*.html);;Text Notes (*.txt)')
        if not p:return
        Path(p).write_text(self.notes.toHtml() if p.lower().endswith('.html') else self.notes.toPlainText(),encoding='utf-8'); self._remember(p)
    def _load_note(self):
        p,_=QFileDialog.getOpenFileName(self,'Load Notes','','Notes (*.html *.txt)')
        if p:self._open_path(p)
    def _open_recent(self,i):
        p=self.recent.itemData(i)
        if p:self._open_path(p)
    def _open_path(self,p):
        try:
            txt=Path(p).read_text(encoding='utf-8'); self.notes.setHtml(txt) if p.lower().endswith('.html') else self.notes.setPlainText(txt); self._remember(p)
        except Exception as e:QMessageBox.warning(self,'Notes',str(e))


class RefinedVideoTab(QWidget):
    """Meeting launcher that deliberately uses Jesson's persistent Browser profile."""
    def __init__(self):
        super().__init__(); root=QVBoxLayout(self); root.setContentsMargins(18,18,18,18); root.setSpacing(14)
        title=QLabel('Video & Meetings'); title.setStyleSheet('font-size:22px;font-weight:700;'); root.addWidget(title)
        info=QLabel('Open meetings in Jesson Browser so Zoom, Google Meet and Teams can reuse the browser’s saved sign-in session.'); info.setWordWrap(True); root.addWidget(info)
        row=QHBoxLayout(); self.platform=QComboBox(); self.platform.addItems(['Zoom','Google Meet','MS Teams','YouTube Lectures','Custom URL']); self.input=QLineEdit(); self.input.setPlaceholderText('Meeting URL / room ID / lecture search'); row.addWidget(self.platform); row.addWidget(self.input,1); root.addLayout(row)
        actions=QHBoxLayout(); inapp=QPushButton('Open in Jesson Browser'); ext=QPushButton('Open in System Browser'); actions.addWidget(inapp); actions.addWidget(ext); actions.addStretch(); root.addLayout(actions); root.addStretch()
        inapp.clicked.connect(self.open_jesson); ext.clicked.connect(self.open_system)
    def _url(self):
        t=self.input.text().strip(); p=self.platform.currentText()
        if p=='Zoom':return t if t.startswith('http') else f'https://zoom.us/j/{t}'
        if p=='Google Meet':return t if t.startswith('http') else f'https://meet.google.com/{t}'
        if p=='MS Teams':return t if t.startswith('http') else f'https://teams.microsoft.com/l/meetup-join/{t}'
        if p=='YouTube Lectures':return t if t.startswith('http') else 'https://www.youtube.com/results?search_query='+urllib.parse.quote_plus(t)
        return t if t.startswith('http') else 'https://'+t
    def open_jesson(self):
        if not self.input.text().strip() and self.platform.currentText()!='YouTube Lectures':QMessageBox.information(self,'Meeting','Enter a meeting link or ID first.');return
        m=self.window(); url=self._url()
        if hasattr(m,'searchTab') and hasattr(m.searchTab,'browser'):m.searchTab.browser.load(QUrl(url));m.tabs.setCurrentWidget(m.searchTab)
    def open_system(self):
        from PyQt5.QtGui import QDesktopServices
        QDesktopServices.openUrl(QUrl(self._url()))


class RefinedThemesTab(ThemesTab):
    SETTINGS_FILE=Path.home()/'.jesson_appearance.json'
    def __init__(self,parent):
        super().__init__(parent); self._restore_appearance()
    def _apply(self,name,bg,accent,text):
        super()._apply(name,bg,accent,text); self._main_parent.apply_dialog_theme(bg,accent,text); self._save_appearance(name=name)
    def set_wallpaper(self):
        path,_=QFileDialog.getOpenFileName(self,'Select Wallpaper','','Images (*.png *.jpg *.jpeg *.webp)')
        if path:self._main_parent.set_wallpaper(path); self._save_appearance(wallpaper=path)
    def _save_appearance(self,**updates):
        data={}
        try:data=json.loads(self.SETTINGS_FILE.read_text(encoding='utf-8'))
        except Exception:pass
        data.update(updates)
        try:self.SETTINGS_FILE.write_text(json.dumps(data),encoding='utf-8')
        except Exception:pass
    def _restore_appearance(self):
        try:data=json.loads(self.SETTINGS_FILE.read_text(encoding='utf-8'))
        except Exception:return
        wp=data.get('wallpaper')
        if wp and Path(wp).exists():self._main_parent.set_wallpaper(wp)



# ===========================================================================
# V8 TARGETED REFINEMENT — page-aware Writer, responsive Calculator,
# embedded Video browser, and placeholder-free Notes.
# ===========================================================================

class DocumentPageOverlay(QWidget):
    """Paints visible page gaps plus repeated header/footer guides over the editor."""
    def __init__(self, parent=None):
        super().__init__(parent)
        self.page_height = 1000
        self.header_text = ''
        self.footer_text = ''
        self.setAttribute(Qt.WA_TransparentForMouseEvents, True)
        self.setAttribute(Qt.WA_NoSystemBackground, True)
        self.setAttribute(Qt.WA_TranslucentBackground, True)

    def set_metrics(self, page_height, header='', footer=''):
        self.page_height = max(240, int(page_height))
        self.header_text = header or ''
        self.footer_text = footer or ''
        self.update()

    def paintEvent(self, event):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing, True)
        h = max(240, self.page_height)
        pages = max(1, int(math.ceil(self.height() / float(h))))
        for i in range(pages):
            top = i * h
            # Header/footer guide text. It remains non-editable; edit through Layout > Header/Footer.
            p.setPen(QColor('#8a94a3'))
            font = QFont('Segoe UI', 8)
            p.setFont(font)
            if self.header_text:
                p.drawText(QRectF(24, top + 10, max(10, self.width()-48), 22), Qt.AlignLeft|Qt.AlignVCenter, self.header_text)
            if self.footer_text:
                p.drawText(QRectF(24, top + h - 34, max(10, self.width()-48), 20), Qt.AlignLeft|Qt.AlignVCenter, self.footer_text)
            # Visible page boundary between pages.
            if i > 0:
                y = top
                p.fillRect(QRectF(0, y-7, self.width(), 14), QColor('#d8dde5'))
                p.setPen(QColor('#b8c0cc'))
                p.drawLine(0, y-7, self.width(), y-7)
                p.drawLine(0, y+7, self.width(), y+7)
        p.end()


class V8CalculatorTab(QA6CalculatorTab):
    """Responsive numeric calculator: uses the available tab area instead of a fixed 900px island."""
    def __init__(self):
        super().__init__()
        self._rebuild_v8_numeric()

    def _rebuild_v8_numeric(self):
        old = self.sub_tabs.widget(0)
        self.sub_tabs.removeTab(0)
        page = QWidget(); page.setObjectName('numericPanel')
        root = QVBoxLayout(page); root.setContentsMargins(12, 10, 12, 12); root.setSpacing(6)

        self.exprDisplay.setMinimumHeight(24); self.exprDisplay.setMaximumHeight(34)
        self.display.setMinimumHeight(62); self.display.setMaximumHeight(82)
        self.historyList.setMinimumHeight(44); self.historyList.setMaximumHeight(68)
        root.addWidget(self.exprDisplay); root.addWidget(self.display); root.addWidget(self.historyList)

        pad = QWidget(); pad.setObjectName('numericPad')
        pad.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        grid = QGridLayout(pad); grid.setContentsMargins(0,0,0,0); grid.setSpacing(5)
        buttons = [
            ('MC',0,0,1,'mem','MC'), ('MR',0,1,1,'mem','MR'), ('M+',0,2,1,'mem','M+'), ('M−',0,3,1,'mem','M-'), ('⌫',0,4,1,'clear','BS'),
            ('sin',1,0,1,'fn','sin'), ('cos',1,1,1,'fn','cos'), ('tan',1,2,1,'fn','tan'), ('(',1,3,1,'op','('), (')',1,4,1,'op',')'),
            ('asin',2,0,1,'fn','asin'), ('acos',2,1,1,'fn','acos'), ('atan',2,2,1,'fn','atan'), ('√',2,3,1,'fn','sqrt'), ('xʸ',2,4,1,'fn','x^y'),
            ('log',3,0,1,'fn','log10'), ('ln',3,1,1,'fn','ln'), ('π',3,2,1,'fn','pi'), ('e',3,3,1,'fn','e'), ('exp',3,4,1,'fn','exp'),
            ('7',4,0,1,'digit','7'), ('8',4,1,1,'digit','8'), ('9',4,2,1,'digit','9'), ('÷',4,3,1,'op','/'), ('+/−',4,4,1,'fn','neg'),
            ('4',5,0,1,'digit','4'), ('5',5,1,1,'digit','5'), ('6',5,2,1,'digit','6'), ('×',5,3,1,'op','*'), ('C',5,4,1,'clear','C'),
            ('1',6,0,1,'digit','1'), ('2',6,1,1,'digit','2'), ('3',6,2,1,'digit','3'), ('−',6,3,1,'op','-'), ('=',6,4,2,'eq','='),
            ('0',7,0,2,'digit','0'), ('.',7,2,1,'digit','.'), ('+',7,3,1,'op','+'),
        ]
        for label,row,col,span,btype,action in buttons:
            b = QPushButton(label); b.setProperty('btnType', btype)
            b.setMinimumSize(54, 40); b.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
            b.clicked.connect(lambda _,a=action:self._handle_action(a))
            grid.addWidget(b,row,col,1,span)
        for c in range(5): grid.setColumnStretch(c,1)
        for r in range(8): grid.setRowStretch(r,1)
        root.addWidget(pad, 1)

        self.numericPage = page
        self.sub_tabs.insertTab(0,page,'Numeric'); self.sub_tabs.setCurrentIndex(0)
        if old is not None: old.deleteLater()
        self._style_numeric_panel(False)


class V8DocumentTab(RefinedDocumentTab):
    """Page-aware Writer refinement: scrolling, visible pages, effective zoom, and richer formulas."""
    BASE_FRAME_W = 794
    BASE_PAGE_H = 1123
    BASE_CONTENT_W = 658
    BASE_CONTENT_H = 1000

    def __init__(self):
        self._syncing_pages = False
        self._last_page_size = None
        self._last_page_layout = None
        super().__init__()
        # Remove default helper text entirely, as requested.
        if hasattr(self, 'emptyHint'):
            self.emptyHint.hide(); self.emptyHint.deleteLater(); self.emptyHint = None
        self.textEdit.setPlaceholderText('')

        self.pageScroll = self.findChild(QScrollArea, 'pageArea')
        if self.pageScroll:
            self.pageScroll.setWidgetResizable(True)
            self.pageScroll.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOn)
            self.pageScroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded)

        # Let the outer page scroller do the scrolling so the sheet can grow through real pages.
        self.textEdit.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.textEdit.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.pageFrame.setMinimumWidth(self.BASE_FRAME_W)
        self.pageFrame.setMaximumWidth(self.BASE_FRAME_W)
        self.textEdit.document().setPageSize(QSizeF(self.BASE_CONTENT_W, self.BASE_CONTENT_H))

        self.pageOverlay = DocumentPageOverlay(self.textEdit.viewport())
        self.pageOverlay.show(); self.pageOverlay.raise_()
        self.textEdit.document().documentLayout().documentSizeChanged.connect(lambda _=None:self._sync_document_pages())
        self.textEdit.textChanged.connect(self._sync_document_pages)
        self.textEdit.viewport().installEventFilter(self)
        self._sync_document_pages()

    def eventFilter(self,obj,event):
        # Keep the overlay aligned, but defer geometry syncing until Qt finishes
        # the current show/resize event. This prevents re-entrant layout churn
        # when switching into the Document tab.
        try:
            if hasattr(self,'pageOverlay') and obj is self.textEdit.viewport() and event.type() in (QEvent.Resize, QEvent.Show):
                rect = self.textEdit.viewport().rect()
                self.pageOverlay.setGeometry(rect)
                self.pageOverlay.raise_()
                if not getattr(self, '_syncing_pages', False):
                    QTimer.singleShot(0, self._sync_document_pages)
        except Exception:
            pass
        return super().eventFilter(obj,event)

    def _page_count(self):
        try:return max(1, int(self.textEdit.document().pageCount()))
        except Exception:return 1

    def _sync_document_pages(self):
        # Guard against documentSizeChanged -> _sync_document_pages -> setPageSize
        # -> documentSizeChanged recursion when the Document tab is shown/resized.
        if getattr(self, '_syncing_pages', False):
            return
        self._syncing_pages = True
        try:
            factor = max(0.5, min(2.0, self._doc_zoom / 100.0))
            target_w = float(self.BASE_CONTENT_W * factor)
            target_h = float(self.BASE_CONTENT_H * factor)

            # setPageSize() itself can emit documentSizeChanged. Only call it when
            # the requested page size materially changed.
            target_key = (round(target_w, 2), round(target_h, 2))
            current = self.textEdit.document().pageSize()
            current_key = (round(float(current.width()), 2), round(float(current.height()), 2))
            if current_key != target_key:
                self.textEdit.document().setPageSize(QSizeF(target_w, target_h))
            self._last_page_size = target_key

            pages = self._page_count()
            page_h = max(240, int(self.BASE_PAGE_H * factor))
            frame_w = max(300, int(self.BASE_FRAME_W * factor))
            editor_h = max(page_h, pages * page_h)
            layout_key = (pages, page_h, frame_w, editor_h)

            # Avoid repeatedly forcing identical widget geometry during tab changes.
            if getattr(self, '_last_page_layout', None) != layout_key:
                self.pageFrame.setMinimumWidth(frame_w)
                self.pageFrame.setMaximumWidth(frame_w)
                self.textEdit.setMinimumHeight(editor_h)
                self.textEdit.setMaximumHeight(editor_h)
                if self.pageScroll and self.pageScroll.widget():
                    self.pageScroll.widget().setMinimumWidth(frame_w + 56)
                    self.pageScroll.widget().setMinimumHeight(editor_h + 70)
                self._last_page_layout = layout_key

            if hasattr(self, 'pageOverlay') and self.pageOverlay is not None:
                self.pageOverlay.setGeometry(self.textEdit.viewport().rect())
                self.pageOverlay.set_metrics(
                    page_h,
                    getattr(self, 'header_text', ''),
                    getattr(self, 'footer_text', '')
                )

            try:
                plain = self.textEdit.toPlainText()
                words = len(plain.split())
                chars = len(plain)
                self.wordCountLabel.setText(
                    f'Words: {words} · Characters: {chars} · Pages: {pages}'
                )
            except Exception:
                pass
        finally:
            self._syncing_pages = False

    def _set_page_zoom(self,value):
        value=max(50,min(200,int(value)))
        old=self._doc_zoom; self._doc_zoom=value
        # Scale font and page metrics together so zoom visibly enlarges the sheet rather than only changing a label.
        steps=int(round((value-old)/10.0))
        if steps>0:self.textEdit.zoomIn(steps)
        elif steps<0:self.textEdit.zoomOut(-steps)
        self.zoomValue.setText(f'{value}%')
        self.zoomLabel.setText(f'{value}%')
        self._sync_document_pages()

    def insert_page_break(self):
        super().insert_page_break()
        self._sync_document_pages()
        # Move viewport toward the newly-created page.
        if self.pageScroll:
            QTimer.singleShot(0, lambda:self.pageScroll.verticalScrollBar().setValue(self.pageScroll.verticalScrollBar().maximum()))

    def edit_header_footer(self):
        super().edit_header_footer()
        self._sync_document_pages()

    def _formula_value(self,table,cell,formula):
        """Excel-like safe table formulas: SUM/AVERAGE/MIN/MAX/COUNT/PRODUCT + refs + ROUND/ABS."""
        expr=formula.strip()
        if expr.startswith('='):expr=expr[1:].strip()
        row,col=cell.row(),cell.column()
        def directional_replace(m):
            fn=m.group(1).upper(); direction=m.group(2).upper()
            vals=[self._numeric_cell(table,r,col) for r in range(0,row)] if direction=='ABOVE' else [self._numeric_cell(table,row,c) for c in range(0,col)]
            if fn=='SUM':v=sum(vals)
            elif fn in ('AVERAGE','AVG'):v=sum(vals)/len(vals) if vals else 0
            elif fn=='MIN':v=min(vals) if vals else 0
            elif fn=='MAX':v=max(vals) if vals else 0
            elif fn=='COUNT':v=len(vals)
            else:
                v=1
                for x in vals:v*=x
            return str(v)
        expr=re.sub(r'\b(SUM|AVERAGE|AVG|MIN|MAX|COUNT|PRODUCT)\(\s*(ABOVE|LEFT)\s*\)',directional_replace,expr,flags=re.I)
        def fn_replace(m):
            fn,a,b=m.group(1).upper(),m.group(2),m.group(3); vals=self._range_values(table,a,b)
            if fn=='SUM':v=sum(vals)
            elif fn in ('AVERAGE','AVG'):v=sum(vals)/len(vals) if vals else 0
            elif fn=='MIN':v=min(vals) if vals else 0
            elif fn=='MAX':v=max(vals) if vals else 0
            elif fn=='COUNT':v=len(vals)
            else:
                v=1
                for x in vals:v*=x
            return str(v)
        expr=re.sub(r'\b(SUM|AVERAGE|AVG|MIN|MAX|COUNT|PRODUCT)\(\s*([A-Za-z]+\d+)\s*:\s*([A-Za-z]+\d+)\s*\)',fn_replace,expr,flags=re.I)
        def cell_replace(m):
            r,c=self._cell_ref(table,m.group(0)); return str(self._numeric_cell(table,r,c))
        expr=re.sub(r'\b[A-Za-z]+[1-9]\d*\b',cell_replace,expr).replace('^','**')
        # Controlled ROUND() / ABS() support after all cell refs have become numbers.
        safe_env={'ROUND':round,'round':round,'ABS':abs,'abs':abs}
        if not re.fullmatch(r'[0-9eE\.\+\-\*\/\%\(\),\sA-Za-z]+',expr):raise ValueError('Formula contains unsupported characters.')
        names=set(re.findall(r'[A-Za-z_]+',expr))
        if any(n not in safe_env for n in names):raise ValueError('Unsupported function: '+', '.join(sorted(names)))
        return eval(expr,{'__builtins__':{}},safe_env)

    def insert_table_formula(self):
        table,cell=self._current_table_cell()
        if not table:
            QMessageBox.information(self,'Table Formula','Place the cursor inside a table cell first.'); return
        current=cell.format().property(self.FORMULA_PROPERTY) or '=SUM(ABOVE)'
        formula,ok=QInputDialog.getText(self,'Table Formula','Examples: =SUM(ABOVE), =A1+B1, =AVERAGE(A1:A4), =COUNT(A1:A8), =PRODUCT(B1:B3), =ROUND(A1/B1,2)',text=str(current))
        if not ok or not formula.strip():return
        try:
            value=self._formula_value(table,cell,formula)
            display=str(int(value)) if isinstance(value,(int,float)) and float(value).is_integer() else f'{float(value):.10g}' if isinstance(value,(int,float)) else str(value)
            self._set_cell_text(cell,display); fmt=cell.format(); fmt.setProperty(self.FORMULA_PROPERTY,formula.strip()); cell.setFormat(fmt)
        except Exception as exc: QMessageBox.warning(self,'Formula Error',str(exc))


class V8NotesAndDrawingTab(QWidget):
    """Restored Notes & Draw UI shell with the refined vector drawing engine."""
    _STYLE = """
        V8NotesAndDrawingTab { background:#f8f9fb; }
        #notesPanel { background:#ffffff; border-right:1px solid #e5e7eb; }
        #notesToolbar { background:#f9fafb; border-bottom:1px solid #e5e7eb; }
        #ntBtn { background:transparent; color:#374151; border:none; border-radius:5px; padding:4px 9px; min-height:24px; }
        #ntBtn:hover { background:#f3f4f6; }
        #notesEdit { border:none; background:#ffffff; color:#111827; font-size:14px; padding:10px; selection-background-color:#ddd6fe; }
        #notesFooter { background:#f9fafb; border-top:1px solid #e5e7eb; }
        #notesCount { color:#9ca3af; font-size:11px; }
        #notesPrimary { background:#6366f1; color:white; border:none; border-radius:6px; padding:5px 12px; }
        #notesSecondary { background:#f3f4f6; color:#374151; border:1px solid #d1d5db; border-radius:6px; padding:5px 10px; }
        #drawPanel { background:#1e1e2e; }
        #drawToolbar { background:#252535; border-bottom:1px solid #3a3a5c; }
        #drawBtn { background:#2a2a4a; color:#c0c0e0; border:1px solid #3a3a5c; border-radius:6px; padding:5px 10px; }
        #drawBtn:hover { background:#3a3a5c; color:white; }
        #drawAccent { background:#7c6af7; color:white; border:none; border-radius:6px; padding:5px 10px; }
        #drawDanger { background:#4a1e1e; color:#ff9a9a; border:1px solid #6a2a2a; border-radius:6px; padding:5px 10px; }
        #colorSwatch { border-radius:12px; border:2px solid #5a5a7a; min-width:24px; max-width:24px; min-height:24px; max-height:24px; }
        QComboBox#listStyle { min-width:120px; }
        QComboBox#drawMode, QSpinBox#drawSize { background:#2a2a4a; color:#e5e7eb; border:1px solid #3a3a5c; border-radius:6px; padding:4px 8px; min-height:26px; }
        QCheckBox#tapDraw { color:#d1d5db; }
    """

    def __init__(self):
        super().__init__()
        self._recent_file = Path.home() / '.jesson_recent_notes.json'
        self._build_ui()

    def _build_ui(self):
        self.setStyleSheet(self._STYLE)
        root = QVBoxLayout(self); root.setContentsMargins(0,0,0,0); root.setSpacing(0)
        split = QSplitter(Qt.Horizontal); root.addWidget(split, 1)

        # Notes: restored compact toolbar and footer layout.
        left = QWidget(); left.setObjectName('notesPanel')
        lv = QVBoxLayout(left); lv.setContentsMargins(0,0,0,0); lv.setSpacing(0)
        tbw = QWidget(); tbw.setObjectName('notesToolbar')
        tb = QHBoxLayout(tbw); tb.setContentsMargins(8,3,8,3); tb.setSpacing(3)
        def nbtn(text, tip, fn):
            b=QPushButton(text); b.setObjectName('ntBtn'); b.setToolTip(tip); b.clicked.connect(fn); return b
        tb.addWidget(nbtn('B','Bold',lambda:self.notes.setFontWeight(QFont.Normal if self.notes.fontWeight()>=QFont.Bold else QFont.Bold)))
        tb.addWidget(nbtn('I','Italic',lambda:self.notes.setFontItalic(not self.notes.fontItalic())))
        tb.addWidget(nbtn('U̲','Underline',lambda:self.notes.setFontUnderline(not self.notes.fontUnderline())))
        self.listStyle=QComboBox(); self.listStyle.setObjectName('listStyle'); self.listStyle.addItems(['No list','• Bullet','○ Circle','■ Square','1. Numbered','A. Lettered']); self.listStyle.currentTextChanged.connect(self._set_list); tb.addWidget(self.listStyle)
        tb.addWidget(nbtn('🔍','Search notes',self._search_notes)); tb.addStretch(); lv.addWidget(tbw)

        self.notes=QTextEdit(); self.notes.setObjectName('notesEdit'); self.notes.setAcceptRichText(True); self.notes.setPlaceholderText('')
        self.notes.textChanged.connect(self._note_state); lv.addWidget(self.notes,1)

        footw=QWidget(); footw.setObjectName('notesFooter'); foot=QHBoxLayout(footw); foot.setContentsMargins(10,5,10,5); foot.setSpacing(7)
        self.notesCount=QLabel('0 words'); self.notesCount.setObjectName('notesCount')
        self.recent=QComboBox(); self.recent.setMinimumWidth(150); self.recent.setToolTip('Recent notes')
        self.loadBtn=QPushButton('📂 Load'); self.loadBtn.setObjectName('notesSecondary')
        self.saveBtn=QPushButton('💾 Save'); self.saveBtn.setObjectName('notesPrimary'); self.saveBtn.setEnabled(False)
        foot.addWidget(self.notesCount); foot.addStretch(); foot.addWidget(QLabel('Recent:')); foot.addWidget(self.recent); foot.addWidget(self.loadBtn); foot.addWidget(self.saveBtn); lv.addWidget(footw)
        self.loadBtn.clicked.connect(self._load_note); self.saveBtn.clicked.connect(self._save_note); self.recent.activated.connect(self._open_recent); self._load_recents()

        # Drawing: keep the exact refined vector canvas/behavior, restore compact toolbar shell.
        right=QWidget(); right.setObjectName('drawPanel'); rv=QVBoxLayout(right); rv.setContentsMargins(0,0,0,0); rv.setSpacing(0)
        dbw=QWidget(); dbw.setObjectName('drawToolbar'); db=QHBoxLayout(dbw); db.setContentsMargins(10,4,10,4); db.setSpacing(6)
        self.color=QPushButton(); self.color.setObjectName('colorSwatch'); self.color.setFixedSize(24,24); self._refresh_swatch(QColor('#111827'))
        self.size=QSpinBox(); self.size.setObjectName('drawSize'); self.size.setRange(1,40); self.size.setValue(3); self.size.setSuffix(' px')
        self.mode=QComboBox(); self.mode.setObjectName('drawMode'); self.mode.addItems(['Pencil','Line','Rectangle','Ellipse','Triangle','Star','Arrow','Text','Pan'])
        self.tapDraw=QCheckBox('Tap draw'); self.tapDraw.setObjectName('tapDraw'); self.tapDraw.setChecked(True)
        undo=QPushButton('↩ Undo'); undo.setObjectName('drawBtn'); clear=QPushButton('🗑 Clear'); clear.setObjectName('drawDanger'); export=QPushButton('💾 Export'); export.setObjectName('drawAccent')
        for w in (self.color,self.size,self.mode,self.tapDraw,undo,clear,export): db.addWidget(w)
        db.addStretch(); rv.addWidget(dbw)
        self.canvas=RefinedVectorCanvas(); rv.addWidget(self.canvas,1)
        self.color.clicked.connect(self._choose_color); self.size.valueChanged.connect(lambda v:setattr(self.canvas,'brushSize',v)); self.mode.currentTextChanged.connect(self.canvas.set_drawing_mode); self.tapDraw.toggled.connect(lambda on:setattr(self.canvas,'tap_draw',on)); undo.clicked.connect(self.canvas.undo); clear.clicked.connect(self.canvas.clear_canvas); export.clicked.connect(self.canvas.save_image)

        split.addWidget(left); split.addWidget(right); split.setStretchFactor(0,1); split.setStretchFactor(1,2); split.setSizes([400,800])
        self._note_state()

    def _refresh_swatch(self, color):
        self.color.setStyleSheet(f'background:{color.name()};border-radius:12px;border:2px solid #5a5a7a;')

    def _choose_color(self):
        c=QColorDialog.getColor(self.canvas.brushColor,self)
        if c.isValid(): self.canvas.brushColor=c; self._refresh_swatch(c)

    def _set_list(self,name):
        c=self.notes.textCursor()
        if name=='No list':
            if c.currentList():
                bf=c.blockFormat(); bf.setObjectIndex(-1); c.setBlockFormat(bf)
        else:
            mp={'• Bullet':QTextListFormat.ListDisc,'○ Circle':QTextListFormat.ListCircle,'■ Square':QTextListFormat.ListSquare,'1. Numbered':QTextListFormat.ListDecimal,'A. Lettered':QTextListFormat.ListUpperAlpha}; c.createList(mp[name])
        self._note_state()

    def _note_state(self):
        text=self.notes.toPlainText(); empty=not text.strip(); self.saveBtn.setEnabled(not empty); self.notesCount.setText(f'{len(text.split()) if text.strip() else 0} words')

    def _search_notes(self):
        q,ok=QInputDialog.getText(self,'Search Notes','Search term:')
        if ok and q:
            cur=self.notes.textCursor(); cur.movePosition(QTextCursor.Start); self.notes.setTextCursor(cur)
            if not self.notes.find(q): QMessageBox.information(self,'Search',f'"{q}" not found.')

    def _load_recents(self):
        self.recent.clear()
        try: paths=json.loads(self._recent_file.read_text(encoding='utf-8')) if self._recent_file.exists() else []
        except Exception: paths=[]
        for p in paths:
            if Path(p).exists(): self.recent.addItem(Path(p).name,p)

    def _remember(self,p):
        vals=[self.recent.itemData(i) for i in range(self.recent.count()) if self.recent.itemData(i) and self.recent.itemData(i)!=p]; vals.insert(0,p); vals=vals[:12]
        try:self._recent_file.write_text(json.dumps(vals),encoding='utf-8')
        except Exception:pass
        self._load_recents()

    def _save_note(self):
        if not self.notes.toPlainText().strip(): return
        p,_=QFileDialog.getSaveFileName(self,'Save Notes','','HTML Notes (*.html);;Text Notes (*.txt)')
        if not p:return
        Path(p).write_text(self.notes.toHtml() if p.lower().endswith('.html') else self.notes.toPlainText(),encoding='utf-8'); self._remember(p)

    def _load_note(self):
        p,_=QFileDialog.getOpenFileName(self,'Load Notes','','Notes (*.html *.txt)')
        if p:self._open_path(p)

    def _open_recent(self,i):
        p=self.recent.itemData(i)
        if p:self._open_path(p)

    def _open_path(self,p):
        try:
            txt=Path(p).read_text(encoding='utf-8'); self.notes.setHtml(txt) if p.lower().endswith('.html') else self.notes.setPlainText(txt); self._remember(p)
        except Exception as e:QMessageBox.warning(self,'Notes',str(e))

class V8VideoTab(QWidget):
    """Restores the richer meeting screen with an embedded persistent browser and system fallback."""
    def __init__(self):
        super().__init__()
        root=QVBoxLayout(self); root.setContentsMargins(12,12,12,12); root.setSpacing(8)
        title=QLabel('Video & Meetings'); title.setStyleSheet('font-size:20px;font-weight:700;'); root.addWidget(title)
        row=QHBoxLayout(); self.platform=QComboBox(); self.platform.addItems(['Zoom','Google Meet','MS Teams','YouTube Lectures','Custom URL'])
        self.input=QLineEdit(); self.input.setPlaceholderText('Meeting URL / room ID / lecture search')
        self.openHere=QPushButton('Open Here'); self.openSystem=QPushButton('Open in System Browser')
        row.addWidget(self.platform); row.addWidget(self.input,1); row.addWidget(self.openHere); row.addWidget(self.openSystem); root.addLayout(row)
        nav=QHBoxLayout(); back=QPushButton('◀'); fwd=QPushButton('▶'); reload=QPushButton('↻'); self.address=QLineEdit(); self.address.setPlaceholderText('Meeting/browser address…')
        nav.addWidget(back); nav.addWidget(fwd); nav.addWidget(reload); nav.addWidget(self.address,1); root.addLayout(nav)
        self.webView=QWebEngineView(); self.profile,self.page=setup_web_engine_page(self.webView,'VideoMeetings',self); root.addWidget(self.webView,1)
        self.status=QLabel('Ready'); self.status.setStyleSheet('color:#6b7280;font-size:11px;'); root.addWidget(self.status)
        self.openHere.clicked.connect(self.open_here); self.openSystem.clicked.connect(self.open_system); self.address.returnPressed.connect(self.navigate_address)
        back.clicked.connect(self.webView.back); fwd.clicked.connect(self.webView.forward); reload.clicked.connect(self.webView.reload)
        self.webView.urlChanged.connect(lambda u:self.address.setText(u.toString())); self.webView.loadStarted.connect(lambda:self.status.setText('Loading…')); self.webView.loadFinished.connect(lambda ok:self.status.setText(self.webView.title() if ok else 'Page failed to load'))
        self.webView.load(QUrl('https://www.google.com'))
    def _url(self):
        t=self.input.text().strip(); p=self.platform.currentText()
        if p=='Zoom':return t if t.startswith('http') else f'https://zoom.us/j/{t}'
        if p=='Google Meet':return t if t.startswith('http') else f'https://meet.google.com/{t}'
        if p=='MS Teams':return t if t.startswith('http') else f'https://teams.microsoft.com/l/meetup-join/{t}'
        if p=='YouTube Lectures':return t if t.startswith('http') else 'https://www.youtube.com/results?search_query='+urllib.parse.quote_plus(t)
        return t if t.startswith(('http://','https://')) else ('https://'+t if t else 'https://www.google.com')
    def open_here(self):
        if not self.input.text().strip() and self.platform.currentText()!='YouTube Lectures':QMessageBox.information(self,'Meeting','Enter a meeting link or ID first.');return
        self.webView.load(QUrl(self._url()))
    def open_system(self):
        from PyQt5.QtGui import QDesktopServices
        QDesktopServices.openUrl(QUrl(self._url()))
    def navigate_address(self):
        t=self.address.text().strip()
        if not t:return
        if not t.startswith(('http://','https://')):t='https://'+t
        self.webView.load(QUrl(t))



class V9DocumentTab(V8DocumentTab):
    """Writer V9: Excel-like table formulas with catalog, autocomplete, and custom expressions."""
    FORMULA_CATALOG = {
        # Statistical / aggregate
        'SUM': ('Statistical', '=SUM(A1:A10)', 'Add numeric values.'),
        'AVERAGE': ('Statistical', '=AVERAGE(A1:A10)', 'Arithmetic mean.'),
        'MEDIAN': ('Statistical', '=MEDIAN(A1:A10)', 'Median value.'),
        'MODE': ('Statistical', '=MODE(A1:A10)', 'Most frequent value.'),
        'MIN': ('Statistical', '=MIN(A1:A10)', 'Smallest numeric value.'),
        'MAX': ('Statistical', '=MAX(A1:A10)', 'Largest numeric value.'),
        'COUNT': ('Statistical', '=COUNT(A1:A10)', 'Count numeric cells.'),
        'COUNTA': ('Statistical', '=COUNTA(A1:A10)', 'Count non-empty cells.'),
        'STDEV.S': ('Statistical', '=STDEV.S(A1:A10)', 'Sample standard deviation.'),
        'STDEV.P': ('Statistical', '=STDEV.P(A1:A10)', 'Population standard deviation.'),
        'VAR.S': ('Statistical', '=VAR.S(A1:A10)', 'Sample variance.'),
        'VAR.P': ('Statistical', '=VAR.P(A1:A10)', 'Population variance.'),
        'SUMSQ': ('Statistical', '=SUMSQ(A1:A10)', 'Sum of squares.'),
        'LARGE': ('Statistical', '=LARGE(A1:A10,2)', 'k-th largest value.'),
        'SMALL': ('Statistical', '=SMALL(A1:A10,2)', 'k-th smallest value.'),
        'RANK': ('Statistical', '=RANK(A1,A1:A10,0)', 'Rank a number in a range.'),
        'PERCENTILE': ('Statistical', '=PERCENTILE(A1:A10,0.9)', 'Interpolated percentile.'),
        'QUARTILE': ('Statistical', '=QUARTILE(A1:A10,1)', 'Quartile 0–4.'),
        # Mathematics
        'PRODUCT': ('Math', '=PRODUCT(A1:A5)', 'Multiply numeric values.'),
        'ABS': ('Math', '=ABS(A1)', 'Absolute value.'),
        'ROUND': ('Math', '=ROUND(A1,2)', 'Round to decimal places.'),
        'ROUNDUP': ('Math', '=ROUNDUP(A1,2)', 'Round away from zero.'),
        'ROUNDDOWN': ('Math', '=ROUNDDOWN(A1,2)', 'Round toward zero.'),
        'INT': ('Math', '=INT(A1)', 'Round down to integer.'),
        'MOD': ('Math', '=MOD(A1,B1)', 'Remainder after division.'),
        'POWER': ('Math', '=POWER(A1,2)', 'Raise number to a power.'),
        'SQRT': ('Math', '=SQRT(A1)', 'Square root.'),
        'EXP': ('Math', '=EXP(A1)', 'e raised to a power.'),
        'LN': ('Math', '=LN(A1)', 'Natural logarithm.'),
        'LOG': ('Math', '=LOG(A1,10)', 'Logarithm with chosen base.'),
        'LOG10': ('Math', '=LOG10(A1)', 'Base-10 logarithm.'),
        'SIGN': ('Math', '=SIGN(A1)', 'Return -1, 0 or 1.'),
        # Logical / conditional
        'IF': ('Logical', '=IF(A1>=50,1,0)', 'Conditional value.'),
        'AND': ('Logical', '=AND(A1>0,B1>0)', 'TRUE if all conditions are true.'),
        'OR': ('Logical', '=OR(A1>0,B1>0)', 'TRUE if any condition is true.'),
        'NOT': ('Logical', '=NOT(A1>0)', 'Reverse a logical value.'),
        'COUNTIF': ('Conditional', '=COUNTIF(A1:A10,">=50")', 'Count cells matching a condition.'),
        'SUMIF': ('Conditional', '=SUMIF(A1:A10,">=50",B1:B10)', 'Sum values whose criteria match.'),
        'AVERAGEIF': ('Conditional', '=AVERAGEIF(A1:A10,">=50",B1:B10)', 'Average values whose criteria match.'),
    }

    def __init__(self):
        super().__init__()
        self._add_formulas_ribbon()

    def _add_formulas_ribbon(self):
        p=QWidget(); h=QHBoxLayout(p); h.setContentsMargins(8,4,8,4); h.setSpacing(8)
        self.formulaCategory=QComboBox(); self.formulaCategory.addItems(['All','Statistical','Math','Logical','Conditional'])
        self.formulaSearch=QLineEdit(); self.formulaSearch.setPlaceholderText('Find a formula…'); self.formulaSearch.setMinimumWidth(150)
        self.formulaPicker=QComboBox(); self.formulaPicker.setMinimumWidth(155)
        self.formulaEntry=QLineEdit(); self.formulaEntry.setPlaceholderText('=SUM(A1:A10)  or  =(A1+B1)*C1'); self.formulaEntry.setMinimumWidth(330)
        completions=[]
        for name,(_,example,_) in self.FORMULA_CATALOG.items(): completions.extend([name+'(', example])
        comp=QCompleter(completions,self.formulaEntry); comp.setCaseSensitivity(Qt.CaseInsensitive); comp.setCompletionMode(QCompleter.PopupCompletion); self.formulaEntry.setCompleter(comp)
        self.formulaHelp=QLabel(''); self.formulaHelp.setStyleSheet('color:#6b7280;font-size:9px;'); self.formulaHelp.setMinimumWidth(210)
        applyBtn=self._tool('✓ Apply',self.apply_formula_bar,'Evaluate the formula in the current table cell')
        insertBtn=self._tool('Insert example',self.insert_formula_example,'Load the selected native formula example')
        recalcBtn=self._tool('Recalculate',self.recalculate_current_table)
        h.addWidget(self._group('Library',[self.formulaCategory,self.formulaSearch,self.formulaPicker,insertBtn]))
        h.addWidget(self._group('Formula Bar',[self.formulaEntry,applyBtn,recalcBtn]))
        h.addWidget(self._group('Description',[self.formulaHelp])); h.addStretch()
        self.wordTabs.addTab(p,'Formulas')
        self.formulaCategory.currentTextChanged.connect(self._refresh_formula_picker)
        self.formulaSearch.textChanged.connect(self._refresh_formula_picker)
        self.formulaPicker.currentTextChanged.connect(self._formula_selected)
        self.formulaEntry.returnPressed.connect(self.apply_formula_bar)
        self._refresh_formula_picker()

    def _refresh_formula_picker(self):
        cat=self.formulaCategory.currentText() if hasattr(self,'formulaCategory') else 'All'
        q=self.formulaSearch.text().strip().lower() if hasattr(self,'formulaSearch') else ''
        cur=self.formulaPicker.currentText() if hasattr(self,'formulaPicker') else ''
        self.formulaPicker.blockSignals(True); self.formulaPicker.clear()
        for name,(category,example,desc) in self.FORMULA_CATALOG.items():
            if cat!='All' and category!=cat: continue
            if q and q not in name.lower() and q not in desc.lower() and q not in example.lower(): continue
            self.formulaPicker.addItem(name)
        if cur and self.formulaPicker.findText(cur)>=0:self.formulaPicker.setCurrentText(cur)
        self.formulaPicker.blockSignals(False)
        self._formula_selected(self.formulaPicker.currentText())

    def _formula_selected(self,name):
        if name in self.FORMULA_CATALOG:
            _,example,desc=self.FORMULA_CATALOG[name]; self.formulaHelp.setText(f'{name}: {desc}\n{example}')
        else:self.formulaHelp.clear()

    def insert_formula_example(self):
        name=self.formulaPicker.currentText()
        if name in self.FORMULA_CATALOG:self.formulaEntry.setText(self.FORMULA_CATALOG[name][1]); self.formulaEntry.setFocus(); self.formulaEntry.end(False)

    def apply_formula_bar(self):
        table,cell=self._current_table_cell()
        if not table:
            QMessageBox.information(self,'Formula','Place the cursor inside a table cell first.'); return
        formula=self.formulaEntry.text().strip()
        if not formula:return
        try:
            value=self._formula_value(table,cell,formula)
            if isinstance(value,bool): display='TRUE' if value else 'FALSE'
            elif isinstance(value,(int,float)) and not isinstance(value,bool): display=str(int(value)) if float(value).is_integer() else f'{float(value):.10g}'
            else: display=str(value)
            self._set_cell_text(cell,display); fmt=cell.format(); fmt.setProperty(self.FORMULA_PROPERTY,formula); cell.setFormat(fmt)
        except Exception as exc: QMessageBox.warning(self,'Formula Error',str(exc))

    def insert_table_formula(self):
        # Use the richer Formula tab rather than a bare input dialog.
        idx=self.wordTabs.indexOf(next((self.wordTabs.widget(i) for i in range(self.wordTabs.count()) if self.wordTabs.tabText(i)=='Formulas'),None))
        if idx>=0:self.wordTabs.setCurrentIndex(idx)
        table,cell=self._current_table_cell()
        if not table:
            QMessageBox.information(self,'Table Formula','Place the cursor inside a table cell first.');return
        current=cell.format().property(self.FORMULA_PROPERTY) or '=SUM(ABOVE)'
        self.formulaEntry.setText(str(current)); self.formulaEntry.setFocus(); self.formulaEntry.selectAll()

    def _raw_cell(self,table,row,col):
        if row<0 or col<0 or row>=table.rows() or col>=table.columns(): raise ValueError('Cell reference is outside the current table.')
        t=table.cellAt(row,col).firstCursorPosition().block().text().strip()
        if not t:return ''
        try:return float(t.replace(',',''))
        except Exception:return t

    @staticmethod
    def _flatten_values(*args):
        out=[]
        for a in args:
            if isinstance(a,(list,tuple)):out.extend(V9DocumentTab._flatten_values(*a))
            else:out.append(a)
        return out

    @staticmethod
    def _nums(*args):
        vals=[]
        for v in V9DocumentTab._flatten_values(*args):
            if isinstance(v,bool): vals.append(float(v))
            elif isinstance(v,(int,float)): vals.append(float(v))
            elif isinstance(v,str):
                try: vals.append(float(v.replace(',','')))
                except Exception: pass
        return vals

    @staticmethod
    def _criterion_match(value,criterion):
        if not isinstance(criterion,str): return value==criterion
        c=criterion.strip(); m=re.match(r'^(<=|>=|<>|!=|=|<|>)(.*)$',c)
        op,target=(m.group(1),m.group(2).strip()) if m else ('=',c)
        try: target=float(target); val=float(value)
        except Exception: val=str(value); target=str(target)
        return {'=':lambda a,b:a==b,'<>':lambda a,b:a!=b,'!=':lambda a,b:a!=b,'<':lambda a,b:a<b,'>':lambda a,b:a>b,'<=':lambda a,b:a<=b,'>=':lambda a,b:a>=b}[op](val,target)

    def _formula_value(self,table,cell,formula):
        expr=formula.strip()
        if expr.startswith('='):expr=expr[1:].strip()
        # Excel operators.
        expr=expr.replace('<>','!=').replace('^','**')
        expr=re.sub(r'(?<![<>=!])=(?!=)', '==', expr)
        # Dotted Excel names become safe Python identifiers.
        expr=re.sub(r'\bSTDEV\.S\b','STDEV_S',expr,flags=re.I); expr=re.sub(r'\bSTDEV\.P\b','STDEV_P',expr,flags=re.I)
        expr=re.sub(r'\bVAR\.S\b','VAR_S',expr,flags=re.I); expr=re.sub(r'\bVAR\.P\b','VAR_P',expr,flags=re.I)
        row,col=cell.row(),cell.column()
        def directional(m):
            direction=m.group(1).upper(); refs=[]
            if direction=='ABOVE': refs=[self._raw_cell(table,r,col) for r in range(row)]
            else: refs=[self._raw_cell(table,row,c) for c in range(col)]
            return repr(refs)
        expr=re.sub(r'\b(ABOVE|LEFT)\b',directional,expr,flags=re.I)
        def range_repl(m):
            a,b=m.group(1),m.group(2); (r1,c1)=self._cell_ref(table,a); (r2,c2)=self._cell_ref(table,b)
            vals=[]
            for r in range(min(r1,r2),max(r1,r2)+1):
                for c in range(min(c1,c2),max(c1,c2)+1):vals.append(self._raw_cell(table,r,c))
            return repr(vals)
        expr=re.sub(r'\b([A-Za-z]+[1-9]\d*)\s*:\s*([A-Za-z]+[1-9]\d*)\b',range_repl,expr)
        def cell_repl(m):
            r,c=self._cell_ref(table,m.group(0)); return repr(self._raw_cell(table,r,c))
        expr=re.sub(r'\b[A-Za-z]+[1-9]\d*\b',cell_repl,expr)

        flat=self._flatten_values; nums=self._nums
        def SUM(*x):return sum(nums(*x))
        def AVERAGE(*x):
            n=nums(*x); return sum(n)/len(n) if n else 0
        def MEDIAN(*x):
            n=nums(*x); return statistics.median(n) if n else 0
        def MODE(*x):
            n=nums(*x)
            if not n:return 0
            counts={v:n.count(v) for v in n}; return max(counts,key=lambda v:(counts[v],-n.index(v)))
        def COUNT(*x):return len(nums(*x))
        def COUNTA(*x):return sum(1 for v in flat(*x) if str(v).strip()!='')
        def PRODUCT(*x):
            n=nums(*x); p=1
            for v in n:p*=v
            return p if n else 0
        def STDEV_S(*x):
            n=nums(*x); return statistics.stdev(n) if len(n)>=2 else 0
        def STDEV_P(*x):
            n=nums(*x); return statistics.pstdev(n) if n else 0
        def VAR_S(*x):
            n=nums(*x); return statistics.variance(n) if len(n)>=2 else 0
        def VAR_P(*x):
            n=nums(*x); return statistics.pvariance(n) if n else 0
        def SUMSQ(*x):return sum(v*v for v in nums(*x))
        def LARGE(arr,k):
            n=sorted(nums(arr),reverse=True); k=int(k); return n[k-1] if 1<=k<=len(n) else 0
        def SMALL(arr,k):
            n=sorted(nums(arr)); k=int(k); return n[k-1] if 1<=k<=len(n) else 0
        def RANK(number,arr,order=0):
            n=sorted(nums(arr),reverse=not bool(order)); return n.index(float(number))+1 if float(number) in n else 0
        def PERCENTILE(arr,k):
            n=sorted(nums(arr)); k=float(k)
            if not n:return 0
            if k<=0:return n[0]
            if k>=1:return n[-1]
            pos=(len(n)-1)*k; lo=int(math.floor(pos)); hi=int(math.ceil(pos)); return n[lo] if lo==hi else n[lo]+(n[hi]-n[lo])*(pos-lo)
        def QUARTILE(arr,q):return PERCENTILE(arr,float(q)/4.0)
        def ROUNDUP(v,d=0):
            f=10**int(d); return math.ceil(abs(float(v))*f)/f*(1 if float(v)>=0 else -1)
        def ROUNDDOWN(v,d=0):
            f=10**int(d); return math.floor(abs(float(v))*f)/f*(1 if float(v)>=0 else -1)
        def IF(cond,a,b=0):return a if cond else b
        def AND(*x):return all(bool(v) for v in flat(*x))
        def OR(*x):return any(bool(v) for v in flat(*x))
        def NOT(x):return not bool(x)
        def COUNTIF(arr,criteria):return sum(1 for v in flat(arr) if self._criterion_match(v,criteria))
        def SUMIF(arr,criteria,sum_range=None):
            a=flat(arr); b=flat(sum_range) if sum_range is not None else a
            return sum(float(b[i]) for i,v in enumerate(a[:len(b)]) if self._criterion_match(v,criteria) and isinstance(b[i],(int,float)))
        def AVERAGEIF(arr,criteria,avg_range=None):
            a=flat(arr); b=flat(avg_range) if avg_range is not None else a; vals=[]
            for i,v in enumerate(a[:len(b)]):
                if self._criterion_match(v,criteria):
                    try:vals.append(float(b[i]))
                    except Exception:pass
            return sum(vals)/len(vals) if vals else 0
        safe={
            'SUM':SUM,'AVERAGE':AVERAGE,'AVG':AVERAGE,'MEDIAN':MEDIAN,'MODE':MODE,'MIN':lambda *x:min(nums(*x)) if nums(*x) else 0,'MAX':lambda *x:max(nums(*x)) if nums(*x) else 0,
            'COUNT':COUNT,'COUNTA':COUNTA,'PRODUCT':PRODUCT,'STDEV_S':STDEV_S,'STDEV_P':STDEV_P,'VAR_S':VAR_S,'VAR_P':VAR_P,'SUMSQ':SUMSQ,'LARGE':LARGE,'SMALL':SMALL,'RANK':RANK,'PERCENTILE':PERCENTILE,'QUARTILE':QUARTILE,
            'ABS':abs,'ROUND':round,'ROUNDUP':ROUNDUP,'ROUNDDOWN':ROUNDDOWN,'INT':math.floor,'MOD':lambda a,b:a%b,'POWER':pow,'SQRT':math.sqrt,'EXP':math.exp,'LN':math.log,'LOG':lambda a,b=10:math.log(a,b),'LOG10':math.log10,'SIGN':lambda x:(x>0)-(x<0),
            'IF':IF,'AND':AND,'OR':OR,'NOT':NOT,'COUNTIF':COUNTIF,'SUMIF':SUMIF,'AVERAGEIF':AVERAGEIF,
            'TRUE':True,'FALSE':False,'true':True,'false':False,
        }
        # Expose lowercase aliases too, while keeping arbitrary names blocked.
        safe.update({k.lower():v for k,v in list(safe.items()) if callable(v)})
        if not re.fullmatch(r'[0-9eE\.\+\-\*\/\%\(\),\[\]\sA-Za-z_"\'<>!=]+',expr):raise ValueError('Formula contains unsupported characters.')
        names=set(re.findall(r'\b[A-Za-z_][A-Za-z0-9_]*\b',expr))
        quoted=re.findall(r'["\'].*?["\']',expr)
        temp=expr
        for q in quoted:temp=temp.replace(q,'')
        names=set(re.findall(r'\b[A-Za-z_][A-Za-z0-9_]*\b',temp))
        unknown=[n for n in names if n not in safe and n not in ('True','False')]
        if unknown:raise ValueError('Unsupported function/name: '+', '.join(sorted(unknown)))
        return eval(expr,{'__builtins__':{}},safe)


class V9VideoTab(QWidget):
    """Video workspace that always reuses the currently active Jesson Browser profile."""
    def __init__(self,browser_tab):
        super().__init__(); self.browser_tab=browser_tab; self._shared_profile=None
        root=QVBoxLayout(self); root.setContentsMargins(12,12,12,12); root.setSpacing(8)
        title=QLabel('Video & Meetings'); title.setStyleSheet('font-size:20px;font-weight:700;'); root.addWidget(title)
        info=QLabel('Embedded meetings reuse the currently selected Jesson Browser profile and its signed-in session.'); info.setWordWrap(True); info.setStyleSheet('color:#6b7280;'); root.addWidget(info)
        row=QHBoxLayout(); self.platform=QComboBox(); self.platform.addItems(['Zoom','Google Meet','MS Teams','Custom URL'])
        self.input=QLineEdit(); self.input.setPlaceholderText('Meeting URL or room ID')
        self.openHere=QPushButton('Open Here (Jesson session)'); self.openDefault=QPushButton('Open in Default Browser')
        row.addWidget(self.platform); row.addWidget(self.input,1); row.addWidget(self.openHere); row.addWidget(self.openDefault); root.addLayout(row)
        nav=QHBoxLayout(); back=QPushButton('◀'); fwd=QPushButton('▶'); reload=QPushButton('↻'); self.address=QLineEdit(); self.address.setPlaceholderText('Meeting address…')
        nav.addWidget(back); nav.addWidget(fwd); nav.addWidget(reload); nav.addWidget(self.address,1); root.addLayout(nav)
        self.webView=QWebEngineView(); root.addWidget(self.webView,1); self._attach_current_browser_profile()
        self.status=QLabel('Ready'); self.status.setStyleSheet('color:#6b7280;font-size:11px;'); root.addWidget(self.status)
        self.openHere.clicked.connect(self.open_here); self.openDefault.clicked.connect(self.open_default); self.address.returnPressed.connect(self.navigate_address)
        back.clicked.connect(self.webView.back); fwd.clicked.connect(self.webView.forward); reload.clicked.connect(self.webView.reload)
        self.webView.urlChanged.connect(lambda u:self.address.setText(u.toString())); self.webView.loadStarted.connect(lambda:self.status.setText('Loading…')); self.webView.loadFinished.connect(lambda ok:self.status.setText(self.webView.title() if ok else 'Page failed to load'))
        self.webView.load(QUrl('https://meet.google.com'))

    def _attach_current_browser_profile(self):
        profile=getattr(self.browser_tab,'profile',None)
        if profile is None:return
        if profile is self._shared_profile:return
        page=QWebEnginePage(profile,self.webView)
        def ask_permission(origin,feature):
            host=origin.host() or origin.toString(); ans=QMessageBox.question(self,'Website permission',f'Allow {host} to use the requested camera/microphone/screen feature?',QMessageBox.Yes|QMessageBox.No,QMessageBox.No)
            page.setFeaturePermission(origin,feature,QWebEnginePage.PermissionGrantedByUser if ans==QMessageBox.Yes else QWebEnginePage.PermissionDeniedByUser)
        page.featurePermissionRequested.connect(ask_permission)
        self.webView.setPage(page); self._shared_profile=profile

    def _url(self):
        t=self.input.text().strip(); p=self.platform.currentText()
        if p=='Zoom':return t if t.startswith('http') else f'https://zoom.us/j/{t}'
        if p=='Google Meet':return t if t.startswith('http') else f'https://meet.google.com/{t}'
        if p=='MS Teams':return t if t.startswith('http') else f'https://teams.microsoft.com/l/meetup-join/{t}'
        return t if t.startswith(('http://','https://')) else ('https://'+t if t else 'https://meet.google.com')
    def open_here(self):
        if not self.input.text().strip():QMessageBox.information(self,'Meeting','Enter a meeting link or ID first.');return
        self._attach_current_browser_profile(); self.webView.load(QUrl(self._url()))
    def open_default(self):
        if not self.input.text().strip():QMessageBox.information(self,'Meeting','Enter a meeting link or ID first.');return
        from PyQt5.QtGui import QDesktopServices
        QDesktopServices.openUrl(QUrl(self._url()))
    def navigate_address(self):
        t=self.address.text().strip()
        if not t:return
        self._attach_current_browser_profile()
        if not t.startswith(('http://','https://')):t='https://'+t
        self.webView.load(QUrl(t))


# =============================================================================
#  V10 Document tab -- the remaining Word features
#  (Find & Replace, spelling, comments, track changes, hyperlinks, bookmarks,
#   page setup, ruler, navigation pane, TOC, citations, mail merge, charts,
#   table tools, watermark, page numbers, richer DOCX export, autosave ...)
# =============================================================================
import csv
import getpass
import difflib
import traceback
import tempfile
import html as _html
from PyQt5.QtGui import (QTextOption, QTextDocumentFragment, QTextDocument, QTextTable,
                         QDesktopServices, QPolygonF, QTextImageFormat)
from PyQt5.QtWidgets import QFrame
from docx.shared import Mm
from docx.enum.section import WD_ORIENT
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.opc.constants import RELATIONSHIP_TYPE as RT

# Custom text-format properties (stored inside the QTextDocument itself, so they
# move with the text when the user edits).
P_INS = QTextFormat.UserProperty + 11   # tracked insertion
P_DEL = QTextFormat.UserProperty + 12   # tracked deletion
P_CMT = QTextFormat.UserProperty + 13   # comment id
P_TOC = QTextFormat.UserProperty + 14   # block belongs to a table of contents

PAPER_PX = {'A4': (794, 1123), 'Letter': (816, 1056), 'Legal': (816, 1344),
            'A5': (559, 794), 'A3': (1123, 1587)}
PAPER_MM = {'A4': (210, 297), 'Letter': (216, 279), 'Legal': (216, 356),
            'A5': (148, 210), 'A3': (297, 420)}
PAPER_Q = {'A4': QPrinter.A4, 'Letter': QPrinter.Letter, 'Legal': QPrinter.Legal,
           'A5': QPrinter.A5, 'A3': QPrinter.A3}
CM = 96.0 / 2.54   # pixels per centimetre at 96 dpi
# top, left, bottom, right (cm)
MARGIN_PRESETS = {'Normal': (2.54, 2.54, 2.54, 2.54), 'Narrow': (1.27, 1.27, 1.27, 1.27),
                  'Moderate': (2.54, 1.91, 2.54, 1.91), 'Wide': (2.54, 5.08, 2.54, 5.08)}
HEADING_SIZES = {20: 1, 16: 2, 13: 3}   # matches EnhancedDocumentTab.STYLE_MAP
CHART_COLORS = ['#4472c4', '#ed7d31', '#a5a5a5', '#ffc000', '#5b9bd5', '#70ad47',
                '#9e480e', '#636363', '#997300', '#264478']


class SpellEngine:
    """Uses pyspellchecker or pyenchant if installed, else a system word list."""
    def __init__(self):
        self.kind = None
        self.checker = None
        self.words = set()
        self.ignore = set()
        self.dict_path = Path.home() / '.jesson_reader' / 'custom_dictionary.txt'
        self.user = set()
        self._load_backend()
        self._load_user()

    def _load_backend(self):
        try:
            from spellchecker import SpellChecker
            self.checker = SpellChecker(); self.kind = 'pyspellchecker'; return
        except Exception:
            pass
        try:
            import enchant
            self.checker = enchant.Dict('en_US'); self.kind = 'enchant'; return
        except Exception:
            pass
        for p in ('/usr/share/dict/words', '/usr/share/dict/american-english',
                  '/usr/share/dict/british-english', '/usr/dict/words'):
            try:
                if os.path.exists(p):
                    with open(p, encoding='utf-8', errors='ignore') as fh:
                        self.words = {w.strip().lower() for w in fh if w.strip()}
                    if self.words:
                        self.kind = 'wordlist'; return
            except Exception:
                pass

    def _load_user(self):
        try:
            if self.dict_path.exists():
                self.user = {w.strip().lower() for w in self.dict_path.read_text(encoding='utf-8').splitlines() if w.strip()}
        except Exception:
            self.user = set()

    def available(self):
        return self.kind is not None

    def add_word(self, word):
        self.user.add(word.lower())
        try:
            self.dict_path.parent.mkdir(parents=True, exist_ok=True)
            self.dict_path.write_text('\n'.join(sorted(self.user)), encoding='utf-8')
        except Exception:
            pass

    def known(self, word):
        lw = word.lower().replace('\u2019', "'")
        if lw.endswith("'s"):
            lw = lw[:-2]
        if not lw or lw in self.user or lw in self.ignore:
            return True
        if len(lw) < 2:
            return True
        try:
            if self.kind == 'pyspellchecker':
                return not self.checker.unknown([lw])
            if self.kind == 'enchant':
                return bool(self.checker.check(word))
            if self.kind == 'wordlist':
                return lw in self.words
        except Exception:
            return True
        return True

    def suggest(self, word):
        try:
            if self.kind == 'pyspellchecker':
                cands = self.checker.candidates(word.lower()) or set()
                best = self.checker.correction(word.lower())
                out = [best] if best and best != word.lower() else []
                out += [c for c in sorted(cands) if c not in out]
                return out[:7]
            if self.kind == 'enchant':
                return list(self.checker.suggest(word))[:7]
            if self.kind == 'wordlist':
                lw = word.lower()
                pool = [x for x in self.words if x and x[0] == lw[0] and abs(len(x) - len(lw)) <= 2]
                return difflib.get_close_matches(lw, pool, n=7, cutoff=0.7)
        except Exception:
            pass
        return []


class FindReplaceDialog(QDialog):
    """Modeless Find and Replace (match case, whole words, regex, highlight all)."""
    def __init__(self, tab):
        super().__init__(tab)
        self.tab = tab
        self.setWindowTitle('Find and Replace')
        self.setModal(False)
        form = QFormLayout(self)
        self.findEdit = QLineEdit(); self.replEdit = QLineEdit()
        self.matchCase = QCheckBox('Match case')
        self.wholeWord = QCheckBox('Find whole words only')
        self.useRegex = QCheckBox('Use regular expressions')
        self.highlightAll = QCheckBox('Highlight all matches'); self.highlightAll.setChecked(True)
        form.addRow('Find what:', self.findEdit)
        form.addRow('Replace with:', self.replEdit)
        for w in (self.matchCase, self.wholeWord, self.useRegex, self.highlightAll):
            form.addRow(w)
        self.status = QLabel('')
        form.addRow(self.status)
        row = QHBoxLayout()
        for text, fn in (('Find Next', self.find_next), ('Find Previous', self.find_prev),
                         ('Replace', self.replace_one), ('Replace All', self.replace_all)):
            b = QPushButton(text)
            b.clicked.connect(lambda _=False, f=fn: f())
            row.addWidget(b)
        form.addRow(row)
        self.findEdit.returnPressed.connect(self.find_next)
        for sig in (self.findEdit.textChanged, self.matchCase.toggled, self.wholeWord.toggled,
                    self.useRegex.toggled, self.highlightAll.toggled):
            sig.connect(lambda *_: self._update_highlight())

    def done(self, r):
        self.tab._set_extra('find', [])
        super().done(r)

    def _pattern(self):
        txt = self.findEdit.text()
        if not txt:
            return None
        flags = 0 if self.matchCase.isChecked() else re.IGNORECASE
        src = txt if self.useRegex.isChecked() else re.escape(txt)
        if self.wholeWord.isChecked():
            src = r'\b(?:' + src + r')\b'
        try:
            return re.compile(src, flags | re.MULTILINE)
        except re.error as exc:
            self.status.setText('Invalid pattern: %s' % exc)
            return None

    def _text(self):
        return self.tab.textEdit.document().toPlainText()

    def _matches(self, pat, text):
        return [m for m in pat.finditer(text) if m.end() > m.start()]

    def _select(self, s, e):
        c = QTextCursor(self.tab.textEdit.document())
        c.setPosition(s); c.setPosition(e, QTextCursor.KeepAnchor)
        self.tab.textEdit.setTextCursor(c)
        self.tab._scroll_to_cursor()

    def _update_highlight(self):
        sels = []
        pat = self._pattern()
        if pat is not None and self.highlightAll.isChecked():
            ms = self._matches(pat, self._text())
            self.status.setText('%d match(es)' % len(ms) if ms else 'No matches')
            for m in ms[:1500]:
                s = QTextEdit.ExtraSelection()
                c = QTextCursor(self.tab.textEdit.document())
                c.setPosition(m.start()); c.setPosition(m.end(), QTextCursor.KeepAnchor)
                s.cursor = c
                f = QTextCharFormat(); f.setBackground(QColor('#fff3a3'))
                s.format = f
                sels.append(s)
        elif pat is None and not self.findEdit.text():
            self.status.setText('')
        self.tab._set_extra('find', sels)

    def find_next(self):
        pat = self._pattern()
        if pat is None:
            return False
        ms = self._matches(pat, self._text())
        if not ms:
            self.status.setText('Not found'); return False
        sel_end = self.tab.textEdit.textCursor().selectionEnd()
        nxt = next((m for m in ms if m.start() >= sel_end), None)
        if nxt is None:
            nxt = ms[0]; self.status.setText('Reached the end - continued from the top')
        else:
            self.status.setText('')
        self._select(nxt.start(), nxt.end())
        return True

    def find_prev(self):
        pat = self._pattern()
        if pat is None:
            return False
        ms = self._matches(pat, self._text())
        if not ms:
            self.status.setText('Not found'); return False
        sel_start = self.tab.textEdit.textCursor().selectionStart()
        prv = next((m for m in reversed(ms) if m.end() <= sel_start), None)
        if prv is None:
            prv = ms[-1]
        self._select(prv.start(), prv.end())
        return True

    def _replacement(self, m):
        repl = self.replEdit.text()
        if self.useRegex.isChecked():
            try:
                return m.expand(repl)
            except re.error:
                return repl
        return repl

    def replace_one(self):
        pat = self._pattern()
        if pat is None:
            return
        cur = self.tab.textEdit.textCursor()
        if cur.hasSelection():
            m = pat.fullmatch(cur.selectedText().replace('\u2029', '\n'))
            if m is not None:
                cur.insertText(self._replacement(m))
                self.tab.textEdit.setTextCursor(cur)
        self.find_next()

    def replace_all(self):
        pat = self._pattern()
        if pat is None:
            return
        ms = self._matches(pat, self._text())
        if not ms:
            self.status.setText('Not found'); return
        doc = self.tab.textEdit.document()
        c = QTextCursor(doc)
        c.beginEditBlock()
        for m in reversed(ms):
            c.setPosition(m.start()); c.setPosition(m.end(), QTextCursor.KeepAnchor)
            c.insertText(self._replacement(m))
        c.endEditBlock()
        self.status.setText('Replaced %d occurrence(s)' % len(ms))
        self._update_highlight()


class SpellDialog(QDialog):
    """Steps through misspelled words: Change / Ignore / Add to dictionary."""
    def __init__(self, tab):
        super().__init__(tab)
        self.tab = tab
        self.setWindowTitle('Spelling')
        self.setModal(False)
        lay = QVBoxLayout(self)
        self.wordLbl = QLabel('')
        self.wordLbl.setStyleSheet('font-size:15px;font-weight:600;color:#b42318;')
        lay.addWidget(QLabel('Not in dictionary:')); lay.addWidget(self.wordLbl)
        self.sugg = QListWidget(); self.sugg.setMinimumHeight(110)
        lay.addWidget(QLabel('Suggestions:')); lay.addWidget(self.sugg)
        grid = QGridLayout()
        specs = [('Change', self.change), ('Change All', self.change_all), ('Ignore', self.ignore),
                 ('Ignore All', self.ignore_all), ('Add to Dictionary', self.add), ('Close', self.close)]
        for i, (t, fn) in enumerate(specs):
            b = QPushButton(t); b.clicked.connect(lambda _=False, f=fn: f())
            grid.addWidget(b, i // 2, i % 2)
        lay.addLayout(grid)
        self._cur = None
        self.sugg.itemDoubleClicked.connect(lambda *_: self.change())

    def start(self):
        self._start_pos = self.tab.textEdit.textCursor().selectionEnd()
        self.next_error(self.tab.textEdit.textCursor().selectionStart())

    def next_error(self, start=None):
        pos = self.tab.textEdit.textCursor().selectionEnd() if start is None else start
        hit = self.tab._spell_find(pos)
        if hit is None and pos > 0:
            hit = self.tab._spell_find(0)
        if hit is None:
            QMessageBox.information(self, 'Spelling', 'The spelling check is complete.')
            self._cur = None
            self.close(); return
        s, e, word = hit
        self._cur = (s, e, word)
        c = QTextCursor(self.tab.textEdit.document())
        c.setPosition(s); c.setPosition(e, QTextCursor.KeepAnchor)
        self.tab.textEdit.setTextCursor(c); self.tab._scroll_to_cursor()
        self.wordLbl.setText(word)
        self.sugg.clear()
        for w in self.tab.spell.suggest(word):
            self.sugg.addItem(w)
        if self.sugg.count():
            self.sugg.setCurrentRow(0)

    def _chosen(self):
        it = self.sugg.currentItem()
        return it.text() if it else None

    def change(self):
        w = self._chosen()
        if not self._cur or not w:
            return
        c = self.tab.textEdit.textCursor()
        c.insertText(w)
        self.next_error(c.position())

    def change_all(self):
        w = self._chosen()
        if not self._cur or not w:
            return
        old = self._cur[2]
        doc = self.tab.textEdit.document()
        text = doc.toPlainText()
        c = QTextCursor(doc); c.beginEditBlock()
        for m in reversed(list(re.finditer(r"\b" + re.escape(old) + r"\b", text))):
            c.setPosition(m.start()); c.setPosition(m.end(), QTextCursor.KeepAnchor); c.insertText(w)
        c.endEditBlock()
        self.next_error(0)

    def ignore(self):
        self.next_error(self.tab.textEdit.textCursor().selectionEnd())

    def ignore_all(self):
        if self._cur:
            self.tab.spell.ignore.add(self._cur[2].lower())
        self.tab._refresh_spelling()
        self.next_error(self.tab.textEdit.textCursor().selectionEnd())

    def add(self):
        if self._cur:
            self.tab.spell.add_word(self._cur[2])
        self.tab._refresh_spelling()
        self.next_error(self.tab.textEdit.textCursor().selectionEnd())


class RulerWidget(QWidget):
    """Horizontal ruler (cm) with draggable first-line, left and right indent markers."""
    def __init__(self, tab):
        super().__init__()
        self.tab = tab
        self.setFixedHeight(22)
        self.drag = None

    def _ppc(self):
        return CM * max(0.5, min(2.0, self.tab._doc_zoom / 100.0))

    def _fmt(self):
        return self.tab.textEdit.textCursor().blockFormat()

    def _marker_x(self):
        bf = self._fmt()
        left = bf.leftMargin()
        return {'first': left + bf.textIndent(), 'left': left, 'right': self.width() - bf.rightMargin()}

    def paintEvent(self, event):
        p = QPainter(self)
        p.fillRect(self.rect(), QColor('#f3f4f6'))
        ppc = self._ppc()
        p.setPen(QColor('#6b7280')); p.setFont(QFont('Segoe UI', 7))
        h = self.height()
        i = 0
        while i * ppc / 2.0 <= self.width():
            x = i * ppc / 2.0
            if i % 2 == 0:
                p.drawLine(int(x), h - 9, int(x), h - 1)
                if i > 0:
                    p.drawText(QRectF(x + 2, 1, 18, 10), Qt.AlignLeft | Qt.AlignTop, str(i // 2))
            else:
                p.drawLine(int(x), h - 5, int(x), h - 1)
            i += 1
        m = self._marker_x()
        p.setPen(QColor('#2b579a')); p.setBrush(QColor('#2b579a'))
        x = m['first']
        p.drawPolygon(QPolygonF([QPointF(x - 4, 0), QPointF(x + 4, 0), QPointF(x, 7)]))
        x = m['left']
        p.drawPolygon(QPolygonF([QPointF(x - 4, h), QPointF(x + 4, h), QPointF(x, h - 7)]))
        x = m['right']
        p.drawPolygon(QPolygonF([QPointF(x - 4, h), QPointF(x + 4, h), QPointF(x, h - 7)]))
        p.end()

    def mousePressEvent(self, e):
        m = self._marker_x()
        best = min(m.items(), key=lambda kv: abs(kv[1] - e.x()))
        self.drag = best[0] if abs(best[1] - e.x()) <= 8 else None

    def mouseMoveEvent(self, e):
        if self.drag:
            self._apply(e.x())

    def mouseReleaseEvent(self, e):
        self.drag = None

    def _apply(self, x):
        x = max(0, min(self.width(), x))
        c = self.tab.textEdit.textCursor()
        doc = self.tab.textEdit.document()
        blk = doc.findBlock(c.selectionStart())
        last = doc.findBlock(c.selectionEnd())
        edit = QTextCursor(doc)
        edit.beginEditBlock()
        while blk.isValid():
            bc = QTextCursor(blk)
            bf = bc.blockFormat()
            if self.drag == 'left':
                bf.setLeftMargin(x)
            elif self.drag == 'first':
                bf.setTextIndent(x - bf.leftMargin())
            elif self.drag == 'right':
                bf.setRightMargin(self.width() - x)
            bc.setBlockFormat(bf)
            if blk.blockNumber() >= last.blockNumber():
                break
            blk = blk.next()
        edit.endEditBlock()
        self.update()


class WordPageOverlay(DocumentPageOverlay):
    """Page gaps + header/footer with alignment and {page}/{pages} fields + watermark."""
    def __init__(self, parent=None):
        super().__init__(parent)
        self.watermark = ''
        self.header_align = Qt.AlignLeft
        self.footer_align = Qt.AlignLeft

    def paintEvent(self, event):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing, True)
        h = max(240, self.page_height)
        pages = max(1, int(math.ceil(self.height() / float(h))))
        for i in range(pages):
            top = i * h
            if self.watermark:
                p.save()
                p.translate(self.width() / 2.0, top + h / 2.0)
                p.rotate(-45)
                f = QFont('Segoe UI', 1); f.setBold(True)
                f.setPixelSize(max(24, int(min(self.width(), h) / 6.5)))
                p.setFont(f); p.setPen(QColor(120, 120, 120, 55))
                p.drawText(QRectF(-self.width(), -h / 6.0, self.width() * 2, h / 3.0), Qt.AlignCenter, self.watermark)
                p.restore()
            p.setPen(QColor('#8a94a3')); p.setFont(QFont('Segoe UI', 8))
            if self.header_text:
                t = self.header_text.replace('{page}', str(i + 1)).replace('{pages}', str(pages))
                p.drawText(QRectF(24, top + 10, max(10, self.width() - 48), 22), self.header_align | Qt.AlignVCenter, t)
            if self.footer_text:
                t = self.footer_text.replace('{page}', str(i + 1)).replace('{pages}', str(pages))
                p.drawText(QRectF(24, top + h - 34, max(10, self.width() - 48), 20), self.footer_align | Qt.AlignVCenter, t)
            if i > 0:
                p.fillRect(QRectF(0, top - 7, self.width(), 14), QColor('#d8dde5'))
                p.setPen(QColor('#b8c0cc'))
                p.drawLine(0, top - 7, self.width(), top - 7)
                p.drawLine(0, top + 7, self.width(), top + 7)
        p.end()



class _Note(Exception):
    """Raised by commands to show a friendly information box instead of an error."""


WORD_RE = re.compile(r"[A-Za-z][A-Za-z'\u2019]+")
MERGE_L, MERGE_R = '\u00ab', '\u00bb'


class V10DocumentTab(V9DocumentTab):
    """Writer V10: the Word features that were missing from V9."""

    def __init__(self):
        # plain-Python state first (Qt widgets are created by the parents)
        self._extras = {}
        self._spell = None
        self._spell_on = False
        self._find_dlg = None
        self._spell_dlg = None
        self._tracking = False
        self._tc_busy = False
        self._tc_text = None
        self._tc_flags = []
        self._last_key = None
        self._painter = None
        self._painter_armed = False
        self.comments = {}
        self._next_cmt = 1
        self.sources = []
        self._merge_rows = []
        self._merge_fields = []
        self._mm_template = None
        self._mm_index = 0
        self._tts = None
        self._paper = 'A4'
        self._orient = 'Portrait'
        self._margins_px = (58, 68, 58, 68)     # top, left, bottom, right
        self.header_align = Qt.AlignLeft
        self.footer_align = Qt.AlignLeft
        try:
            self.doc_author = getpass.getuser()
        except Exception:
            self.doc_author = 'Author'
        self.doc_title = ''
        super().__init__()
        try:
            self._v10_setup()
        except Exception:
            traceback.print_exc()     # a failure here must never stop the app from starting

    # ------------------------------------------------------------------ setup
    @property
    def spell(self):
        if self._spell is None:
            self._spell = SpellEngine()
        return self._spell

    def _v10_setup(self):
        ed = self.textEdit
        ed.viewport().setMouseTracking(True)
        ed.installEventFilter(self)
        ed.setContextMenuPolicy(Qt.CustomContextMenu)
        ed.customContextMenuRequested.connect(self._ctx_menu)
        # watermark / aligned header-footer / page-number aware overlay
        old = self.pageOverlay
        new = WordPageOverlay(ed.viewport())
        new.setGeometry(old.geometry()); new.page_height = old.page_height
        new.show(); new.raise_()
        old.hide(); old.deleteLater()
        self.pageOverlay = new
        self._build_side_panel()
        self._build_ruler()
        self._refresh_timer = QTimer(self)
        self._refresh_timer.setSingleShot(True); self._refresh_timer.setInterval(450)
        self._refresh_timer.timeout.connect(self._deferred_refresh)
        ed.textChanged.connect(lambda: self._refresh_timer.start())
        ed.document().contentsChange.connect(self._on_contents_change)
        ed.cursorPositionChanged.connect(lambda: self.ruler.update())
        # ribbon
        self._build_v10_ribbons()
        self._extend_file_menu()
        # shortcuts (only active while this tab has focus)
        self._sc('Ctrl+F', lambda: self.open_find(False))
        self._sc('Ctrl+H', lambda: self.open_find(True))
        self._sc('Ctrl+K', self.insert_hyperlink)
        self._sc('Ctrl+Alt+M', self.add_comment)
        self._sc('F7', self.open_spelling)
        self._sc('Ctrl+Shift+E', lambda: self.btnTrack.setChecked(not self.btnTrack.isChecked()))
        # autosave every minute (only if the document changed)
        self._autosave_path = Path.home() / '.jesson_reader' / 'autosave_document.html'
        self._autosave_timer = QTimer(self)
        self._autosave_timer.setInterval(60000)
        self._autosave_timer.timeout.connect(self._autosave_tick)
        self._autosave_timer.start()
        self._apply_page_setup()

    def _sc(self, keys, fn):
        s = QShortcut(QKeySequence(keys), self)
        s.setContext(Qt.WidgetWithChildrenShortcut)
        s.activated.connect(self._safe(fn))
        return s

    # ---------------------------------------------------------------- helpers
    def _safe(self, fn):
        def run(*_):
            try:
                fn()
            except _Note as note:
                QMessageBox.information(self, 'Document', str(note))
            except Exception as exc:
                traceback.print_exc()
                QMessageBox.warning(self, 'Document', 'That command failed: %s' % exc)
        return run

    def _t(self, label, fn, tip=''):
        return self._tool(label, self._safe(fn), tip)

    def _toggle(self, label, fn, tip=''):
        b = self._tool(label, lambda *a: None, tip or label)
        b.setCheckable(True)
        b.setStyleSheet(b.styleSheet() + 'QPushButton:checked{background:#dbeafe;border:1px solid #93c5fd;}')
        b.toggled.connect(lambda v, f=fn: self._safe(lambda: f(v))())
        return b

    def _menu_btn(self, label, items, tip=''):
        b = QToolButton()
        b.setText(label + ' \u25be'); b.setToolTip(tip or label)
        b.setPopupMode(QToolButton.InstantPopup)
        m = QMenu(b)
        for text, fn in items:
            if text is None:
                m.addSeparator(); continue
            a = m.addAction(text)
            a.triggered.connect(self._safe(fn))
        b.setMenu(m)
        b.setStyleSheet('QToolButton{background:transparent;color:#1f2937;border:1px solid transparent;border-radius:4px;padding:6px 9px;} '
                        'QToolButton:hover{background:#eaf2fb;border-color:#d6e4f0;} QToolButton::menu-indicator{image:none;}')
        return b

    def _set_extra(self, key, sels):
        self._extras[key] = sels
        allsel = []
        for v in self._extras.values():
            allsel.extend(v)
        self.textEdit.setExtraSelections(allsel)

    def _frags(self, start=0, end=None):
        """(start, end, charFormat) for every text fragment overlapping [start, end)."""
        doc = self.textEdit.document()
        out = []
        blk = doc.findBlock(start) if start else doc.begin()
        while blk.isValid():
            if end is not None and blk.position() >= end:
                break
            it = blk.begin()
            while not it.atEnd():
                fr = it.fragment()
                if fr.isValid():
                    a = fr.position(); b = a + fr.length()
                    if b > start and (end is None or a < end):
                        out.append((max(a, start), b if end is None else min(b, end), fr.charFormat()))
                it += 1
            blk = blk.next()
        return out

    def _scan(self, prop):
        res = []
        for a, b, fmt in self._frags():
            if fmt.hasProperty(prop):
                val = fmt.property(prop)
                if res and res[-1][1] == a and res[-1][2] == val:
                    res[-1][1] = b
                else:
                    res.append([a, b, val])
        return res

    def _clear_prop(self, prop, value=None):
        doc = self.textEdit.document()
        c = QTextCursor(doc)
        c.beginEditBlock()
        for a, b, fmt in self._frags():
            if fmt.hasProperty(prop) and (value is None or fmt.property(prop) == value):
                c.setPosition(a); c.setPosition(b, QTextCursor.KeepAnchor)
                f = QTextCharFormat(fmt); f.clearProperty(prop)
                c.setCharFormat(f)
        c.endEditBlock()

    def _scroll_to_cursor(self):
        try:
            r = self.textEdit.cursorRect()
            if self.pageScroll is not None and self.pageScroll.widget() is not None:
                pt = self.textEdit.viewport().mapTo(self.pageScroll.widget(), r.topLeft())
                bar = self.pageScroll.verticalScrollBar()
                if pt.y() < bar.value() + 40 or pt.y() > bar.value() + self.pageScroll.viewport().height() - 80:
                    bar.setValue(max(0, pt.y() - 120))
            else:
                self.textEdit.ensureCursorVisible()
        except Exception:
            pass

    def _plain_fmt(self):
        f = QTextCharFormat(self.textEdit.currentCharFormat())
        if f.isAnchor() or f.anchorHref():
            f.setAnchor(False); f.setAnchorHref(''); f.setAnchorNames([])
            f.clearForeground(); f.setFontUnderline(False)
        for p in (P_INS, P_DEL, P_CMT):
            f.clearProperty(p)
        f.setBackground(QBrush())
        return f

    def _select_range(self, a, b):
        c = QTextCursor(self.textEdit.document())
        c.setPosition(a); c.setPosition(b, QTextCursor.KeepAnchor)
        self.textEdit.setTextCursor(c)
        self._scroll_to_cursor()

    def _cell_str(self, table, r, c):
        cell = table.cellAt(r, c)
        cur = cell.firstCursorPosition()
        cur.setPosition(cell.lastCursorPosition().position(), QTextCursor.KeepAnchor)
        return cur.selectedText().replace('\u2029', '\n').strip()

    def _cur_table(self):
        c = self.textEdit.textCursor()
        t = c.currentTable()
        if t is None:
            raise _Note('Place the cursor inside a table first.')
        return c, t

    # ------------------------------------------------------------ side panel
    def _build_side_panel(self):
        self.sideTabs = QTabWidget()
        self.sideTabs.setMinimumWidth(240); self.sideTabs.setMaximumWidth(380)
        self.navList = QListWidget()
        self.navList.itemClicked.connect(self._nav_clicked)
        self.sideTabs.addTab(self.navList, 'Navigation')
        cm = QWidget(); lv = QVBoxLayout(cm); lv.setContentsMargins(4, 4, 4, 4)
        row = QHBoxLayout()
        for text, fn in (('New', self.add_comment), ('Edit', self.edit_comment),
                         ('Resolve', self.resolve_comment), ('Delete', self.delete_comment)):
            b = QPushButton(text); b.clicked.connect(self._safe(fn)); row.addWidget(b)
        lv.addLayout(row)
        self.cmtList = QListWidget(); self.cmtList.setWordWrap(True)
        self.cmtList.itemClicked.connect(self._cmt_clicked)
        lv.addWidget(self.cmtList)
        self.sideTabs.addTab(cm, 'Comments')
        parent_layout = self.pageScroll.parentWidget().layout() if self.pageScroll is not None else None
        if parent_layout is None:
            return
        idx = parent_layout.indexOf(self.pageScroll)
        parent_layout.removeWidget(self.pageScroll)
        self.splitter = QSplitter(Qt.Horizontal)
        self.splitter.addWidget(self.pageScroll)
        self.splitter.addWidget(self.sideTabs)
        self.splitter.setStretchFactor(0, 1); self.splitter.setStretchFactor(1, 0)
        parent_layout.insertWidget(idx, self.splitter, 1)
        self.sideTabs.hide()

    def _show_panel(self, index, on=True):
        if on:
            self.sideTabs.setCurrentIndex(index)
            self.sideTabs.show()
            self._refresh_nav(); self._refresh_comments()
        else:
            self.sideTabs.hide()

    def toggle_nav(self, on):
        self._show_panel(0, on)

    def toggle_comments_panel(self, on):
        self._show_panel(1, on)

    def _deferred_refresh(self):
        try:
            if self._spell_on:
                self._refresh_spelling()
            self._refresh_comments()
            if self.sideTabs.isVisible():
                self._refresh_nav()
        except Exception:
            traceback.print_exc()

    # ----------------------------------------------------------------- ruler
    def _build_ruler(self):
        self.ruler = RulerWidget(self)
        self.pageFrame.layout().insertWidget(0, self.ruler)
        self.ruler.hide()

    def toggle_ruler(self, on):
        self.ruler.setVisible(on)
        self._sync_document_pages()

    # ------------------------------------------------------------- find/spell
    def open_find(self, replace=False):
        if self._find_dlg is None:
            self._find_dlg = FindReplaceDialog(self)
        sel = self.textEdit.textCursor().selectedText()
        if sel and '\u2029' not in sel:
            self._find_dlg.findEdit.setText(sel)
        self._find_dlg.show(); self._find_dlg.raise_(); self._find_dlg.activateWindow()
        (self._find_dlg.replEdit if replace else self._find_dlg.findEdit).setFocus()

    def _find_text(self):          # the old Review > Find button now opens the full dialog
        self.open_find(False)

    def toggle_spelling(self, on):
        if on and not self.spell.available():
            QMessageBox.information(self, 'Spelling',
                                    'No dictionary was found on this computer.\n\nInstall one with:\n    pip install pyspellchecker\nthen restart the app.')
            self.btnSpell.blockSignals(True); self.btnSpell.setChecked(False); self.btnSpell.blockSignals(False)
            return
        self._spell_on = on
        self._refresh_spelling()

    def _spell_find(self, start):
        text = self.textEdit.document().toPlainText()
        for m in WORD_RE.finditer(text, start):
            w = m.group().strip("'\u2019")
            if len(w) >= 3 and not w.isupper() and not self.spell.known(w):
                return m.start(), m.start() + len(w), w
        return None

    def _refresh_spelling(self):
        if not self._spell_on:
            self._set_extra('spell', []); return
        text = self.textEdit.document().toPlainText()
        doc = self.textEdit.document()
        sels = []; seen = 0
        for m in WORD_RE.finditer(text):
            w = m.group().strip("'\u2019")
            if len(w) < 3 or w.isupper():
                continue
            seen += 1
            if seen > 6000:
                break
            if not self.spell.known(w):
                s = QTextEdit.ExtraSelection()
                c = QTextCursor(doc)
                c.setPosition(m.start()); c.setPosition(m.start() + len(w), QTextCursor.KeepAnchor)
                s.cursor = c
                f = QTextCharFormat()
                f.setUnderlineStyle(QTextCharFormat.WaveUnderline); f.setUnderlineColor(QColor('#dc2626'))
                s.format = f
                sels.append(s)
        self._set_extra('spell', sels)

    def open_spelling(self):
        if not self.spell.available():
            self.toggle_spelling(True); return
        if not self._spell_on:
            self.btnSpell.setChecked(True)
        if self._spell_dlg is None:
            self._spell_dlg = SpellDialog(self)
        self._spell_dlg.show(); self._spell_dlg.raise_()
        self._spell_dlg.start()

    # ---------------------------------------------------------- context menu
    def _ctx_menu(self, pos):
        menu = self.textEdit.createStandardContextMenu()
        acts = menu.actions()
        first = acts[0] if acts else None
        cur = self.textEdit.cursorForPosition(pos)
        extra = []
        if self._spell_on and self.spell.available():
            wc = QTextCursor(cur); wc.select(QTextCursor.WordUnderCursor)
            w = wc.selectedText().strip("'\u2019")
            if w and WORD_RE.fullmatch(w) and len(w) >= 3 and not w.isupper() and not self.spell.known(w):
                sug = self.spell.suggest(w)
                for s in sug:
                    a = QAction(s, menu)
                    a.triggered.connect(lambda _=False, s=s, wc=wc: wc.insertText(s))
                    extra.append(a)
                if not sug:
                    a = QAction('(no suggestions)', menu); a.setEnabled(False); extra.append(a)
                a = QAction('Add to Dictionary', menu)
                a.triggered.connect(lambda _=False, w=w: (self.spell.add_word(w), self._refresh_spelling()))
                extra.append(a)
                a = QAction('Ignore All', menu)
                a.triggered.connect(lambda _=False, w=w: (self.spell.ignore.add(w.lower()), self._refresh_spelling()))
                extra.append(a)
                extra.append(None)
        href = self.textEdit.anchorAt(pos)
        if href:
            self.textEdit.setTextCursor(cur)
            for text, fn in (('Open Link', lambda: self._follow_link(href)),
                             ('Edit Hyperlink\u2026', self.insert_hyperlink),
                             ('Remove Hyperlink', self.remove_hyperlink)):
                a = QAction(text, menu); a.triggered.connect(self._safe(fn)); extra.append(a)
            extra.append(None)
        if self.textEdit.textCursor().hasSelection():
            a = QAction('New Comment', menu); a.triggered.connect(self._safe(self.add_comment)); extra.append(a)
            extra.append(None)
        for a in extra:
            if a is None:
                menu.insertSeparator(first)
            else:
                menu.insertAction(first, a)
        menu.exec_(self.textEdit.viewport().mapToGlobal(pos))

    def eventFilter(self, obj, event):
        try:
            t = event.type()
            if obj is self.textEdit.viewport():
                if t == QEvent.MouseButtonRelease and event.button() == Qt.LeftButton:
                    if event.modifiers() & Qt.ControlModifier:
                        href = self.textEdit.anchorAt(event.pos())
                        if href:
                            self._follow_link(href)
                    elif self._painter_armed:
                        self._apply_painter()
                elif t == QEvent.MouseMove:
                    over = bool(event.modifiers() & Qt.ControlModifier) and bool(self.textEdit.anchorAt(event.pos()))
                    self.textEdit.viewport().setCursor(Qt.PointingHandCursor if over else Qt.IBeamCursor)
            elif obj is self.textEdit and t == QEvent.KeyPress:
                self._last_key = event.key()
                if event.matches(QKeySequence.Undo) or event.matches(QKeySequence.Redo):
                    self._tc_busy = True
                    QTimer.singleShot(0, self._tc_after_undo)
        except Exception:
            pass
        return super().eventFilter(obj, event)

    # ------------------------------------------------------------- hyperlinks
    def _follow_link(self, href):
        if href.startswith('#'):
            self._goto_bookmark(href[1:])
        else:
            QDesktopServices.openUrl(QUrl(href))

    def _link_range(self):
        pos = self.textEdit.textCursor().position()
        frs = self._frags()
        idx = None
        for i, (a, b, fmt) in enumerate(frs):
            if fmt.anchorHref() and a <= pos <= b:
                idx = i; break
        if idx is None:
            return None
        href = frs[idx][2].anchorHref()
        lo = idx; hi = idx
        while lo > 0 and frs[lo - 1][2].anchorHref() == href and frs[lo - 1][1] == frs[lo][0]:
            lo -= 1
        while hi < len(frs) - 1 and frs[hi + 1][2].anchorHref() == href and frs[hi + 1][0] == frs[hi][1]:
            hi += 1
        return frs[lo][0], frs[hi][1], href

    @staticmethod
    def _strip_link(fmt):
        if fmt.isAnchor() or fmt.anchorHref():
            fmt.setAnchor(False); fmt.setAnchorHref(''); fmt.setAnchorNames([])
            fmt.clearForeground(); fmt.setFontUnderline(False)

    def _insert_link(self, label, href):
        c = self.textEdit.textCursor()
        base = QTextCharFormat(c.charFormat()); self._strip_link(base)
        fmt = QTextCharFormat(base)
        fmt.setAnchor(True); fmt.setAnchorHref(href)
        fmt.setForeground(QColor('#0563c1')); fmt.setFontUnderline(True)
        c.insertText(label, fmt)
        self.textEdit.setTextCursor(c)
        self.textEdit.setCurrentCharFormat(base)

    def insert_hyperlink(self):
        c = self.textEdit.textCursor()
        cur_href = ''
        if not c.hasSelection():
            rng = self._link_range()
            if rng:
                self._select_range(rng[0], rng[1]); cur_href = rng[2]
                c = self.textEdit.textCursor()
        sel = c.selectedText().replace('\u2029', ' ')
        d = QDialog(self); d.setWindowTitle('Insert Hyperlink'); f = QFormLayout(d)
        txt = QLineEdit(sel); url = QLineEdit(cur_href or 'https://')
        bm = QComboBox(); bm.addItem('(none)'); bm.addItems(self._bookmark_names())
        f.addRow('Text to display:', txt); f.addRow('Address:', url); f.addRow('Or bookmark in this document:', bm)
        box = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        box.accepted.connect(d.accept); box.rejected.connect(d.reject); f.addRow(box)
        if d.exec_() != QDialog.Accepted:
            return
        href = url.text().strip()
        if bm.currentIndex() > 0:
            href = '#' + bm.currentText()
        if not href or href in ('https://', 'http://'):
            return
        if not href.startswith('#') and '://' not in href and not href.lower().startswith('mailto:'):
            href = ('mailto:' + href) if re.fullmatch(r'[^@\s]+@[^@\s]+\.[^@\s]+', href) else 'https://' + href
        self._insert_link(txt.text() or href, href)

    def remove_hyperlink(self):
        c = self.textEdit.textCursor()
        if c.hasSelection():
            a, b = c.selectionStart(), c.selectionEnd()
        else:
            rng = self._link_range()
            if not rng:
                raise _Note('Place the cursor inside a hyperlink first.')
            a, b = rng[0], rng[1]
        edit = QTextCursor(self.textEdit.document())
        edit.beginEditBlock()
        for fa, fb, fmt in self._frags(a, b):
            if fmt.isAnchor() or fmt.anchorHref():
                edit.setPosition(fa); edit.setPosition(fb, QTextCursor.KeepAnchor)
                nf = QTextCharFormat(fmt); self._strip_link(nf)
                edit.setCharFormat(nf)
        edit.endEditBlock()

    # -------------------------------------------------------------- bookmarks
    def _bookmark_names(self):
        names = []
        for a, b, fmt in self._frags():
            for n in fmt.anchorNames():
                if n and n not in names:
                    names.append(n)
        return names

    def _bookmark_range(self, name):
        frs = [(a, b) for a, b, fmt in self._frags() if name in fmt.anchorNames()]
        if not frs:
            return None
        lo, hi = frs[0]
        for a, b in frs[1:]:
            if a == hi:
                hi = b
            else:
                break
        return lo, hi

    def insert_bookmark(self):
        c = self.textEdit.textCursor()
        if not c.hasSelection():
            c.select(QTextCursor.WordUnderCursor)
        if not c.hasSelection():
            raise _Note('Select some text (or put the cursor in a word) to bookmark.')
        name, ok = QInputDialog.getText(self, 'Bookmark', 'Bookmark name (letters, digits, underscore):')
        if not ok:
            return
        name = name.strip()
        if not re.fullmatch(r'[A-Za-z_][A-Za-z0-9_]*', name):
            raise _Note('Bookmark names must start with a letter and use only letters, digits and underscores.')
        existing = list(c.charFormat().anchorNames())
        fmt = QTextCharFormat(); fmt.setAnchor(True)
        fmt.setAnchorNames(existing + [name] if name not in existing else existing)
        c.mergeCharFormat(fmt)

    def _goto_bookmark(self, name):
        rng = self._bookmark_range(name)
        if not rng:
            raise _Note('Bookmark "%s" was not found.' % name)
        c = QTextCursor(self.textEdit.document()); c.setPosition(rng[0])
        self.textEdit.setTextCursor(c); self._scroll_to_cursor()

    def goto_bookmark(self):
        names = self._bookmark_names()
        if not names:
            raise _Note('This document has no bookmarks yet.')
        name, ok = QInputDialog.getItem(self, 'Go To Bookmark', 'Bookmark:', names, 0, False)
        if ok:
            self._goto_bookmark(name)

    def insert_cross_reference(self):
        names = self._bookmark_names()
        if not names:
            raise _Note('Add a bookmark first (References > Bookmark).')
        name, ok = QInputDialog.getItem(self, 'Cross-reference', 'Link to bookmark:', names, 0, False)
        if not ok:
            return
        rng = self._bookmark_range(name)
        label = name
        if rng:
            cc = QTextCursor(self.textEdit.document()); cc.setPosition(rng[0]); cc.setPosition(rng[1], QTextCursor.KeepAnchor)
            label = cc.selectedText().replace('\u2029', ' ') or name
        self._insert_link(label, '#' + name)

    # --------------------------------------------------------------- comments
    def _cmt_at_cursor(self):
        v = self.textEdit.textCursor().charFormat().property(P_CMT)
        return v if isinstance(v, int) else None

    def _selected_cmt(self):
        it = self.cmtList.currentItem()
        if it is not None:
            return it.data(Qt.UserRole)
        return self._cmt_at_cursor()

    def add_comment(self):
        c = self.textEdit.textCursor()
        if not c.hasSelection():
            c.select(QTextCursor.WordUnderCursor)
        if not c.hasSelection():
            raise _Note('Select the text you want to comment on.')
        text, ok = QInputDialog.getMultiLineText(self, 'New Comment', 'Comment:')
        if not ok or not text.strip():
            return
        cid = self._next_cmt; self._next_cmt += 1
        self.comments[cid] = {'author': self.doc_author, 'text': text.strip(),
                              'time': datetime.datetime.now(), 'resolved': False}
        fmt = QTextCharFormat(); fmt.setProperty(P_CMT, cid)
        c.mergeCharFormat(fmt)
        self._show_panel(1, True)

    def edit_comment(self):
        cid = self._selected_cmt()
        if cid not in self.comments:
            raise _Note('Select a comment first.')
        text, ok = QInputDialog.getMultiLineText(self, 'Edit Comment', 'Comment:', self.comments[cid]['text'])
        if ok and text.strip():
            self.comments[cid]['text'] = text.strip(); self._refresh_comments()

    def resolve_comment(self):
        cid = self._selected_cmt()
        if cid not in self.comments:
            raise _Note('Select a comment first.')
        self.comments[cid]['resolved'] = not self.comments[cid]['resolved']; self._refresh_comments()

    def delete_comment(self):
        cid = self._selected_cmt()
        if cid not in self.comments:
            raise _Note('Select a comment first.')
        self._clear_prop(P_CMT, cid)
        self.comments.pop(cid, None)
        self._refresh_comments()

    def _refresh_comments(self):
        ranges = {}
        for a, b, cid in self._scan(P_CMT):
            ranges.setdefault(cid, []).append((a, b))
        for cid in list(self.comments):
            if cid not in ranges:
                self.comments.pop(cid)          # its text was deleted
        doc = self.textEdit.document()
        sels = []
        for cid, rs in ranges.items():
            info = self.comments.get(cid)
            if info is None:
                continue
            for a, b in rs:
                s = QTextEdit.ExtraSelection()
                c = QTextCursor(doc); c.setPosition(a); c.setPosition(b, QTextCursor.KeepAnchor)
                s.cursor = c
                f = QTextCharFormat(); f.setBackground(QColor('#e5e7eb' if info['resolved'] else '#fff2a8'))
                s.format = f
                sels.append(s)
        self._set_extra('comments', sels)
        if self.sideTabs.isVisible():
            keep = self._selected_cmt() if self.cmtList.currentItem() else None
            self.cmtList.clear()
            for cid in sorted(ranges, key=lambda k: ranges[k][0][0]):
                info = self.comments.get(cid)
                if info is None:
                    continue
                a, b = ranges[cid][0]
                cc = QTextCursor(doc); cc.setPosition(a); cc.setPosition(min(b, a + 60), QTextCursor.KeepAnchor)
                snippet = cc.selectedText().replace('\u2029', ' ')
                head = '%s \u00b7 %s%s' % (info['author'], info['time'].strftime('%b %d %H:%M'), '  \u2713 resolved' if info['resolved'] else '')
                it = QListWidgetItem('%s\n\u201c%s\u201d\n%s' % (head, snippet, info['text']))
                it.setData(Qt.UserRole, cid)
                self.cmtList.addItem(it)
                if cid == keep:
                    self.cmtList.setCurrentItem(it)

    def _cmt_clicked(self, item):
        cid = item.data(Qt.UserRole)
        for a, b, v in self._scan(P_CMT):
            if v == cid:
                self._select_range(a, b); break

    def _refresh_nav(self):
        self.navList.clear()
        for lvl, txt, pos in self._headings():
            it = QListWidgetItem('    ' * (lvl - 1) + txt)
            it.setData(Qt.UserRole, pos)
            self.navList.addItem(it)

    def _nav_clicked(self, item):
        c = QTextCursor(self.textEdit.document()); c.setPosition(item.data(Qt.UserRole))
        self.textEdit.setTextCursor(c); self._scroll_to_cursor()

    # ---------------------------------------------------------- track changes
    def toggle_tracking(self, on):
        self._tracking = on
        if on:
            self._snapshot()

    def _snapshot(self):
        doc = self.textEdit.document()
        self._tc_text = doc.toPlainText()
        flags = ['0'] * len(self._tc_text)
        for a, b, fmt in self._frags():
            if fmt.hasProperty(P_INS):
                ch = 'i'
            elif fmt.hasProperty(P_DEL):
                ch = 'd'
            else:
                continue
            for k in range(a, min(b, len(flags))):
                flags[k] = ch
        self._tc_flags = flags
        self._refresh_track_marks()

    def _tc_after_undo(self):
        self._tc_busy = False
        if self._tracking:
            self._snapshot()

    def _on_contents_change(self, pos, rem, add):
        if not self._tracking or self._tc_busy or self._tc_text is None:
            return
        doc = self.textEdit.document()
        new = doc.toPlainText()
        old = self._tc_text
        if rem == add and old[pos:pos + rem] == new[pos:pos + add]:
            self._snapshot(); return                       # formatting-only change
        removed = old[pos:pos + rem]
        rflags = self._tc_flags[pos:pos + rem]
        self._tc_busy = True
        keep = ''
        try:
            c = QTextCursor(doc)
            c.joinPreviousEditBlock()
            if add > 0:
                c.setPosition(pos); c.setPosition(pos + add, QTextCursor.KeepAnchor)
                f = QTextCharFormat(); f.setProperty(P_INS, True)
                c.mergeCharFormat(f)
            keep = ''.join(ch for ch, fl in zip(removed, rflags) if fl != 'i' and ch != '\ufffc')
            if keep:
                c.setPosition(pos)
                df = QTextCharFormat(c.charFormat())
                df.clearProperty(P_INS); df.clearProperty(P_CMT); df.setProperty(P_DEL, True)
                c.insertText(keep, df)
            c.endEditBlock()
            tc = self.textEdit.textCursor()
            if add > 0:
                tc.setPosition(pos + len(keep) + add)
            elif self._last_key == Qt.Key_Delete:
                tc.setPosition(pos + len(keep))
            else:
                tc.setPosition(pos)
            self.textEdit.setTextCursor(tc)
        finally:
            self._tc_busy = False
        self._snapshot()

    def _refresh_track_marks(self):
        doc = self.textEdit.document()
        sels = []
        for a, b, fmt in self._frags():
            kind = 'i' if fmt.hasProperty(P_INS) else ('d' if fmt.hasProperty(P_DEL) else None)
            if kind is None:
                continue
            s = QTextEdit.ExtraSelection()
            c = QTextCursor(doc); c.setPosition(a); c.setPosition(b, QTextCursor.KeepAnchor)
            s.cursor = c
            f = QTextCharFormat()
            if kind == 'i':
                f.setForeground(QColor('#1d4ed8')); f.setFontUnderline(True)
            else:
                f.setForeground(QColor('#dc2626')); f.setFontStrikeOut(True)
            s.format = f
            sels.append(s)
        if sels or self._extras.get('track'):
            self._set_extra('track', sels)

    def _delete_marked(self, prop):
        doc = self.textEdit.document()
        c = QTextCursor(doc)
        c.beginEditBlock()
        for a, b, _ in reversed(self._scan(prop)):
            c.setPosition(a); c.setPosition(b, QTextCursor.KeepAnchor); c.removeSelectedText()
        c.endEditBlock()

    def accept_all_changes(self):
        self._tc_busy = True
        try:
            self._delete_marked(P_DEL)
            self._clear_prop(P_INS)
        finally:
            self._tc_busy = False
        self._snapshot() if self._tracking else self._refresh_track_marks()

    def reject_all_changes(self):
        self._tc_busy = True
        try:
            self._delete_marked(P_INS)
            self._clear_prop(P_DEL)
        finally:
            self._tc_busy = False
        self._snapshot() if self._tracking else self._refresh_track_marks()

    def next_change(self):
        pos = self.textEdit.textCursor().selectionEnd()
        marks = sorted([(a, b) for a, b, _ in self._scan(P_INS)] + [(a, b) for a, b, _ in self._scan(P_DEL)])
        if not marks:
            raise _Note('There are no tracked changes in this document.')
        nxt = next((m for m in marks if m[0] >= pos), marks[0])
        self._select_range(nxt[0], nxt[1])

    # ----------------------------------------------------------- Home extras
    def _selected_or_word(self):
        c = self.textEdit.textCursor()
        if not c.hasSelection():
            c.select(QTextCursor.WordUnderCursor)
        return c

    def toggle_strike(self):
        f = QTextCharFormat(); f.setFontStrikeOut(not self.textEdit.currentCharFormat().fontStrikeOut())
        self.merge_char_format(f)

    def set_script(self, kind):
        cur = self.textEdit.currentCharFormat().verticalAlignment()
        want = QTextCharFormat.AlignSuperScript if kind == 'sup' else QTextCharFormat.AlignSubScript
        f = QTextCharFormat()
        f.setVerticalAlignment(QTextCharFormat.AlignNormal if cur == want else want)
        self.merge_char_format(f)

    def grow_font(self, delta):
        size = self.textEdit.currentCharFormat().fontPointSize() or 12
        self.set_font_size(int(max(6, min(96, round(size + delta)))))

    def set_case(self, mode):
        c = self._selected_or_word()
        if not c.hasSelection():
            raise _Note('Select some text first.')
        old = c.selectedText().replace('\u2029', '\n')
        if mode == 'upper':
            new = old.upper()
        elif mode == 'lower':
            new = old.lower()
        elif mode == 'title':
            new = re.sub(r"[A-Za-z]+('[A-Za-z]+)?", lambda m: m.group(0).capitalize(), old)
        elif mode == 'sentence':
            low = old.lower()
            new = re.sub(r'(^|[.!?]\s+)([a-z])', lambda m: m.group(1) + m.group(2).upper(), low)
        else:
            new = old.swapcase()
        if len(new) != len(old):
            c.insertText(new); return
        s = c.selectionStart()
        edit = QTextCursor(self.textEdit.document())
        edit.beginEditBlock()
        for a, b, fmt in reversed(self._frags(s, c.selectionEnd())):
            edit.setPosition(a); edit.setPosition(b, QTextCursor.KeepAnchor)
            edit.insertText(new[a - s:b - s], fmt)
        edit.endEditBlock()

    def set_align(self, which):
        al = {'left': Qt.AlignLeft, 'center': Qt.AlignHCenter, 'right': Qt.AlignRight, 'justify': Qt.AlignJustify}[which]
        self.textEdit.setAlignment(al)

    def shade_paragraph(self):
        col = QColorDialog.getColor(QColor('#fff2a8'), self, 'Paragraph shading')
        if not col.isValid():
            return
        c = self.textEdit.textCursor(); doc = self.textEdit.document()
        blk = doc.findBlock(c.selectionStart()); last = doc.findBlock(c.selectionEnd())
        edit = QTextCursor(doc); edit.beginEditBlock()
        while blk.isValid():
            bc = QTextCursor(blk); bf = bc.blockFormat(); bf.setBackground(QBrush(col)); bc.setBlockFormat(bf)
            if blk.blockNumber() >= last.blockNumber():
                break
            blk = blk.next()
        edit.endEditBlock()

    def clear_shading(self):
        c = self.textEdit.textCursor(); doc = self.textEdit.document()
        blk = doc.findBlock(c.selectionStart()); last = doc.findBlock(c.selectionEnd())
        edit = QTextCursor(doc); edit.beginEditBlock()
        while blk.isValid():
            bc = QTextCursor(blk); bf = bc.blockFormat(); bf.setBackground(QBrush()); bc.setBlockFormat(bf)
            if blk.blockNumber() >= last.blockNumber():
                break
            blk = blk.next()
        edit.endEditBlock()

    def paragraph_spacing(self):
        c = self.textEdit.textCursor(); bf = c.blockFormat()
        d = QDialog(self); d.setWindowTitle('Paragraph Spacing'); f = QFormLayout(d)
        before = QSpinBox(); before.setRange(0, 200); before.setValue(int(bf.topMargin()))
        after = QSpinBox(); after.setRange(0, 200); after.setValue(int(bf.bottomMargin()))
        f.addRow('Before (px):', before); f.addRow('After (px):', after)
        box = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        box.accepted.connect(d.accept); box.rejected.connect(d.reject); f.addRow(box)
        if d.exec_() != QDialog.Accepted:
            return
        doc = self.textEdit.document()
        blk = doc.findBlock(c.selectionStart()); last = doc.findBlock(c.selectionEnd())
        edit = QTextCursor(doc); edit.beginEditBlock()
        while blk.isValid():
            bc = QTextCursor(blk); b2 = bc.blockFormat()
            b2.setTopMargin(before.value()); b2.setBottomMargin(after.value()); bc.setBlockFormat(b2)
            if blk.blockNumber() >= last.blockNumber():
                break
            blk = blk.next()
        edit.endEditBlock()

    def sort_paragraphs(self):
        c = self.textEdit.textCursor()
        if not c.hasSelection():
            raise _Note('Select the paragraphs you want to sort.')
        doc = self.textEdit.document()
        a = doc.findBlock(c.selectionStart()); b = doc.findBlock(c.selectionEnd())
        lines = []
        blk = a
        while blk.isValid():
            lines.append(blk.text())
            if blk.blockNumber() >= b.blockNumber():
                break
            blk = blk.next()
        order, ok = QInputDialog.getItem(self, 'Sort', 'Order:', ['A to Z', 'Z to A'], 0, False)
        if not ok:
            return
        lines.sort(key=lambda s: s.lower(), reverse=(order == 'Z to A'))
        edit = QTextCursor(doc)
        edit.setPosition(a.position())
        edit.setPosition(b.position() + b.length() - 1, QTextCursor.KeepAnchor)
        edit.insertText('\n'.join(lines))

    def toggle_marks(self, on):
        doc = self.textEdit.document()
        opt = doc.defaultTextOption()
        flags = QTextOption.ShowTabsAndSpaces | QTextOption.ShowLineAndParagraphSeparators
        opt.setFlags(opt.flags() | flags) if on else opt.setFlags(opt.flags() & ~flags)
        doc.setDefaultTextOption(opt)

    def toggle_painter(self, on):
        if on:
            c = self.textEdit.textCursor()
            self._painter = (QTextCharFormat(c.charFormat()), QTextBlockFormat(c.blockFormat()))
            self._painter_armed = True
            self.textEdit.viewport().setCursor(Qt.CrossCursor)
        else:
            self._painter_armed = False
            self.textEdit.viewport().setCursor(Qt.IBeamCursor)

    def _apply_painter(self):
        c = self.textEdit.textCursor()
        if self._painter and c.hasSelection():
            cf, bf = self._painter
            f = QTextCharFormat(cf)
            for p in (P_INS, P_DEL, P_CMT):
                f.clearProperty(p)
            c.mergeCharFormat(f)
            c.mergeBlockFormat(bf)
            self._painter_armed = False
            self.btnPainter.blockSignals(True); self.btnPainter.setChecked(False); self.btnPainter.blockSignals(False)
            self.textEdit.viewport().setCursor(Qt.IBeamCursor)

    # ----------------------------------------------------------- Insert extras
    def insert_symbol(self):
        syms = ('\u00a9 \u00ae \u2122 \u00b0 \u00b1 \u00d7 \u00f7 \u2260 \u2264 \u2265 \u2248 \u221e \u221a \u2211 \u220f \u222b \u2202 \u2206 \u03c0 '
                '\u03b1 \u03b2 \u03b3 \u03b4 \u03b5 \u03b8 \u03bb \u03bc \u03c3 \u03c6 \u03c9 \u03a9 \u2190 \u2191 \u2192 \u2193 \u2194 \u21d2 \u21d4 '
                '\u2022 \u25e6 \u25aa \u25cf \u2605 \u2606 \u2713 \u2717 \u2020 \u2021 \u00a7 \u00b6 \u2026 \u2013 \u2014 \u00ab \u00bb \u201c \u201d '
                '\u00bd \u00bc \u00be \u00b2 \u00b3 \u20ac \u00a3 \u00a5 \u00a2 \u2030 \u00b5').split()
        d = QDialog(self); d.setWindowTitle('Symbol'); g = QGridLayout(d)
        for i, s in enumerate(syms):
            b = QPushButton(s); b.setFixedSize(38, 34)
            b.clicked.connect(lambda _=False, s=s: self._put_symbol(s))
            g.addWidget(b, i // 10, i % 10)
        close = QPushButton('Close'); close.clicked.connect(d.accept)
        g.addWidget(close, (len(syms) // 10) + 1, 0, 1, 10)
        d.exec_()

    def _put_symbol(self, s):
        c = self.textEdit.textCursor()
        c.insertText(s, QTextCharFormat(c.charFormat()))
        self.textEdit.setTextCursor(c)

    def insert_equation(self):
        items = ['x^2 + y^2 = z^2', 'E = mc^2', 'x = (-b \u00b1 \u221a(b^2 - 4ac)) / (2a)', 'a_n = a_1 + (n-1)d',
                 'H_2O', 'CO_2', '\u03a3_{i=1}^{n} i = n(n+1)/2', '\u222b_{a}^{b} f(x) dx']
        txt, ok = QInputDialog.getItem(self, 'Equation',
                                       'Pick a template or type your own.\nUse ^ for superscript and _ for subscript (braces for groups):',
                                       items, 0, True)
        if not ok or not txt.strip():
            return
        runs = []; buf = ''; i = 0
        while i < len(txt):
            ch = txt[i]
            if ch in '^_' and i + 1 < len(txt):
                if buf:
                    runs.append((buf, 'n')); buf = ''
                if txt[i + 1] == '{':
                    j = txt.find('}', i + 2)
                    j = len(txt) if j < 0 else j
                    seg = txt[i + 2:j]; i = j + 1
                else:
                    seg = txt[i + 1]; i += 2
                runs.append((seg, 'sup' if ch == '^' else 'sub'))
            else:
                buf += ch; i += 1
        if buf:
            runs.append((buf, 'n'))
        c = self.textEdit.textCursor()
        base = QTextCharFormat(c.charFormat()); base.setFontItalic(True)
        c.beginEditBlock()
        for seg, kind in runs:
            f = QTextCharFormat(base)
            f.setVerticalAlignment({'n': QTextCharFormat.AlignNormal, 'sup': QTextCharFormat.AlignSuperScript,
                                    'sub': QTextCharFormat.AlignSubScript}[kind])
            c.insertText(seg, f)
        c.endEditBlock()
        self.textEdit.setTextCursor(c)
        self.textEdit.setCurrentCharFormat(self._plain_fmt())

    def insert_shape(self, kind):
        col = QColorDialog.getColor(QColor('#4472c4'), self, 'Shape color')
        if not col.isValid():
            return
        W, H = 180, 120
        img = QImage(W, H, QImage.Format_ARGB32); img.fill(Qt.transparent)
        p = QPainter(img); p.setRenderHint(QPainter.Antialiasing, True)
        p.setBrush(col); p.setPen(QPen(col.darker(140), 2))
        r = QRectF(6, 6, W - 12, H - 12)
        if kind == 'Rectangle':
            p.drawRect(r)
        elif kind == 'Rounded Rectangle':
            p.drawRoundedRect(r, 18, 18)
        elif kind == 'Ellipse':
            p.drawEllipse(r)
        elif kind == 'Triangle':
            p.drawPolygon(QPolygonF([QPointF(W / 2, 6), QPointF(W - 6, H - 6), QPointF(6, H - 6)]))
        elif kind == 'Right Arrow':
            p.drawPolygon(QPolygonF([QPointF(6, 38), QPointF(W - 62, 38), QPointF(W - 62, 8), QPointF(W - 6, H / 2),
                                     QPointF(W - 62, H - 8), QPointF(W - 62, H - 38), QPointF(6, H - 38)]))
        else:   # Star
            pts = []
            for k in range(10):
                ang = -math.pi / 2 + k * math.pi / 5
                rad = (H / 2 - 6) if k % 2 == 0 else (H / 4.2)
                pts.append(QPointF(W / 2 + rad * math.cos(ang), H / 2 + rad * math.sin(ang)))
            p.drawPolygon(QPolygonF(pts))
        p.end()
        c = self.textEdit.textCursor()
        c.insertImage(img, 'shape_%d' % int(time.time() * 1000))

    def insert_textbox(self):
        c = self.textEdit.textCursor()
        t = c.insertTable(1, 1)
        tf = t.format(); tf.setBorder(1); tf.setCellPadding(10)
        tf.setWidth(QTextLength(QTextLength.PercentageLength, 55)); tf.setAlignment(Qt.AlignHCenter)
        t.setFormat(tf)

    def insert_columns(self, n):
        c = self.textEdit.textCursor()
        t = c.insertTable(1, n)
        tf = t.format(); tf.setBorder(0); tf.setCellPadding(10)
        tf.setWidth(QTextLength(QTextLength.PercentageLength, 100))
        t.setFormat(tf)

    def insert_cover_page(self):
        title, ok = QInputDialog.getText(self, 'Cover Page', 'Title:')
        if not ok:
            return
        sub, _ = QInputDialog.getText(self, 'Cover Page', 'Subtitle (optional):')
        author, _ = QInputDialog.getText(self, 'Cover Page', 'Author:', text=self.doc_author)
        doc = self.textEdit.document()
        self._tc_busy = True
        try:
            c = QTextCursor(doc); c.movePosition(QTextCursor.Start); c.beginEditBlock()
            lines = [(title, 36, True, '#1f4e79', 180), (sub, 18, False, '#5b6573', 8),
                     (author, 14, False, '#374151', 60), (datetime.date.today().strftime('%B %d, %Y'), 12, False, '#6b7280', 6)]
            for text, size, bold, color, top in lines:
                if not text:
                    continue
                bf = QTextBlockFormat(); bf.setAlignment(Qt.AlignHCenter); bf.setTopMargin(top)
                cf = QTextCharFormat(); cf.setFontPointSize(size); cf.setFontWeight(QFont.Bold if bold else QFont.Normal)
                cf.setForeground(QColor(color))
                c.setBlockFormat(bf); c.insertText(text, cf); c.insertBlock(QTextBlockFormat(), QTextCharFormat())
            nb = QTextBlockFormat(c.blockFormat()); nb.setPageBreakPolicy(QTextFormat.PageBreak_AlwaysBefore)
            c.setBlockFormat(nb)
            c.endEditBlock()
        finally:
            self._tc_busy = False
        if self._tracking:
            self._snapshot()
        self._sync_document_pages()

    def set_page_number(self, where):
        text = 'Page {page} of {pages}'
        for attr in ('header_text', 'footer_text'):
            v = getattr(self, attr)
            for tok in ('Page {page} of {pages}', 'Page {page}', '{page}'):
                v = v.replace(tok, '')
            setattr(self, attr, v.strip())
        if where != 'remove':
            pos, al = where
            if pos == 'bottom':
                self.footer_text = text; self.footer_align = al
            else:
                self.header_text = text; self.header_align = al
        self._push_overlay_alignment()
        self._sync_document_pages()

    def _push_overlay_alignment(self):
        self.pageOverlay.header_align = self.header_align
        self.pageOverlay.footer_align = self.footer_align
        self.pageOverlay.update()

    def edit_header_footer(self):
        d = QDialog(self); d.setWindowTitle('Header and Footer'); f = QFormLayout(d)
        h = QLineEdit(self.header_text); ft = QLineEdit(self.footer_text)
        names = [('Left', Qt.AlignLeft), ('Center', Qt.AlignHCenter), ('Right', Qt.AlignRight)]
        ha = QComboBox(); fa = QComboBox()
        for n, _ in names:
            ha.addItem(n); fa.addItem(n)
        ha.setCurrentIndex([v for _, v in names].index(self.header_align) if self.header_align in [v for _, v in names] else 0)
        fa.setCurrentIndex([v for _, v in names].index(self.footer_align) if self.footer_align in [v for _, v in names] else 0)
        f.addRow('Header:', h); f.addRow('Header alignment:', ha); f.addRow('Footer:', ft); f.addRow('Footer alignment:', fa)
        f.addRow(QLabel('Tip: type {page} for the page number and {pages} for the total.'))
        box = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        box.accepted.connect(d.accept); box.rejected.connect(d.reject); f.addRow(box)
        if d.exec_() == QDialog.Accepted:
            self.header_text = h.text(); self.footer_text = ft.text()
            self.header_align = names[ha.currentIndex()][1]; self.footer_align = names[fa.currentIndex()][1]
            self._push_overlay_alignment()
        self._sync_document_pages()

    # ------------------------------------------------------------ page layout
    def _apply_page_setup(self):
        w, h = PAPER_PX.get(self._paper, PAPER_PX['A4'])
        if self._orient == 'Landscape':
            w, h = h, w
        t, l, b, r = self._margins_px
        self.BASE_FRAME_W = int(w); self.BASE_PAGE_H = int(h)
        self.BASE_CONTENT_W = int(w - l - r); self.BASE_CONTENT_H = int(h - t - b - 7)
        self.pageFrame.layout().setContentsMargins(int(l), int(t), int(r), int(b))
        self._last_page_layout = None
        self._sync_document_pages()

    def set_paper(self, name):
        self._paper = name; self._apply_page_setup()

    def set_orientation(self, name):
        self._orient = name; self._apply_page_setup()

    def set_margin_preset(self, name):
        t, l, b, r = MARGIN_PRESETS[name]
        self._margins_px = (t * CM, l * CM, b * CM, r * CM); self._apply_page_setup()

    def page_setup_dialog(self):
        d = QDialog(self); d.setWindowTitle('Page Setup'); f = QFormLayout(d)
        paper = QComboBox(); paper.addItems(list(PAPER_PX)); paper.setCurrentText(self._paper)
        orient = QComboBox(); orient.addItems(['Portrait', 'Landscape']); orient.setCurrentText(self._orient)
        spins = []
        for label, val in zip(('Top (cm):', 'Left (cm):', 'Bottom (cm):', 'Right (cm):'), self._margins_px):
            s = QDoubleSpinBox(); s.setRange(0.0, 10.0); s.setDecimals(2); s.setSingleStep(0.25); s.setValue(round(val / CM, 2))
            spins.append(s); f.addRow(label, s)
        f.insertRow(0, 'Paper size:', paper); f.insertRow(1, 'Orientation:', orient)
        box = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        box.accepted.connect(d.accept); box.rejected.connect(d.reject); f.addRow(box)
        if d.exec_() != QDialog.Accepted:
            return
        self._paper = paper.currentText(); self._orient = orient.currentText()
        self._margins_px = tuple(s.value() * CM for s in spins)
        self._apply_page_setup()

    def set_watermark(self):
        items = ['CONFIDENTIAL', 'DRAFT', 'DO NOT COPY', 'SAMPLE', '(remove watermark)']
        txt, ok = QInputDialog.getItem(self, 'Watermark', 'Choose or type watermark text:', items, 0, True)
        if not ok:
            return
        self.pageOverlay.watermark = '' if txt.startswith('(remove') else txt.strip()
        self.pageOverlay.update()

    def _configure_printer(self, printer):
        try:
            printer.setPageSize(PAPER_Q.get(self._paper, QPrinter.A4))
            printer.setOrientation(QPrinter.Landscape if self._orient == 'Landscape' else QPrinter.Portrait)
            t, l, b, r = [v * 25.4 / 96.0 for v in self._margins_px]
            printer.setPageMargins(l, t, r, b, QPrinter.Millimeter)
        except Exception:
            pass

    def print_document(self):
        printer = QPrinter(QPrinter.HighResolution); self._configure_printer(printer)
        if QPrintDialog(printer, self).exec_() == QDialog.Accepted:
            self.textEdit.document().print_(printer)

    def print_preview(self):
        printer = QPrinter(QPrinter.HighResolution); self._configure_printer(printer)
        pv = QPrintPreviewDialog(printer, self)
        pv.paintRequested.connect(lambda p: self.textEdit.document().print_(p))
        pv.exec_()

    def _export_pdf_direct(self):
        path, _ = QFileDialog.getSaveFileName(self, 'Export PDF', '', 'PDF (*.pdf)')
        if not path:
            return
        if not path.lower().endswith('.pdf'):
            path += '.pdf'
        try:
            printer = QPrinter(QPrinter.HighResolution); self._configure_printer(printer)
            printer.setOutputFormat(QPrinter.PdfFormat); printer.setOutputFileName(path)
            self.textEdit.document().print_(printer)
            QMessageBox.information(self, 'Export PDF', 'PDF exported successfully.')
        except Exception as exc:
            QMessageBox.warning(self, 'Export PDF', str(exc))

    # ------------------------------------------------ headings, TOC, citations
    def _headings(self):
        res = []
        blk = self.textEdit.document().begin()
        while blk.isValid():
            txt = blk.text().strip()
            if txt and not blk.blockFormat().hasProperty(P_TOC):
                lvl = None
                it = blk.begin()
                while not it.atEnd():
                    fr = it.fragment()
                    if fr.isValid():
                        fmt = fr.charFormat()
                        if fmt.fontWeight() >= QFont.Bold:
                            lvl = HEADING_SIZES.get(int(round(fmt.fontPointSize())))
                        break
                    it += 1
                if lvl:
                    res.append((lvl, txt, blk.position()))
            blk = blk.next()
        return res

    def _page_of(self, pos):
        doc = self.textEdit.document()
        ph = doc.pageSize().height()
        if ph <= 0:
            return 1
        y = doc.documentLayout().blockBoundingRect(doc.findBlock(pos)).top()
        return int(y // ph) + 1

    def _toc_blocks(self):
        out = []
        blk = self.textEdit.document().begin()
        while blk.isValid():
            if blk.blockFormat().hasProperty(P_TOC):
                out.append(blk)
            blk = blk.next()
        return out

    def _toc_remove(self):
        """Removes an existing TOC; returns the position where it used to start, or None."""
        blocks = self._toc_blocks()
        if not blocks:
            return None
        doc = self.textEdit.document()
        first, last = blocks[0], blocks[-1]
        c = QTextCursor(doc)
        c.setPosition(first.position())
        c.setPosition(last.position() + last.length() - 1, QTextCursor.KeepAnchor)
        c.removeSelectedText()
        c.setBlockFormat(QTextBlockFormat())
        return c.position()

    def _toc_insert_at(self, pos, heads):
        doc = self.textEdit.document()
        c = QTextCursor(doc); c.setPosition(pos)
        tabpos = max(100.0, doc.pageSize().width() - 12)
        entries = [('Table of Contents', 0, 0)] + [(t, l, self._page_of(p)) for l, t, p in heads]
        c.beginEditBlock()
        for text, lvl, page in entries:
            bf = QTextBlockFormat(); bf.setProperty(P_TOC, True)
            cf = QTextCharFormat()
            if lvl == 0:
                cf.setFontPointSize(16); cf.setFontWeight(QFont.Bold); bf.setBottomMargin(6)
            else:
                cf.setFontPointSize(11)
                bf.setLeftMargin((lvl - 1) * 18)
                bf.setTabPositions([QTextOption.Tab(float(tabpos - (lvl - 1) * 18), QTextOption.RightTab)])
            c.setBlockFormat(bf)
            c.insertText(text if lvl == 0 else '%s\t%d' % (text, page), cf)
            c.insertBlock()
        c.setBlockFormat(QTextBlockFormat())
        c.setCharFormat(QTextCharFormat())
        c.endEditBlock()

    def insert_toc(self):
        heads = self._headings()
        if not heads:
            raise _Note('Apply Heading 1 / 2 / 3 styles (Home > Styles) to your titles first.')
        self._tc_busy = True
        try:
            pos = self._toc_remove()
            if pos is None:
                c = self.textEdit.textCursor()
                if c.block().text():
                    c.movePosition(QTextCursor.EndOfBlock); c.insertBlock()
                pos = c.position()
            self._toc_insert_at(pos, heads)
            # page numbers shift once the TOC itself exists, so build it a second time
            heads = self._headings()
            pos = self._toc_remove()
            if pos is not None:
                self._toc_insert_at(pos, heads)
        finally:
            self._tc_busy = False
        if self._tracking:
            self._snapshot()
        self._sync_document_pages()

    def update_toc(self):
        if not self._toc_blocks():
            raise _Note('This document has no table of contents yet.')
        self.insert_toc()

    def manage_sources(self):
        d = QDialog(self); d.setWindowTitle('Manage Sources'); lay = QVBoxLayout(d)
        lst = QListWidget(); lay.addWidget(lst)

        def refill():
            lst.clear()
            for s in self.sources:
                lst.addItem('%s (%s). %s' % (s['author'], s['year'], s['title']))

        def add():
            a, ok = QInputDialog.getText(d, 'Add Source', 'Author (e.g. Smith, J.):')
            if not ok or not a.strip():
                return
            y, ok = QInputDialog.getText(d, 'Add Source', 'Year:')
            if not ok:
                return
            t, ok = QInputDialog.getText(d, 'Add Source', 'Title:')
            if not ok:
                return
            p, _ = QInputDialog.getText(d, 'Add Source', 'Publisher / journal (optional):')
            self.sources.append({'author': a.strip(), 'year': y.strip() or 'n.d.', 'title': t.strip(), 'publisher': p.strip()})
            refill()

        def remove():
            r = lst.currentRow()
            if r >= 0:
                self.sources.pop(r); refill()

        row = QHBoxLayout()
        for text, fn in (('Add\u2026', add), ('Remove', remove), ('Close', d.accept)):
            b = QPushButton(text); b.clicked.connect(lambda _=False, f=fn: f()); row.addWidget(b)
        lay.addLayout(row); refill(); d.resize(460, 300); d.exec_()

    def insert_citation(self):
        if not self.sources:
            raise _Note('Add a source first (References > Sources).')
        labels = ['%s (%s)' % (s['author'], s['year']) for s in self.sources]
        item, ok = QInputDialog.getItem(self, 'Insert Citation', 'Source:', labels, 0, False)
        if not ok:
            return
        s = self.sources[labels.index(item)]
        self.textEdit.textCursor().insertText('(%s, %s)' % (s['author'].split(',')[0].strip(), s['year']))

    def insert_bibliography(self):
        if not self.sources:
            raise _Note('Add a source first (References > Sources).')
        c = self.textEdit.textCursor()
        c.beginEditBlock()
        if c.block().text():
            c.movePosition(QTextCursor.EndOfBlock); c.insertBlock()
        plain = self._plain_fmt()
        hf = QTextCharFormat(plain); hf.setFontWeight(QFont.Bold); hf.setFontPointSize(14)
        c.setBlockFormat(QTextBlockFormat()); c.insertText('Bibliography', hf); c.insertBlock()
        for s in sorted(self.sources, key=lambda x: x['author'].lower()):
            bf = QTextBlockFormat(); bf.setLeftMargin(36); bf.setTextIndent(-36)
            c.setBlockFormat(bf)
            entry = '%s (%s). %s.' % (s['author'], s['year'], s['title'].rstrip('.'))
            if s['publisher']:
                entry += ' %s.' % s['publisher'].rstrip('.')
            c.insertText(entry, plain); c.insertBlock()
        c.setBlockFormat(QTextBlockFormat())
        c.endEditBlock()

    # --------------------------------------------------------- table tools
    def tbl_insert(self, what):
        c, t = self._cur_table(); cell = t.cellAt(c)
        if what == 'row_above':
            t.insertRows(cell.row(), 1)
        elif what == 'row_below':
            t.insertRows(cell.row() + cell.rowSpan(), 1)
        elif what == 'col_left':
            t.insertColumns(cell.column(), 1)
        else:
            t.insertColumns(cell.column() + cell.columnSpan(), 1)

    def tbl_delete(self, what):
        c, t = self._cur_table(); cell = t.cellAt(c)
        if what == 'row':
            if t.rows() <= 1:
                what = 'table'
            else:
                t.removeRows(cell.row(), 1); return
        if what == 'col':
            if t.columns() <= 1:
                what = 'table'
            else:
                t.removeColumns(cell.column(), 1); return
        d = QTextCursor(self.textEdit.document())
        d.setPosition(t.firstPosition() - 1); d.setPosition(t.lastPosition() + 1, QTextCursor.KeepAnchor)
        d.removeSelectedText()

    def tbl_merge(self):
        c, t = self._cur_table()
        if not c.hasSelection():
            raise _Note('Drag across two or more cells to select them, then merge.')
        t.mergeCells(c)

    def tbl_split(self):
        c, t = self._cur_table(); cell = t.cellAt(c)
        if cell.rowSpan() <= 1 and cell.columnSpan() <= 1:
            raise _Note('This cell is not merged, so there is nothing to split.')
        t.splitCell(cell.row(), cell.column(), 1, 1)

    def tbl_shade(self):
        c, t = self._cur_table()
        col = QColorDialog.getColor(QColor('#dbeafe'), self, 'Cell shading')
        if not col.isValid():
            return
        if c.hasSelection():
            r, nr, k, nk = c.selectedTableCells()
        else:
            cell = t.cellAt(c); r, nr, k, nk = cell.row(), 1, cell.column(), 1
        for rr in range(r, r + nr):
            for cc in range(k, k + nk):
                cell = t.cellAt(rr, cc); f = cell.format(); f.setBackground(QBrush(col)); cell.setFormat(f)

    def tbl_clear_shade(self):
        c, t = self._cur_table()
        if c.hasSelection():
            r, nr, k, nk = c.selectedTableCells()
        else:
            cell = t.cellAt(c); r, nr, k, nk = cell.row(), 1, cell.column(), 1
        for rr in range(r, r + nr):
            for cc in range(k, k + nk):
                cell = t.cellAt(rr, cc); f = cell.format(); f.setBackground(QBrush()); cell.setFormat(f)

    def tbl_borders(self, width):
        c, t = self._cur_table(); tf = t.format()
        tf.setBorder(width); tf.setBorderStyle(QTextFrameFormat.BorderStyle_Solid)
        t.setFormat(tf)

    def tbl_autofit(self):
        c, t = self._cur_table(); tf = t.format()
        tf.setWidth(QTextLength(QTextLength.PercentageLength, 100)); t.setFormat(tf)

    def tbl_sort(self):
        c, t = self._cur_table(); cell = t.cellAt(c); col = cell.column()
        order, ok = QInputDialog.getItem(self, 'Sort Table', 'Sort by this column:', ['A to Z', 'Z to A'], 0, False)
        if not ok:
            return
        hdr, ok = QInputDialog.getItem(self, 'Sort Table', 'Is the first row a header?', ['Yes', 'No'], 0, False)
        if not ok:
            return
        skip = 1 if hdr == 'Yes' else 0
        rows = [[self._cell_str(t, r, k) for k in range(t.columns())] for r in range(t.rows())]
        head, body = rows[:skip], rows[skip:]

        def key(row):
            s = row[col].replace(',', '')
            try:
                return (0, float(s), '')
            except ValueError:
                return (1, 0.0, row[col].lower())
        body.sort(key=key, reverse=(order == 'Z to A'))
        for r, row in enumerate(head + body):
            for k, txt in enumerate(row):
                cc = t.cellAt(r, k)
                cur = cc.firstCursorPosition()
                cur.setPosition(cc.lastCursorPosition().position(), QTextCursor.KeepAnchor)
                cur.insertText(txt)

    # --------------------------------------------------------------- charts
    def insert_chart(self, kind):
        c, t = self._cur_table()
        rows = [[self._cell_str(t, r, k) for k in range(t.columns())] for r in range(t.rows())]

        def num(s):
            try:
                return float(s.replace(',', '').replace('%', '').replace('$', ''))
            except ValueError:
                return None
        header = None; body = rows
        if rows and len(rows[0]) > 1 and all(num(x) is None for x in rows[0][1:]) and any(rows[0][1:]):
            header = rows[0]; body = rows[1:]
        if t.columns() < 2 or not body:
            raise _Note('A chart needs a label column plus at least one numeric column.')
        labels = [r[0] or str(i + 1) for i, r in enumerate(body)]
        series = []
        for k in range(1, t.columns()):
            vals = [num(r[k]) for r in body]
            if any(v is not None for v in vals):
                series.append((header[k] if header and header[k] else 'Series %d' % k, [v or 0.0 for v in vals]))
        if not series:
            raise _Note('No numeric data found in this table.')
        title, ok = QInputDialog.getText(self, 'Chart', 'Chart title (optional):')
        img = self._render_chart(kind, labels, series, title if ok else '')
        doc = self.textEdit.document()
        cur = QTextCursor(doc)
        cur.setPosition(min(t.lastPosition() + 1, max(0, doc.characterCount() - 1)))
        cur.insertImage(img, 'chart_%d' % int(time.time() * 1000))

    def _render_chart(self, kind, labels, series, title):
        W, H = 640, 380
        img = QImage(W, H, QImage.Format_ARGB32); img.fill(QColor('white'))
        p = QPainter(img); p.setRenderHint(QPainter.Antialiasing, True)
        p.setPen(QColor('#111827')); p.setFont(QFont('Segoe UI', 12, QFont.Bold))
        p.drawText(QRectF(0, 8, W, 26), Qt.AlignCenter, title)
        p.setFont(QFont('Segoe UI', 8))
        if kind == 'Pie':
            vals = [abs(v) for v in series[0][1]]; tot = sum(vals) or 1.0
            size = min(H - 80, W * 0.5)
            rect = QRectF(40, 52 + (H - 80 - size) / 2.0, size, size)
            start = 90 * 16
            for i, v in enumerate(vals):
                span = int(v / tot * 360 * 16)
                p.setBrush(QColor(CHART_COLORS[i % len(CHART_COLORS)])); p.setPen(QPen(QColor('white'), 1.5))
                p.drawPie(rect, start, -span); start -= span
            y = 60
            for i, lab in enumerate(labels):
                p.setBrush(QColor(CHART_COLORS[i % len(CHART_COLORS)])); p.setPen(Qt.NoPen)
                p.drawRect(QRectF(rect.right() + 40, y, 12, 12))
                p.setPen(QColor('#374151'))
                p.drawText(QRectF(rect.right() + 58, y - 2, W - rect.right() - 64, 16), Qt.AlignLeft | Qt.AlignVCenter,
                           '%s (%.0f%%)' % (lab, vals[i] / tot * 100))
                y += 20
            p.end(); return img
        left, right, top, bottom = 58, 16, 46, 70
        plot = QRectF(left, top, W - left - right, H - top - bottom)
        allv = [v for _, vs in series for v in vs]
        ymax = max(allv + [0.0]); ymin = min(allv + [0.0])
        if ymax == ymin:
            ymax = ymin + 1.0
        span = ymax - ymin

        def ypos(v):
            return plot.bottom() - (v - ymin) / span * plot.height()
        p.setPen(QPen(QColor('#e5e7eb'), 1))
        for i in range(6):
            v = ymin + span * i / 5.0; y = ypos(v)
            p.drawLine(QPointF(plot.left(), y), QPointF(plot.right(), y))
            p.setPen(QColor('#6b7280'))
            p.drawText(QRectF(4, y - 8, left - 8, 16), Qt.AlignRight | Qt.AlignVCenter, '%g' % round(v, 2))
            p.setPen(QPen(QColor('#e5e7eb'), 1))
        p.setPen(QPen(QColor('#9ca3af'), 1.2))
        p.drawLine(QPointF(plot.left(), ypos(0)), QPointF(plot.right(), ypos(0)))
        n = len(labels); slot = plot.width() / max(1, n)
        for i, lab in enumerate(labels):
            p.setPen(QColor('#374151'))
            p.drawText(QRectF(plot.left() + i * slot, plot.bottom() + 6, slot, 30), Qt.AlignHCenter | Qt.AlignTop, lab)
        ns = len(series)
        for si, (name, vals) in enumerate(series):
            col = QColor(CHART_COLORS[si % len(CHART_COLORS)])
            if kind == 'Line':
                p.setPen(QPen(col, 2.4)); p.setBrush(col)
                pts = [QPointF(plot.left() + (i + 0.5) * slot, ypos(v)) for i, v in enumerate(vals)]
                for a, b in zip(pts, pts[1:]):
                    p.drawLine(a, b)
                for q in pts:
                    p.drawEllipse(q, 3.5, 3.5)
            else:
                bw = slot * 0.7 / ns
                p.setPen(Qt.NoPen); p.setBrush(col)
                for i, v in enumerate(vals):
                    x = plot.left() + i * slot + slot * 0.15 + si * bw
                    y0, y1 = ypos(0), ypos(v)
                    p.drawRect(QRectF(x, min(y0, y1), bw - 1, abs(y1 - y0)))
        lx = plot.left()
        for si, (name, _) in enumerate(series):
            col = QColor(CHART_COLORS[si % len(CHART_COLORS)])
            p.setPen(Qt.NoPen); p.setBrush(col); p.drawRect(QRectF(lx, H - 24, 12, 12))
            p.setPen(QColor('#374151')); p.drawText(QRectF(lx + 16, H - 27, 120, 18), Qt.AlignLeft | Qt.AlignVCenter, name)
            lx += 140
        p.end()
        return img

    # ----------------------------------------------------------- mail merge
    def mm_select_recipients(self):
        path, _ = QFileDialog.getOpenFileName(self, 'Select Recipients (CSV)', '', 'CSV files (*.csv);;All files (*)')
        if not path:
            return
        with open(path, encoding='utf-8-sig', newline='') as fh:
            rows = list(csv.DictReader(fh))
        if not rows:
            raise _Note('That file has no data rows. The first row must be the field names.')
        self._merge_rows = rows; self._merge_fields = list(rows[0].keys())
        self.mmField.clear(); self.mmField.addItems(self._merge_fields)
        self.mmInfo.setText('%d recipients' % len(rows))

    def mm_insert_field(self):
        if not self._merge_fields:
            raise _Note('Select recipients first.')
        self.textEdit.textCursor().insertText('%s%s%s' % (MERGE_L, self.mmField.currentText(), MERGE_R))

    def _mm_render(self, html, row):
        for k, v in row.items():
            html = html.replace('%s%s%s' % (MERGE_L, k, MERGE_R), _html.escape(str(v or '')))
        return html

    def _mm_set_html(self, html):
        self._tc_busy = True
        try:
            self.textEdit.setHtml(html)
        finally:
            self._tc_busy = False

    def mm_preview(self, on):
        if on:
            if not self._merge_rows:
                self.btnPreview.blockSignals(True); self.btnPreview.setChecked(False); self.btnPreview.blockSignals(False)
                raise _Note('Select recipients first.')
            self._mm_template = self.textEdit.toHtml(); self._mm_index = 0; self._mm_show()
        elif self._mm_template is not None:
            self._mm_set_html(self._mm_template); self._mm_template = None; self.mmInfo.setText('%d recipients' % len(self._merge_rows))

    def _mm_show(self):
        self._mm_set_html(self._mm_render(self._mm_template, self._merge_rows[self._mm_index]))
        self.mmInfo.setText('Record %d of %d' % (self._mm_index + 1, len(self._merge_rows)))

    def mm_step(self, d):
        if self._mm_template is None:
            raise _Note('Turn on Preview Results first.')
        self._mm_index = (self._mm_index + d) % len(self._merge_rows); self._mm_show()

    def mm_finish(self):
        if not self._merge_rows:
            raise _Note('Select recipients first.')
        if QMessageBox.question(self, 'Finish & Merge',
                                'Create one merged copy per recipient (%d pages)?\nThis replaces the current document, so save your template first.' % len(self._merge_rows),
                                QMessageBox.Yes | QMessageBox.No, QMessageBox.No) != QMessageBox.Yes:
            return
        tpl = self._mm_template if self._mm_template is not None else self.textEdit.toHtml()
        self._mm_template = None
        self.btnPreview.blockSignals(True); self.btnPreview.setChecked(False); self.btnPreview.blockSignals(False)
        self._tc_busy = True
        try:
            self.textEdit.clear()
            doc = self.textEdit.document()
            c = QTextCursor(doc)
            for i, row in enumerate(self._merge_rows):
                if i > 0:
                    c.insertBlock()
                start = c.position()
                c.insertFragment(QTextDocumentFragment.fromHtml(self._mm_render(tpl, row)))
                if i > 0:
                    bc = QTextCursor(doc.findBlock(start)); bf = bc.blockFormat()
                    bf.setPageBreakPolicy(QTextFormat.PageBreak_AlwaysBefore); bc.setBlockFormat(bf)
        finally:
            self._tc_busy = False
        self.mmInfo.setText('Merged %d letters' % len(self._merge_rows))
        self._sync_document_pages()

    # -------------------------------------------------------- review / misc
    def show_statistics(self):
        text = self.textEdit.toPlainText()
        words = len(text.split())
        paras = len([b for b in text.split('\n') if b.strip()])
        QMessageBox.information(self, 'Word Count',
                                'Pages: %d\nWords: %d\nCharacters (no spaces): %d\nCharacters (with spaces): %d\nParagraphs: %d\nReading time: about %.1f min'
                                % (self._page_count(), words, len(re.sub(r'\s', '', text)), len(text), paras, words / 230.0))

    def read_aloud(self):
        text = self.textEdit.textCursor().selectedText().replace('\u2029', '\n') or self.textEdit.toPlainText()
        if not text.strip():
            raise _Note('There is no text to read.')
        if self._tts is None:
            self._tts = QTextToSpeech(self)
        self._tts.say(text)

    def stop_reading(self):
        if self._tts is not None:
            self._tts.stop()

    def toggle_readonly(self, on):
        self.textEdit.setReadOnly(on)

    def document_properties(self):
        d = QDialog(self); d.setWindowTitle('Document Properties'); f = QFormLayout(d)
        t = QLineEdit(self.doc_title); a = QLineEdit(self.doc_author)
        f.addRow('Title:', t); f.addRow('Author (used for comments and tracked changes):', a)
        box = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        box.accepted.connect(d.accept); box.rejected.connect(d.reject); f.addRow(box)
        if d.exec_() == QDialog.Accepted:
            self.doc_title = t.text().strip(); self.doc_author = a.text().strip() or self.doc_author

    def _autosave_tick(self):
        try:
            if self.textEdit.document().isModified() and not self.textEdit.isReadOnly():
                self._autosave_path.parent.mkdir(parents=True, exist_ok=True)
                self._autosave_path.write_text(self.textEdit.toHtml(), encoding='utf-8')
        except Exception:
            pass

    def recover_autosave(self):
        if not self._autosave_path.exists():
            raise _Note('There is no autosaved copy yet. The editor saves one every minute while you have unsaved changes.')
        if QMessageBox.question(self, 'Recover', 'Replace the current document with the last autosaved copy?',
                                QMessageBox.Yes | QMessageBox.No, QMessageBox.No) != QMessageBox.Yes:
            return
        self._mm_set_html(self._autosave_path.read_text(encoding='utf-8'))
        self.textEdit.document().setModified(True)
        self._refresh_comments()
        if self._tracking:
            self._snapshot()

    def new_document(self):
        self._tc_busy = True
        try:
            super().new_document()
        finally:
            self._tc_busy = False
        if not self.textEdit.toPlainText():
            self.comments.clear()
        if self._tracking:
            self._snapshot()

    def load_document(self):
        self._tc_busy = True
        try:
            super().load_document()
        finally:
            self._tc_busy = False
        self.comments.clear()
        self._refresh_comments()
        if self._tracking:
            self._snapshot()

    # --------------------------------------------------------------- ribbons
    def _page_layout(self, name):
        for i in range(self.wordTabs.count()):
            if self.wordTabs.tabText(i) == name:
                return self.wordTabs.widget(i).layout()
        return None

    def _new_tab(self, name):
        p = QWidget(); h = QHBoxLayout(p); h.setContentsMargins(8, 4, 8, 4); h.setSpacing(4); h.addStretch()
        self.wordTabs.addTab(p, name)
        return h

    def _add_to(self, tab, title, widgets):
        lay = self._page_layout(tab)
        if lay is None:
            lay = self._new_tab(tab)
        lay.insertWidget(max(0, lay.count() - 1), self._group(title, widgets))

    def _extend_file_menu(self):
        for btn in self.findChildren(QToolButton):
            if btn.text() == 'File' and btn.menu() is not None:
                m = btn.menu(); m.addSeparator()
                for text, fn in (('Page Setup\u2026', self.page_setup_dialog),
                                 ('Document Properties\u2026', self.document_properties),
                                 ('Export as PDF\u2026', self._export_pdf_direct),
                                 ('Recover Autosaved Copy', self.recover_autosave)):
                    a = m.addAction(text); a.triggered.connect(self._safe(fn))
                break

    def _build_v10_ribbons(self):
        t, T = self._t, self._toggle
        # ---------------- Home
        self.btnPainter = T('Format Painter', self.toggle_painter, 'Copy formatting, then select text to apply it')
        self._add_to('Home', 'Clipboard', [t('Undo', self.text_undo), t('Redo', self.text_redo), t('Cut', self.textEdit.cut),
                                           t('Copy', self.textEdit.copy), t('Paste', self.textEdit.paste), self.btnPainter])
        case_menu = self._menu_btn('Aa', [('UPPERCASE', lambda: self.set_case('upper')), ('lowercase', lambda: self.set_case('lower')),
                                          ('Title Case', lambda: self.set_case('title')), ('Sentence case', lambda: self.set_case('sentence')),
                                          ('tOGGLE cASE', lambda: self.set_case('toggle'))], 'Change case')
        self._add_to('Home', 'Font+', [t('S\u0336', self.toggle_strike, 'Strikethrough'), t('x\u2082', lambda: self.set_script('sub'), 'Subscript'),
                                       t('x\u00b2', lambda: self.set_script('sup'), 'Superscript'), case_menu,
                                       t('A\u207a', lambda: self.grow_font(1), 'Grow font'), t('A\u207b', lambda: self.grow_font(-1), 'Shrink font')])
        self._add_to('Home', 'Align', [t('Left', lambda: self.set_align('left')), t('Center', lambda: self.set_align('center')),
                                       t('Right', lambda: self.set_align('right')), t('Justify', lambda: self.set_align('justify'))])
        shade = self._menu_btn('Shading', [('Shade paragraph\u2026', self.shade_paragraph), ('No shading', self.clear_shading)], 'Paragraph shading')
        self._add_to('Home', 'Paragraph+', [shade, t('Spacing', self.paragraph_spacing, 'Paragraph spacing'), t('Sort A\u2013Z', self.sort_paragraphs, 'Sort selected paragraphs'),
                                            T('\u00b6', self.toggle_marks, 'Show / hide formatting marks')])
        self._add_to('Home', 'Editing', [t('Find', lambda: self.open_find(False)), t('Replace', lambda: self.open_find(True)),
                                         t('Select All', self.textEdit.selectAll)])
        # ---------------- Insert
        self._add_to('Insert', 'Links', [t('Hyperlink', self.insert_hyperlink, 'Insert or edit a hyperlink (Ctrl+K)'),
                                         t('Bookmark', self.insert_bookmark), t('Cross-ref', self.insert_cross_reference, 'Link to a bookmark')])
        self._add_to('Insert', 'Symbols', [t('\u03a9 Symbol', self.insert_symbol), t('\u03c0 Equation', self.insert_equation)])
        shapes = self._menu_btn('Shapes', [(n, lambda n=n: self.insert_shape(n)) for n in
                                           ('Rectangle', 'Rounded Rectangle', 'Ellipse', 'Triangle', 'Right Arrow', 'Star')])
        charts = self._menu_btn('Chart', [(n + ' chart from table', lambda n=n: self.insert_chart(n)) for n in ('Bar', 'Line', 'Pie')],
                                'Builds a chart from the table your cursor is in')
        self._add_to('Insert', 'Illustrations+', [shapes, charts, t('Text Box', self.insert_textbox)])
        pn = self._menu_btn('Page Number', [('Bottom - left', lambda: self.set_page_number(('bottom', Qt.AlignLeft))),
                                            ('Bottom - center', lambda: self.set_page_number(('bottom', Qt.AlignHCenter))),
                                            ('Bottom - right', lambda: self.set_page_number(('bottom', Qt.AlignRight))),
                                            ('Top - center', lambda: self.set_page_number(('top', Qt.AlignHCenter))),
                                            ('Top - right', lambda: self.set_page_number(('top', Qt.AlignRight))),
                                            (None, None), ('Remove page numbers', lambda: self.set_page_number('remove'))])
        self._add_to('Insert', 'Pages+', [t('Cover Page', self.insert_cover_page), pn])
        # ---------------- Layout
        margins = self._menu_btn('Margins', [(n + '  (%.2f cm)' % v[0] if v[0] == v[1] else n, lambda n=n: self.set_margin_preset(n))
                                             for n, v in MARGIN_PRESETS.items()] + [(None, None), ('Custom\u2026', self.page_setup_dialog)])
        orient = self._menu_btn('Orientation', [('Portrait', lambda: self.set_orientation('Portrait')), ('Landscape', lambda: self.set_orientation('Landscape'))])
        size = self._menu_btn('Size', [(n, lambda n=n: self.set_paper(n)) for n in PAPER_PX])
        cols = self._menu_btn('Columns', [('Two', lambda: self.insert_columns(2)), ('Three', lambda: self.insert_columns(3))],
                              'Inserts a borderless multi-column table (text does not flow between columns)')
        self._add_to('Layout', 'Page Setup', [margins, orient, size, cols, t('Setup\u2026', self.page_setup_dialog)])
        self._add_to('Layout', 'Page Background', [t('Watermark', self.set_watermark)])
        self._add_to('Layout', 'Spacing', [t('Before / After', self.paragraph_spacing)])
        # ---------------- Review
        self.btnSpell = T('Spelling', self.toggle_spelling, 'Underline misspelled words (needs pyspellchecker)')
        self._add_to('Review', 'Proofing+', [self.btnSpell, t('Check\u2026', self.open_spelling, 'Step through spelling errors (F7)'),
                                             t('Statistics', self.show_statistics)])
        self._add_to('Review', 'Comments', [t('New Comment', self.add_comment), t('Delete', self.delete_comment),
                                            T('Panel', self.toggle_comments_panel, 'Show the comments pane')])
        self.btnTrack = T('Track Changes', self.toggle_tracking, 'Mark insertions and deletions (Ctrl+Shift+E)')
        self._add_to('Review', 'Tracking', [self.btnTrack, t('Accept All', self.accept_all_changes), t('Reject All', self.reject_all_changes),
                                            t('Next', self.next_change, 'Jump to next change')])
        self._add_to('Review', 'Speech', [t('Read Aloud', self.read_aloud), t('Stop', self.stop_reading)])
        self._add_to('Review', 'Protect', [T('Read-only', self.toggle_readonly, 'Lock the document against edits')])
        # ---------------- View
        self._add_to('View', 'Show', [T('Ruler', self.toggle_ruler), T('Navigation', self.toggle_nav, 'Headings pane')])
        # ---------------- References
        self._add_to('References', 'Table of Contents', [t('Insert TOC', self.insert_toc), t('Update TOC', self.update_toc)])
        self._add_to('References', 'Footnotes', [t('Insert Footnote', self.insert_footnote)])
        self._add_to('References', 'Citations', [t('Sources\u2026', self.manage_sources), t('Cite', self.insert_citation),
                                                 t('Bibliography', self.insert_bibliography)])
        self._add_to('References', 'Links', [t('Bookmark', self.insert_bookmark), t('Go To', self.goto_bookmark),
                                             t('Cross-ref', self.insert_cross_reference)])
        # ---------------- Mailings
        self.mmField = QComboBox(); self.mmField.setMinimumWidth(130)
        self.mmInfo = QLabel('No recipients'); self.mmInfo.setStyleSheet('color:#6b7280;font-size:10px;')
        self.btnPreview = T('Preview Results', self.mm_preview)
        self._add_to('Mailings', 'Start', [t('Recipients (CSV)\u2026', self.mm_select_recipients), self.mmInfo])
        self._add_to('Mailings', 'Fields', [self.mmField, t('Insert Field', self.mm_insert_field)])
        self._add_to('Mailings', 'Preview', [self.btnPreview, t('\u25c0', lambda: self.mm_step(-1)), t('\u25b6', lambda: self.mm_step(1))])
        self._add_to('Mailings', 'Finish', [t('Finish & Merge', self.mm_finish)])
        # ---------------- Table Tools
        self._add_to('Table Tools', 'Rows & Columns', [t('Row \u2191', lambda: self.tbl_insert('row_above'), 'Insert row above'),
                                                      t('Row \u2193', lambda: self.tbl_insert('row_below'), 'Insert row below'),
                                                      t('Col \u2190', lambda: self.tbl_insert('col_left'), 'Insert column left'),
                                                      t('Col \u2192', lambda: self.tbl_insert('col_right'), 'Insert column right')])
        self._add_to('Table Tools', 'Delete', [t('Del Row', lambda: self.tbl_delete('row')), t('Del Col', lambda: self.tbl_delete('col')),
                                               t('Del Table', lambda: self.tbl_delete('table'))])
        self._add_to('Table Tools', 'Merge', [t('Merge Cells', self.tbl_merge), t('Split Cell', self.tbl_split)])
        borders = self._menu_btn('Borders', [('No border', lambda: self.tbl_borders(0)), ('Thin', lambda: self.tbl_borders(1)),
                                             ('Thick', lambda: self.tbl_borders(3))])
        self._add_to('Table Tools', 'Style', [t('Shading', self.tbl_shade), t('Clear', self.tbl_clear_shade), borders,
                                              t('AutoFit', self.tbl_autofit), t('Sort', self.tbl_sort)])
        # tab order: Home Insert Layout References Mailings Review View ...
        try:
            bar = self.wordTabs.tabBar()
            names = [self.wordTabs.tabText(i) for i in range(self.wordTabs.count())]
            for target, nm in ((3, 'References'), (4, 'Mailings')):
                if nm in names and names.index(nm) != target:
                    bar.moveTab(names.index(nm), target)
                    names = [self.wordTabs.tabText(i) for i in range(self.wordTabs.count())]
        except Exception:
            pass
        self._wrap_ribbon_pages()

    def _wrap_ribbon_pages(self):
        """Wrap every ribbon page in a horizontal scroll area so nothing is clipped."""
        for i in range(self.wordTabs.count()):
            w = self.wordTabs.widget(i)
            if isinstance(w, QScrollArea):
                continue
            label = self.wordTabs.tabText(i)
            h = max(w.sizeHint().height(), 78) + 16
            self.wordTabs.removeTab(i)
            sa = QScrollArea()
            sa.setWidgetResizable(True)
            sa.setStyleSheet('QScrollArea{border:0;background:transparent;}')
            sa.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
            sa.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded)
            sa.setWidget(w)
            sa.setFixedHeight(h)
            self.wordTabs.insertTab(i, sa, label)
        self.wordTabs.setCurrentIndex(0)

    # ------------------------------------------------------------ DOCX export
    @staticmethod
    def _docx_shade(element_parent, hexcolor):
        shd = OxmlElement('w:shd')
        shd.set(qn('w:val'), 'clear'); shd.set(qn('w:color'), 'auto'); shd.set(qn('w:fill'), hexcolor.lstrip('#'))
        element_parent.append(shd)

    def _docx_field(self, par, instr):
        run = par.add_run()
        b = OxmlElement('w:fldChar'); b.set(qn('w:fldCharType'), 'begin')
        it = OxmlElement('w:instrText'); it.set(qn('xml:space'), 'preserve'); it.text = instr
        e = OxmlElement('w:fldChar'); e.set(qn('w:fldCharType'), 'end')
        run._r.append(b); run._r.append(it); run._r.append(e)

    def _docx_hf(self, hf, text, align):
        p = hf.paragraphs[0]
        p.alignment = (WD_ALIGN_PARAGRAPH.CENTER if align & Qt.AlignHCenter else
                       WD_ALIGN_PARAGRAPH.RIGHT if align & Qt.AlignRight else WD_ALIGN_PARAGRAPH.LEFT)
        for part in re.split(r'(\{pages\}|\{page\})', text):
            if part == '{page}':
                self._docx_field(p, 'PAGE')
            elif part == '{pages}':
                self._docx_field(p, 'NUMPAGES')
            elif part:
                p.add_run(part)

    def _docx_run(self, par, text, fmt, ctx):
        run = par.add_run(text)
        if fmt.hasProperty(QTextFormat.BackgroundBrush) and fmt.background().style() != Qt.NoBrush:
            self._docx_shade(run._r.get_or_add_rPr(), fmt.background().color().name())
        run.bold = fmt.fontWeight() >= QFont.Bold
        run.italic = fmt.fontItalic()
        run.underline = fmt.fontUnderline()
        if fmt.fontStrikeOut():
            run.font.strike = True
        va = fmt.verticalAlignment()
        if va == QTextCharFormat.AlignSuperScript:
            run.font.superscript = True
        elif va == QTextCharFormat.AlignSubScript:
            run.font.subscript = True
        if fmt.fontPointSize() > 0:
            run.font.size = Pt(fmt.fontPointSize())
        if fmt.fontFamily():
            run.font.name = fmt.fontFamily()
        if fmt.hasProperty(QTextFormat.ForegroundBrush):
            col = fmt.foreground().color()
            if col.isValid():
                run.font.color.rgb = RGBColor(col.red(), col.green(), col.blue())
        return run

    def _docx_image(self, par, fmt, ctx):
        imf = QTextImageFormat(fmt)
        name = imf.name()
        img = self.textEdit.document().resource(QTextDocument.ImageResource, QUrl(name))
        if not isinstance(img, QImage):
            img = QImage(name)
        if img.isNull():
            return
        tmp = tempfile.NamedTemporaryFile(suffix='.png', delete=False); tmp.close()
        img.save(tmp.name, 'PNG'); ctx['tmp'].append(tmp.name)
        w = imf.width() or img.width()
        par.add_run().add_picture(tmp.name, width=Pt(min(w * 0.75, 460)))

    def _docx_fill(self, par, block, ctx):
        bf = block.blockFormat()
        if bf.background().style() != Qt.NoBrush:
            self._docx_shade(par._p.get_or_add_pPr(), bf.background().color().name())
        al = bf.alignment()
        if al & Qt.AlignHCenter:
            par.alignment = WD_ALIGN_PARAGRAPH.CENTER
        elif al & Qt.AlignRight:
            par.alignment = WD_ALIGN_PARAGRAPH.RIGHT
        elif al & Qt.AlignJustify:
            par.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
        pf = par.paragraph_format
        if bf.leftMargin() > 0:
            pf.left_indent = Pt(bf.leftMargin() * 0.75)
        if bf.textIndent() != 0:
            pf.first_line_indent = Pt(bf.textIndent() * 0.75)
        if bf.rightMargin() > 0:
            pf.right_indent = Pt(bf.rightMargin() * 0.75)
        if bf.topMargin() > 0:
            pf.space_before = Pt(bf.topMargin() * 0.75)
        if bf.bottomMargin() > 0:
            pf.space_after = Pt(bf.bottomMargin() * 0.75)
        if bf.lineHeightType() == QTextBlockFormat.ProportionalHeight and bf.lineHeight() > 0:
            pf.line_spacing = bf.lineHeight() / 100.0
        if bf.pageBreakPolicy() & QTextFormat.PageBreak_AlwaysBefore:
            pf.page_break_before = True
        lst = block.textList()
        style = None
        if lst is not None:
            st = lst.format().style()
            style = 'List Bullet' if st in (QTextListFormat.ListDisc, QTextListFormat.ListCircle, QTextListFormat.ListSquare) else 'List Number'
        else:
            it = block.begin()
            while not it.atEnd():
                fr = it.fragment()
                if fr.isValid():
                    fm = fr.charFormat()
                    if fm.fontWeight() >= QFont.Bold and HEADING_SIZES.get(int(round(fm.fontPointSize()))):
                        style = 'Heading %d' % HEADING_SIZES[int(round(fm.fontPointSize()))]
                    break
                it += 1
        if style:
            try:
                par.style = style
            except Exception:
                pass
        it = block.begin()
        while not it.atEnd():
            fr = it.fragment()
            if fr.isValid():
                fmt = fr.charFormat()
                if fmt.isImageFormat():
                    self._docx_image(par, fmt, ctx)
                else:
                    text = fr.text()
                    href = fmt.anchorHref()
                    run = self._docx_run(par, text, fmt, ctx)
                    if href:
                        h = OxmlElement('w:hyperlink')
                        if href.startswith('#'):
                            h.set(qn('w:anchor'), href[1:])
                        else:
                            rid = par.part.relate_to(href, RT.HYPERLINK, is_external=True)
                            h.set(qn('r:id'), rid)
                        par._p.remove(run._r); h.append(run._r); par._p.append(h)
                    for name in fmt.anchorNames():
                        if name and not href:
                            ctx['bm'] += 1
                            bs = OxmlElement('w:bookmarkStart'); bs.set(qn('w:id'), str(ctx['bm'])); bs.set(qn('w:name'), name)
                            be = OxmlElement('w:bookmarkEnd'); be.set(qn('w:id'), str(ctx['bm']))
                            run._r.addprevious(bs); run._r.addnext(be)
                    if fmt.hasProperty(P_CMT):
                        ctx['cmt'].setdefault(fmt.property(P_CMT), []).append(run)
                    kind = 'ins' if fmt.hasProperty(P_INS) else ('del' if fmt.hasProperty(P_DEL) else None)
                    if kind:
                        ctx['rev'] += 1
                        wrap = OxmlElement('w:' + kind)
                        wrap.set(qn('w:id'), str(1000 + ctx['rev'])); wrap.set(qn('w:author'), self.doc_author)
                        wrap.set(qn('w:date'), datetime.datetime.now().strftime('%Y-%m-%dT%H:%M:%SZ'))
                        parent = run._r.getparent()
                        parent.replace(run._r, wrap); wrap.append(run._r)
                        if kind == 'del':
                            for tnode in run._r.findall(qn('w:t')):
                                tnode.tag = qn('w:delText')
            it += 1

    def _docx_table(self, container, qt, ctx):
        rows, cols = qt.rows(), qt.columns()
        t = container.add_table(rows=rows, cols=cols)
        if qt.format().border() > 0:
            try:
                t.style = 'Table Grid'
            except Exception:
                pass
        for r in range(rows):
            for c in range(cols):
                cell = qt.cellAt(r, c)
                if cell.row() != r or cell.column() != c:
                    continue
                dcell = t.cell(r, c)
                rs, cs = cell.rowSpan(), cell.columnSpan()
                if rs > 1 or cs > 1:
                    dcell = dcell.merge(t.cell(r + rs - 1, c + cs - 1))
                bg = cell.format().background()
                if bg.style() != Qt.NoBrush:
                    self._docx_shade(dcell._tc.get_or_add_tcPr(), bg.color().name())
                first = True
                # QTextTableCell.begin() is not exposed by PyQt5. Iterate the
                # owning frame and include only blocks/frames in this cell.
                start = cell.firstCursorPosition().position()
                end = cell.lastCursorPosition().position()
                it = qt.begin()
                while not it.atEnd():
                    blk = it.currentBlock()
                    if blk.isValid() and start <= blk.position() <= end:
                        par = dcell.paragraphs[0] if first else dcell.add_paragraph()
                        first = False
                        self._docx_fill(par, blk, ctx)
                    it += 1

    def _export_docx(self, path):
        doc = Document()
        ctx = {'tmp': [], 'cmt': {}, 'bm': 0, 'rev': 0}
        sec = doc.sections[0]
        w, h = PAPER_MM.get(self._paper, PAPER_MM['A4'])
        if self._orient == 'Landscape':
            sec.orientation = WD_ORIENT.LANDSCAPE; w, h = h, w
        sec.page_width = Mm(w); sec.page_height = Mm(h)
        t, l, b, r = [v * 25.4 / 96.0 for v in self._margins_px]
        sec.top_margin, sec.left_margin, sec.bottom_margin, sec.right_margin = Mm(t), Mm(l), Mm(b), Mm(r)
        if self.header_text:
            self._docx_hf(sec.header, self.header_text, self.header_align)
        if self.footer_text:
            self._docx_hf(sec.footer, self.footer_text, self.footer_align)
        try:
            doc.core_properties.author = self.doc_author
            if self.doc_title:
                doc.core_properties.title = self.doc_title
        except Exception:
            pass
        try:
            qdoc = self.textEdit.document()
            it = qdoc.rootFrame().begin()
            while not it.atEnd():
                blk = it.currentBlock()
                if blk.isValid():
                    self._docx_fill(doc.add_paragraph(), blk, ctx)
                else:
                    fr = it.currentFrame()
                    if fr is not None and hasattr(fr, 'cellAt'):
                        self._docx_table(doc, fr, ctx)
                it += 1
            if ctx['cmt']:
                if hasattr(doc, 'add_comment'):
                    for cid, runs in ctx['cmt'].items():
                        info = self.comments.get(cid)
                        if not info:
                            continue
                        try:
                            doc.add_comment(runs=runs, text=info['text'], author=info['author'],
                                            initials=''.join(x[0] for x in info['author'].split())[:3].upper() or 'A')
                        except Exception:
                            pass
                else:
                    doc.add_heading('Comments', level=2)
                    for cid in sorted(ctx['cmt']):
                        info = self.comments.get(cid)
                        if info:
                            doc.add_paragraph('%s: %s' % (info['author'], info['text']))
            doc.save(path)
        finally:
            for fpath in ctx['tmp']:
                try:
                    os.remove(fpath)
                except OSError:
                    pass



# =============================================================================
#  V10 Video tab -- restyled to match the rest of the app (light surfaces, white
#  rounded cards, indigo accent, header strip, pill / ghost buttons), with a
#  welcome screen, platform pills, recent meetings and a focus mode.
#  Meeting logic (_url, profile sharing, permission prompts) is inherited from V9.
# =============================================================================
from PyQt5.QtWidgets import QStackedWidget, QButtonGroup


class V10VideoTab(V9VideoTab):
    PLATFORMS = [
        ('Zoom', '\U0001F535', 'Join with a meeting ID or an invite link', 'Meeting ID or Zoom link'),
        ('Google Meet', '\U0001F7E2', 'Paste a meeting code or a meet.google.com link', 'Meeting code or Meet link'),
        ('MS Teams', '\U0001F7E3', 'Open a Teams meeting invitation link', 'Teams meeting link'),
        ('Custom URL', '\U0001F310', 'Any web meeting, webinar or recorded lecture', 'https://\u2026'),
    ]

    _STYLE = """
        #V10VideoTab { background:#f6f7fb; }
        #videoHeader { background:#ffffff; border-bottom:1px solid #e5e7eb; }
        #videoTitle { color:#111827; font-size:18px; font-weight:bold; }
        #videoSub { color:#6b7280; font-size:12px; }
        #videoChip { background:#eef2ff; color:#4338ca; border:1px solid #c7d2fe; border-radius:11px; padding:3px 12px; font-size:11px; font-weight:600; }
        #videoCard { background:#ffffff; border:1px solid #e5e7eb; border-radius:12px; }
        #videoSection { color:#6b7280; font-size:11px; font-weight:600; }
        #videoPill { background:#f3f4f6; color:#374151; border:1px solid #d1d5db; border-radius:15px; padding:6px 16px; }
        #videoPill:hover { background:#eef2ff; border-color:#a5b4fc; }
        #videoPill:checked { background:#eef2ff; color:#4338ca; border:1px solid #6366f1; font-weight:bold; }
        #videoInput { background:#ffffff; color:#111827; border:1px solid #d1d5db; border-radius:10px; padding:7px 12px; min-height:22px; selection-background-color:#c7d2fe; }
        #videoInput:focus { border:1px solid #6366f1; }
        QComboBox#videoInput::drop-down { border:none; width:22px; }
        #videoPrimary { background:#6366f1; color:white; border:none; border-radius:8px; padding:8px 18px; font-weight:bold; }
        #videoPrimary:hover { background:#4f46e5; }
        #videoPrimary:pressed { background:#4338ca; }
        #videoGhost { background:#f3f4f6; color:#374151; border:1px solid #d1d5db; border-radius:8px; padding:7px 12px; }
        #videoGhost:hover { background:#e5e7eb; }
        #videoGhost:checked { background:#eef2ff; color:#4338ca; border:1px solid #6366f1; }
        #videoNav { background:#f3f4f6; color:#374151; border:1px solid #e5e7eb; border-radius:8px; min-width:32px; max-width:32px; min-height:30px; font-size:14px; }
        #videoNav:hover { background:#e5e7eb; }
        #videoToolbar { background:#fafafa; border-bottom:1px solid #e5e7eb; border-top-left-radius:12px; border-top-right-radius:12px; }
        #videoWelcome { background:transparent; }
        #videoHeroTitle { color:#111827; font-size:20px; font-weight:bold; }
        #videoHeroSub { color:#6b7280; font-size:12px; }
        #videoTile { background:#ffffff; color:#374151; border:1px solid #e5e7eb; border-radius:12px; padding:14px 12px; min-width:170px; min-height:96px; }
        #videoTile:hover { border:1px solid #6366f1; background:#f5f6ff; }
        #videoStatus { color:#6b7280; font-size:11px; }
    """

    def __init__(self, browser_tab):
        QWidget.__init__(self)                       # V9's layout is replaced entirely
        self.browser_tab = browser_tab
        self._shared_profile = None
        self._platform = 'Google Meet'
        self._recent_file = Path.home() / '.jesson_reader' / 'recent_meetings.json'
        self.setObjectName('V10VideoTab')
        self.setStyleSheet(self._STYLE)

        root = QVBoxLayout(self); root.setContentsMargins(0, 0, 0, 0); root.setSpacing(0)

        # ---- header strip (same pattern as the Study AI tab)
        self.header = QWidget(); self.header.setObjectName('videoHeader')
        hl = QHBoxLayout(self.header); hl.setContentsMargins(20, 14, 20, 14); hl.setSpacing(12)
        titles = QVBoxLayout(); titles.setSpacing(2)
        t = QLabel('Video & Meetings'); t.setObjectName('videoTitle')
        s = QLabel('Join Zoom, Google Meet or Teams inside the app \u2014 your saved browser sign-ins are reused.'); s.setObjectName('videoSub')
        titles.addWidget(t); titles.addWidget(s)
        hl.addLayout(titles, 1)
        self.profileChip = QLabel(''); self.profileChip.setObjectName('videoChip'); hl.addWidget(self.profileChip, 0, Qt.AlignVCenter)
        root.addWidget(self.header)

        body = QWidget(); bl = QVBoxLayout(body); bl.setContentsMargins(16, 14, 16, 10); bl.setSpacing(12)

        # ---- join card
        self.joinCard = QWidget(); self.joinCard.setObjectName('videoCard')
        jl = QVBoxLayout(self.joinCard); jl.setContentsMargins(16, 14, 16, 14); jl.setSpacing(10)
        sec = QLabel('PLATFORM'); sec.setObjectName('videoSection'); jl.addWidget(sec)
        pills = QHBoxLayout(); pills.setSpacing(8)
        self.pillGroup = QButtonGroup(self); self.pillGroup.setExclusive(True)
        self.pills = {}
        for name, icon, _desc, _ph in self.PLATFORMS:
            b = QPushButton('%s  %s' % (icon, name)); b.setObjectName('videoPill'); b.setCheckable(True)
            b.setCursor(Qt.PointingHandCursor)
            self.pillGroup.addButton(b); pills.addWidget(b); self.pills[name] = b
            b.clicked.connect(lambda _=False, n=name: self._set_platform(n))
        pills.addStretch(1)
        jl.addLayout(pills)
        row = QHBoxLayout(); row.setSpacing(8)
        self.input = QLineEdit(); self.input.setObjectName('videoInput')
        self.openHere = QPushButton('Join here'); self.openHere.setObjectName('videoPrimary'); self.openHere.setCursor(Qt.PointingHandCursor)
        self.openDefault = QPushButton('Open in browser'); self.openDefault.setObjectName('videoGhost')
        self.newMeet = QPushButton('\uff0b New Google Meet'); self.newMeet.setObjectName('videoGhost')
        row.addWidget(self.input, 1); row.addWidget(self.openHere); row.addWidget(self.openDefault); row.addWidget(self.newMeet)
        jl.addLayout(row)
        rrow = QHBoxLayout(); rrow.setSpacing(8)
        rl = QLabel('RECENT'); rl.setObjectName('videoSection')
        self.recent = QComboBox(); self.recent.setObjectName('videoInput'); self.recent.setMinimumWidth(260)
        rrow.addWidget(rl); rrow.addWidget(self.recent); rrow.addStretch(1)
        jl.addLayout(rrow)
        bl.addWidget(self.joinCard)

        # keeps V9's _url() working (it reads self.platform.currentText())
        self.platform = QComboBox(self); self.platform.addItems([p[0] for p in self.PLATFORMS]); self.platform.hide()

        # ---- stage card: toolbar + (welcome | web view)
        self.stageCard = QWidget(); self.stageCard.setObjectName('videoCard')
        sl = QVBoxLayout(self.stageCard); sl.setContentsMargins(0, 0, 0, 0); sl.setSpacing(0)
        tb = QWidget(); tb.setObjectName('videoToolbar')
        tl = QHBoxLayout(tb); tl.setContentsMargins(10, 8, 10, 8); tl.setSpacing(6)
        self.backBtn = QPushButton('\u25c0'); self.fwdBtn = QPushButton('\u25b6'); self.reloadBtn = QPushButton('\u21bb')
        for b in (self.backBtn, self.fwdBtn, self.reloadBtn):
            b.setObjectName('videoNav'); b.setCursor(Qt.PointingHandCursor); tl.addWidget(b)
        self.address = QLineEdit(); self.address.setObjectName('videoInput'); self.address.setPlaceholderText('Meeting address\u2026')
        tl.addWidget(self.address, 1)
        self.focusBtn = QPushButton('\u2922  Focus'); self.focusBtn.setObjectName('videoGhost'); self.focusBtn.setCheckable(True)
        self.focusBtn.setToolTip('Hide the header and join panel so the meeting fills the tab')
        tl.addWidget(self.focusBtn)
        sl.addWidget(tb)

        self.stack = QStackedWidget()
        self.welcome = self._build_welcome()
        self.webView = QWebEngineView()
        self.stack.addWidget(self.welcome); self.stack.addWidget(self.webView)
        sl.addWidget(self.stack, 1)
        self._attach_current_browser_profile()
        bl.addWidget(self.stageCard, 1)

        self.status = QLabel('Ready'); self.status.setObjectName('videoStatus'); bl.addWidget(self.status)
        root.addWidget(body, 1)

        # ---- wiring
        self.openHere.clicked.connect(self.open_here)
        self.openDefault.clicked.connect(self.open_default)
        self.newMeet.clicked.connect(self.start_new_meet)
        self.input.returnPressed.connect(self.open_here)
        self.address.returnPressed.connect(self.navigate_address)
        self.backBtn.clicked.connect(self._go_back)
        self.fwdBtn.clicked.connect(self._go_forward)
        self.reloadBtn.clicked.connect(self._reload)
        self.focusBtn.toggled.connect(self._toggle_focus)
        self.recent.activated.connect(self._use_recent)
        self.webView.urlChanged.connect(self._url_changed)
        self.webView.loadStarted.connect(lambda: self.status.setText('Loading\u2026'))
        self.webView.loadFinished.connect(lambda ok: self.status.setText((self.webView.title() or 'Ready') if ok else 'Page failed to load'))
        self._load_recents()
        self._set_platform('Google Meet')

    # ------------------------------------------------------------- building
    def _build_welcome(self):
        page = QWidget(); page.setObjectName('videoWelcome')
        v = QVBoxLayout(page); v.setContentsMargins(20, 20, 20, 20); v.setSpacing(10)
        v.addStretch(1)
        icon = QLabel('\U0001F4F9'); icon.setAlignment(Qt.AlignCenter); icon.setStyleSheet('font-size:44px;background:transparent;')
        title = QLabel('Start or join a meeting'); title.setObjectName('videoHeroTitle'); title.setAlignment(Qt.AlignCenter)
        sub = QLabel('Pick a platform above, paste your link or meeting ID, and press Join.\nYour camera and microphone permissions are asked the first time.')
        sub.setObjectName('videoHeroSub'); sub.setAlignment(Qt.AlignCenter)
        v.addWidget(icon); v.addWidget(title); v.addWidget(sub)
        tiles = QHBoxLayout(); tiles.setSpacing(12); tiles.addStretch(1)
        for name, ic, desc, _ph in self.PLATFORMS[:3]:
            b = QPushButton('%s\n%s\n%s' % (ic, name, desc)); b.setObjectName('videoTile'); b.setCursor(Qt.PointingHandCursor)
            b.setMaximumWidth(230)
            b.clicked.connect(lambda _=False, n=name: self._tile_clicked(n))
            tiles.addWidget(b)
        tiles.addStretch(1)
        v.addSpacing(8); v.addLayout(tiles); v.addStretch(2)
        return page

    # -------------------------------------------------------------- behaviour
    def _set_platform(self, name):
        self._platform = name
        if name in self.pills:
            self.pills[name].setChecked(True)
        self.platform.setCurrentText(name)
        for n, _ic, _d, ph in self.PLATFORMS:
            if n == name:
                self.input.setPlaceholderText(ph)

    def _tile_clicked(self, name):
        self._set_platform(name); self.input.setFocus()

    def _refresh_profile_chip(self):
        name = 'Default'
        try:
            combo = getattr(self.browser_tab, 'profileCombo', None)
            if combo is not None and combo.currentText() and not combo.currentText().startswith('+'):
                name = combo.currentText()
        except Exception:
            pass
        self.profileChip.setText('\U0001F464  Profile: %s' % name)

    def showEvent(self, e):
        super().showEvent(e)
        self._refresh_profile_chip()

    def _show_web(self):
        self.stack.setCurrentWidget(self.webView)

    def _url_changed(self, u):
        txt = u.toString()
        if txt and txt != 'about:blank':
            self.address.setText(txt)

    def _go_back(self):
        if self.stack.currentWidget() is self.webView and self.webView.history().canGoBack():
            self.webView.back()
        else:
            self.stack.setCurrentWidget(self.welcome)

    def _go_forward(self):
        if self.webView.history().canGoForward():
            self._show_web(); self.webView.forward()

    def _reload(self):
        if self.stack.currentWidget() is self.webView:
            self.webView.reload()

    def _toggle_focus(self, on):
        self.header.setVisible(not on)
        self.joinCard.setVisible(not on)
        self.focusBtn.setText('\u2923  Exit focus' if on else '\u2922  Focus')

    def open_here(self):
        if not self.input.text().strip():
            QMessageBox.information(self, 'Meeting', 'Enter a meeting link or ID first.'); return
        self._attach_current_browser_profile()
        self._show_web(); self.webView.load(QUrl(self._url()))
        self._remember(self.input.text().strip())

    def navigate_address(self):
        t = self.address.text().strip()
        if not t:
            return
        self._attach_current_browser_profile()
        if not t.startswith(('http://', 'https://')):
            t = 'https://' + t
        self._show_web(); self.webView.load(QUrl(t))

    def start_new_meet(self):
        self._set_platform('Google Meet')
        self._attach_current_browser_profile()
        self._show_web(); self.webView.load(QUrl('https://meet.google.com/new'))

    # ---------------------------------------------------------------- recents
    def _load_recents(self):
        self.recent.clear()
        self.recent.addItem('Choose a recent meeting\u2026', None)
        try:
            items = json.loads(self._recent_file.read_text(encoding='utf-8')) if self._recent_file.exists() else []
        except Exception:
            items = []
        for it in items[:8]:
            try:
                label = '%s  \u00b7  %s' % (it['platform'], it['value'] if len(it['value']) <= 46 else it['value'][:43] + '\u2026')
                self.recent.addItem(label, it)
            except Exception:
                continue

    def _remember(self, value):
        entry = {'platform': self._platform, 'value': value}
        items = []
        for i in range(1, self.recent.count()):
            d = self.recent.itemData(i)
            if d and d != entry:
                items.append(d)
        items.insert(0, entry)
        try:
            self._recent_file.parent.mkdir(parents=True, exist_ok=True)
            self._recent_file.write_text(json.dumps(items[:8]), encoding='utf-8')
        except Exception:
            pass
        self._load_recents()

    def _use_recent(self, index):
        d = self.recent.itemData(index)
        if d:
            self._set_platform(d.get('platform', 'Custom URL'))
            self.input.setText(d.get('value', ''))
            self.input.setFocus()


# Jesson Reader: additive editor/playback improvements. Existing engines remain above.
from PyQt5.QtCore import QSignalBlocker
from PyQt5.QtWidgets import QFrame
from PyQt5.QtGui import QTransform, QTextDocument
import tempfile
import hashlib


def discover_icon_path():
    """Use an explicit icon or any valid ICO beside the source/executable/bundle."""
    roots = []
    if getattr(sys, 'frozen', False):
        roots.append(Path(sys.executable).resolve().parent)
    roots.extend([Path(__file__).resolve().parent, Path(getattr(sys, '_MEIPASS', Path(__file__).resolve().parent)), Path.cwd()])
    candidates = []
    if os.environ.get('JESSON_ICON'):
        candidates.append(Path(os.environ['JESSON_ICON']).expanduser())
    for root in dict.fromkeys(roots):
        try:
            candidates.extend(sorted((p for p in root.iterdir() if p.is_file() and p.suffix.lower() == '.ico'),
                                     key=lambda p: (p.name.casefold() != 'jesson_app.ico', p.name.casefold())))
        except OSError:
            continue
    for path in candidates:
        if path.is_file() and not QIcon(str(path)).pixmap(32, 32).isNull():
            return str(path)
    return None


def reader_icon():
    path = discover_icon_path()
    if path:
        return QIcon(path)
    # A readable fallback, not a substitute claim for the user's supplied artwork.
    pix = QPixmap(128, 128); pix.fill(Qt.transparent)
    painter = QPainter(pix); painter.setRenderHint(QPainter.Antialiasing)
    painter.setBrush(QColor('#2857a4')); painter.setPen(Qt.NoPen)
    painter.drawRoundedRect(QRectF(4, 4, 120, 120), 24, 24)
    painter.setPen(Qt.white); painter.setFont(QFont('Sans Serif', 65, QFont.Bold))
    painter.drawText(pix.rect(), Qt.AlignCenter, 'J'); painter.end()
    return QIcon(pix)


class ReliableMusicPlayerTab(RefinedMusicPlayerTab):
    """The queue is a model; the player receives exactly the selected file.

    Qt's automatic playlist error-advance is deliberately disconnected. Only a
    real EndOfMedia advances the queue. No timer can later select an old click.
    """
    def __init__(self):
        self._play_requested = False
        self._queue_busy = False
        super().__init__()
        self.mediaPlayer.setPlaylist(None)
        self.mediaPlayer.setParent(self)
        self.playlist.setParent(self)
        self.playlist.currentIndexChanged.connect(self._load_index)
        self.mediaPlayer.mediaStatusChanged.connect(self._media_status)
        self.mediaPlayer.error.connect(self.handle_media_error)
        for shortcut in self.findChildren(QShortcut):
            shortcut.setContext(Qt.WidgetWithChildrenShortcut)
        self.btnPlay.setToolTip('Play or pause the selected track (Space)')
        self.btnPrev.setToolTip('Previous track'); self.btnNext.setToolTip('Next track')
        self.playlistView.setAccessibleName('Music queue')

    def _load_index(self, index):
        if self._queue_busy:
            return
        if not 0 <= index < self.playlistView.count():
            self.mediaPlayer.stop(); return
        item = self.playlistView.item(index)
        path = item.data(Qt.UserRole) or ''
        self.playlistView.setCurrentItem(item)
        if not os.path.isfile(path):
            self._play_requested = False
            self.mediaPlayer.stop()
            self.trackSub.setText('File unavailable. Locate this track or remove it from the queue.')
            return
        self.trackSub.setText('Loading…')
        self.mediaPlayer.stop()
        self.mediaPlayer.setMedia(QMediaContent(QUrl.fromLocalFile(os.path.abspath(path))))
        if self._play_requested:
            self.mediaPlayer.play()

    def play_selected(self, item):
        if item is None:
            return
        self._sync_playlist_from_view()
        index = self.playlistView.row(item)
        self._play_requested = True
        if self.playlist.currentIndex() == index:
            self._load_index(index)
        else:
            self.playlist.setCurrentIndex(index)

    def toggle_play_pause(self):
        state = self.mediaPlayer.state()
        if state == QMediaPlayer.PlayingState:
            self._play_requested = False; self.mediaPlayer.pause()
        elif state == QMediaPlayer.PausedState:
            self._play_requested = True; self.mediaPlayer.play()
        else:
            item = self.playlistView.currentItem()
            if item is None and self.playlistView.count():
                item = self.playlistView.item(0)
            self.play_selected(item)

    def _sync_playlist_from_view(self, preserve_path=None):
        paths = self._paths_in_view()
        before = [self.playlist.media(i).canonicalUrl().toLocalFile() for i in range(self.playlist.mediaCount())]
        if [self._norm(p) for p in before] == [self._norm(p) for p in paths]:
            return
        current = preserve_path or self.mediaPlayer.currentMedia().canonicalUrl().toLocalFile()
        old_row = self.playlistView.currentRow()
        self._queue_busy = True
        blocker = QSignalBlocker(self.playlist)
        try:
            self.playlist.clear()
            # Retain missing entries so the row/media indexes never shift silently.
            for path in paths:
                self.playlist.addMedia(QMediaContent(QUrl.fromLocalFile(os.path.abspath(path))))
            index = next((i for i, p in enumerate(paths) if self._norm(p) == self._norm(current)), -1)
            if index < 0 and paths:
                index = min(max(0, old_row), len(paths) - 1)
            self.playlist.setCurrentIndex(index)
        finally:
            del blocker
            self._queue_busy = False
        if current and not any(self._norm(p) == self._norm(current) for p in paths):
            self._play_requested = False; self.mediaPlayer.stop()
        self._update_track_count()

    def remove_music(self):
        indexes = sorted((self.playlistView.row(i) for i in self.playlistView.selectedItems()), reverse=True)
        for index in indexes:
            self.playlistView.takeItem(index)
        self._sync_playlist_from_view()
        self._filter_queue(self.queueSearch.text())

    def load_playlist(self):
        self._play_requested = False
        super().load_playlist()

    def _clear_queue_safely(self):
        self._play_requested = False
        super()._clear_queue_safely()

    def _media_status(self, status):
        if status == QMediaPlayer.InvalidMedia:
            self.handle_media_error(getattr(self.mediaPlayer, "error_code", QMediaPlayer.FormatError) or QMediaPlayer.FormatError)
        elif status == QMediaPlayer.EndOfMedia and self._play_requested:
            old = self.playlist.currentIndex()
            self.playlist.next()
            if self.playlist.currentIndex() == old:
                if self._repeat_on:
                    self._load_index(old)
                else:
                    self._play_requested = False

    def handle_media_error(self, error):
        if error == QMediaPlayer.NoError:
            return
        self._play_requested = False
        self.mediaPlayer.stop()
        self.trackSub.setText('Cannot play this file. Check that the file is readable and the bundled VLC runtime is present.')
        self.trackSub.setToolTip('Playback stayed on the selected track; it was not silently skipped.')


class PhysicalRuler(RulerWidget):
    def _ppc(self):
        # The whole page/ruler is scaled once by the graphics view.
        return CM


class PagedOverlay(WordPageOverlay):
    def __init__(self, tab, parent):
        super().__init__(parent); self.tab = tab

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)
        width, height = self.tab._paper_metrics()
        step = height + self.tab.PAGE_GAP
        pages = self.tab._page_count()
        for page in range(pages):
            y = page * step
            painter.fillRect(QRectF(0, y + height, width, self.tab.PAGE_GAP), QColor('#d8dde5'))
            painter.setPen(QColor('#b9c1ce'))
            painter.drawLine(0, y, int(width), y)
            painter.drawLine(0, int(y + height), int(width), int(y + height))
            painter.save(); painter.translate(0, y)
            self.tab._paint_page_decoration(painter, page, pages)
            painter.restore()
        painter.end()


class WordDocumentTab(V10DocumentTab):
    """Preserve the existing writer commands; improve its physical page canvas."""
    PAGE_GAP = 24

    def merge_char_format(self, fmt):
        # The old helper applied a selection twice, requiring two undo actions.
        cursor = self.textEdit.textCursor()
        if cursor.hasSelection():
            cursor.beginEditBlock(); cursor.mergeCharFormat(fmt); cursor.endEditBlock()
            self.textEdit.setTextCursor(cursor)
        else:
            self.textEdit.mergeCurrentCharFormat(fmt)

    def _group(self, title, widgets):
        box = QWidget(); layout = QVBoxLayout(box)
        layout.setContentsMargins(8, 5, 8, 3); layout.setSpacing(4)
        grid = QGridLayout(); grid.setSpacing(3)
        if widgets and isinstance(widgets[0], QFontComboBox):
            widgets[0].setFixedWidth(170); widgets[1].setFixedWidth(55)
            grid.addWidget(widgets[0], 0, 0, 1, 4); grid.addWidget(widgets[1], 0, 4)
            for index, widget in enumerate(widgets[2:]):
                grid.addWidget(widget, 1, index)
        else:
            columns = max(1, math.ceil(len(widgets) / 2))
            for index, widget in enumerate(widgets):
                grid.addWidget(widget, index // columns, index % columns)
        layout.addLayout(grid)
        label = QLabel(title); label.setAlignment(Qt.AlignCenter)
        label.setStyleSheet('color:#627084;font-size:10px;')
        layout.addWidget(label)
        return box

    def __init__(self):
        self._physical_canvas = False
        super().__init__()
        old_host = self.pageScroll.takeWidget()
        old_host.layout().removeWidget(self.pageFrame)
        self.pageFrame.setParent(None)
        self.pageFrame.layout().setContentsMargins(0, 0, 0, 0)
        self.pageFrame.layout().setSpacing(0)
        old_ruler = self.ruler
        self.pageFrame.layout().removeWidget(old_ruler); old_ruler.deleteLater()
        self.ruler = PhysicalRuler(self)
        self.pageFrame.layout().insertWidget(0, self.ruler); self.ruler.hide()
        self.pageScene = QGraphicsScene(self)
        self.pageProxy = self.pageScene.addWidget(self.pageFrame)
        self.pageCanvas = QGraphicsView(self.pageScene)
        self.pageCanvas.setFrameShape(QFrame.NoFrame)
        self.pageCanvas.setAlignment(Qt.AlignLeft | Qt.AlignTop)
        self.pageCanvas.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.pageCanvas.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.pageCanvas.setStyleSheet('background:transparent;border:0;')
        self.pageCanvas.setRenderHint(QPainter.TextAntialiasing)
        host = QWidget(); row = QHBoxLayout(host)
        row.setContentsMargins(24, 24, 24, 24)
        row.addStretch(); row.addWidget(self.pageCanvas); row.addStretch()
        self.pageScroll.setWidget(host); old_host.deleteLater()
        self.textEdit.setFrameShape(QFrame.NoFrame)
        self.textEdit.setViewportMargins(0, 0, 0, 0)
        self.pageOverlay.hide(); self.pageOverlay.deleteLater()
        self.pageOverlay = PagedOverlay(self, self.textEdit.viewport())
        self.pageOverlay.show()
        # Status signals can fire as soon as the physical canvas is enabled.
        self.documentTitle = self.findChild(QLabel, 'docTitle')
        self._physical_canvas = True
        self.wordTabs.setStyleSheet(self.wordTabs.styleSheet() + ' #wordRibbonTabs QWidget{background:#fbfbfb;}')
        home = self._page_layout('Home').parentWidget()
        self.fontCombo = home.findChild(QFontComboBox)
        self.sizeSpin = home.findChild(QSpinBox)
        for label, name in [('B', 'boldBtn'), ('I', 'italicBtn'), ('U', 'underlineBtn')]:
            button = next(b for b in home.findChildren(QPushButton) if b.text() == label)
            button.setCheckable(True); setattr(self, name, button)
        self.textEdit.document().setDefaultFont(QFont('Calibri', 12))
        title = self.findChild(QLabel, 'docTitle')
        self.documentTitle = title
        strip = title.parentWidget().layout()
        for label, fn, tip in [('↶', self.text_undo, 'Undo'), ('↷', self.text_redo, 'Redo'),
                               ('Save', self.save_document, 'Save (Ctrl+S)')]:
            button = QPushButton(label); button.setToolTip(tip)
            button.setStyleSheet('QPushButton{color:white;background:transparent;border:0;padding:5px 10px;} QPushButton:hover{background:#416dac;}')
            button.clicked.connect(self._safe(fn)); strip.insertWidget(strip.count() - 1, button)
        bottom = self.findChild(QWidget, 'bottomBar').layout()
        self.pageStatus.hide()
        self.pageStatus = QLabel('Page 1 of 1'); bottom.insertWidget(1, self.pageStatus)
        self.textEdit.cursorPositionChanged.connect(self._update_document_status)
        self.textEdit.document().modificationChanged.connect(self._update_document_status)
        self.textEdit.cursorPositionChanged.connect(self._scroll_to_cursor)
        self.pageScroll.viewport().installEventFilter(self)
        for shortcut in self.findChildren(QShortcut):
            shortcut.setContext(Qt.WidgetWithChildrenShortcut)
        # File menu actions are labels only; avoid competing application-wide shortcuts.
        for button in self.findChildren(QToolButton):
            if button.text() == 'File' and button.menu():
                for action in button.menu().actions():
                    action.setShortcut(QKeySequence())
                action = button.menu().addAction('Save As…'); action.triggered.connect(self.save_as_document)
        for keys, fn in [('Ctrl+N', self.new_document), ('Ctrl+O', self.load_document),
                          ('Ctrl+Shift+S', self.save_as_document), ('Ctrl+P', self.print_document),
                          ('Ctrl+L', lambda: self.set_align('left')), ('Ctrl+E', lambda: self.set_align('center')),
                          ('Ctrl+R', lambda: self.set_align('right')), ('Ctrl+J', lambda: self.set_align('justify'))]:
            self._sc(keys, fn)
        self._add_to('View', 'Page zoom', [self._t('Page Width', self.fit_page_width)])
        self._wrap_ribbon_pages()
        self._apply_page_setup()
        self._autosave_path = Path(app_data_dir()) / 'recovery' / 'autosave_document.html'
        self.textEdit.document().setModified(False)
        self._update_document_status()

    def _page_layout(self, name):
        for index in range(self.wordTabs.count()):
            if self.wordTabs.tabText(index) == name:
                widget = self.wordTabs.widget(index)
                if isinstance(widget, QScrollArea):
                    widget = widget.widget()
                return widget.layout()
        return None

    def _paper_metrics(self):
        width, height = PAPER_PX.get(self._paper, PAPER_PX['A4'])
        return (height, width) if self._orient == 'Landscape' else (width, height)

    def _apply_page_setup(self):
        if not self._physical_canvas:
            return super()._apply_page_setup()
        width, height = self._paper_metrics()
        top, left, bottom, right = self._margins_px
        if left + right >= width - 80 or top + bottom >= height - 80:
            if hasattr(self, '_valid_page_setup'):
                self._paper, self._orient, self._margins_px = self._valid_page_setup
            raise _Note('Margins must leave at least 80 pixels of writing space in both directions.')
        self._valid_page_setup = (self._paper, self._orient, self._margins_px)
        document = self.textEdit.document()
        fmt = document.rootFrame().frameFormat()
        fmt.setTopMargin(top); fmt.setLeftMargin(left)
        fmt.setBottomMargin(bottom + self.PAGE_GAP); fmt.setRightMargin(right)
        document.rootFrame().setFrameFormat(fmt)
        document.setPageSize(QSizeF(width, height + self.PAGE_GAP))
        self._sync_document_pages()

    def _sync_document_pages(self):
        if not getattr(self, '_physical_canvas', False):
            return super()._sync_document_pages()
        if self._syncing_pages:
            return
        self._syncing_pages = True
        try:
            width, height = self._paper_metrics()
            pages = self._page_count()
            editor_height = pages * (height + self.PAGE_GAP)
            self.textEdit.setFixedSize(int(width), int(editor_height))
            frame_height = editor_height + (22 if self.ruler.isVisible() else 0)
            self.pageFrame.setFixedSize(int(width), int(frame_height))
            self.pageScene.setSceneRect(0, 0, width, frame_height)
            factor = self._doc_zoom / 100.0
            self.pageCanvas.setTransform(QTransform().scale(factor, factor))
            self.pageCanvas.setFixedSize(math.ceil(width * factor) + 2, math.ceil(frame_height * factor) + 2)
            self.pageOverlay.setGeometry(self.textEdit.viewport().rect()); self.pageOverlay.raise_()
            self.pageOverlay.set_metrics(height + self.PAGE_GAP, self.header_text, self.footer_text)
            self.pageScroll.widget().setMinimumSize(math.ceil(width * factor) + 50, math.ceil(frame_height * factor) + 50)
            self._update_document_status()
        finally:
            self._syncing_pages = False

    def _set_page_zoom(self, value):
        if not getattr(self, '_physical_canvas', False):
            return super()._set_page_zoom(value)
        self._doc_zoom = max(50, min(200, int(value)))
        self.zoomValue.setText(f'{self._doc_zoom}%'); self.zoomLabel.setText(f'{self._doc_zoom}%')
        self._sync_document_pages()

    def change_zoom(self, delta):
        self._set_page_zoom(self._doc_zoom + delta)

    def fit_page_width(self):
        width, _ = self._paper_metrics()
        self._set_page_zoom(int(100 * max(100, self.pageScroll.viewport().width() - 52) / width))

    def _scroll_to_cursor(self):
        if not getattr(self, '_physical_canvas', False):
            return super()._scroll_to_cursor()
        rect = self.textEdit.cursorRect()
        factor = self._doc_zoom / 100.0
        y = 24 + (rect.y() + (22 if self.ruler.isVisible() else 0)) * factor
        bar = self.pageScroll.verticalScrollBar()
        visible_height = self.pageScroll.viewport().height()
        if y < bar.value() + 24:
            bar.setValue(max(0, int(y - 24)))
        elif y + rect.height() * factor > bar.value() + visible_height - 24:
            bar.setValue(int(y + rect.height() * factor - visible_height + 24))

    def eventFilter(self, obj, event):
        if getattr(self, '_physical_canvas', False) and event.type() == QEvent.Wheel and event.modifiers() & Qt.ControlModifier:
            self._set_page_zoom(self._doc_zoom + (10 if event.angleDelta().y() > 0 else -10))
            return True
        return super().eventFilter(obj, event)

    def _update_document_status(self, *_):
        if not hasattr(self, 'pageStatus') or getattr(self, 'documentTitle', None) is None:
            return
        document = self.textEdit.document()
        width, height = self._paper_metrics()
        block = self.textEdit.textCursor().block()
        y = document.documentLayout().blockBoundingRect(block).top()
        page = min(self._page_count(), max(1, int(y // (height + self.PAGE_GAP)) + 1))
        text = self.textEdit.toPlainText()
        self.wordCountLabel.setText(f'Words: {len(text.split())} · Characters: {len(text)}')
        self.pageStatus.setText(f'Page {page} of {self._page_count()}')
        name = Path(self.current_file).name if self.current_file else 'Document — Jesson Writer'
        self.documentTitle.setText(name + (' • Unsaved' if document.isModified() else ''))

    def update_page_status(self):
        if getattr(self, '_physical_canvas', False):
            self._update_document_status()
        else:
            super().update_page_status()

    def _paint_page_decoration(self, painter, page, pages):
        width, height = self._paper_metrics()
        top, left, bottom, right = self._margins_px
        painter.save()
        overlay = self.pageOverlay
        if overlay.watermark:
            painter.translate(width / 2, height / 2); painter.rotate(-45)
            font = QFont('Sans Serif', 44, QFont.Bold); font.setPixelSize(59); painter.setFont(font)
            painter.setPen(QColor(120, 120, 120, 55))
            painter.drawText(QRectF(-width, -80, width * 2, 160), Qt.AlignCenter, overlay.watermark)
            painter.restore(); painter.save()
        font = QFont('Sans Serif', 9); font.setPixelSize(12)
        painter.setFont(font); painter.setPen(QColor('#697386'))
        for text, align, y in [(self.header_text, self.header_align, max(0, top / 2 - 12)),
                               (self.footer_text, self.footer_align, height - max(24, bottom / 2 + 12))]:
            if text:
                text = text.replace('{page}', str(page + 1)).replace('{pages}', str(pages))
                painter.drawText(QRectF(left, y, width - left - right, 24), align | Qt.AlignVCenter, text)
        painter.restore()

    def _render_printer(self, printer):
        self._apply_page_setup()
        self._configure_printer(printer); printer.setFullPage(True)
        painter = QPainter(printer)
        if not painter.isActive():
            raise OSError('The printer or PDF output could not be opened.')
        width, height = self._paper_metrics()
        pages = self._page_count()
        try:
            for page in range(pages):
                if page and not printer.newPage():
                    raise OSError('A new print page could not be created.')
                painter.save(); painter.scale(printer.width() / width, printer.height() / height)
                painter.setClipRect(QRectF(0, 0, width, height))
                painter.save(); painter.translate(0, -page * (height + self.PAGE_GAP))
                self.textEdit.document().drawContents(painter, QRectF(0, page * (height + self.PAGE_GAP), width, height))
                painter.restore(); self._paint_page_decoration(painter, page, pages); painter.restore()
        finally:
            painter.end()

    def print_document(self):
        printer = QPrinter(QPrinter.HighResolution); self._configure_printer(printer)
        if QPrintDialog(printer, self).exec_() == QDialog.Accepted:
            self._render_printer(printer)

    def print_preview(self):
        printer = QPrinter(QPrinter.HighResolution); self._configure_printer(printer)
        preview = QPrintPreviewDialog(printer, self)
        preview.paintRequested.connect(self._render_printer); preview.exec_()

    def _export_pdf_direct(self):
        path, _ = QFileDialog.getSaveFileName(self, 'Export PDF', '', 'PDF (*.pdf)')
        if path:
            self._write_document(path if path.lower().endswith('.pdf') else path + '.pdf')

    def _write_document(self, path):
        path = Path(path); suffix = path.suffix.lower()
        if suffix not in ('.docx', '.html', '.htm', '.txt', '.pdf'):
            raise _Note('Choose DOCX, HTML, TXT or PDF.')
        handle, temporary = tempfile.mkstemp(dir=str(path.parent), suffix=suffix)
        os.close(handle)
        try:
            if suffix == '.docx':
                self._export_docx(temporary)
            elif suffix in ('.html', '.htm'):
                Path(temporary).write_text(self.textEdit.toHtml(), encoding='utf-8')
            elif suffix == '.txt':
                Path(temporary).write_text(self.textEdit.toPlainText(), encoding='utf-8')
            else:
                printer = QPrinter(QPrinter.HighResolution)
                printer.setOutputFormat(QPrinter.PdfFormat); printer.setOutputFileName(temporary)
                self._render_printer(printer)
            os.replace(temporary, path)
        finally:
            if os.path.exists(temporary):
                os.unlink(temporary)
        if suffix != '.pdf':
            self._save_metadata(path)
            self.current_file = str(path); self.current_format = suffix.lstrip('.')
            self.textEdit.document().setModified(False)
        self._update_document_status()
        return True

    def _save_metadata(self, path):
        # HTML cannot represent Qt's custom comment/change properties itself.
        marks = []
        for start, end, fmt in self._frags():
            props = {str(prop): fmt.property(prop) for prop in (P_INS, P_DEL, P_CMT) if fmt.hasProperty(prop)}
            if props:
                marks.append([start, end, props])
        saved_comments = {}
        for cid, info in self.comments.items():
            saved = dict(info)
            if isinstance(saved.get('time'), datetime.datetime):
                saved['time'] = saved['time'].isoformat()
            saved_comments[cid] = saved
        metadata = {'version': 1, 'textHash': hashlib.sha256(self.textEdit.toPlainText().encode('utf-8')).hexdigest(),
                    'comments': saved_comments, 'sources': self.sources, 'marks': marks,
                    'paper': self._paper, 'orientation': self._orient, 'margins': self._margins_px,
                    'header': self.header_text, 'footer': self.footer_text,
                    'headerAlign': int(self.header_align), 'footerAlign': int(self.footer_align),
                    'watermark': self.pageOverlay.watermark, 'author': self.doc_author, 'title': self.doc_title}
        target = Path(str(path) + '.jesson.json')
        fd, temporary = tempfile.mkstemp(dir=str(target.parent), suffix='.json')
        try:
            with os.fdopen(fd, 'w', encoding='utf-8') as handle:
                json.dump(metadata, handle, ensure_ascii=False, indent=2)
            os.replace(temporary, target)
        finally:
            if os.path.exists(temporary):
                os.unlink(temporary)

    def _restore_metadata(self, path):
        target = Path(str(path) + '.jesson.json')
        if not target.is_file() or target.stat().st_size > 5_000_000:
            return
        try:
            data = json.loads(target.read_text(encoding='utf-8'))
            digest = hashlib.sha256(self.textEdit.toPlainText().encode('utf-8')).hexdigest()
            if data.get('version') != 1 or data.get('textHash') != digest:
                return
            self.comments = {int(k): v for k, v in data.get('comments', {}).items()}
            for info in self.comments.values():
                info['time'] = datetime.datetime.fromisoformat(info['time']) if info.get('time') else datetime.datetime.now()
            self._next_cmt = max(self.comments, default=0) + 1
            self.sources = data.get('sources', [])
            if data.get('paper') in PAPER_PX:
                self._paper = data['paper']
            if data.get('orientation') in ('Portrait', 'Landscape'):
                self._orient = data['orientation']
            margins = data.get('margins')
            width, height = self._paper_metrics()
            if (isinstance(margins, list) and len(margins) == 4 and
                all(isinstance(v, (int, float)) and math.isfinite(v) and v >= 0 for v in margins) and
                margins[1] + margins[3] < width - 80 and margins[0] + margins[2] < height - 80):
                self._margins_px = tuple(margins)
            self.header_text = str(data.get('header', '')); self.footer_text = str(data.get('footer', ''))
            self.header_align = Qt.Alignment(data.get('headerAlign', int(Qt.AlignLeft)))
            self.footer_align = Qt.Alignment(data.get('footerAlign', int(Qt.AlignLeft)))
            self.pageOverlay.watermark = str(data.get('watermark', ''))
            self.doc_author = str(data.get('author', 'Author')); self.doc_title = str(data.get('title', ''))
            document = self.textEdit.document()
            for start, end, props in data.get('marks', []):
                if not 0 <= start < end < document.characterCount():
                    continue
                cursor = QTextCursor(document); cursor.setPosition(start)
                cursor.setPosition(end, QTextCursor.KeepAnchor)
                fmt = QTextCharFormat()
                for prop in (P_INS, P_DEL, P_CMT):
                    if str(prop) in props:
                        fmt.setProperty(prop, props[str(prop)])
                cursor.mergeCharFormat(fmt)
        except (OSError, ValueError, TypeError, KeyError):
            # A corrupt/stale sidecar must never prevent opening the main document.
            return

    def save_document(self):
        if self.current_file and Path(self.current_file).suffix.lower() in ('.docx', '.html', '.htm', '.txt'):
            return self._write_document(self.current_file)
        return self.save_as_document()

    def _autosave_tick(self):
        if not self.textEdit.document().isModified():
            return
        try:
            self._autosave_path.parent.mkdir(parents=True, exist_ok=True)
            fd, temporary = tempfile.mkstemp(dir=str(self._autosave_path.parent), suffix='.html')
            try:
                with os.fdopen(fd, 'w', encoding='utf-8') as handle:
                    handle.write(self.textEdit.toHtml())
                os.replace(temporary, self._autosave_path)
            finally:
                if os.path.exists(temporary):
                    os.unlink(temporary)
            self._save_metadata(self._autosave_path)
        except (OSError, TypeError, ValueError):
            # Autosave must not interrupt typing or mark the real document saved.
            return

    def recover_autosave(self):
        if not self._autosave_path.is_file():
            raise _Note('No recovery copy is available yet.')
        if not self.maybe_save():
            return
        if self._load_path(str(self._autosave_path)):
            self.current_file = None; self.current_format = 'html'
            self.textEdit.document().setModified(True)
            self._update_document_status()

    def save_as_document(self):
        path, selected = QFileDialog.getSaveFileName(self, 'Save As', self.current_file or 'Document.docx',
                    'Word Document (*.docx);;HTML Document (*.html);;Plain Text (*.txt);;PDF (*.pdf)')
        if not path:
            return False
        extension = re.search(r'\*([.][a-z]+)', selected)
        if not Path(path).suffix and extension:
            path += extension.group(1)
        return self._write_document(path)

    def maybe_save(self):
        if not self.textEdit.document().isModified():
            return True
        answer = QMessageBox.question(self, 'Unsaved document', 'Save your changes before continuing?',
                      QMessageBox.Save | QMessageBox.Discard | QMessageBox.Cancel, QMessageBox.Save)
        if answer == QMessageBox.Cancel:
            return False
        if answer == QMessageBox.Save:
            try:
                return bool(self.save_document()) and not self.textEdit.document().isModified()
            except Exception:
                QMessageBox.warning(self, 'Save failed', 'The document could not be saved. Your changes remain open.')
                return False
        return True

    def new_document(self):
        if not self.maybe_save():
            return
        self._tc_busy = True
        try:
            self.textEdit.clear(); self.current_file = None; self.current_format = None
            self.comments.clear(); self.sources.clear()
            self.footnotes.clear()
            self.header_text = ''; self.footer_text = ''; self.pageOverlay.watermark = ''
        finally:
            self._tc_busy = False
        self._refresh_comments(); self._apply_page_setup()
        self.textEdit.document().setModified(False)
        if self._tracking:
            self._snapshot()
        self._update_document_status()

    def load_document(self):
        if not self.maybe_save():
            return
        path, _ = QFileDialog.getOpenFileName(self, 'Open Document', '', 'Documents (*.docx *.html *.htm *.txt *.pdf)')
        if not path:
            return
        self._load_path(path)

    def _mm_set_html(self, html):
        super()._mm_set_html(html)
        self._apply_page_setup()

    def _load_path(self, path):
        # Existing importer remains callable; native HTML retains advanced metadata.
        self._tc_busy = True
        try:
            if not self._load_document_path(path):
                return False
            self.comments.clear(); self.sources.clear()
            self.header_text = ''; self.footer_text = ''; self.pageOverlay.watermark = ''
            self._restore_metadata(path)
        finally:
            self._tc_busy = False
        self._apply_page_setup()
        self._refresh_comments(); self._refresh_nav()
        if self._tracking:
            self._snapshot()
        self.textEdit.document().setModified(False)
        self._update_document_status()
        return True



class MainWindow(QMainWindow):
    def set_wallpaper(self,path):
        self._wallpaper_path=path
        self._wallpaper=QPixmap(path) if path and os.path.exists(path) else QPixmap()
        self.update()

    def paintEvent(self,event):
        super().paintEvent(event)
        if getattr(self,'_wallpaper',QPixmap()).isNull(): return
        p=QPainter(self); pix=self._wallpaper.scaled(self.size(),Qt.KeepAspectRatioByExpanding,Qt.SmoothTransformation); p.setOpacity(0.22); p.drawPixmap((self.width()-pix.width())//2,(self.height()-pix.height())//2,pix); p.end()

    def apply_dialog_theme(self,bg,accent,text):
        # Dialog/menu styling only; avoids leaking button geometry into app tabs.
        extra=f"""QDialog,QMessageBox,QInputDialog{{background:{bg};color:{text};}} QDialog QLabel,QMessageBox QLabel,QInputDialog QLabel{{color:{text};}} QMenu{{background:{bg};color:{text};border:1px solid {accent};}} QMenu::item:selected{{background:{accent};color:white;}}"""
        self.setStyleSheet(self.styleSheet()+extra)

    def __init__(self):
        super().__init__()
        self.init_ui()
        self._apply_default_style()

    def _apply_default_style(self):
        default = """
            QMainWindow { background-color: #f5f5f5; }
            QSlider::groove:horizontal {
                height: 4px; background: #e5e7eb; border-radius: 2px;
            }
            QSlider::handle:horizontal {
                background: #6366f1; width: 14px; height: 14px;
                margin: -5px 0; border-radius: 7px;
            }
            QSlider::sub-page:horizontal { background: #6366f1; border-radius: 2px; }
            QStatusBar { background: #f9fafb; color: #6b7280; font-size: 11px;
                         border-top: 1px solid #e5e7eb; }
            QScrollBar:vertical { width: 8px; background: #f9fafb; border: none; }
            QScrollBar::handle:vertical {
                background: #d1d5db; border-radius: 4px; min-height: 24px;
            }
            QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical { height: 0; }
            QScrollBar:horizontal { height: 8px; background: #f9fafb; border: none; }
            QScrollBar::handle:horizontal { background: #d1d5db; border-radius: 4px; }
            QScrollBar::add-line:horizontal, QScrollBar::sub-line:horizontal { width: 0; }
        """
        self.setStyleSheet(default)
        # Store it so ThemesTab can restore it when switching back to Light
        self.themesTab._default_style = default

    def init_ui(self):
        self.setWindowTitle("Jesson Multifunction Application")
        self.setWindowIcon(reader_icon())
        QApplication.instance().setWindowIcon(self.windowIcon())
        self.setGeometry(100, 100, 1300, 780)
        self.setMinimumSize(900, 600)

        self.statusBar = QStatusBar()
        self.setStatusBar(self.statusBar)
        self.statusBar.showMessage("Ready  ·  Ctrl+1–9 / Ctrl+0 switch tabs  ·  top tabs scroll on smaller screens")

        self.tabs = QTabWidget()
        self.tabs.setObjectName("mainTabs")
        # The tab stylesheet — stored so ThemesTab can restore it on Light theme
        self._tab_style = """
            QTabWidget::pane { border: none; background: #f5f5f5; }
            QTabBar { background: #ffffff; border-bottom: 2px solid #e5e7eb; }
            QTabBar::tab {
                background: transparent; color: #6b7280;
                padding: 10px 18px; margin-right: 1px;
                border: none; border-bottom: 2px solid transparent;
                font-size: 12px; min-width: 90px;
            }
            QTabBar::tab:selected {
                color: #6366f1; font-weight: bold;
                border-bottom: 2px solid #6366f1;
            }
            QTabBar::tab:hover { color: #374151; }
            QTabBar::scroller { width: 20px; }
        """
        self.tabs.setStyleSheet(self._tab_style)
        self.tabs.tabBar().setElideMode(Qt.ElideNone)
        self.tabs.tabBar().setExpanding(False)
        self.tabs.setUsesScrollButtons(True)

        self.aiStudyTab     = QA5StudyAssistantTab()
        self.musicTab       = ReliableMusicPlayerTab()
        self.ttsTab         = TTSTab()
        self.calcTab        = V8CalculatorTab()
        self.docTab         = WordDocumentTab()
        self.pdfViewerTab   = PolishedPDFViewerTab()
        self.notesDrawingTab= V8NotesAndDrawingTab()
        self.searchTab      = SearchTab()
        self.videoTab       = V10VideoTab(self.searchTab)
        self.themesTab      = RefinedThemesTab(self)

        tab_list = [
            (self.aiStudyTab,      "✨  Study AI"),
            (self.musicTab,        "🎵  Music"),
            (self.ttsTab,          "🔊  Speech"),
            (self.calcTab,         "🧮  Calculator"),
            (self.docTab,          "📄  Document"),
            (self.pdfViewerTab,    "📑  PDF"),
            (self.notesDrawingTab, "📝  Notes & Draw"),
            (self.searchTab,       "🔍  Browser"),
            (self.videoTab,        "📹  Video"),
            (self.themesTab,       "🎨  Themes"),
        ]
        for widget, label in tab_list:
            self.tabs.addTab(widget, label)

        for i in range(min(9, len(tab_list))):
            QShortcut(QKeySequence(f"Ctrl+{i+1}"), self).activated.connect(lambda idx=i: self.tabs.setCurrentIndex(idx))
        if len(tab_list) >= 10:
            QShortcut(QKeySequence("Ctrl+0"), self).activated.connect(lambda: self.tabs.setCurrentIndex(9))

        self.tabs.currentChanged.connect(self._on_tab_changed)
        self.setCentralWidget(self.tabs)

    def closeEvent(self, event):
        worker = getattr(self.aiStudyTab, 'worker', None)
        if worker is not None and worker.isRunning():
            QMessageBox.information(self, 'Study request in progress',
                                    'Please wait for the current AI request to finish before closing.')
            event.ignore(); return
        if not self.docTab.maybe_save():
            event.ignore(); return
        self.musicTab.mediaPlayer.release()
        self.docTab.stop_reading()
        event.accept()

    def _on_tab_changed(self, index):
        name = self.tabs.tabText(index).strip().lstrip("✨🎵🔊🧮📄📑📝🔍📹🎨 ")
        self.statusBar.showMessage(f"{name}  ·  Use Ctrl+{index+1 if index < 9 else 0} or the scrollable tab bar")


# ---------------------------------------------------------------------------
# Crash guard: PyQt5 aborts the whole program (silently, with no window) when a
# button/signal handler raises an unhandled Python exception. Installing our own
# excepthook turns those into a log entry plus a dialog, and faulthandler records
# hard (native) crashes. Everything is written to ~/.jesson_reader/crash.log
# ---------------------------------------------------------------------------
_CRASH_LOG_HANDLE = None
_LAST_ERROR_DIALOG = [0.0]

def _install_crash_guard():
    global _CRASH_LOG_HANDLE
    import traceback as _tb
    log_dir = Path.home() / ".jesson_reader"
    try:
        log_dir.mkdir(parents=True, exist_ok=True)
    except Exception:
        pass
    log_path = log_dir / "crash.log"
    try:
        import faulthandler
        _CRASH_LOG_HANDLE = open(log_path, "a", buffering=1, encoding="utf-8")
        _CRASH_LOG_HANDLE.write("\n=== session started %s ===\n" % datetime.datetime.now().isoformat(timespec="seconds"))
        faulthandler.enable(file=_CRASH_LOG_HANDLE, all_threads=True)
    except Exception:
        pass

    def _hook(exc_type, exc, tb):
        text = "".join(_tb.format_exception(exc_type, exc, tb))
        try:
            with open(log_path, "a", encoding="utf-8") as fh:
                fh.write("\n[%s] Unhandled error\n%s" % (datetime.datetime.now().isoformat(timespec="seconds"), text))
        except Exception:
            pass
        try:
            sys.__stderr__.write(text)
        except Exception:
            pass
        try:
            app = QApplication.instance()
            if app is None or QThread.currentThread() != app.thread():
                return
            now = time.time()
            if now - _LAST_ERROR_DIALOG[0] < 3.0:      # never stack dialogs
                return
            _LAST_ERROR_DIALOG[0] = now
            short = "%s: %s" % (exc_type.__name__, exc)
            QTimer.singleShot(0, lambda: QMessageBox.warning(
                None, "Something went wrong",
                "The app hit an error but kept running:\n\n%s\n\nDetails were saved to:\n%s" % (short[:400], log_path)))
        except Exception:
            pass

    sys.excepthook = _hook

if __name__ == "__main__":
    import os
    _install_crash_guard()
    # Suppress QtWebEngine JavaScript console noise (SameSite cookie warnings, CSP errors, etc.)
    os.environ.setdefault("QTWEBENGINE_CHROMIUM_FLAGS", "--disable-logging --log-level=3")
    os.environ["QT_LOGGING_RULES"] = "*.debug=false;qt.webenginecontext*=false"

    # High-DPI attributes MUST be set before QApplication is constructed
    QApplication.setAttribute(Qt.AA_EnableHighDpiScaling, True)
    QApplication.setAttribute(Qt.AA_UseHighDpiPixmaps, True)

    app = QApplication(sys.argv)
    window = MainWindow()
    window.show()
    sys.exit(app.exec_())
