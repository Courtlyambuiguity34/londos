# Jesson Reader — current Windows bundle

This is your standalone reader, using the attached Jesson.zip as its starting point. It is independent of Londos. The download ZIP is stored in the Londos branch for convenience.

## Manual VLC, study plan and reading focus

See **MANUAL-VLC-AND-STUDY.md** for the complete folder layout and instructions. Both `vlc_runtime` and `vlc-runtime` are accepted without re-downloading a valid supplied runtime. Keep all helper files from this ZIP. **build_windows_offline.bat** performs no dependency or VLC downloads.

The new **Study Planner** provides a timetable builder, daily/weekly repeats, focus/break timer, daily goal, snoozing and Windows reminders after closing the app (enable them in the planner). **F11** enters reading focus; bottom-bar music controls and the timer remain visible. Original tab shortcuts are preserved; **Ctrl+Alt+P** opens Study Planner.

## Build and run on your Windows PC

1. Extract the entire ZIP into a folder you own. Keep all its Python files together.
2. Double-click **build_windows.bat**.
3. The batch checks for **64-bit Python 3.13**, starting with `D:\1\Python\Python313\python.exe`, then common install locations and `py -3.13`.
4. It checks your existing packages individually, creates **no virtual environment**, and installs only absent packages and absent dependencies. Installed package versions are constrained against replacement. Compatibility conflicts require manual resolution; presence alone is not proof of compatibility. Pip must already be available.
5. It prepares portable **VLC 3.0.24 x64** from VideoLAN, checking the archive against its published SHA-256. This is downloaded only when neither manual runtime directory is present. Valid manual runtimes are reused; incomplete ones stop the build. The full plugin tree, DLLs and distribution notices are retained. An incomplete runtime folder must be moved aside before retrying.
6. It builds and opens **dist\Jesson.exe**. Close an older running EXE before rebuilding.

The first build needs internet for missing packages and the VLC download. The source ZIP does not include the large native VLC runtime; the build fetches it. Subsequent builds reuse it. The resulting single EXE includes VLC and its plugins: the destination PC needs neither Python, VLC installation, nor a K-Lite codec pack for music playback. It still needs a functioning Windows audio device/driver. Damaged, unsupported, encrypted or DRM-protected files cannot be guaranteed playable.

No prebuilt Windows EXE, installer or API credentials are included. Windows builds must run on Windows. The actual Python 3.13 Windows EXE needs acceptance testing on your PC; cloud verification uses Python 3.12 on Linux.

To run the source using your existing Python after dependency preparation:

```bat
"D:\1\Python\Python313\python.exe" Jesson_Reader.py
```

For a diagnostic folder build:

```bat
"D:\1\Python\Python313\python.exe" prepare_vlc.py
"D:\1\Python\Python313\python.exe" build_app.py --name Jesson --console --zip
```

This creates `dist\Jesson\Jesson.exe` and losslessly compressed `dist\Jesson-portable.zip`. Distribute the entire folder, including `_internal`, or its ZIP. For a single EXE plus optional compressed download:

```bat
"D:\1\Python\Python313\python.exe" build_app.py --onefile --name Jesson --zip
```

Do not use the old uploaded `.spec` files: they contain machine-specific paths. They are preserved in your original attachment, but omitted from the updated download. The build helper regenerates its spec from the current folder.

## Changes in this update

- **Music codecs:** replaced Qt's platform-dependent playback backend with libVLC. The existing queue, shuffle/repeat, favourites, filtering, playlists, selection, seek and volume controls remain. Only a genuine end-of-media advances the queue; errors keep the selected track. Qt's playlist remains an ordering model, not the decoder. YouTube/meeting/browser playback still uses the browser; VLC does not replace the embedded browser.
- **PDF sticky notes:** choose Note, then click a location on the page. Notes appear as yellow cards with readable previews; click a card to read/edit the complete note or delete it. Existing PDF Text/FreeText annotations are accessible too. The **Page notes** sidebar keeps overlapping notes individually accessible. Cards follow zoom, fit, page navigation and rotation. The dialog uses Segoe Print for handwriting-style display where that font is installed, with normal font fallback elsewhere.
- **PDF persistence:** use Save As to write annotation changes into a PDF. Notes are standard PDF annotations, so other compatible PDF readers can open them. The yellow UI cards and their font are Jesson's display layer, not text stamped over the page. Printing retains the existing PDF rendering behavior rather than stamping these cards into page content.
- **Imported Word font changes:** programmatic ribbon synchronization no longer fires formatting callbacks. Choosing a font applies it to the selected text and returns typing focus to the editor. As in Word, select existing text to change its font; with no selection, the chosen font applies to subsequent typing, not the whole document.
- **Tables:** fixed the off-by-one cell selection that left a trailing digit behind. Replacing `3` repeatedly now keeps `3` instead of producing `33`. Single-digit cell reads also retain their digit. Replacements form one undo operation. Checked imported DOCX cells A2=1 and A3=2, repeated formula application/recalculation, changing A2 to 10, and undo.
- **Packaging:** preserved your `Jesson.exe` name and existing-Python workflow. Removed blanket collection of every google.genai submodule; PyInstaller follows the actual imports. Added optional maximum-level ZIP compression without removing files. Your supplied `neon_orbital_ai_icon_ecosystem.ico` is included and detected automatically.

## Repeat-one and favourites playback

The repeat button cycles **Off → All songs → One song → Off**. One-song mode shows `↻1`; hover for the current mode and the next click's action. Repeat-one restarts the same song at its natural end, including with shuffle enabled. Manual Next/Previous still let you change songs.

**★ Favorites now controls playback**, as well as the displayed list. Only starred songs already in the loaded queue are eligible for Play, Next, Previous, shuffle and automatic advancement. Switching it on while a non-favourite plays moves to an eligible favourite; if there are none, playback stops with a clear message. Removing the currently playing favourite moves to another favourite or stops if none remain. Switching favourites off restores the full loaded queue without deleting it.

Shuffle visits each eligible song once per round. Repeat-all starts another round; repeat-off stops at its end. Previous follows shuffle history. Starting again after an exhausted shuffled round creates a fresh round. Search remains a visual filter and does not narrow playback further. Saved favourite marks do not automatically import unloaded songs, and Save Playlist continues to save the complete loaded queue.

## Size and functionality

Compression is lossless and does not reduce audio quality, note quality or images. A single-file PyInstaller EXE already uses compression; wrapping it in a ZIP may save little. A folder build compressed as a ZIP is another portable distribution option; extract it before running. Single-file launch is slower while native resources are unpacked.

The embedded Qt WebEngine browser, native PDF engine, recording FFmpeg resources, numerical packages and VLC plugins dominate size. This update keeps them. Bundling VLC can increase size compared with depending on system codecs. No fixed Windows size reduction is claimed; the Windows output has not been built here. Removing browser/recording features, pruning VLC codecs, or aggressive binary packing would need separate compatibility testing and is not enabled by this builder.

## Existing reader features and document compatibility

Your existing Study AI, Music, Speech, Calculator, Document, PDF, Notes/Draw, Browser, Video/Meetings and Themes tabs remain, with Study Planner appended as the eleventh tab. The earlier physical-page canvas, ribbon commands, view-only zoom, unsaved-work protection, atomic document saves, multipage PDF export, DOCX export fixes, recovery, comments, mail merge and icon fallback are retained.

Use HTML for editable rich notes. Keep the adjacent `document.html.jesson.json` sidecar with the document when copying or backing it up; it holds supported comment/review and paper metadata. Plain text loses formatting. DOCX import/export preserves the supported features, but complex Word layouts, embedded images, advanced review interoperability and exact Word pagination are not fully equivalent. Keep originals of important documents. HTML/DOCX are not a complete spreadsheet format; the existing custom formula format is not a guarantee of Excel/Word formula interoperability.

## Icons

The ICO from your attachment is bundled. Any other valid `.ico`/`.ICO` beside the source is detected; `jesson_app.ico` is preferred if several exist. `JESSON_ICON` explicitly selects an icon. Runtime lookup also checks beside the EXE and its bundled resources. Without a usable icon, a readable J fallback remains.

To convert a saved image into a multi-resolution ICO, use your Python to run `prepare_icon.py my-picture.png`. It refuses to overwrite an existing output.

## Gemini and local data

Configure your own key through the app's API Keys dialog or `GEMINI_API_KEY` / numbered slots 1–5. `GEMINI_MODEL` selects a supported model. No keys are included in the archive. Keys entered in the dialog are stored in a per-user JSON configuration, which is not encrypted; protect your Windows account and do not distribute that file.

The earlier live Gemini check is historical evidence, not a fresh check from this update. No live Gemini request was repeated for these media/editor changes. Generated study answers still need checking against your course material. Browser sign-ins, study files and local configuration are not bundled.

## Verification and Windows acceptance

See VERIFICATION.md for the checks actually run and their limits. Native libVLC MP3, FLAC and WAV decoding was checked with generated first/second tracks on Linux, using dummy audio output. User-original songs, Windows speakers and Windows Python 3.13 packaging remain checks for your computer.

After rebuilding, check your two songs, seek/pause/next, repeat/shuffle, your ICO, imported DOCX selection/font/undo, repeated table calculation, PDF note placement/edit/delete/Save As/reopen, browser HTTPS, Study AI, speech and any drawing/recording features you rely on. Back up your revision notes.
