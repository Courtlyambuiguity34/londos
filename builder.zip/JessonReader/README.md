# Jesson Reader — refined editor and reliable music playback

This is a separate application. Its download archive is stored in the Londos repository for convenience; it does not use or modify Londos application services.

## Run on Windows

Install **64-bit Python 3.12** from python.org. Extract this entire bundle into a folder you own. Open a terminal in that folder:

```bat
py -3.12 -m venv .venv
.venv\Scripts\python.exe -m pip install -r requirements.txt
.venv\Scripts\python.exe Jesson_Reader.py
```

To build an executable, use the instructions below. You do not need Node.js, PostgreSQL, MongoDB, Redis, or any Londos configuration.

On Linux/macOS, use `python3 -m venv .venv`, `.venv/bin/python -m pip install -r requirements.txt`, then `.venv/bin/python Jesson_Reader.py`. A graphical desktop and working platform multimedia/speech drivers are needed for those features. The cloud checks used a headless Linux container, not your Windows PC.

## Improvements made

- **Document pages:** physical paper dimensions and margins, visible page boundaries, centered writing surface, accurate page status, mouse typing through the page canvas, and cursor-following outer scrolling.
- **Zoom:** scales the page view without changing saved font formatting or page count. Use View → Page Width or Ctrl + mouse wheel. Existing zoom controls remain.
- **Ribbon:** compact two-row command groups, all existing ribbon tabs/commands retained, synchronized visible font controls and working Bold/Italic/Underline toggles. Quick-access Undo/Redo/Save remain visible.
- **Files:** Ctrl+S saves the current editable document; Ctrl+Shift+S opens Save As. New/Open/Close protect unsaved work with Save/Discard/Cancel. File replacement uses temporary files to avoid truncating the original on a failed write.
- **Printing/PDF:** multipage output, visible header/footer fields and page numbers, proper printer scaling. Fixed the previous single-page PDF save path. PDF is an export: it does not mark your editable document saved or replace its current filename.
- **DOCX:** fixed the existing table-export crash caused by calling a method unavailable in PyQt5. The existing DOCX importer/exporter and its formatting/review features remain available.
- **Recovery:** periodic HTML autosave keeps unsaved status and the original document path. Recovery includes comment metadata and paper setup.
- **Music:** direct playback of the selected file instead of Qt's automatic error-skipping playlist path. Removed delayed selection races; preserved row/media indexes when files go missing; retained queue filtering, favourites, drag reordering, playlist load/save, shuffle, repeat, seeking and volume. A playback error remains visible on the selected track.
- **Branding/icons:** removed the MindGrasp wording. Runtime discovery supports any valid `.ico`/`.ICO` filename beside the source or executable, with bundled-resource support and a readable J fallback.
- **Gemini:** supports existing locally managed keys and runtime environment keys. Uses one selected key/model per request, closes its client, and gives sanitized failures without copying provider exception text or cycling through keys for quota.

All 52 original classes and their 610 methods remain in the source. New classes extend the existing implementations. This inventory is evidence of retained APIs, not proof that every original feature has been exhaustively tested.

## Document compatibility and native notes

Use **HTML** when continuing rich notes in this reader. A small adjacent `your-document.html.jesson.json` file preserves comments/change markers, headers/footers, paper setup and other supported metadata. Keep it beside the document when copying or backing up your notes. A stale or corrupt sidecar does not prevent opening the main document. Sidecars are private document data, not API-key files.

DOCX is useful for sharing with Word; PDF is useful for printing. Plain text intentionally loses formatting. This application is **Word-inspired, not a complete Microsoft Word replacement**. Complex imported Word layouts/images, native Word collaboration, review interoperability, flowing columns, advanced equation/footnote behavior and exact print fidelity across different fonts/printers are not fully equivalent. Existing approximations were retained rather than silently removed. Keep an original copy of important Word documents before editing them here.

## Use your icon

Put your existing ICO file in the same folder as `Jesson_Reader.py`; no rename is required. Invalid ICO files are skipped. `jesson_app.ico` is preferred when several icons are present. `JESSON_ICON` can explicitly select a file. In a packaged app, icons beside the executable are checked before bundled icons.

The inline artwork from the chat was not available as a downloadable PNG/ICO in the workspace. It has **not** been redrawn or claimed bundled. If you save that picture locally as `my-picture.png`, convert it with:

```bat
.venv\Scripts\python.exe prepare_icon.py my-picture.png
```

This creates a multi-resolution `jesson_app.ico` and refuses to overwrite an existing output. The build helper automatically includes a valid ICO as both the executable icon and a runtime resource. Without an ICO, the window uses the J fallback; the executable file icon may remain PyInstaller's default.

## Build with PyInstaller on Windows

Build **on Windows** to obtain a Windows `.exe`. PyInstaller does not cross-compile Windows executables from this Linux cloud environment.

Double-click `build_windows.bat` to install build dependencies and create/open the single-file **`dist\builder.exe`**. Install 64-bit Python 3.12 first and extract the whole ZIP. This is the reader executable, not an installer; no prebuilt Windows executable is included. See `START_HERE.txt`.

For a manual folder build instead, run:

```bat
.venv\Scripts\python.exe -m pip install -r requirements-build.txt
.venv\Scripts\python.exe build_app.py
```

The result is `dist\JessonReader\JessonReader.exe`. Distribute the **entire** `dist\JessonReader` directory, including `_internal`; the EXE alone is insufficient in this recommended folder build. The helper collects Qt WebEngine, its process/resources, and supported multimedia/speech plugins. It creates a PyInstaller spec automatically.

Start with the folder build because it is easier to diagnose. After testing that build on your computer, an optional single-file build is:

```bat
.venv\Scripts\python.exe build_app.py --onefile
```

The single-file result is `dist\JessonReader.exe`; startup is slower while resources are extracted. Use `--console` for diagnostic builds. Close a running previous build before rebuilding. No Windows executable, installer or signing certificate was created in this cloud task.

## Gemini configuration

Your app's API Keys dialog still works. Keys saved by that dialog are stored in your per-user application configuration, not the executable; the local JSON file is not encrypted. Protect your Windows account and keep that file out of distribution bundles.

Alternatively set `GEMINI_API_KEY` or `GEMINI_API_KEY_1` through your own local environment. Numbered slots 1–5 are supported. Set `GEMINI_MODEL` to a supported model; `GEMINI_KEY_SLOT` chooses an available key starting at 1. Existing cloud model configuration is accepted as a fallback, but no cloud credentials are shipped in this download. Proxy-backed cloud placeholders are not portable API keys.

One live, bounded request using the active `gemini-2.5-flash` setting succeeded during this task. This establishes current API acceptance, not a guarantee of future quota or exam-answer correctness. The app sends only the prompt, relevant conversation and study material you choose to provide; it does not automatically upload unrelated files. Review generated answers against your course material.

## Checks and remaining desktop verification

`tests/test_reader.py` has **18 passing focused checks**: typing/focus, formatting/undo, zoom invariance, multipage PDF with header/footer numbering, HTML comment recovery, DOCX table export, unsaved-work cancellation, existing command availability, first two audio tracks, rapid track selection, missing tracks, reorder/filter behavior, error handling, ICO discovery/frozen paths, fallback icon, autosave, Gemini error redaction, and mail-merge margin preservation.

The first two generated WAV files decoded and advanced their playback positions. Your original failing songs were not supplied, so their specific codec/content behavior still needs checking on your PC. No audible speaker output was verified in this container.

The full ten-tab MainWindow initialized with a renderable icon. A Linux PyInstaller folder build completed, includes WebEngine resources/media plugin, and remained running during an eight-second startup observation. That observation is not a complete frozen functional test. The headless environment lacks a usable speech backend/OpenGL desktop and showed browser/NSS/OpenSSL and multimedia warnings; speech, browser HTTPS and recording in the frozen Windows app remain desktop acceptance checks.

Before relying on the EXE, try: both original songs, seeking/pause/next, queue reordering, typing/undo/save/reopen, PDF/DOCX export, your own ICO, Study AI, browser HTTPS, speech, and drawing/video features you use. Keep your study documents backed up.

Optional next ideas, **not implemented without your approval**: an exam focus timer, a revision timetable, spaced-repetition scheduling, and a more complete DOCX import engine.

## Updated automatic builder (Python 3.13)

The supplied batch now uses your existing 64-bit Python 3.13, searching `D:\1\Python\Python313\python.exe` first, common install paths next, then `py -3.13`. It creates no virtual environment. `ensure_build_packages.py` checks every required distribution and installs only missing packages and missing dependencies, constraining installed versions against replacement. Conflicts stop installation. Existing versions are retained even if they differ from the reference requirements, so presence alone does not establish compatibility. The earlier Python 3.12 virtual-environment instructions remain an alternative manual workflow; the automatic batch follows this section. Python 3.13 Windows builds have not been executed here.
