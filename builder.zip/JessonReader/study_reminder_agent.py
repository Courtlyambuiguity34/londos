"""Windows-only lightweight reminder process and per-user Task Scheduler setup."""
import argparse
import csv
import io
import tempfile
import xml.etree.ElementTree as ET
import sqlite3
import ctypes
import datetime as dt
import hashlib
import os
from pathlib import Path
import subprocess
import sys
import time
from study_schedule import read_plan, ReminderLedger, collect_reminders


def task_name(store):
    suffix = hashlib.sha256(str(Path(store).resolve()).casefold().encode()).hexdigest()[:12]
    return 'Jesson Study Reminders ' + suffix


def agent_command(store):
    executable = Path(sys.executable)
    command = [str(executable)]
    if not getattr(sys, 'frozen', False):
        windowless = executable.with_name('pythonw.exe')
        if os.name == 'nt' and windowless.exists(): command[0] = str(windowless)
        command.append(str(Path(__file__).resolve().parent / 'Jesson_Reader.py'))
    return command + ['--study-reminder-agent', '--store', str(Path(store).resolve())]


def _schtasks(arguments):
    return subprocess.run(['schtasks', *arguments], capture_output=True, text=True,
                          timeout=20, creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))


def task_xml(store, sid):
    ns = 'http://schemas.microsoft.com/windows/2004/02/mit/task'
    ET.register_namespace('', ns)
    root = ET.Element('{' + ns + '}Task', version='1.2')
    def node(parent, tag, text=None, **attrs):
        child = ET.SubElement(parent, '{' + ns + '}' + tag, attrs)
        if text is not None: child.text = text
        return child
    trigger = node(node(root, 'Triggers'), 'LogonTrigger')
    node(trigger, 'Enabled', 'true'); node(trigger, 'UserId', sid)
    principal = node(node(root, 'Principals'), 'Principal', id='Author')
    node(principal, 'UserId', sid); node(principal, 'LogonType', 'InteractiveToken')
    node(principal, 'RunLevel', 'LeastPrivilege')
    settings = node(root, 'Settings')
    for tag, value in (('MultipleInstancesPolicy', 'IgnoreNew'), ('DisallowStartIfOnBatteries', 'false'),
                       ('StopIfGoingOnBatteries', 'false'), ('StartWhenAvailable', 'true'),
                       ('Enabled', 'true'), ('ExecutionTimeLimit', 'PT0S')):
        node(settings, tag, value)
    restart = node(settings, 'RestartOnFailure')
    node(restart, 'Interval', 'PT1M'); node(restart, 'Count', '3')
    action = node(node(root, 'Actions', Context='Author'), 'Exec')
    command = agent_command(store)
    node(action, 'Command', command[0])
    node(action, 'Arguments', subprocess.list2cmdline(command[1:]))
    return ET.tostring(root, encoding='utf-16', xml_declaration=True)


def register_task(store):
    if os.name != 'nt': raise RuntimeError('Background reminders require the Windows build.')
    identity = subprocess.run(['whoami', '/user', '/fo', 'csv', '/nh'], capture_output=True,
                              text=True, timeout=10, creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
    if identity.returncode: raise RuntimeError('Could not identify the Windows account for reminders.')
    try:
        sid = next(csv.reader(io.StringIO(identity.stdout.strip())))[1]
        if not sid.startswith('S-1-'): raise ValueError('Invalid SID')
    except (IndexError, StopIteration, ValueError):
        raise RuntimeError('Could not identify the Windows account for reminders.') from None
    with tempfile.TemporaryDirectory(prefix='jesson-task-') as directory:
        path = Path(directory) / 'reminders.xml'
        path.write_bytes(task_xml(store, sid))
        result = _schtasks(['/Create', '/TN', task_name(store), '/XML', str(path), '/F'])
    if result.returncode:
        raise RuntimeError('Windows did not allow the reminder task. Task Scheduler may be restricted for this account. ' + (result.stderr or result.stdout).strip()[:350])


def start_task(store):
    result = _schtasks(['/Run', '/TN', task_name(store)])
    if result.returncode: raise RuntimeError('The reminder task was saved but could not start. Sign in again or retry enabling background reminders.')


def remove_task(store):
    if os.name != 'nt': return
    _schtasks(['/End', '/TN', task_name(store)])
    result = _schtasks(['/Delete', '/TN', task_name(store), '/F'])
    if result.returncode: raise RuntimeError('Background reminders are disabled in Jesson, but Windows could not remove the task. Remove it from Task Scheduler if it still exists.')


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--study-reminder-agent', action='store_true')
    parser.add_argument('--store', required=True)
    args = parser.parse_args()
    if os.name != 'nt': return 1
    from ctypes import wintypes
    kernel = ctypes.WinDLL('kernel32', use_last_error=True)
    kernel.CreateMutexW.argtypes = (wintypes.LPVOID, wintypes.BOOL, wintypes.LPCWSTR)
    kernel.CreateMutexW.restype = wintypes.HANDLE
    kernel.CloseHandle.argtypes = (wintypes.HANDLE,)
    lock_name = 'Local\\' + task_name(args.store).replace(' ', '_')
    handle = kernel.CreateMutexW(None, False, lock_name)
    if not handle: return 1
    if ctypes.get_last_error() == 183:
        kernel.CloseHandle(handle); return 0
    try:
        ledger = ReminderLedger(Path(args.store).with_suffix('.reminders.sqlite3'))
        while True:
            try:
                data = read_plan(args.store)
                if not data['settings'].get('background_reminders'): return 0
                due = collect_reminders(data, ledger, dt.datetime.now())
                if due:
                    lines = [f'{session["subject"]} — {start:%a %d %b, %H:%M} ({session["minutes"]} min)' for session, start in due[:12]]
                    if len(due) > 12: lines.append(f'And {len(due)-12} more sessions; open Study Planner.')
                    text = '\n\n'.join(lines) + '\n\nOpen Jesson → Study Planner to start, complete or snooze a session.'
                    ctypes.windll.user32.MessageBoxW(None, text, 'Jesson study reminder', (0x40 if data['settings'].get('sound') else 0) | 0x10000)
            except (OSError, ValueError, KeyError, TypeError, sqlite3.Error):
                # A partial/manual edit or temporarily locked file is retried.
                pass
            time.sleep(30)
    finally:
        kernel.CloseHandle(handle)


if __name__ == '__main__':
    raise SystemExit(main())
