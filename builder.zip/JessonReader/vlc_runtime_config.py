"""Shared discovery for manually supplied and downloaded Windows VLC files."""
from pathlib import Path
import struct

RUNTIME_NAMES = ('vlc_runtime', 'vlc-runtime')


def is_x64_dll(path):
    try:
        with Path(path).open('rb') as stream:
            if stream.read(2) != b'MZ': return False
            stream.seek(0x3C)
            offset = struct.unpack('<I', stream.read(4))[0]
            stream.seek(offset)
            return stream.read(6) == b'PE\x00\x00\x64\x86'
    except (OSError, ValueError, struct.error):
        return False


def runtime_problems(root):
    root = Path(root)
    problems = []
    for name in ('libvlc.dll', 'libvlccore.dll'):
        if not (root / name).is_file(): problems.append(f'Missing {name}')
        elif not is_x64_dll(root / name): problems.append(f'{name} must be a 64-bit Windows DLL')
    # This establishes a usable minimum, not full codec coverage.
    for category in ('access', 'audio_output', 'codec', 'demux'):
        directory = root / 'plugins' / category
        if not directory.is_dir() or not any(directory.glob('*.dll')):
            problems.append(f'Missing plugin DLLs in plugins/{category}')
    bad_plugin = next((path for path in (root / 'plugins').rglob('*.dll') if not is_x64_dll(path)), None)
    if bad_plugin: problems.append(f'Plugin must be a 64-bit Windows DLL: {bad_plugin.relative_to(root)}')
    return problems


def valid_runtime(root):
    return not runtime_problems(root)


def find_runtime(folder):
    return next((Path(folder) / name for name in RUNTIME_NAMES if valid_runtime(Path(folder) / name)), None)
