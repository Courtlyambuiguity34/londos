# Current Jesson update verification

Baseline: the current `londos/builder.zip`, extracted into a separate workspace directory. Its custom Windows Python search paths, `Jesson.exe` name and ICO were preserved. The standalone app remains separate from Londos; only its distributable source ZIP is committed there.

## PDF and Document workspace update

This update was applied to the current `builder.zip` source, not to Londos application code. Public ArtCraft/PdfCraft/WordCraft interaction ideas were independently reimplemented with Python/PyQt; no Rust implementation or branded assets were copied.

Before the update, the complete current archive suite passed **67 tests with 6 optional/native skips**. After integration, the focused workspace plus affected existing reader suites passed **31 tests with 2 optional native-media skips**. The final complete suite passed **72 tests with 6 optional/native skips** in 4.16 seconds, followed by a successful compile check of the main application, build helper and affected modules. These checks cover ordered DOCX paragraph/table import; font, page setup and first-section header/footer import; command discovery; PDF thumbnails and visible tabs; document-wide search and visible matches; text copy; read mode; atomic in-place PDF replacement/reopen; malformed-PDF preservation; and the existing document/PDF regressions.

The complete MainWindow was also launched headlessly with a writable temporary per-user data directory. It remained running until the intentional 8-second timeout (exit 124), with no Python initialization exception. The managed Linux environment reported its known missing speechd/OpenGL support and Qt/OpenSSL mismatch; this is not a Windows desktop acceptance test. Both new workspace previews were captured from the actual PyQt widgets and inspected after the final layout adjustment.

## Executed checks

- Initial focused document regression selection: **4 passed**, 15 deselected.
- Requested-fix and existing packaging/package-selection tests: **17 passed** (8 new feature checks, 6 existing builder checks, 3 existing package-check tests).
- **Real libVLC native decoding: 3 passed**. For each MP3, FLAC and WAV, FFmpeg generated two 4-second tone tracks. Each first/second queue entry played, duration reached at least 3.9 seconds, position advanced, and no media error was reported. Pause/resume and seeking were also exercised. This used Linux libVLC 3.0.24 with dummy audio output, not Windows or audible speakers. The Linux test libraries were extracted under the workspace without a system installation.
- Existing affected reader regression selection: **11 passed**, 8 deselected. Covered first/second WAV playback through VLC, rapid selection, missing tracks, filtered/reordered queues, media error staying on selection, multipage PDF, HTML metadata recovery, DOCX export, unsaved cancellation and existing Writer commands.
- Lossless distribution ZIP test: **1 passed**, 6 deselected. Verified executable/resource bytes retained in the generated ZIP with a mocked build.
- Windows VLC collection command tests: **2 passed**. Verified a missing native runtime stops the build, and a complete runtime is included in single-file build arguments. These simulate Windows command construction; they do not execute a Windows build.
- PDF placement, existing-note edit/delete/save/reopen, rotation/zoom mapping, and overlapping-note accessibility: **3 passed**, 6 deselected, after sidebar addition; repeated after changing card previews to wrap on two lines, again **3 passed**.
- All **56 classes and 656 methods** from the attached application's main source remain present by AST inventory. This proves retained method names, not exhaustive functionality.
- The supplied ICO was decoded successfully and the build helper selected it by its existing filename.
- Official Windows portable VLC 3.0.24 was actually downloaded and extracted; SHA-256 matched `fcf30850371ad10c9373cc4f0f4501e7dee49e3e9ae9f20c72fb2661a1ca6323`. Required DLLs and full plugin directory were present. A corrupt-checksum fixture was rejected before extraction.

## Defects corrected

- Table cell read/write selected through `lastCursorPosition - 1`, omitting the final digit. The cursor now selects the complete cell contents and replacements form one edit block. Imported A2=1/A3=2 yields 3 through repeated recalculation; changing A2 to 10 yields 12. Undo restores the prior result.
- Ribbon synchronization changed the font combo without suppressing signals, allowing formatting updates to feed back into document formatting. Synchronization now blocks signals, and intentional font changes return focus to the document. Imported DOCX font selection and undo were exercised.
- PDF Text annotations previously rendered only tiny icons with no interaction. Clickable preview cards, full-text edit/delete dialogs, click placement and a per-page notes list now expose notes. Native annotation save/reopen was exercised.
- Music decoding previously depended on Qt's system media backend. The Qt-facing adapter now decodes with libVLC; the Windows builder includes the portable runtime instead of relying on installed codec packs. Error and end-of-media handling remain distinct and UI signals run on the Qt thread.

## Packaging and size

A Linux PyInstaller folder build completed and collected `vlc_backend`, `pdf_notes`, `vlc` and `google.genai`. The embedded browser, numerical libraries, PDF engine, recording dependencies and VLC plugins have not been removed. The earlier Linux folder occupied about 903 MiB; an intermediate updated build about 902 MiB. This is not a meaningful guaranteed reduction and is not a Windows EXE size measurement. The Windows VLC runtime adds about 191 MiB of uncompressed files before single-file compression.

Maximum-level ZIP compression is optional and lossless. Blanket google.genai submodule collection is removed in favor of actual import analysis. UPX packing is explicitly disabled in build_app.py to avoid introducing a separate native-binary compatibility requirement. No user media is transcoded or downsampled.

The native runtime, local test profiles, generated audio, build outputs, machine-specific spec files, raw build logs, secrets and local app configurations are omitted from the source ZIP. The batch downloads the native VLC runtime during build, with checksum verification. Its licensing/notices are retained in the runtime and described in THIRD_PARTY_MEDIA.md.

## Limits and Windows acceptance

No Windows EXE was produced or executed in the Linux environment. Python 3.13 Windows execution, audible speaker output, the user's original songs, and the complete frozen app remain acceptance checks on the user's PC. Linux native decode tests used a dummy output sink. Browser HTTPS, speech drivers and recording were not exhaustively retested. Gemini was not called again; the included gemini-check.json is historical evidence only.

The app is Word-inspired, not full Microsoft Word parity. Existing complex DOCX import and review/sidecar limitations remain. Existing-text font changes require a selection. PDF note cards are a reader overlay backed by standard annotations; they are not permanently stamped page text. Use Save As to persist PDF changes.

Rebuild with build_windows.bat and test original songs, controls, font selection, repeated formulas, note save/reopen, supplied icon and your usual study workflows. Keep your source study documents backed up.

Final Linux folder rebuild completed after the wrapped-card change. Its PYZ contains all four named modules. The frozen app remained running for an 8-second headless startup observation (timeout exit 124). The container showed unavailable speech/OpenGL and incompatible Qt OpenSSL warnings; this observation does not establish full frozen speech/browser/media functionality or Windows success. Windows build-command verification was repeated after explicitly disabling UPX: 1 passed, 1 deselected.

## Manual VLC and Study Planner update

Added an eleventh Study Planner tab, per-user timetable/history storage, daily/weekly repetitions, monotonic focus/break timing, daily completed-focus goal, snoozing, CSV export, bottom-bar music controls and F11 reading focus. Existing tab shortcuts are retained. Optional Windows background reminders register a per-user interactive Task Scheduler task and use a lightweight entry point before the main UI imports. The foreground app and background agent share an atomic SQLite claim ledger so the same occurrence is not delivered twice.

Manual runtime discovery now accepts both `vlc_runtime` and `vlc-runtime`. Required core DLLs and every supplied plugin DLL must have x64 Windows PE headers; empty required plugin folders are rejected. The actual downloaded VLC 3.0.24 runtime passed validation for all 360 plugin DLLs. Running `prepare_vlc.py --offline` against it returned success and reported that downloading was skipped. An offline batch is included; offline dependency checks never invoke pip install.

Executed targeted checks:

- Combined manual-runtime, Windows packaging-command, existing package-check and initial study-tool tests: **19 passed**.
- Background-registration failure reporting, completed-session snooze rejection and lightweight reminder entry: **3 passed**, 9 deselected at that point.
- Background agent loop simulation plus affected timetable persistence/corrupt-file checks after validation changes: **3 passed**, 10 deselected (two were targeted reruns, one was a new test).
- These runs cover **23 distinct focused tests**. The Windows native APIs and Task Scheduler calls were simulated on Linux; no claim of a real Windows task registration is made.
- Concurrent foreground/background reminder claims emitted only one reminder; snooze expiry, completed occurrence suppression, next daily occurrence and eligible overdue handling passed.
- Focus pause/resume, exact completion once, optional music-pause signal, break transition and saved paused state after reopen passed. Corrupt plan JSON was retained as a backup before replacement.
- Full MainWindow initialized with eleven tabs. Reading focus hid/restored the ribbon/tab bar without changing document text; bottom music control remained available and the timer continued on another tab. Existing headless Qt/WebEngine profile teardown warnings remain environment/desktop acceptance limits.
- A new Linux PyInstaller folder build completed. Its archive includes study_planner, study_schedule, study_reminder_agent, vlc_runtime_config, vlc_backend, pdf_notes and sqlite3. The frozen executable's `--study-reminder-agent --help` returned successfully without starting Qt. This verifies the packaged entry point, not Windows native task execution.

Background task configuration uses the current account SID, InteractiveToken and LeastPrivilege, starts at sign-in, permits battery operation, and has no default three-day execution cutoff. A Windows process mutex prevents duplicate agent instances. Real task creation, sign-in restart, native notification appearance and behavior on the user's Windows policy still require testing on the user's PC. Source/frozen Windows Python 3.13 builds were not executed here.

No unrelated Londos tests, provider/API checks, or previously verified codec-format suites were repeated for these study-tool changes. See MANUAL-VLC-AND-STUDY.md for manual plugin recommendations, offline setup, background-reminder enable/disable steps, and a short real Windows acceptance check.

## Repeat-one and favourites playback correction

Previously repeat only toggled off/all, and favourites only hid rows while the playback model retained all tracks. The active player now owns eligibility/navigation with three repeat modes, favourite-only playback, shuffled rounds and previous-track history. Manual next/previous remain available during repeat-one; only successful end-of-media repeats/advances, never an error. Search stays a visual filter. No queue entries are deleted by a filter.

Executed 11 focused mocked-backend checks plus 1 real libVLC end-of-media check: **12 passed**. Covered repeat cycle, repeat-one with shuffle, manual skipping, favourites-only next/previous/automatic advancement, all-mode wrap, one-favourite loops, empty favourites, unfavouriting a playing song, shuffle history/exhaustion/restart, error handling, search/full-queue restoration and arrow shortcut routing. The native check used four generated short WAVs on Linux with dummy audio output, proved the same favourite actually restarted, then proved repeat-off advanced only to the other favourite and stopped without error. Actual Windows speakers and user-original songs were not tested.

Existing rapid-selection, missing-track, filtered/reordered-queue and media-error regressions: **4 passed**, 15 deselected. No unrelated study-planner, provider or Londos suites were rerun; no new Windows build was produced. The source ZIP is ready for the user's pending build using the included batch.
