# Current Jesson update verification

Baseline: the user-uploaded `Jesson.zip`, extracted into a new workspace directory. The uploaded archive was not overwritten. Its custom Windows Python search paths, `Jesson.exe` name and ICO were preserved. The standalone app remains separate from Londos; only its distributable source ZIP is committed there.

## Executed checks

- Initial focused document regression selection: **4 passed**, 15 deselected.
- Requested-fix and existing packaging/package-selection tests: **17 passed** (8 new feature checks, 6 existing builder checks, 3 existing package-check tests).
- **Real libVLC native decoding: 3 passed**. For each MP3, FLAC and WAV, FFmpeg generated two 4-second tone tracks. Each first/second queue entry played, duration reached at least 3.9 seconds, position advanced, and no media error was reported. Pause/resume and seeking were also exercised. This used Linux libVLC 3.0.24 with dummy audio output, not Windows or audible speakers. The Linux test libraries were extracted under the workspace without a system installation.
- Existing affected reader regression selection: **11 passed**, 8 deselected. Covered first/second WAV playback through VLC, rapid selection, missing tracks, filtered/reordered queues, media error staying on selection, multipage PDF, HTML metadata recovery, DOCX export, unsaved cancellation and existing Writer commands.
- Lossless distribution ZIP test: **1 passed**, 6 deselected. Verified executable/resource bytes retained in the generated ZIP with a mocked build.
- Windows VLC collection command tests: **2 passed**. Verified a missing native runtime stops the build, and a complete runtime is included in single-file build arguments. These simulate Windows command construction; they do not execute a Windows build.
- PDF placement, existing-note edit/delete/save/reopen, rotation/zoom mapping, and overlapping-note accessibility: **3 passed**, 6 deselected, after sidebar addition; repeated after changing card previews to wrap on two lines, again **3 passed**.
- All **56 classes and 656 methods** from the attached application's main source remain present by AST inventory. This proves retained method names, not exhaustive functionality.
- The supplied ICO was decoded successfully and the build helper selected it by its existing filename.
- Official Windows portable VLC 3.0.24 was actually downloaded and extracted; SHA-256 matched `fcf30850371ad10c9373cc4f0f4501e7dee49e3e9ae9f20c72fb2661a1ca6323`. Required DLLs and full plugin directory were present. A corrupt-checksum fixture was rejected before extraction.

## Defects corrected

- Table cell read/write selected through `lastCursorPosition - 1`, omitting the final digit. The cursor now selects the complete cell contents and replacements form one edit block. Imported A2=1/A3=2 yields 3 through repeated recalculation; changing A2 to 10 yields 12. Undo restores the prior result.
- Ribbon synchronization changed the font combo without suppressing signals, allowing formatting updates to feed back into document formatting. Synchronization now blocks signals, and intentional font changes return focus to the document. Imported DOCX font selection and undo were exercised.
- PDF Text annotations previously rendered only tiny icons with no interaction. Clickable preview cards, full-text edit/delete dialogs, click placement and a per-page notes list now expose notes. Native annotation save/reopen was exercised.
- Music decoding previously depended on Qt's system media backend. The Qt-facing adapter now decodes with libVLC; the Windows builder includes the portable runtime instead of relying on installed codec packs. Error and end-of-media handling remain distinct and UI signals run on the Qt thread.

## Packaging and size

A Linux PyInstaller folder build completed and collected `vlc_backend`, `pdf_notes`, `vlc` and `google.genai`. The embedded browser, numerical libraries, PDF engine, recording dependencies and VLC plugins have not been removed. The earlier Linux folder occupied about 903 MiB; an intermediate updated build about 902 MiB. This is not a meaningful guaranteed reduction and is not a Windows EXE size measurement. The Windows VLC runtime adds about 191 MiB of uncompressed files before single-file compression.

Maximum-level ZIP compression is optional and lossless. Blanket google.genai submodule collection is removed in favor of actual import analysis. UPX packing is explicitly disabled in build_app.py to avoid introducing a separate native-binary compatibility requirement. No user media is transcoded or downsampled.

The native runtime, local test profiles, generated audio, build outputs, machine-specific spec files, raw build logs, secrets and local app configurations are omitted from the source ZIP. The batch downloads the native VLC runtime during build, with checksum verification. Its licensing/notices are retained in the runtime and described in THIRD_PARTY_MEDIA.md.

## Limits and Windows acceptance

No Windows EXE was produced or executed in the Linux environment. Python 3.13 Windows execution, audible speaker output, the user's original songs, and the complete frozen app remain acceptance checks on the user's PC. Linux native decode tests used a dummy output sink. Browser HTTPS, speech drivers and recording were not exhaustively retested. Gemini was not called again; the included gemini-check.json is historical evidence only.

The app is Word-inspired, not full Microsoft Word parity. Existing complex DOCX import and review/sidecar limitations remain. Existing-text font changes require a selection. PDF note cards are a reader overlay backed by standard annotations; they are not permanently stamped page text. Use Save As to persist PDF changes.

Rebuild with build_windows.bat and test original songs, controls, font selection, repeated formulas, note save/reopen, supplied icon and your usual study workflows. Keep your source study documents backed up.

Final Linux folder rebuild completed after the wrapped-card change. Its PYZ contains all four named modules. The frozen app remained running for an 8-second headless startup observation (timeout exit 124). The container showed unavailable speech/OpenGL and incompatible Qt OpenSSL warnings; this observation does not establish full frozen speech/browser/media functionality or Windows success. Windows build-command verification was repeated after explicitly disabling UPX: 1 passed, 1 deselected.
