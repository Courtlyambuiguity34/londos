"""Python/PyQt PDF workspace enhancements inspired by PdfCraft's interaction model.

This module does not copy PdfCraft's Rust implementation or visual assets.  It
adapts the useful product ideas (thumbnail navigation, document-wide search,
focused reading and safe writes) to Jesson's existing PyMuPDF viewer.
"""

import os
import tempfile
from pathlib import Path

import pymupdf as fitz
from PyQt5.QtCore import Qt, QSize, QTimer
from PyQt5.QtGui import QIcon, QImage, QKeySequence, QPixmap
from PyQt5.QtWidgets import (
    QApplication,
    QComboBox,
    QFileDialog,
    QInputDialog,
    QLabel,
    QLineEdit,
    QListWidget,
    QListWidgetItem,
    QMessageBox,
    QPushButton,
    QShortcut,
    QSplitter,
    QTabWidget,
    QWidget,
)


class CraftPDFWorkspaceMixin:
    """Add a reader-grade workspace without replacing the proven PDF engine."""

    THUMBNAIL_WIDTH = 116
    MAX_SEARCH_RESULTS = 500

    def __init__(self):
        self._view_mode = "Fit page"
        self._pdf_dirty = False
        self._search_hits = {}
        self._search_pages = []
        self._search_page_index = -1
        self._search_overlays = []
        self._thumbnail_items = []
        self._thumbnail_queue = []
        super().__init__()
        self._install_craft_workspace()

    def _install_craft_workspace(self):
        splitter = self.scroll.parentWidget()
        if not isinstance(splitter, QSplitter):
            splitter = self.findChild(QSplitter)
        self._craft_splitter = splitter
        self._craft_sidebar = next(
            (tabs for tabs in self.findChildren(QTabWidget) if tabs.indexOf(self.outline) >= 0),
            None,
        )
        if self._craft_sidebar is not None:
            self._craft_sidebar.setObjectName("pdfSidebar")
            self._craft_sidebar.setMinimumWidth(390)
            self._craft_sidebar.setMaximumWidth(460)
            self.thumbnailList = QListWidget()
            self.thumbnailList.setObjectName("pdfThumbnails")
            self.thumbnailList.setViewMode(QListWidget.IconMode)
            self.thumbnailList.setIconSize(QSize(self.THUMBNAIL_WIDTH, 154))
            self.thumbnailList.setResizeMode(QListWidget.Adjust)
            self.thumbnailList.setMovement(QListWidget.Static)
            self.thumbnailList.setWordWrap(True)
            self.thumbnailList.setSpacing(7)
            self.thumbnailList.itemClicked.connect(self._thumbnail_clicked)
            self._craft_sidebar.insertTab(0, self.thumbnailList, "Pages")

            self.searchResults = QListWidget()
            self.searchResults.setObjectName("pdfSearchResults")
            self.searchResults.setWordWrap(True)
            self.searchResults.itemClicked.connect(self._search_result_clicked)
            self._craft_sidebar.addTab(self.searchResults, "Search")
        else:
            self.thumbnailList = QListWidget(self)
            self.searchResults = QListWidget(self)

        bar = self.findChild(QWidget, "bar")
        if bar is not None and bar.layout() is not None:
            layout = bar.layout()
            self.viewMode = QComboBox()
            self.viewMode.setObjectName("pdfViewMode")
            self.viewMode.addItems(["Fit page", "Fit width", "100%"])
            self.viewMode.setToolTip("Choose how the current page fits the reading area")
            self.viewMode.currentTextChanged.connect(self.set_view_mode)
            layout.addWidget(self.viewMode)

            self.copyTextButton = QPushButton("Copy text")
            self.copyTextButton.setToolTip("Copy this page's selectable text")
            self.copyTextButton.clicked.connect(self.copy_page_text)
            layout.addWidget(self.copyTextButton)

            self.readModeButton = QPushButton("Read")
            self.readModeButton.setCheckable(True)
            self.readModeButton.setToolTip("Hide side panels for distraction-free reading")
            self.readModeButton.toggled.connect(self.set_read_mode)
            layout.addWidget(self.readModeButton)

            self.infoButton = QPushButton("Info")
            self.infoButton.clicked.connect(self.show_document_info)
            layout.addWidget(self.infoButton)

            for button in bar.findChildren(QPushButton):
                if button.text() == "Find":
                    try:
                        button.clicked.disconnect()
                    except TypeError:
                        pass
                    button.setText("Find all")
                    button.setToolTip("Search every page and list the matching pages")
                    button.clicked.connect(self.search_document)
                    break

        try:
            self.search.returnPressed.disconnect()
        except TypeError:
            pass
        self.search.returnPressed.connect(self.search_document)

        self._thumbnail_timer = QTimer(self)
        self._thumbnail_timer.setSingleShot(True)
        self._thumbnail_timer.timeout.connect(self._render_next_thumbnail)
        for sequence, callback in (
            ("Ctrl+F", lambda: self.search.setFocus()),
            ("F3", lambda: self.next_search_result(1)),
            ("Shift+F3", lambda: self.next_search_result(-1)),
            ("Ctrl+0", lambda: self.set_view_mode("Fit page")),
            ("Ctrl+Shift+R", lambda: self.readModeButton.toggle()),
        ):
            shortcut = QShortcut(QKeySequence(sequence), self)
            shortcut.setContext(Qt.WidgetWithChildrenShortcut)
            shortcut.activated.connect(callback)

        self.setStyleSheet(
            self.styleSheet()
            + """
            QListWidget#pdfThumbnails,QListWidget#pdfSearchResults {
                background:#f4f6f8;color:#202124;border:0;padding:6px;
            }
            QListWidget#pdfThumbnails::item,QListWidget#pdfSearchResults::item {
                background:white;border:1px solid #d8dde5;border-radius:6px;padding:6px;
            }
            QListWidget#pdfThumbnails::item:selected,QListWidget#pdfSearchResults::item:selected {
                background:#dbeafe;border:2px solid #2563eb;
            }
            QTabWidget#pdfSidebar QTabBar::tab {
                font-size:11px;padding:5px 7px;min-width:0;
            }
            """
        )

    # --------------------------------------------------------------- loading
    def open_pdf(self):
        path, _ = QFileDialog.getOpenFileName(self, "Open PDF", "", "PDF Files (*.pdf)")
        if path:
            self.load_pdf_path(path)

    def load_pdf_path(self, path, password=None):
        """Open a PDF without discarding the current unsaved PDF on failure."""
        if not self.maybe_save_pdf():
            return False
        candidate = None
        try:
            candidate = fitz.open(str(path))
            if candidate.needs_pass:
                supplied = password
                while supplied is None:
                    supplied, accepted = QInputDialog.getText(
                        self,
                        "Protected PDF",
                        "Password:",
                        QLineEdit.Password,
                    )
                    if not accepted:
                        candidate.close()
                        return False
                if not candidate.authenticate(supplied):
                    candidate.close()
                    QMessageBox.warning(self, "Protected PDF", "The password was not accepted.")
                    return False
            if len(candidate) < 1:
                raise ValueError("The PDF has no pages.")
            previous = self.pdf_doc
            self.pdf_doc = candidate
            candidate = None
            if previous is not None:
                previous.close()
            self.path = str(path)
            self.current_page = 0
            self.zoom = 1.0
            self.fit = True
            self._pdf_dirty = False
            self.pageSpin.blockSignals(True)
            self.pageSpin.setMaximum(len(self.pdf_doc))
            self.pageSpin.setValue(1)
            self.pageSpin.blockSignals(False)
            self.load_outline()
            self._clear_search()
            self._refresh_thumbnails()
            self.render()
            self.status.setText(f"{Path(path).name} · {len(self.pdf_doc)} page(s) · Ready")
            return True
        except Exception as exc:
            if candidate is not None:
                candidate.close()
            QMessageBox.warning(self, "PDF Error", f"The PDF could not be opened: {exc}")
            return False

    # ------------------------------------------------------------ thumbnails
    def _refresh_thumbnails(self):
        self._thumbnail_timer.stop()
        self.thumbnailList.clear()
        self._thumbnail_items = []
        self._thumbnail_queue = []
        if self.pdf_doc is None:
            return
        for page_index in range(len(self.pdf_doc)):
            item = QListWidgetItem(f"Page {page_index + 1}")
            item.setData(Qt.UserRole, page_index)
            item.setTextAlignment(Qt.AlignHCenter)
            item.setSizeHint(QSize(self.THUMBNAIL_WIDTH + 28, 188))
            self.thumbnailList.addItem(item)
            self._thumbnail_items.append(item)
            self._thumbnail_queue.append(page_index)
        self.thumbnailList.setCurrentRow(self.current_page)
        self._prioritize_thumbnail(self.current_page)
        self._thumbnail_timer.start(0)

    def _prioritize_thumbnail(self, page_index):
        if page_index in self._thumbnail_queue:
            self._thumbnail_queue.remove(page_index)
            self._thumbnail_queue.insert(0, page_index)

    def _render_next_thumbnail(self):
        if self.pdf_doc is None or not self._thumbnail_queue:
            return
        page_index = self._thumbnail_queue.pop(0)
        if 0 <= page_index < len(self.pdf_doc) and page_index < len(self._thumbnail_items):
            try:
                page = self.pdf_doc[page_index]
                scale = self.THUMBNAIL_WIDTH / max(1.0, page.rect.width)
                pix = page.get_pixmap(matrix=fitz.Matrix(scale, scale), alpha=False, annots=True)
                image = QImage(
                    pix.samples,
                    pix.width,
                    pix.height,
                    pix.stride,
                    QImage.Format_RGB888,
                ).copy()
                self._thumbnail_items[page_index].setIcon(QIcon(QPixmap.fromImage(image)))
            except (RuntimeError, ValueError, IndexError):
                self._thumbnail_items[page_index].setToolTip("Preview unavailable; the page can still be opened.")
        if self._thumbnail_queue:
            self._thumbnail_timer.start(1)

    def _thumbnail_clicked(self, item):
        page = item.data(Qt.UserRole)
        if isinstance(page, int):
            self._go_to_page(page)

    def _go_to_page(self, page_index):
        if self.pdf_doc is None:
            return
        self.current_page = max(0, min(int(page_index), len(self.pdf_doc) - 1))
        self.pageSpin.blockSignals(True)
        self.pageSpin.setValue(self.current_page + 1)
        self.pageSpin.blockSignals(False)
        if self.current_page < self.thumbnailList.count():
            self.thumbnailList.setCurrentRow(self.current_page)
            self.thumbnailList.scrollToItem(self.thumbnailList.item(self.current_page))
        self.render()

    def jump(self, page_number):
        self._go_to_page(page_number - 1)

    def step_page(self, delta):
        self._go_to_page(self.current_page + delta)

    # ---------------------------------------------------------------- search
    def _clear_search(self):
        self._search_hits = {}
        self._search_pages = []
        self._search_page_index = -1
        if hasattr(self, "searchResults"):
            self.searchResults.clear()
        self._clear_search_overlays()

    def search_document(self):
        query = self.search.text().strip()
        self._clear_search()
        if self.pdf_doc is None or not query:
            return
        total = 0
        for page_index in range(len(self.pdf_doc)):
            try:
                page = self.pdf_doc[page_index]
                hits = page.search_for(query)
            except (RuntimeError, ValueError):
                hits = []
            if hits:
                remaining = self.MAX_SEARCH_RESULTS - total
                kept = hits[: max(0, remaining)]
                if kept:
                    self._search_hits[page_index] = kept
                    self._search_pages.append(page_index)
                    text = " ".join(page.get_text("text").split())
                    lowered = text.casefold()
                    at = lowered.find(query.casefold())
                    start = max(0, at - 45) if at >= 0 else 0
                    snippet = text[start : start + 130]
                    item = QListWidgetItem(
                        f"Page {page_index + 1} · {len(hits)} match(es)\n{snippet}"
                    )
                    item.setData(Qt.UserRole, page_index)
                    item.setToolTip(snippet)
                    self.searchResults.addItem(item)
                    total += len(kept)
            if total >= self.MAX_SEARCH_RESULTS:
                break
            if page_index % 20 == 0:
                QApplication.processEvents()
        if not self._search_pages:
            self.status.setText(f'No matches for “{query}”.')
            return
        self._search_page_index = 0
        if self._craft_sidebar is not None:
            self._craft_sidebar.setCurrentWidget(self.searchResults)
        self._go_to_page(self._search_pages[0])
        suffix = " (first 500 shown)" if total >= self.MAX_SEARCH_RESULTS else ""
        self.status.setText(f'{total} match(es) on {len(self._search_pages)} page(s){suffix}.')

    def next_search_result(self, direction=1):
        if not self._search_pages:
            self.search_document()
            return
        self._search_page_index = (self._search_page_index + direction) % len(self._search_pages)
        self.searchResults.setCurrentRow(self._search_page_index)
        self._go_to_page(self._search_pages[self._search_page_index])

    def _search_result_clicked(self, item):
        page = item.data(Qt.UserRole)
        if isinstance(page, int):
            try:
                self._search_page_index = self._search_pages.index(page)
            except ValueError:
                self._search_page_index = -1
            self._go_to_page(page)

    def _clear_search_overlays(self):
        for overlay in self._search_overlays:
            overlay.hide()
            overlay.deleteLater()
        self._search_overlays = []

    def _show_search_overlays(self):
        self._clear_search_overlays()
        if self.pdf_doc is None or self.current_page not in self._search_hits:
            return
        bounds = self._image_bounds()
        if not bounds:
            return
        page = self.pdf_doc[self.current_page]
        left, top, width, height = bounds
        for hit in self._search_hits[self.current_page]:
            displayed = hit * page.rotation_matrix
            marker = QWidget(self.pageLabel)
            marker.setAttribute(Qt.WA_TransparentForMouseEvents)
            marker.setStyleSheet(
                "background:rgba(255,215,0,105);border:1px solid rgba(210,145,0,170);"
            )
            x = left + displayed.x0 * width / max(1.0, page.rect.width)
            y = top + displayed.y0 * height / max(1.0, page.rect.height)
            w = max(3, displayed.width * width / max(1.0, page.rect.width))
            h = max(3, displayed.height * height / max(1.0, page.rect.height))
            marker.setGeometry(int(x), int(y), int(w), int(h))
            marker.show()
            marker.raise_()
            self._search_overlays.append(marker)

    # --------------------------------------------------------------- viewing
    def render(self):
        if self.pdf_doc is None:
            return
        self.fit = self._view_mode == "Fit page"
        super().render()
        if self._view_mode == "Fit width":
            pixmap = self.pageLabel.pixmap()
            if pixmap is not None and not pixmap.isNull():
                width = max(80, self.scroll.viewport().width() - 34)
                self.pageLabel.setPixmap(pixmap.scaledToWidth(width, Qt.SmoothTransformation))
                # PDFNotesMixin positioned note cards against the pre-scaled
                # image. Reposition them after changing the displayed width.
                self._show_note_cards()
        self._show_search_overlays()
        if self.current_page < self.thumbnailList.count():
            self.thumbnailList.setCurrentRow(self.current_page)

    def set_view_mode(self, mode):
        if mode not in {"Fit page", "Fit width", "100%"}:
            return
        self._view_mode = mode
        if mode == "100%":
            self.zoom = 1.0
            self.fit = False
        self.render()

    def set_read_mode(self, enabled):
        if self._craft_sidebar is not None:
            self._craft_sidebar.setVisible(not enabled)
        self.status.setVisible(not enabled)
        self.readModeButton.setText("Exit read" if enabled else "Read")
        self.render()

    def copy_page_text(self):
        if self.pdf_doc is None:
            return
        text = self.pdf_doc[self.current_page].get_text("text")
        QApplication.clipboard().setText(text)
        self.status.setText(
            f"Copied page {self.current_page + 1} text."
            if text.strip()
            else f"Page {self.current_page + 1} has no selectable text; try OCR."
        )

    def show_document_info(self):
        if self.pdf_doc is None:
            return
        metadata = self.pdf_doc.metadata or {}
        page = self.pdf_doc[self.current_page]
        lines = [
            f"File: {Path(self.path).name if self.path else 'Unsaved PDF'}",
            f"Pages: {len(self.pdf_doc)}",
            f"Current size: {page.rect.width:.0f} × {page.rect.height:.0f} points",
            f"PDF format: {metadata.get('format') or 'Unknown'}",
            f"Title: {metadata.get('title') or 'Not set'}",
            f"Author: {metadata.get('author') or 'Not set'}",
            f"Encrypted: {'Yes' if self.pdf_doc.is_encrypted else 'No'}",
        ]
        QMessageBox.information(self, "PDF information", "\n".join(lines))

    # --------------------------------------------------------------- editing
    def _annotation_signature(self):
        if self.pdf_doc is None:
            return ()
        page = self.pdf_doc[self.current_page]
        return tuple(
            (annot.xref, annot.type[0], annot.info.get("content", ""), tuple(annot.rect))
            for annot in (page.annots() or ())
        )

    def _edit_note(self, xref, point=None):
        before = self._annotation_signature()
        super()._edit_note(xref, point)
        if self._annotation_signature() != before:
            self._pdf_dirty = True

    def rotate(self, degrees):
        if self.pdf_doc is None:
            return
        super().rotate(degrees)
        self._pdf_dirty = True
        self._queue_thumbnail_refresh(self.current_page)

    def highlight_search(self):
        if self.pdf_doc is None:
            return
        query = self.search.text().strip()
        hits = self.pdf_doc[self.current_page].search_for(query) if query else []
        super().highlight_search()
        if hits:
            self._pdf_dirty = True
            self._queue_thumbnail_refresh(self.current_page)

    def _queue_thumbnail_refresh(self, page_index):
        if 0 <= page_index < len(self._thumbnail_items):
            self._thumbnail_items[page_index].setIcon(QIcon())
            if page_index not in self._thumbnail_queue:
                self._thumbnail_queue.insert(0, page_index)
            if not self._thumbnail_timer.isActive():
                self._thumbnail_timer.start(0)

    def save_as(self):
        if self.pdf_doc is None:
            return False
        path, _ = QFileDialog.getSaveFileName(
            self,
            "Save PDF As",
            self.path or "Document.pdf",
            "PDF Files (*.pdf)",
        )
        return self._save_pdf_to(path) if path else False

    def _save_pdf_to(self, path):
        if self.pdf_doc is None or not path:
            return False
        destination = Path(path)
        if destination.suffix.lower() != ".pdf":
            destination = destination.with_suffix(".pdf")
        destination.parent.mkdir(parents=True, exist_ok=True)
        descriptor, temporary = tempfile.mkstemp(
            dir=str(destination.parent), prefix=".jesson-pdf-", suffix=".pdf"
        )
        os.close(descriptor)
        os.unlink(temporary)
        replacing_open_source = bool(
            self.path
            and os.path.normcase(os.path.abspath(self.path))
            == os.path.normcase(os.path.abspath(destination))
        )
        current_page = self.current_page
        try:
            self.pdf_doc.save(temporary, garbage=4, deflate=True)
            # Windows does not permit replacing a file held open by PyMuPDF.
            # Close only after the complete replacement has been written.
            if replacing_open_source:
                self.pdf_doc.close()
                self.pdf_doc = None
            os.replace(temporary, destination)
            if replacing_open_source:
                self.pdf_doc = fitz.open(str(destination))
                self.current_page = min(current_page, len(self.pdf_doc) - 1)
        except Exception as exc:
            if os.path.exists(temporary):
                os.unlink(temporary)
            if self.pdf_doc is None and destination.exists():
                try:
                    self.pdf_doc = fitz.open(str(destination))
                    self.current_page = min(current_page, len(self.pdf_doc) - 1)
                except Exception:
                    pass
            QMessageBox.warning(self, "Save Error", f"The PDF was not replaced: {exc}")
            return False
        self.path = str(destination)
        self._pdf_dirty = False
        self.status.setText(f"Saved {destination.name}")
        return True

    def maybe_save_pdf(self):
        if self.pdf_doc is None or not self._pdf_dirty:
            return True
        answer = QMessageBox.question(
            self,
            "Unsaved PDF changes",
            "Save your PDF annotations or page changes before continuing?",
            QMessageBox.Save | QMessageBox.Discard | QMessageBox.Cancel,
            QMessageBox.Save,
        )
        if answer == QMessageBox.Cancel:
            return False
        if answer == QMessageBox.Save:
            return bool(self._save_pdf_to(self.path)) if self.path else bool(self.save_as())
        return True

