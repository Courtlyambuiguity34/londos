"""Clickable PDF note cards backed by ordinary PDF Text annotations."""
from PyQt5.QtCore import Qt, QEvent, QTimer, QPointF
from PyQt5.QtGui import QFont
from PyQt5.QtWidgets import QPushButton, QDialog, QVBoxLayout, QLabel, QTextEdit, QDialogButtonBox, QTabWidget, QListWidget, QListWidgetItem
import pymupdf as fitz
import textwrap


class PDFNotesMixin:
    def __init__(self):
        self._note_cards = []
        self._place_note = False
        super().__init__()
        # A list keeps overlapping imported notes individually accessible.
        split = self.scroll.parentWidget()
        index = split.indexOf(self.outline)
        sidebar = QTabWidget()
        sidebar.addTab(self.outline, 'Outline')
        self.noteList = QListWidget()
        self.noteList.setWordWrap(True)
        self.noteList.itemClicked.connect(lambda item: self._edit_note(item.data(Qt.UserRole)))
        sidebar.addTab(self.noteList, 'Page notes')
        split.insertWidget(index, sidebar)
        self.pageLabel.setStyleSheet('background:#3c4043;padding:0;')
        self.pageLabel.installEventFilter(self)
        self.scroll.viewport().installEventFilter(self)

    def add_note(self):
        if not self.pdf_doc:
            return
        self._place_note = True
        self.pageLabel.setCursor(Qt.CrossCursor)
        self.status.setText('Click the PDF page to place a sticky note. Press Escape to cancel.')

    def _image_bounds(self):
        pixmap = self.pageLabel.pixmap()
        if pixmap is None or pixmap.isNull():
            return None
        area = self.pageLabel.contentsRect()
        width = pixmap.width() / pixmap.devicePixelRatio()
        height = pixmap.height() / pixmap.devicePixelRatio()
        return ((area.width() - width) / 2 + area.x(),
                (area.height() - height) / 2 + area.y(), width, height)

    def _page_point(self, point):
        bounds = self._image_bounds()
        if not bounds or not self.pdf_doc:
            return None
        left, top, width, height = bounds
        if not (left <= point.x() <= left + width and top <= point.y() <= top + height):
            return None
        page = self.pdf_doc[self.current_page]
        displayed = fitz.Point((point.x()-left)*page.rect.width/width,
                               (point.y()-top)*page.rect.height/height)
        return displayed * page.derotation_matrix

    def eventFilter(self, obj, event):
        if obj is self.scroll.viewport() and event.type() == QEvent.Resize:
            QTimer.singleShot(0, self.render)
        if obj is self.pageLabel and event.type() == QEvent.Resize:
            QTimer.singleShot(0, self._show_note_cards)
        if obj is self.pageLabel and event.type() == QEvent.MouseButtonPress and event.button() == Qt.LeftButton:
            if self._place_note:
                point = self._page_point(event.pos())
                if point is not None:
                    self._place_note = False
                    self.pageLabel.unsetCursor()
                    self._edit_note(None, point)
                    return True
        return super().eventFilter(obj, event)

    def keyPressEvent(self, event):
        if event.key() == Qt.Key_Escape and self._place_note:
            self._place_note = False
            self.pageLabel.unsetCursor()
            self.status.setText('Note placement cancelled.')
            return
        super().keyPressEvent(event)

    def render(self):
        super().render()
        self._show_note_cards()

    def _show_note_cards(self):
        for card in self._note_cards:
            card.hide(); card.deleteLater()
        self._note_cards = []
        if hasattr(self, "noteList"):
            self.noteList.clear()
        bounds = self._image_bounds()
        if not self.pdf_doc or not bounds:
            return
        page = self.pdf_doc[self.current_page]
        left, top, width, height = bounds
        for annotation in page.annots() or ():
            if annotation.type[0] not in (fitz.PDF_ANNOT_TEXT, fitz.PDF_ANNOT_FREE_TEXT):
                continue
            text = annotation.info.get('content', '')
            if not text.strip():
                continue
            position = annotation.rect.top_left * page.rotation_matrix
            card = QPushButton(self.pageLabel)
            lines = textwrap.wrap(text.replace('\n', ' '), width=22)
            preview = '\n'.join(lines[:2]) + ('…' if len(lines) > 2 else '')
            card.setText('✎ Note\n' + preview + '\nClick to read / edit')
            card.setToolTip(text)
            card.setAccessibleName('PDF sticky note: ' + text)
            card.setFont(QFont('Segoe Print', 10))
            card.setStyleSheet('QPushButton{background:#fff3a6;color:#332b10;border:1px solid #cfb94c;border-radius:4px;padding:5px;text-align:left;} QPushButton:hover{background:#ffe779;}')
            card_width = max(30, min(200, int(width)))
            card_height = max(30, min(82, int(height)))
            x = left + position.x * width / page.rect.width
            y = top + position.y * height / page.rect.height
            x = max(left, min(x, left + width - card_width))
            y = max(top, min(y, top + height - card_height))
            card.setGeometry(int(x), int(y), card_width, card_height)
            xref = annotation.xref
            if hasattr(self, 'noteList'):
                entry = QListWidgetItem(text[:180], self.noteList)
                entry.setData(Qt.UserRole, xref); entry.setToolTip(text)
            card.clicked.connect(lambda checked=False, ref=xref: self._edit_note(ref))
            card.show(); card.raise_()
            self._note_cards.append(card)

    def _edit_note(self, xref, point=None):
        page = self.pdf_doc[self.current_page]
        annotation = page.load_annot(xref) if xref is not None else None
        dialog = QDialog(self)
        dialog.setWindowTitle('PDF sticky note')
        dialog.resize(460, 330)
        layout = QVBoxLayout(dialog)
        label = QLabel(f'Page {self.current_page+1} · Save As to preserve changes in the PDF')
        label.setWordWrap(True); layout.addWidget(label)
        editor = QTextEdit()
        editor.setAcceptRichText(False)
        editor.setFont(QFont('Segoe Print', 12))
        editor.setStyleSheet('background:#fff7bf;color:#332b10;padding:10px;')
        editor.setPlainText(annotation.info.get('content', '') if annotation else '')
        layout.addWidget(editor)
        buttons = QDialogButtonBox(QDialogButtonBox.Save | QDialogButtonBox.Cancel)
        buttons.accepted.connect(dialog.accept); buttons.rejected.connect(dialog.reject)
        delete = None
        if annotation:
            delete = buttons.addButton('Delete note', QDialogButtonBox.DestructiveRole)
            delete.clicked.connect(lambda: dialog.done(2))
        layout.addWidget(buttons)
        result = dialog.exec_()
        if result == 2 and annotation:
            page.delete_annot(annotation)
        elif result == QDialog.Accepted and editor.toPlainText().strip():
            text = editor.toPlainText().strip()
            if annotation:
                annotation.set_info(content=text); annotation.update()
            else:
                annotation = page.add_text_annot(point, text, icon='Note')
                annotation.set_colors(stroke=(1, .88, .3)); annotation.update()
        else:
            return
        self.render()
        self.status.setText('Sticky notes changed — Save As to preserve them in the PDF.')
