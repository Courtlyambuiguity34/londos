@echo off
setlocal
cd /d "%~dp0"
echo Building your single-file Jesson Reader as builder.exe...
py -3.12 -c "import struct; raise SystemExit(0 if struct.calcsize('P') == 8 else 1)" >nul 2>&1
if errorlevel 1 goto need_python
py -3.12 -m venv .venv
if errorlevel 1 goto failed
.venv\Scripts\python.exe -m pip install -r requirements-build.txt
if errorlevel 1 goto failed
.venv\Scripts\python.exe build_app.py --onefile --name builder
if errorlevel 1 goto failed
echo.
echo Ready: %~dp0dist\builder.exe
echo This is the standalone reader application. Keep it and launch it directly.
start "" "%~dp0dist\builder.exe"
pause
exit /b 0
:need_python
echo Install 64-bit Python 3.12 from https://www.python.org/downloads/windows/
echo Include the Python launcher, then run this batch file again.
pause
exit /b 1
:failed
echo The build failed. Read the error above; the existing source remains available.
pause
exit /b 1
