@echo off
setlocal
cd /d "%~dp0"
set "READER_PYTHON="
call :try_python "D:\1\Python\Python313\python.exe"
if defined READER_PYTHON goto found
call :try_python "%LOCALAPPDATA%\Programs\Python\Python313\python.exe"
if defined READER_PYTHON goto found
call :try_python "%ProgramFiles%\Python313\python.exe"
if defined READER_PYTHON goto found
call :try_python "%ProgramFiles%\Python 3.13\python.exe"
if defined READER_PYTHON goto found
call :try_python "C:\Python313\python.exe"
if defined READER_PYTHON goto found
for /f "delims=" %%P in ('py -3.13 -c "import sys; print(sys.executable)" 2^>nul') do call :try_python "%%P"
if not defined READER_PYTHON goto need_python
:found
echo Using "%READER_PYTHON%"
echo Checking existing packages. No virtual environment will be created.
"%READER_PYTHON%" -m pip --version >nul 2>&1
if errorlevel 1 goto need_pip
"%READER_PYTHON%" ensure_build_packages.py
if errorlevel 1 goto failed
"%READER_PYTHON%" prepare_vlc.py
if errorlevel 1 goto failed
"%READER_PYTHON%" build_app.py --onefile --name Jesson
if errorlevel 1 goto failed
echo Ready: %~dp0dist\Jesson.exe
start "" "%~dp0dist\Jesson.exe"
pause
exit /b 0
:try_python
if defined READER_PYTHON exit /b 0
if not exist "%~1" exit /b 0
"%~1" -c "import sys, struct; raise SystemExit(0 if sys.version_info[:2] == (3, 13) and struct.calcsize('P') == 8 else 1)" >nul 2>&1
if errorlevel 1 exit /b 0
set "READER_PYTHON=%~1"
exit /b 0
:need_python
echo No 64-bit Python 3.13 found. Install it or edit the search paths in this batch.
pause
exit /b 1
:need_pip
echo Pip is missing. Run "%READER_PYTHON%" -m ensurepip, then try again.
pause
exit /b 1
:failed
echo Build failed. Read the error above. Python 3.13 Windows packaging still needs verification on your PC.
pause
exit /b 1
