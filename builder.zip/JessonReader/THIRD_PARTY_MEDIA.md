# Portable media runtime

The Windows build downloads the official portable VLC 3.0.24 x64 distribution from:

https://download.videolan.org/pub/videolan/vlc/3.0.24/win64/vlc-3.0.24-win64.zip

The verified published SHA-256 is:

`fcf30850371ad10c9373cc4f0f4501e7dee49e3e9ae9f20c72fb2661a1ca6323`

Published checksum: the archive URL followed by `.sha256`.

The build retains the full runtime distribution, including its COPYING, AUTHORS, README and plugin files. Its upstream license/notices apply. The public source distribution is available from https://download.videolan.org/pub/videolan/vlc/3.0.24/ . The python-vlc wrapper is installed separately through pip; its source retains its upstream license header. Jesson uses libVLC through that wrapper, with Qt signals/timers for UI controls.

The source download ZIP omits the large native runtime and generated builds. Running the batch prepares it; the finished Windows EXE includes it. Build an EXE with build_app.py so the runtime collection rules are applied, rather than reusing an old machine-specific spec.

Music decoding uses VLC. Browser videos/meetings, speech synthesis and recording keep their existing browser/platform/FFmpeg paths. Bundled VLC does not add DRM support or guarantee decoding corrupted media.
