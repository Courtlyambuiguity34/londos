# Manual VLC and comfortable study setup

## Use VLC files without downloading them again

Keep **all files from the Jesson source ZIP**, then add your runtime folder. The four files in the proposed example are not sufficient: the reader imports the media, PDF-note and study helper modules too.

```text
builder/
    Jesson_Reader.py
    vlc_backend.py
    vlc_runtime_config.py
    pdf_notes.py
    study_planner.py
    study_schedule.py
    study_reminder_agent.py
    build_windows.bat
    build_windows_offline.bat
    build_app.py
    ensure_build_packages.py
    prepare_vlc.py
    requirements.txt
    requirements-build.txt
    jesson_app.ico                 (or your existing ICO filename)
    ...other files from the ZIP...
    vlc_runtime/
        libvlc.dll
        libvlccore.dll
        plugins/
            ...plugin folders containing DLLs...
        ...matching runtime support files and license notices...
```

Both **vlc_runtime** and **vlc-runtime** work. If both are valid, the underscore name is preferred. The build copies the chosen runtime into a canonical bundled `vlc-runtime` directory. A valid existing runtime is reused without downloading; an incomplete or incompatible supplied folder causes a clear error rather than an overwrite or replacement download. The builder checks x64 DLL headers and the presence of access, audio-output, codec and demux plugin DLLs; this structural validation cannot prove every codec will work.

Use DLLs and plugins from the **same 64-bit Windows VLC distribution**. Copy the complete plugins directory for the most reliable format coverage. Keep required root support DLLs and upstream license notices. Do not mix 32-bit plugins with 64-bit Python/VLC.

Your proposed categories — access, audio_filter, audio_mixer, audio_output, codec, demux, packetizer, stream_filter and meta_engine — contain the principal local-audio components. They may be adequate for a tested selection of audio files, but they are not a universal minimum. Supporting modules in misc, stream_extractor, logger or other categories can be needed for particular formats or inputs. Folder names alone do not establish which decoders are actually inside. Jesson does not automatically prune the supplied runtime or promise all formats for a pruned set.

**Recommended starting point:** the two core DLLs, the complete matching plugins tree and required support files/notices. Verify your actual MP3/M4A/AAC/FLAC/WAV files before experimenting with a smaller copy. You do not need to install K-Lite or register VLC in Windows for this bundled playback path.

### Strictly offline build

Double-click **build_windows_offline.bat**, or run:

```bat
build_windows.bat --offline
```

This checks existing Python packages and the manual VLC directory. It does not run pip install or download VLC. If something is absent it reports the requirement and stops. Normal build_windows.bat retains the earlier behavior of installing missing Python packages and downloading VLC only if no runtime was supplied.

Both modes use your existing Python 3.13 and create no virtual environment. The result is `dist\Jesson.exe`.

### Size recommendation

Keep the full reader features. The browser engine and native libraries are substantial; pruning VLC alone cannot turn this into a tiny application. A folder build is often preferable when using background reminders because both processes share the same installed files instead of independently extracting a large single-file executable:

```bat
"D:\1\Python\Python313\python.exe" build_app.py --name Jesson --zip
```

Extract `dist\Jesson-portable.zip` and retain the entire Jesson folder including `_internal`. The default batch still creates a single EXE. ZIP compression is lossless; it does not reduce music or image quality. No unsupported percentage size reduction is promised.

## Study Planner

Open **Study Planner**, use **Ctrl+Alt+P**, or press **Study plan** in the bottom bar.

- Add a subject, local start date/time, session length and optional page numbers/reading goal.
- Choose Once, Daily or Weekly, with an end date for repeats. Four weeks is the initial repeat-until date; change it to match your exams.
- Select a row to update/delete it or start its focus session. Completing a repeated occurrence leaves future repeats available.
- Snooze an incomplete, due reminder for ten minutes. Export the timetable as CSV when useful.
- Configure focus minutes, break minutes and a daily completed-focus goal. Pause/resume uses a monotonic deadline; delayed UI ticks do not shorten the timer. Closing Jesson saves the remaining time and reopens the timer paused.
- Focus and break transitions wait for you to start the next block. They do not force continuous study or award time for incomplete blocks. Progress is based on completed focus blocks, not surveillance of reading activity.
- Keep music playing through breaks by default, or enable automatic music pause when a focus block finishes. Resume it whenever you wish.

## Reading focus and music

Press **F11** or **Focus F11** in the bottom bar to enter a full-screen reading view. The main tab bar, Word ribbon and PDF toolbar are hidden temporarily; your document and its formatting are untouched. Press F11, Escape or Exit focus to restore the previous view. The timer, music play/pause button and Study plan button remain available at the bottom.

Existing themes, document zoom and PDF fit controls remain. Set a comfortable font/zoom before entering focus. Select existing document text before changing its font. The source bundle includes the earlier fixes for PDF sticky notes, table recalculation and music decoding.

## Reminders after closing Jesson on Windows

1. Put the final EXE, or the entire folder build, at a location you will keep.
2. Open Study Planner and click **Enable reminders after closing Jesson**.
3. Jesson registers a Task Scheduler task for your current Windows account, at normal user privilege, and starts its reminder process. It also starts at your next sign-in. No password is collected or stored.
4. Close Jesson normally. The timetable reminders can continue while your PC is on and you are signed in. A sleeping/offline-from-power PC cannot display a reminder; eligible overdue sessions are checked when the process resumes or starts again.
5. Click **Disable background reminders** to turn this off and remove the task. If you move/update the EXE location, disable and re-enable the feature to register the current path.

Task names start with `Jesson Study Reminders`. You can inspect them in Windows Task Scheduler. The app reports registration/start/removal failures instead of claiming success. Account or device policy may restrict task creation; this must be checked on your PC. No system-wide administrator service is installed.

The background entry point loads the timetable/notification code before Qt or the main reader UI. A single-file EXE still has PyInstaller extraction overhead; a folder build avoids that repeated native-file extraction. A process mutex and shared SQLite notification ledger prevent duplicate reminders from the foreground app and background process. Only the current account's timetable is used.

Background support covers timetable reminders. The interactive focus timer deliberately pauses when you close the reader. Reminders are local; no email, cloud account or paid service is needed.

## Data and verification

Study data is stored beside other per-user Jesson settings, normally `%LOCALAPPDATA%\JessonAssistant\study_plan.json`. Reminder history/deduplication is in `study_plan.reminders.sqlite3` beside it. Back up the JSON if you want to keep your plan. Invalid JSON is preserved as a backup before a new plan is written. Timetable CSV exports include your entered topics and notes; share them only when you intend to.

Focused checks cover persistence, timer state transitions, snoozing, concurrent reminder claims, manual runtime aliases, architecture checks, offline build behavior and restoration of reading focus controls. Windows Task Scheduler registration and native reminder dialogs were simulated in tests, not executed on a Windows PC in this cloud environment. Perform a short real reminder test after enabling it: create a session a few minutes ahead, close Jesson, confirm its reminder, then reopen and confirm it is not delivered twice.

No model choice establishes that this is objectively the best reading app. The goal is a comfortable reader whose behavior is understandable, tested and useful for your study routine.
