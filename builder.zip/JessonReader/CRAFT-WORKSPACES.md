# Jesson craft workspaces

Jesson remains an independent Python/PyQt application. This update studies the public interaction patterns of ArtCraft, PdfCraft and WordCraft, then implements suitable ideas in Python without copying their Rust source, brand assets or proprietary application code.

## PDF workspace

![PDF workspace with whole-document search](craft-pdf-preview.png)

Open the **PDF** tab and choose **Open**. The left workspace now contains:

- **Pages** — lazy-rendered page thumbnails; click one to navigate.
- **Outline** — the PDF's embedded bookmarks, when present.
- **Page notes** — every readable Text/FreeText annotation on the current page, including overlapping notes.
- **Search** — matches from the whole document, with page number and context.

Enter text in **Find in PDF** and press Enter or choose **Find all**. Every page is searched, matching pages appear in the Search panel, and matches on the open page are highlighted without altering the PDF. Use `F3` and `Shift+F3` to move between matching pages. At most 500 individual matches are listed so unusually large documents cannot make the interface grow without limit.

The view menu provides **Fit page**, **Fit width** and **100%**. **Read** hides the sidebar and status line for a focused canvas; choose **Exit read** to restore them. **Copy text** copies selectable text from the current page. Scanned image-only pages may need OCR in a dedicated OCR tool before text can be searched or copied.

Sticky notes remain ordinary PDF annotations. Choose **Note**, click the page, write the note, then click its yellow card or its Page notes entry to read, edit or delete it. Rotation, highlights and note edits are treated as unsaved changes. Jesson asks before replacing or closing an edited PDF. Saving uses a complete temporary file and atomic replacement; on Windows the source is closed only after the temporary PDF is complete, then reopened.

Malformed, empty and unsupported PDFs do not replace the document already open. Password-protected PDFs prompt for a password. Keep a backup of important originals: PDF forms, signatures, DRM, unusual encryption and every third-party annotation type are not guaranteed editable.

## Document workspace

![Document workspace with physical page and searchable tools](craft-document-preview.png)

The Document tab keeps Jesson's existing Word-inspired ribbon, page canvas, tables and formulas, comments, tracked changes, citations, mail merge, headers/footers, print/PDF output and recovery tools.

Use **Search tools** in the blue title strip, `Alt+Q`, or `Ctrl+Shift+P` to open the document command palette. Search by a tool name or purpose—for example `comment`, `page`, `find`, `read`, or `recover`—then press Enter. The palette calls the same guarded commands as the ribbon; it does not implement a second editing path.

DOCX import now follows the source document's paragraph/table order instead of moving every table to the end. It imports supported run fonts, sizes, bold/italic/underline, colour, superscript/subscript, paragraph alignment and spacing, page orientation/margins, and the first section's text header/footer. A matching `.jesson.json` sidecar remains authoritative for Jesson-native comments, review marks and page metadata.

Jesson is not a complete Microsoft Word replacement. Complex floating objects, macros, fields, multi-section page furniture, exact pagination, advanced equations and full tracked-change interoperability may differ. Keep the original DOCX and verify exported coursework before submission. HTML plus its adjacent `.jesson.json` remains the best format for Jesson-native review metadata.

## ArtCraft influence

ArtCraft's useful contribution here is its discoverable tool-catalogue and panel model: primary work stays on a central canvas while searchable tools and contextual collections remain nearby. Jesson applies that model to the command palette and PDF sidebar. It does not incorporate ArtCraft's media-generation code, providers or assets.

## Keyboard summary

| Shortcut | Action |
| --- | --- |
| `Alt+Q` / `Ctrl+Shift+P` | Search Document tools |
| `Ctrl+F` in PDF | Focus PDF search |
| `F3` / `Shift+F3` in PDF | Next / previous matching page |
| `Ctrl+0` in PDF | Fit page |
| `Ctrl+Shift+R` in PDF | Toggle PDF read mode |

