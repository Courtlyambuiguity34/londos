"""Build on the OS you intend to use: Windows builds require Windows Python."""
import argparse
import os
import re
from pathlib import Path
import subprocess
import sys

from PIL import Image


def find_icon(folder):
    explicit = os.environ.get('JESSON_ICON')
    candidates = ([Path(explicit).expanduser()] if explicit else [])
    candidates += sorted((p for p in folder.iterdir() if p.is_file() and p.suffix.lower() == '.ico'),
                         key=lambda p: (p.name.casefold() != 'jesson_app.ico', p.name.casefold()))
    for candidate in candidates:
        try:
            with Image.open(candidate) as image:
                if image.format == 'ICO':
                    image.load()
                    return candidate.resolve()
        except (OSError, ValueError):
            pass
    return None


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--onefile', action='store_true', help='Larger startup cost; test onedir first.')
    parser.add_argument('--console', action='store_true', help='Keep a terminal for packaging diagnostics.')
    parser.add_argument("--name", default="JessonReader", help="Executable basename.")
    args = parser.parse_args()
    if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_-]{0,59}", args.name):
        parser.error("--name must contain 1–60 letters, digits, underscores or hyphens and start with a letter or digit.")
    folder = Path(__file__).resolve().parent
    icon = find_icon(folder)
    command = [sys.executable, '-m', 'PyInstaller', '--noconfirm', '--clean',
               '--name', args.name, '--onefile' if args.onefile else '--onedir',
               '--console' if args.console else '--windowed',
               '--collect-submodules', 'google.genai',
               '--hidden-import', 'PyQt5.QtMultimedia', '--hidden-import', 'PyQt5.QtTextToSpeech',
               '--hidden-import', 'PyQt5.QtWebEngineWidgets',
               '--exclude-module', 'PySide6', '--exclude-module', 'PyQt6',
               '--exclude-module', 'torch', '--exclude-module', 'tensorflow',
               '--exclude-module', 'jax',
               '--collect-data', 'spellchecker',
               '--collect-data', 'imageio_ffmpeg']
    # Qt's PyInstaller hooks collect WebEngine helpers, locales and resources.
    # Explicitly retain optional multimedia/TTS platform plugins where provided.
    from PyQt5.QtCore import QLibraryInfo
    plugins = Path(QLibraryInfo.location(QLibraryInfo.PluginsPath))
    for category in ('mediaservice', 'audio', 'texttospeech'):
        source = plugins / category
        if source.is_dir():
            command += ['--add-data', f'{source}{os.pathsep}PyQt5/Qt5/plugins/{category}']
    if icon:
        command += ['--icon', str(icon), '--add-data', f'{icon}{os.pathsep}.']
        print('Found a valid ICO; bundling it for the executable and window.')
    else:
        print('No valid ICO found: the window uses the built-in J fallback. Add your ICO and rebuild for an EXE file icon.')
    command.append(str(folder / 'Jesson_Reader.py'))
    return subprocess.call(command, cwd=folder)


if __name__ == '__main__':
    raise SystemExit(main())
