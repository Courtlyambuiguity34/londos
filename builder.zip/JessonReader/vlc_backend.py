"""Qt-facing libVLC audio adapter; all UI signals are emitted by a Qt timer."""
import os
from pathlib import Path
import sys
from PyQt5.QtCore import QObject, QTimer, pyqtSignal
from PyQt5.QtMultimedia import QMediaPlayer, QMediaContent

_DLL_HANDLES = []


def runtime_directory():
    from vlc_runtime_config import find_runtime, valid_runtime
    for base in (Path(getattr(sys, '_MEIPASS', Path(__file__).resolve().parent)),
                 Path(sys.executable).resolve().parent, Path(__file__).resolve().parent):
        runtime = find_runtime(base)
        if runtime:
            return runtime
    if os.environ.get('JESSON_VLC_DIR'):
        runtime = Path(os.environ['JESSON_VLC_DIR'])
        if valid_runtime(runtime): return runtime
    if os.name == 'nt':
        runtime = Path(os.environ.get('ProgramFiles', r'C:\Program Files')) / 'VideoLAN' / 'VLC'
        if valid_runtime(runtime): return runtime
    return None


def load_vlc():
    if os.name == 'nt':
        root = runtime_directory()
        if root is None:
            raise RuntimeError('VLC runtime missing. Rebuild with the supplied Windows batch.')
        if hasattr(os, 'add_dll_directory'):
            _DLL_HANDLES.append(os.add_dll_directory(str(root)))
        os.environ['PYTHON_VLC_LIB_PATH'] = str(root / 'libvlc.dll')
        os.environ['PYTHON_VLC_MODULE_PATH'] = str(root)
        os.environ['VLC_PLUGIN_PATH'] = str(root / 'plugins')
    import vlc
    return vlc


class VLCMediaPlayer(QObject):
    durationChanged = pyqtSignal(int)
    positionChanged = pyqtSignal(int)
    currentMediaChanged = pyqtSignal(object)
    stateChanged = pyqtSignal(int)
    mediaStatusChanged = pyqtSignal(int)
    error = pyqtSignal(int)

    def __init__(self, parent=None):
        super().__init__(parent)
        self._media = QMediaContent()
        self._instance = self._player = self._vlc = None
        self._state = QMediaPlayer.StoppedState
        self._duration = self._position = self._volume = 0
        self._terminal_reported = False
        self.error_code = QMediaPlayer.NoError
        self._timer = QTimer(self)
        self._timer.setInterval(150)
        self._timer.timeout.connect(self._poll)
        try:
            self._vlc = load_vlc()
            self._instance = self._vlc.Instance('--no-video', '--quiet', '--no-media-library')
            if not self._instance:
                raise RuntimeError('VLC initialization failed')
            self._player = self._instance.media_player_new()
        except Exception:
            self.error_code = QMediaPlayer.ServiceMissingError

    def setPlaylist(self, playlist):
        # Queue order/shuffle/repeat stay in the existing QMediaPlaylist model.
        pass

    def currentMedia(self):
        return self._media

    def setMedia(self, media):
        self.stop()
        self._media = media
        self._terminal_reported = False
        self._duration = self._position = 0
        self.durationChanged.emit(0)
        self.positionChanged.emit(0)
        self.currentMediaChanged.emit(media)
        if self._player is not None:
            self.error_code = QMediaPlayer.NoError
            native = self._instance.media_new_path(media.canonicalUrl().toLocalFile())
            self._player.set_media(native)
            native.release()

    def isAvailable(self): return self._player is not None

    def state(self): return self._state
    def duration(self): return self._duration
    def position(self): return self._position

    def _set_state(self, state):
        if state != self._state:
            self._state = state
            self.stateChanged.emit(state)

    def _failure(self):
        if self._terminal_reported:
            return
        self._terminal_reported = True
        self.error_code = QMediaPlayer.ResourceError if self._player else QMediaPlayer.ServiceMissingError
        self._timer.stop()
        self._set_state(QMediaPlayer.StoppedState)
        self.error.emit(self.error_code)

    def play(self):
        if self._player is None:
            self._failure(); return
        self._terminal_reported = False
        if self._player.play() == -1:
            self._failure(); return
        self._timer.start()

    def pause(self):
        if self._player is not None:
            self._player.set_pause(1)
            self._set_state(QMediaPlayer.PausedState)

    def stop(self):
        self._timer.stop()
        if self._player is not None:
            self._player.stop()
        self._position = 0
        self.positionChanged.emit(0)
        self._set_state(QMediaPlayer.StoppedState)

    def setPosition(self, position):
        if self._player is not None:
            self._player.set_time(max(0, int(position)))

    def setVolume(self, volume):
        self._volume = max(0, min(100, int(volume)))
        if self._player is not None:
            self._player.audio_set_volume(self._volume)

    def volume(self): return self._volume

    def _poll(self):
        if self._player is None:
            return
        state = self._player.get_state()
        if state == self._vlc.State.Error:
            self._failure(); return
        if state == self._vlc.State.Ended:
            if not self._terminal_reported:
                self._terminal_reported = True
                self._timer.stop()
                self._set_state(QMediaPlayer.StoppedState)
                self.mediaStatusChanged.emit(QMediaPlayer.EndOfMedia)
            return
        if state == self._vlc.State.Playing:
            self._set_state(QMediaPlayer.PlayingState)
        elif state == self._vlc.State.Paused:
            self._set_state(QMediaPlayer.PausedState)
        duration = max(0, self._player.get_length())
        position = max(0, self._player.get_time())
        if duration != self._duration:
            self._duration = duration; self.durationChanged.emit(duration)
        if position != self._position:
            self._position = position; self.positionChanged.emit(position)

    def release(self):
        self.stop()
        if self._player is not None:
            self._player.release(); self._player = None
        if self._instance is not None:
            self._instance.release(); self._instance = None
