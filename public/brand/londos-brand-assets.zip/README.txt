Londos brand assets - 20 October 2026

londos-logo.png: transparent logo for light website backgrounds (1200 x 400).
londos-logo-dark.png: reversed logo on green (1200 x 400).
londos-mark.png: transparent standalone symbol (1024 x 1024).
app-icon-192.png and app-icon-512.png: standard app icons.
app-icon-maskable-512.png: Android icon with extra cropping space.
apple-touch-icon.png: 180 x 180 Apple home-screen icon.
favicon-64.png: browser icon.

These are PNG raster assets, not vector paths. Keep their aspect ratios.
The repository includes the artwork masters and scripts/build-brand-assets.mjs.
The website header/footer and all three PWA manifests use these assets.
