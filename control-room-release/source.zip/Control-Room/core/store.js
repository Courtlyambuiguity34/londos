import Database from 'better-sqlite3';
import {randomUUID} from 'node:crypto';
import {catalog,calculateLines} from '../shared/catalog.js';
import {safeUrl,assertPlain} from './security.js';
const now=()=>new Date().toISOString();
export const today=()=>{const d=new Date();return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;};
export class Store {
  constructor(file) {
    this.db=new Database(file);
    this.db.pragma('foreign_keys = ON'); this.db.pragma('trusted_schema = OFF'); this.db.pragma('journal_mode = WAL'); this.db.pragma('busy_timeout = 5000');
    this.migrate(); this.seed();
  }
  migrate() {
    this.db.exec('CREATE TABLE IF NOT EXISTS migrations(version INTEGER PRIMARY KEY, applied_at TEXT NOT NULL)');
    if(this.db.prepare('SELECT MAX(version) AS v FROM migrations').get().v>1) throw new Error('This workspace needs a newer Control Room version.');
    if(this.db.prepare('SELECT 1 FROM migrations WHERE version=1').get()) return;
    this.db.transaction(()=>{
      for(const [table,def] of Object.entries(catalog)) {
        const cols=def.fields.map(f=>`"${f.name}" ${['money','number','boolean'].includes(f.type)?'INTEGER':'TEXT'}${f.required?' NOT NULL':''}${f.type==='ref'?` REFERENCES "${f.target}"(id) ON DELETE RESTRICT`:''}`);
        if(def.lines) cols.push('subtotal_minor INTEGER NOT NULL DEFAULT 0','tax_minor INTEGER NOT NULL DEFAULT 0','total_minor INTEGER NOT NULL DEFAULT 0');
        this.db.exec(`CREATE TABLE "${table}" (id TEXT PRIMARY KEY, ${cols.join(',')}, archived INTEGER NOT NULL DEFAULT 0, created_at TEXT NOT NULL, updated_at TEXT NOT NULL)`);
        this.db.exec(`CREATE INDEX "idx_${table}_name" ON "${table}"(name); CREATE INDEX "idx_${table}_archive" ON "${table}"(archived)`);
        for(const f of def.fields.filter(f=>f.type==='ref'||f.type==='date')) this.db.exec(`CREATE INDEX "idx_${table}_${f.name}" ON "${table}"("${f.name}")`);
      }
      this.db.exec(`
        CREATE UNIQUE INDEX uq_project_service ON project_services(project_id,account_id);
        CREATE UNIQUE INDEX uq_document_path ON documents(relative_path) WHERE relative_path IS NOT NULL;
        CREATE UNIQUE INDEX uq_invoice_number ON invoices(name);
        CREATE UNIQUE INDEX uq_quotation_number ON quotations(name);
        CREATE TABLE quotation_lines(id TEXT PRIMARY KEY, parent_id TEXT NOT NULL REFERENCES quotations(id) ON DELETE CASCADE, position INTEGER NOT NULL, description TEXT NOT NULL, quantity_milli INTEGER NOT NULL, unit_price_minor INTEGER NOT NULL, total_minor INTEGER NOT NULL);
        CREATE TABLE invoice_lines(id TEXT PRIMARY KEY, parent_id TEXT NOT NULL REFERENCES invoices(id) ON DELETE CASCADE, position INTEGER NOT NULL, description TEXT NOT NULL, quantity_milli INTEGER NOT NULL, unit_price_minor INTEGER NOT NULL, total_minor INTEGER NOT NULL);
        CREATE INDEX idx_ql_parent ON quotation_lines(parent_id); CREATE INDEX idx_il_parent ON invoice_lines(parent_id);
        CREATE TABLE quotation_revisions(id TEXT PRIMARY KEY, quotation_id TEXT NOT NULL REFERENCES quotations(id) ON DELETE RESTRICT, revision INTEGER NOT NULL, name TEXT NOT NULL, client_id TEXT, project_id TEXT, issue_date TEXT, valid_until TEXT, description TEXT, currency TEXT NOT NULL, tax_bps INTEGER, discount_minor INTEGER, subtotal_minor INTEGER, tax_minor INTEGER, total_minor INTEGER, status TEXT, notes TEXT, attachment_id TEXT REFERENCES documents(id) ON DELETE RESTRICT, created_at TEXT NOT NULL);
        CREATE TABLE quotation_revision_lines(id TEXT PRIMARY KEY, revision_id TEXT NOT NULL REFERENCES quotation_revisions(id) ON DELETE CASCADE, position INTEGER, description TEXT, quantity_milli INTEGER, unit_price_minor INTEGER, total_minor INTEGER);
        CREATE INDEX idx_revision_quote ON quotation_revisions(quotation_id);
        CREATE TABLE activities(id TEXT PRIMARY KEY, entity TEXT NOT NULL, record_id TEXT, action TEXT NOT NULL, title TEXT NOT NULL, created_at TEXT NOT NULL);
        CREATE INDEX idx_activities_record ON activities(entity,record_id);
        CREATE TABLE notifications(id TEXT PRIMARY KEY, dedup_key TEXT UNIQUE NOT NULL, entity TEXT, record_id TEXT, title TEXT NOT NULL, due_date TEXT, state TEXT NOT NULL DEFAULT 'pending', snoozed_until TEXT, delivered INTEGER NOT NULL DEFAULT 0, created_at TEXT NOT NULL);
        CREATE INDEX idx_notifications_state ON notifications(state,snoozed_until);
        CREATE TABLE backups(id TEXT PRIMARY KEY, name TEXT NOT NULL, path TEXT NOT NULL, checksum TEXT NOT NULL, created_at TEXT NOT NULL, uploaded_at TEXT);
        CREATE TABLE settings(key TEXT PRIMARY KEY, value TEXT NOT NULL);
      `);
      this.db.prepare('INSERT INTO migrations VALUES(1,?)').run(now());
    })();
  }
  seed() {
    if(this.setting('seed_v1')) return;
    this.db.transaction(()=>{
      for(const [name,provider] of [['Techco Consulting','Bluehost'],['African Collaboration Chamber (AFCC)','Render'],['Women in Energy Uganda','Render'],['Londos','Render'],['Enakal','Render'],['Non-Waste','Render'],['Obulamu','Render'],['ReGreenEdu','unconfirmed']]) {
        const client=this.save('clients',{name,classification:'existing',status:'active',notes:'Initial record from build brief. Contact and business details await confirmation.'});
        this.save('projects',{name,client_id:client.id,hosting_provider:provider,status:'unconfirmed'});
      }
      this.setSetting('seed_v1',true);
    })();
  }
  definition(table) {if(!Object.hasOwn(catalog,table)) throw new Error('Unknown record type.'); return catalog[table];}
  activity(entity,record_id,action,title) {this.db.prepare('INSERT INTO activities VALUES(?,?,?,?,?,?)').run(randomUUID(),entity,record_id,action,title,now());}
  setting(key,fallback=null) {const row=this.db.prepare('SELECT value FROM settings WHERE key=?').get(key); return row?JSON.parse(row.value):fallback;}
  setSetting(key,value) {this.db.prepare('INSERT INTO settings VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value').run(key,JSON.stringify(value));}
  list(table,{query='',page=1,pageSize=30,archived=false,filters={},before=null,sort='updated_at',direction='DESC'}={}) {
    const def=this.definition(table); assertPlain(filters);
    if(typeof query!=='string'||query.length>500) throw new Error('Search is too long.');
    const valid=['id','created_at','updated_at','archived',...def.fields.map(f=>f.name),...(def.lines?['total_minor']:[])];
    if(!valid.includes(sort)||!['ASC','DESC'].includes(direction)) throw new Error('Invalid sort.');
    const where=['archived=?'],args=[archived?1:0];
    if(query.trim()) {where.push('('+def.fields.filter(f=>!['number','money','boolean'].includes(f.type)).map(f=>`COALESCE("${f.name}",'') LIKE ? ESCAPE '\\'`).join(' OR ')+')'); const term='%'+query.replace(/[\\%_]/g,'\\$&')+'%'; args.push(...def.fields.filter(f=>!['number','money','boolean'].includes(f.type)).map(()=>term));}
    for(const [key,value] of Object.entries(filters)) {if(!valid.includes(key)) throw new Error('Invalid filter.'); where.push(`"${key}"=?`); args.push(value);}
    if(before){assertPlain(before);if(![...def.fields.filter(f=>f.type==='date').map(f=>f.name),'created_at','updated_at'].includes(before.field)||typeof before.value!=='string'||!/^\d{4}-\d{2}-\d{2}$/.test(before.value))throw new Error('Invalid date filter.');where.push(`substr("${before.field}",1,10)<=?`);args.push(before.value);}
    page=Math.max(1,Math.floor(Number(page)||1)); pageSize=Math.min(200,Math.max(1,Math.floor(Number(pageSize)||30)));
    const clause=where.join(' AND '), total=this.db.prepare(`SELECT COUNT(*) AS n FROM "${table}" WHERE ${clause}`).get(...args).n;
    const rows=this.db.prepare(`SELECT * FROM "${table}" WHERE ${clause} ORDER BY "${sort}" ${direction},id LIMIT ? OFFSET ?`).all(...args,pageSize,(page-1)*pageSize);
    if(table==='invoices') for(const row of rows) Object.assign(row,this.balance(row.id));
    return {rows,total,page,pageSize};
  }
  options() {return Object.fromEntries(Object.keys(catalog).map(table=>[table,this.db.prepare(`SELECT id,name,archived FROM "${table}" ORDER BY name LIMIT 20000`).all()]));}
  get(table,id) {
    const def=this.definition(table); if(typeof id!=='string') throw new Error('Invalid ID.');
    const row=this.db.prepare(`SELECT * FROM "${table}" WHERE id=?`).get(id); if(!row) throw new Error('Record was not found.');
    if(def.lines) row.lines=this.db.prepare(`SELECT * FROM ${table==='invoices'?'invoice_lines':'quotation_lines'} WHERE parent_id=? ORDER BY position`).all(id);
    if(table==='invoices') Object.assign(row,this.balance(id));
    return row;
  }
  normalize(table,input,old) {
    const def=this.definition(table); assertPlain(input);
    const allowed=new Set(['id','archived','lines',...def.fields.filter(f=>!f.readonly).map(f=>f.name)]);
    for(const key of Object.keys(input)) if(!allowed.has(key)) throw new Error(`Field ${key} is not editable.`);
    const data={};
    for(const f of def.fields) {
      if(f.readonly) {data[f.name]=old?.[f.name]??null;continue;}
      let v=Object.hasOwn(input,f.name)?input[f.name]:(old?.[f.name]??f.default??null);
      if(v==='') v=null;
      if(f.required && (v===null||v===undefined)) throw new Error(`${f.label} is required.`);
      if(v!=null) {
        if(['number','money','boolean'].includes(f.type)) {
          if(!Number.isSafeInteger(v)||v<0) throw new Error(`${f.label} must be a non-negative whole number.`);
          if(f.type==='boolean'&&v>1) throw new Error('Invalid checkbox value.');
        } else {
          if(typeof v!=='string'||v.length>(f.type==='textarea'?20000:4096)||v.includes('\0')) throw new Error(`Invalid ${f.label}.`);
          v=v.trim(); if(f.required&&!v) throw new Error(`${f.label} is required.`);
          if(f.type==='url') safeUrl(v);
          if(f.type==='email'&&!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v)) throw new Error('Enter a valid email address.');
          if(f.type==='date'&&(!/^\d{4}-\d{2}-\d{2}$/.test(v)||!Number.isFinite(Date.parse(v))||new Date(v).toISOString().slice(0,10)!==v)) throw new Error('Enter a valid calendar date.');
          if(f.type==='select'&&!f.options.includes(v)) throw new Error(`Invalid ${f.label}.`);
          if(f.type==='file'&&v!==old?.[f.name]&&!this.approvedPaths?.has(v)) throw new Error('Choose the file using the file picker.');
        }
      }
      data[f.name]=v;
    }
    if(data.project_id && Object.hasOwn(data,'client_id')) { const project=this.get('projects',data.project_id); if(data.client_id && project.client_id && data.client_id!==project.client_id) throw new Error('The selected project belongs to a different client.'); if(!data.client_id)data.client_id=project.client_id; }
    if(data.contact_id && data.client_id && this.get('contacts',data.contact_id).client_id!==data.client_id) throw new Error('The selected contact belongs to a different client.');
    if(table==='custom_fields') {if(!data.entity||!data.record_id)throw new Error('Choose the record type and enter an existing record ID.');this.get(data.entity,data.record_id);}
    if(table==='clients'&&!old&&!data.date_added)data.date_added=today();
    if(table==='documents' && ['size','missing','name'].some(k=>Object.hasOwn(input,k)&&input[k]!==old?.[k])) throw new Error('Use document actions to change the file.');
    if(input.archived!==undefined&&![0,1].includes(input.archived)) throw new Error('Invalid archive state.');
    data.archived=input.archived??old?.archived??0;
    return data;
  }
  save(table,input) {
    const def=this.definition(table); if(def.readOnly) throw new Error('This history is read-only.');
    return this.db.transaction(()=>{
      const old=input.id?this.get(table,input.id):null;
      if(table==='documents'&&!old) throw new Error('Import a file to create a document.');
      const data=this.normalize(table,input,old); const id=old?.id||randomUUID();
      let computed;
      if(def.lines) {
        const lines=input.lines??old?.lines??[]; if(!Array.isArray(lines)||lines.length>500) throw new Error('Invalid line items.');
        if(!lines.length && data.status!=='draft') throw new Error('Add at least one line item before issuing.');
        computed=calculateLines(lines,data.tax_bps||0,data.discount_minor||0); Object.assign(data,{subtotal_minor:computed.subtotal_minor,tax_minor:computed.tax_minor,total_minor:computed.total_minor});
      }
      if(table==='invoices'&&old) {
        const payments=this.db.prepare('SELECT COUNT(*) n FROM payments WHERE invoice_id=?').get(id).n;
        if(payments&&(data.currency!==old.currency||data.status==='void'||data.status==='draft'||data.total_minor<this.balance(id).paid_minor)) throw new Error('An invoice with payments must keep its currency, remain issued, and cover its paid balance.');
      }
      if(table==='payments') this.validatePayment(data,old?.id);
      if(table==='tasks'&&data.status==='completed'&&!data.completed_date) data.completed_date=today();
      if(table==='quotations'&&old) this.snapshotQuotation(old);
      const timestamp=now();
      if(old) this.db.prepare(`UPDATE "${table}" SET ${Object.keys(data).map(k=>`"${k}"=?`).join(',')},updated_at=? WHERE id=?`).run(...Object.values(data),timestamp,id);
      else this.db.prepare(`INSERT INTO "${table}" (id,${Object.keys(data).map(k=>`"${k}"`).join(',')},created_at,updated_at) VALUES (${Array(Object.keys(data).length+3).fill('?').join(',')})`).run(id,...Object.values(data),timestamp,timestamp);
      if(computed) {
        const lt=table==='invoices'?'invoice_lines':'quotation_lines'; this.db.prepare(`DELETE FROM ${lt} WHERE parent_id=?`).run(id);
        const stmt=this.db.prepare(`INSERT INTO ${lt} VALUES(?,?,?,?,?,?,?)`);
        computed.lines.forEach((l,i)=>stmt.run(randomUUID(),id,i,l.description.trim(),l.quantity_milli,l.unit_price_minor,l.total_minor));
      }
      if(table==='contacts'&&data.is_primary) this.db.prepare('UPDATE contacts SET is_primary=0 WHERE client_id=? AND id<>?').run(data.client_id,id);
      if(table==='communications'&&data.client_id) this.db.prepare('UPDATE clients SET last_contact=COALESCE(?,last_contact),next_followup=COALESCE(?,next_followup),updated_at=? WHERE id=?').run(data.contact_date,data.next_followup,timestamp,data.client_id);
      this.activity(table,id,old?'updated':'created',data.name); return this.get(table,id);
    })();
  }
  validatePayment(data,exclude) {
    if(!data.amount_minor) throw new Error('Payment must be greater than zero.');
    const invoice=this.get('invoices',data.invoice_id);
    if(invoice.currency!==data.currency) throw new Error('Payment currency must match the invoice.');
    if(invoice.status!=='issued') throw new Error('Issue the invoice before recording a payment.');
    const paid=this.db.prepare("SELECT COALESCE(SUM(CASE kind WHEN 'refund' THEN -amount_minor ELSE amount_minor END),0) n FROM payments WHERE invoice_id=? AND id<>?").get(data.invoice_id,exclude||'').n;
    const next=paid+(data.kind==='refund'?-data.amount_minor:data.amount_minor);
    if(next<0||next>invoice.total_minor) throw new Error('Payment/refund exceeds the invoice balance or recorded payments.');
    if(exclude) {const old=this.get('payments',exclude); if(old.invoice_id!==data.invoice_id) throw new Error('Payments cannot move between invoices.');}
  }
  balance(id) {
    const invoice=this.db.prepare('SELECT total_minor,status FROM invoices WHERE id=?').get(id); if(!invoice) throw new Error('Invoice not found.');
    const paid=this.db.prepare("SELECT COALESCE(SUM(CASE kind WHEN 'refund' THEN -amount_minor ELSE amount_minor END),0) n FROM payments WHERE invoice_id=?").get(id).n;
    return {paid_minor:paid,balance_minor:invoice.total_minor-paid,payment_status:invoice.status==='void'?'void':invoice.total_minor===paid&&invoice.total_minor>0?'paid':paid?'partial':invoice.status};
  }
  snapshotQuotation(old) {
    const id=randomUUID(),revision=this.db.prepare('SELECT COALESCE(MAX(revision),0)+1 n FROM quotation_revisions WHERE quotation_id=?').get(old.id).n;
    const keys=['name','client_id','project_id','issue_date','valid_until','description','currency','tax_bps','discount_minor','subtotal_minor','tax_minor','total_minor','status','notes','attachment_id'];
    this.db.prepare(`INSERT INTO quotation_revisions(id,quotation_id,revision,${keys.join(',')},created_at) VALUES(${Array(keys.length+4).fill('?').join(',')})`).run(id,old.id,revision,...keys.map(k=>old[k]),now());
    const stmt=this.db.prepare('INSERT INTO quotation_revision_lines VALUES(?,?,?,?,?,?,?)');
    old.lines.forEach((l,i)=>stmt.run(randomUUID(),id,i,l.description,l.quantity_milli,l.unit_price_minor,l.total_minor));
  }
  revisions(id) {return this.db.prepare('SELECT * FROM quotation_revisions WHERE quotation_id=? ORDER BY revision DESC').all(id).map(r=>({...r,lines:this.db.prepare('SELECT * FROM quotation_revision_lines WHERE revision_id=? ORDER BY position').all(r.id)}));}
  remove(table,id) {
    this.definition(table); if(['payments','renewals','documents'].includes(table)) throw new Error('Payments are retained for audit. Documents use the file actions.');
    return this.db.transaction(()=>{const old=this.get(table,id); try{this.db.prepare(`DELETE FROM "${table}" WHERE id=?`).run(id);}catch(e){if((e.code?.includes('FOREIGNKEY')||e.message?.includes('FOREIGN KEY constraint')))throw new Error('This record has linked records or history. Archive it, or unlink those records first.');throw e;}this.activity(table,id,'deleted',old.name);})();
  }
  related(table,id) {
    this.get(table,id); const result={};
    for(const [t,def] of Object.entries(catalog)) {const fields=def.fields.filter(f=>f.type==='ref'&&f.target===table); if(fields.length) result[t]=this.db.prepare(`SELECT * FROM "${t}" WHERE ${fields.map(f=>`"${f.name}"=?`).join(' OR ')} ORDER BY updated_at DESC LIMIT 200`).all(...fields.map(()=>id));}
    result.activities=this.db.prepare('SELECT * FROM activities WHERE entity=? AND record_id=? ORDER BY created_at DESC LIMIT 50').all(table,id);
    return result;
  }
  search(query) {
    if(typeof query!=='string'||query.trim().length<2) return [];
    return Object.entries(catalog).flatMap(([table,def])=>this.list(table,{query,pageSize:10}).rows.map(r=>({table,id:r.id,name:r.name,label:def.singular}))).slice(0,120);
  }
  finance() {
    const invoices=this.db.prepare("SELECT i.currency,i.fund_type,CAST(SUM(i.total_minor) AS TEXT) billed, CAST(SUM(i.total_minor-COALESCE(p.paid,0)) AS TEXT) outstanding FROM invoices i LEFT JOIN (SELECT invoice_id,SUM(CASE kind WHEN 'refund' THEN -amount_minor ELSE amount_minor END) paid FROM payments GROUP BY invoice_id) p ON p.invoice_id=i.id WHERE i.status='issued' GROUP BY i.currency,i.fund_type").all();
    const payments=this.db.prepare("SELECT p.currency,i.fund_type,CAST(SUM(CASE p.kind WHEN 'refund' THEN -p.amount_minor ELSE p.amount_minor END) AS TEXT) received FROM payments p JOIN invoices i ON i.id=p.invoice_id GROUP BY p.currency,i.fund_type").all();
    const expenses=this.db.prepare('SELECT currency,fund_type,CAST(SUM(amount_minor) AS TEXT) spent FROM expenses GROUP BY currency,fund_type').all();
    for(const row of [...invoices,...payments,...expenses])for(const key of ['billed','outstanding','received','spent'])if(row[key]!==undefined){const value=BigInt(row[key]);if(value>BigInt(Number.MAX_SAFE_INTEGER)||value< -BigInt(Number.MAX_SAFE_INTEGER))throw new Error('Financial totals exceed the supported safe integer range. Export individual records for analysis.');row[key]=Number(value);}
    return {invoices,payments,expenses};
  }
  dashboard() {
    const count=(t,where='1=1',args=[])=>this.db.prepare(`SELECT COUNT(*) n FROM ${t} WHERE archived=0 AND ${where}`).get(...args).n;
    const d=today(),end=new Date(Date.parse(d)+30*86400000).toISOString().slice(0,10);
    const counts={clients:count('clients'),projects:count('projects'),websites:count('projects',"live_url IS NOT NULL AND status IN ('active','maintenance')"),development:count('projects',"status='in-development'"),followups:count('clients','next_followup<=?',[end]),domains:count('domains','expiry_date<=?',[end]),hosting:count('hosting_accounts','renewal_date<=?',[end])+count('hosting_services','renewal_date<=?',[end]),email:count('email_subscriptions','COALESCE(expiry_date,renewal_date)<=?',[end]),quotations:count('quotations',"status IN ('issued','revised')"),contracts:count('contracts',"status='active'"),tasks:count('tasks',"status NOT IN ('completed','cancelled')"),invoices:this.db.prepare("SELECT COUNT(*) n FROM invoices i WHERE status='issued' AND total_minor>(SELECT COALESCE(SUM(CASE kind WHEN 'refund' THEN -amount_minor ELSE amount_minor END),0) FROM payments p WHERE p.invoice_id=i.id)").get().n};
    return {counts,finance:this.finance(),projects:this.list('projects',{pageSize:6}).rows,tasks:this.db.prepare("SELECT * FROM tasks WHERE archived=0 AND status NOT IN ('completed','cancelled') ORDER BY due_date IS NULL,due_date LIMIT 6").all(),activities:this.db.prepare('SELECT * FROM activities ORDER BY created_at DESC LIMIT 8').all(),notifications:this.notifications(),lastBackup:this.db.prepare('SELECT * FROM backups ORDER BY created_at DESC LIMIT 1').get()||null};
  }
  refreshReminders(day=today()) {
    const configured=this.setting('reminder_days',[60,30,14,7,1,0]); const intervals=[...new Set(configured)].sort((a,b)=>a-b);
    const sources=[['domains','expiry_date'],['hosting_accounts','renewal_date'],['hosting_services','renewal_date'],['email_subscriptions','expiry_date'],['email_subscriptions','renewal_date'],['service_accounts','renewal_date'],['contracts','end_date'],['invoices','due_date'],['clients','next_followup'],['communications','next_followup'],['projects','due_date'],['tasks','due_date'],['data_sources','review_date'],['quotations','valid_until']];
    const activeKeys=new Set();
    this.db.transaction(()=>{
      for(const [table,field] of sources) for(const row of this.db.prepare(`SELECT * FROM ${table} WHERE archived=0 AND "${field}" IS NOT NULL`).all()) {
        if(['completed','cancelled','retired','terminated','closed','rejected','accepted','void','draft','inactive'].includes(row.status)) continue;
        if(table==='invoices'&&this.balance(row.id).balance_minor===0) continue;
        const days=Math.round((Date.parse(row[field])-Date.parse(day))/86400000),bucket=days<0?'overdue':intervals.find(n=>days<=n);
        if(bucket===undefined) continue;
        const key=`${table}:${row.id}:${field}:${row[field]}:${bucket}`; activeKeys.add(key);
        const snoozed=this.db.prepare("SELECT snoozed_until FROM notifications WHERE entity=? AND record_id=? AND due_date=? AND state='pending' AND snoozed_until>? ORDER BY snoozed_until DESC LIMIT 1").get(table,row.id,row[field],now())?.snoozed_until||null;
        this.db.prepare('INSERT OR IGNORE INTO notifications(id,dedup_key,entity,record_id,title,due_date,created_at,snoozed_until) VALUES(?,?,?,?,?,?,?,?)').run(randomUUID(),key,table,row.id,`${row.name} · ${field.replaceAll('_',' ')} ${days<0?'overdue':days===0?'today':`in ${days} days`}`,row[field],now(),snoozed);
      }
      const backupDays=this.setting('backup_reminder_days',0),last=this.db.prepare('SELECT created_at FROM backups ORDER BY created_at DESC LIMIT 1').get()?.created_at;
      if(backupDays>0&&(!last||(Date.parse(day)-Date.parse(last.slice(0,10)))/86400000>=backupDays)) {
        const key=`backup:${last||'never'}`;activeKeys.add(key);this.db.prepare('INSERT OR IGNORE INTO notifications(id,dedup_key,entity,title,created_at) VALUES(?,?,?,?,?)').run(randomUUID(),key,'settings','Time to create a workspace backup',now());
      }
      for(const notification of this.db.prepare("SELECT id,dedup_key FROM notifications WHERE state='pending'").all()) if(!activeKeys.has(notification.dedup_key)) this.db.prepare("UPDATE notifications SET state='resolved' WHERE id=?").run(notification.id);
    })();
    return this.notifications();
  }
  notifications() {return this.db.prepare('SELECT * FROM notifications ORDER BY created_at DESC LIMIT 500').all();}
  notificationAction(id,action,until) {
    if(!['dismiss','complete','snooze'].includes(action)) throw new Error('Invalid reminder action.');
    if(action==='snooze'&&(!until||!Number.isFinite(Date.parse(until))||Date.parse(until)<=Date.now())) throw new Error('Choose a future snooze time.');
    this.db.prepare('UPDATE notifications SET state=?,snoozed_until=?,delivered=? WHERE id=?').run(action==='snooze'?'pending':action==='complete'?'completed':'dismissed',action==='snooze'?until:null,action==='snooze'?0:1,id);
  }
  renewDomain(id,newExpiry,amount,currency,evidence) {
    const old=this.get('domains',id);
    if(!/^\d{4}-\d{2}-\d{2}$/.test(newExpiry)||newExpiry<= (old.expiry_date||today())) throw new Error('New expiry must follow the previous expiry (or today).');
    return this.db.transaction(()=>{
      const updated=this.save('domains',{id,expiry_date:newExpiry,status:'active'}); const ts=now();
      if(!Number.isSafeInteger(amount)||amount<0||!catalog.domains.fields.find(f=>f.name==='currency').options.includes(currency))throw new Error('Invalid renewal amount/currency.');
      this.db.prepare('INSERT INTO renewals(id,name,domain_id,renewed_on,previous_expiry,new_expiry,amount_minor,currency,evidence_id,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?)').run(randomUUID(),`${old.name} renewal`,id,today(),old.expiry_date,newExpiry,amount,currency,evidence||null,ts,ts);
      return updated;
    })();
  }
  close(){this.db.close();}
}
