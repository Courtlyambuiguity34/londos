/* eslint-disable no-control-regex -- Deliberately reject control characters in untrusted URLs and filenames. */
import path from 'node:path';
import fs from 'node:fs';
export function safeUrl(value, contact=false) {
  if (typeof value!=='string'||value.length>4096||/[\x00-\x20]/.test(value)) throw new Error('Invalid URL.');
  const u=new URL(value);
  if (!(contact?['https:','http:','mailto:','tel:']:['https:','http:']).includes(u.protocol) || u.username || u.password) throw new Error('Only ordinary web links are permitted.');
  if(['http:','https:'].includes(u.protocol) && !u.hostname) throw new Error('URL needs a hostname.');
  return u.href;
}
export function safeName(name) {
  if (typeof name!=='string'||!name.trim()||name.length>180||/[<>:"/\\|?*\x00-\x1f]/.test(name)||/[. ]$/.test(name)||/^(con|prn|aux|nul|com[0-9]|lpt[0-9])(?:\.|$)/i.test(name)||name==='.'||name==='..') throw new Error('Use a valid Windows filename without slashes or reserved characters.');
  return name;
}
export function inside(root, relative) {
  if (typeof relative!=='string'||path.isAbsolute(relative)||/^[a-z]:/i.test(relative)||relative.includes('\\')||relative.includes('\0')) throw new Error('Invalid workspace path.');
  const base=path.resolve(root), target=path.resolve(base,relative);
  if(target!==base&&!target.startsWith(base+path.sep)) throw new Error('Path leaves the workspace.');
  const pieces=path.relative(base,target).split(path.sep); let cursor=base;
  for(const piece of pieces.filter(Boolean)) safeName(piece);
  if(fs.existsSync(base)&&fs.lstatSync(base).isSymbolicLink()) throw new Error('Workspace symlinks are not supported.');
  for(const piece of pieces) {cursor=path.join(cursor,piece); if(fs.existsSync(cursor)&&fs.lstatSync(cursor).isSymbolicLink()) throw new Error('Symbolic links are not allowed in managed paths.');}
  return target;
}
export function assertPlain(input) {if(!input||typeof input!=='object'||Array.isArray(input)||Object.getPrototypeOf(input)!==Object.prototype) throw new Error('Expected a record.');}
