import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import {createHash,randomUUID} from 'node:crypto';
import AdmZip from 'adm-zip';
import Database from 'better-sqlite3';
import {Store} from './store.js';
import {inside,safeName} from './security.js';
import {catalog,categories} from '../shared/catalog.js';
const stamp=()=>new Date().toISOString();
const hash=b=>createHash('sha256').update(b).digest('hex');
const csv=rows=>{
  if(!rows.length) return '';
  const keys=Object.keys(rows[0]);
  const quote=v=>'"'+String(v??'').replace(/^[=+@\-\t\r]/,"'$&").replaceAll('"','""')+'"';
  return keys.map(quote).join(',')+'\r\n'+rows.map(r=>keys.map(k=>quote(r[k])).join(',')).join('\r\n');
};
export class Workspace {
  constructor(root) {
    fs.mkdirSync(root,{recursive:true}); this.root=fs.realpathSync(root);
    for(const folder of ['Database','Clients','Projects',...categories,'Backups','Exports']) fs.mkdirSync(inside(this.root,folder),{recursive:true});
    this.store=new Store(inside(this.root,'Database/control-room.sqlite'));
    this.store.approvedPaths=new Set();
    fs.writeFileSync(inside(this.root,'Database/workspace.json'),JSON.stringify({format:'control-room',version:1},null,2));
    this.ensureFolders(); this.reconcile();
  }
  ensureFolders() {
    const existing=fs.readdirSync(inside(this.root,'Clients'));
    for(const client of this.store.db.prepare('SELECT id,name FROM clients').all()) {
      const slug=client.name.replace(/[^a-z0-9 -]/gi,'').slice(0,45).trim().replace(/ +/g,'-')||'Client';
      const folder=existing.find(n=>n.startsWith(client.id+'-'))||`${client.id}-${slug}`;
      for(const category of categories) fs.mkdirSync(inside(this.root,`Clients/${folder}/${category}`),{recursive:true});
    }
    for(const project of this.store.db.prepare('SELECT id FROM projects').all()) fs.mkdirSync(inside(this.root,`Projects/${project.id}`),{recursive:true});
  }
  clientFolder(id) {
    this.store.get('clients',id);this.ensureFolders();
    const name=fs.readdirSync(inside(this.root,'Clients')).find(n=>n.startsWith(id+'-'));
    return `Clients/${name}`;
  }
  documentFolder(clientId,projectId,category='Correspondence') {
    safeName(category); if(projectId)this.store.get('projects',projectId);
    const dir=clientId?`${this.clientFolder(clientId)}/${category}`:projectId?`Projects/${projectId}/${category}`:category;
    if(!clientId&&!projectId&&['Database','Backups','Exports','Clients','Projects'].includes(category))throw new Error('Choose a document category, not a system folder.');
    fs.mkdirSync(inside(this.root,dir),{recursive:true});return dir;
  }
  importFile(source,{client_id=null,project_id=null,category='Correspondence',external=false}={}) {
    if(typeof source!=='string'||!fs.existsSync(source)||!fs.statSync(source).isFile()||fs.lstatSync(source).isSymbolicLink()) throw new Error('Choose an existing regular file.');
    if(project_id){const project=this.store.get('projects',project_id);if(client_id&&project.client_id&&client_id!==project.client_id)throw new Error('The project belongs to a different client.');if(!client_id)client_id=project.client_id;}
    const basename=safeName(path.basename(source));
    let relative=null,absolute=source;
    if(!external) {
      const folder=this.documentFolder(client_id,project_id,category);relative=`${folder}/${basename}`;absolute=inside(this.root,relative);
      fs.copyFileSync(source,absolute,fs.constants.COPYFILE_EXCL);
    } else {if(client_id)this.store.get('clients',client_id);if(project_id)this.store.get('projects',project_id);}
    const id=randomUUID(),ts=stamp();
    try{this.store.db.prepare('INSERT INTO documents(id,name,client_id,project_id,category,extension,relative_path,external_path,size,missing,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)').run(id,basename,client_id,project_id,category,path.extname(source).slice(1).toLowerCase(),relative,external?source:null,fs.statSync(absolute).size,0,ts,ts);}catch(e){if(relative)fs.unlinkSync(absolute);throw e;}
    this.store.activity('documents',id,external?'linked':'imported',basename);return this.store.get('documents',id);
  }
  walk(dir=this.root,relative='') {
    const files=[];
    for(const entry of fs.readdirSync(dir,{withFileTypes:true})) {
      if(entry.isSymbolicLink()||(!relative&&['Database','Backups','Exports'].includes(entry.name)))continue;
      const rel=relative?`${relative}/${entry.name}`:entry.name;
      const full=inside(this.root,rel);
      if(entry.isDirectory()) files.push(...this.walk(full,rel)); else if(entry.isFile())files.push(rel);
    }
    return files;
  }
  reconcile() {
    const files=this.walk(); const known=new Map(this.store.db.prepare('SELECT id,relative_path,size,missing FROM documents WHERE relative_path IS NOT NULL').all().map(r=>[r.relative_path,r]));
    let added=0;
    this.store.db.transaction(()=>{
      for(const relative of files) {
        const stat=fs.statSync(inside(this.root,relative)),old=known.get(relative);
        if(old){this.store.db.prepare('UPDATE documents SET missing=0,size=? WHERE id=?').run(stat.size,old.id);known.delete(relative);continue;}
        const pieces=relative.split('/'),clientId=pieces[0]==='Clients'?pieces[1].slice(0,36):null,projectId=pieces[0]==='Projects'?pieces[1]:null;
        const client=clientId&&this.store.db.prepare('SELECT id FROM clients WHERE id=?').get(clientId),project=projectId&&this.store.db.prepare('SELECT id FROM projects WHERE id=?').get(projectId);
        const category=pieces[0]==='Clients'?pieces[2]:pieces[0]==='Projects'?pieces[2]||'Projects':pieces[0];
        const id=randomUUID(),ts=stamp();
        this.store.db.prepare('INSERT INTO documents(id,name,client_id,project_id,category,extension,relative_path,size,missing,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?)').run(id,path.basename(relative),client?.id||null,project?.id||null,category,path.extname(relative).slice(1).toLowerCase(),relative,stat.size,0,ts,ts);added++;
      }
      for(const old of known.values())this.store.db.prepare('UPDATE documents SET missing=1 WHERE id=?').run(old.id);
      for(const doc of this.store.db.prepare('SELECT id,external_path FROM documents WHERE external_path IS NOT NULL').all()) this.store.db.prepare('UPDATE documents SET missing=? WHERE id=?').run(fs.existsSync(doc.external_path)?0:1,doc.id);
    })();
    return {added,indexed:files.length};
  }
  resolveDocument(id) {
    const doc=this.store.get('documents',id); const filename=doc.relative_path?inside(this.root,doc.relative_path):doc.external_path;
    if(!filename||!fs.existsSync(filename)||!fs.statSync(filename).isFile())throw new Error('The file is missing. Reconnect its drive or restore it, then refresh.');
    if(fs.lstatSync(filename).isSymbolicLink())throw new Error('Symbolic links are not supported.');
    return filename;
  }
  moveDocument(id,{name,category,client_id,project_id}) {
    const doc=this.store.get('documents',id);if(!doc.relative_path) throw new Error('Linked external files can be opened or unlinked; import a copy before moving.');
    if(project_id){const project=this.store.get('projects',project_id);if(client_id&&project.client_id&&client_id!==project.client_id)throw new Error('The project belongs to a different client.');if(!client_id)client_id=project.client_id;}
    safeName(name);const old=this.resolveDocument(id),dir=this.documentFolder(client_id||null,project_id||null,category),relative=`${dir}/${name}`,target=inside(this.root,relative);
    if(target!==old && fs.existsSync(target)) throw new Error('A file already exists at the destination.');
    if(target!==old) fs.renameSync(old,target);
    try {this.store.db.prepare('UPDATE documents SET name=?,category=?,client_id=?,project_id=?,relative_path=?,extension=?,updated_at=? WHERE id=?').run(name,category,client_id||null,project_id||null,relative,path.extname(name).slice(1).toLowerCase(),stamp(),id);} catch(e){if(target!==old) fs.renameSync(target,old);throw e;}
    this.store.activity('documents',id,'moved',name);return this.store.get('documents',id);
  }
  async backup() {
    const temp=fs.mkdtempSync(path.join(os.tmpdir(),'control-room-backup-'));
    try{
      await this.store.db.backup(path.join(temp,'control-room.sqlite'));
      const snapshot=new Database(path.join(temp,'control-room.sqlite'),{readonly:true});
      try{if(snapshot.pragma('integrity_check',{simple:true})!=='ok')throw new Error('Database backup verification failed.');}finally{snapshot.close();}
      const zip=new AdmZip();const manifest={format:'control-room-backup',version:1,created_at:stamp(),files:[],external_files:'Linked external files remain links; copy those files separately.'};
      let archiveBytes=0;
      const add=(rel,file)=>{const size=fs.statSync(file).size;archiveBytes+=size;if(size>512*1024**2||archiveBytes>2*1024**3||manifest.files.length>=24999)throw new Error('Workspace exceeds the supported backup size or file-count limit.');const content=fs.readFileSync(file);manifest.files.push({path:rel,size:content.length,sha256:hash(content)});zip.addFile(rel,content);};
      add('Database/control-room.sqlite',path.join(temp,'control-room.sqlite'));
      for(const rel of this.walk())add(rel,inside(this.root,rel));
      zip.addFile('manifest.json',Buffer.from(JSON.stringify(manifest,null,2)));
      const name=`Control-Room-${stamp().replace(/[:.]/g,'-')}-${randomUUID().slice(0,8)}.zip`,target=inside(this.root,`Backups/${name}`);
      zip.writeZip(target);
      Workspace.verifyArchive(target);
      this.store.db.prepare('INSERT INTO backups VALUES(?,?,?,?,?,NULL)').run(randomUUID(),name,target,hash(fs.readFileSync(target)),stamp());
      this.store.activity('settings',null,'backup',name);return {name,path:target};
    }finally{fs.rmSync(temp,{recursive:true,force:true});}
  }
  static verifyArchive(filename) {
    const zip=new AdmZip(filename),entries=zip.getEntries();
    if(entries.length>25000)throw new Error('Archive has too many files.');
    let size=0;const byName=new Map();
    for(const entry of entries) {
      const name=entry.entryName;
      if(entry.isDirectory||name.startsWith('/')||name.includes('\\')||name.split('/').some(p=>p==='..'||p==='.'||!p)||/^[a-z]:/i.test(name)||byName.has(name))throw new Error('Unsafe or duplicate archive entry.');
      size+=entry.header.size; if(size>2*1024**3||entry.header.size>512*1024**2)throw new Error('Archive exceeds the 2 GB restore limit (512 MB per file).');
      byName.set(name,entry);
    }
    const me=byName.get('manifest.json');if(!me||me.header.size>5*1024**2)throw new Error('Backup manifest is missing or too large.');
    const manifest=JSON.parse(me.getData().toString());
    if(manifest.format!=='control-room-backup'||manifest.version!==1||!Array.isArray(manifest.files)||manifest.files.length!==entries.length-1)throw new Error('Unsupported or incomplete backup.');
    const seen=new Set();
    for(const file of manifest.files) {
      if(!file||typeof file.path!=='string'||seen.has(file.path)||file.path==='manifest.json')throw new Error('Invalid manifest.');seen.add(file.path);
      if(file.path.startsWith('Database/')&&file.path!=='Database/control-room.sqlite')throw new Error('Unsupported database entry.');
      if(['Backups','Exports'].includes(file.path.split('/')[0]))throw new Error('Invalid managed file entry.');
      const e=byName.get(file.path);if(!e||e.header.size!==file.size||hash(e.getData())!==file.sha256)throw new Error(`Backup integrity check failed: ${file.path}`);
    }
    if(!seen.has('Database/control-room.sqlite'))throw new Error('Backup database is missing.');
    return {zip,manifest};
  }
  static restore(filename,target) {
    if(fs.existsSync(target)&&fs.readdirSync(target).length)throw new Error('Restore requires an empty folder. The existing workspace is preserved.');
    const {zip,manifest}=Workspace.verifyArchive(filename);fs.mkdirSync(target,{recursive:true});
    try {
      for(const file of manifest.files) {const dest=inside(target,file.path);fs.mkdirSync(path.dirname(dest),{recursive:true});fs.writeFileSync(dest,zip.getEntry(file.path).getData(),{flag:'wx'});}
      const db=new Database(inside(target,'Database/control-room.sqlite'),{readonly:true});
      try{db.pragma('trusted_schema = OFF');if(db.pragma('integrity_check',{simple:true})!=='ok'||db.pragma('foreign_key_check').length)throw new Error('Restored database integrity check failed.');if(!db.prepare('SELECT version FROM migrations WHERE version=1').get())throw new Error('Not a Control Room database.');}finally{db.close();}
      return new Workspace(target);
    }catch(e){for(const entry of fs.readdirSync(target))fs.rmSync(path.join(target,entry),{recursive:true,force:true});throw e;}
  }
  exportBundle(scope='all',id=null) {
    const data={};
    if(scope==='clients'||scope==='projects') {
      const main=this.store.get(scope,id);
      const all=Object.fromEntries(Object.keys(catalog).map(table=>[table,this.store.db.prepare(`SELECT * FROM ${table}`).all()]));
      const projectIds=new Set(scope==='projects'?[id]:all.projects.filter(p=>p.client_id===id).map(p=>p.id));
      const selected=new Map();
      const add=(table,recordId)=>{if(!recordId)return;if(!selected.has(table))selected.set(table,new Set());selected.get(table).add(recordId);};
      add(scope,id);if(scope==='projects')add('clients',main.client_id);
      for(const projectId of projectIds)add('projects',projectId);
      for(const [table,rows]of Object.entries(all))for(const row of rows)if((scope==='clients'&&row.client_id===id)||(row.project_id&&projectIds.has(row.project_id)))add(table,row.id);
      // Only descend through ownership, never through shared account/attachment references.
      for(const [table,field,parent]of [['payments','invoice_id','invoices'],['mailboxes','subscription_id','email_subscriptions'],['renewals','domain_id','domains']])for(const row of all[table])if(selected.get(parent)?.has(row[field]))add(table,row.id);
      for(const [table,ids]of [...selected])for(const row of all[table].filter(r=>ids.has(r.id)))for(const field of catalog[table].fields.filter(f=>f.type==='ref'&&['hosting_accounts','service_accounts','contacts','documents'].includes(f.target)))add(field.target,row[field.name]);
      for(const row of all.custom_fields)if(selected.get(row.entity)?.has(row.record_id))add('custom_fields',row.id);
      for(const [table,ids]of selected)data[table]=[...ids].map(key=>this.store.get(table,key));
    }else {
      const tables=scope==='finance'?['invoices','payments','expenses']:scope==='documents'?['documents']:Object.keys(catalog);
      if(!['finance','documents','all'].includes(scope))throw new Error('Invalid export scope.');
      for(const table of tables)data[table]=this.store.db.prepare(`SELECT id FROM ${table}`).all().map(r=>this.store.get(table,r.id));
    }
    if(data.quotations){data.quotation_revisions=data.quotations.flatMap(q=>this.store.revisions(q.id));data.quotation_lines=data.quotations.flatMap(q=>q.lines);data.quotation_revision_lines=data.quotation_revisions.flatMap(r=>r.lines);}
    if(data.invoices)data.invoice_lines=data.invoices.flatMap(i=>i.lines);
    const zip=new AdmZip(),missing=[];
    zip.addFile('records.json',Buffer.from(JSON.stringify({exported_at:stamp(),scope,data},null,2)));
    for(const [table,rows] of Object.entries(data))zip.addFile(`csv/${table}.csv`,Buffer.from(csv(rows.map(({lines,...r})=>r))));
    for(const doc of data.documents||[]) {
      if(doc.external_path){missing.push(`${doc.name}: externally linked, not copied (${doc.external_path})`);continue;}
      try {zip.addLocalFile(this.resolveDocument(doc.id),'documents',`${doc.id}-${doc.name}`);}catch{missing.push(`${doc.name}: missing`);}
    }
    zip.addFile('export-notes.txt',Buffer.from('Amounts are integer minor units. UGX/RWF have zero decimals; other supported currencies have two.\nExternal linked files are not bundled.\n'+missing.join('\n')));
    const filename=inside(this.root,`Exports/${scope}-${stamp().replace(/[:.]/g,'-')}.zip`);zip.writeZip(filename);return {path:filename,missing};
  }
  close(){this.store.close();}
}
