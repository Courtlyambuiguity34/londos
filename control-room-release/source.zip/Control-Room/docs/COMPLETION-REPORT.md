# Control Room — completion and verification report

Prepared 19 October 2026. Implementation and verification below were performed on 18 October 2026. This is an implemented local Electron application with real SQLite and filesystem operations. The supplied brief is retained as `BUILD-BRIEF.txt`. Unrelated workspace projects were not changed, and no repository or deployment was published.

## Implemented

- Electron 44.9.0, React/Vite, Lucide, secure preload/IPC, workspace onboarding, saved themes, collapsible navigation, global search, quick add, and unsaved-edit protection.
- Database-backed dashboard counts, projects/activity, tasks, renewals/follow-ups, per-currency receivables, quotations/contracts, notifications, and last backup.
- Clients, multiple offices and contacts, primary-contact selection, communications, follow-ups, archive, and foreign-key-protected deletion.
- Projects with client relationships, statuses/priorities/dates, user-provided quick links, technical notes, folders, and linked-record views.
- Eight specified projects/clients, with only stated hosting providers. ReGreenEdu remains unconfirmed. Unknown URLs, dates, contacts, and payments remain blank.
- Hosting accounts/services, domains/DNS/registrars, confirmed renewals/evidence, email subscriptions/mailboxes, service accounts, project-account links, and database registry.
- Sheets/Excel/CSV/Drive/data-source registry, local file picker, default-app/browser opening, and integration descriptions.
- Managed documents and external links, stable-ID folders, categories, watch/poll/startup/manual reconciliation, missing flags, rename/move/reveal/open, and protected deletion.
- Normalized quotation items, immutable previous revisions and historical attachment references, contracts, and quotation/invoice PDFs.
- Integer-minor-unit finance, partial payments/refunds, tax/discounts, currency/balance validation, separate revenue/pass-through classifications, and expenses.
- Tasks, completion dates, date-derived reminders, deduplication, snooze/history/acknowledgement, tray, and desktop-notification integration.
- SQLite backup API, checksum manifests, integrity-checked restore to an empty folder, scoped client/project/finance/document/all-record ZIP exports, and manual upload confirmations.
- Windows packaging configuration, icon assets, SQLite Node-API prebuild handling, Windows scripts, and GitHub Actions tests/build/artifacts/tagged releases.

## Verification performed

Host: Linux x64, Node 24.19.0, Electron 44.9.0, actual Electron windows under Xvfb. No Windows host was available.

| Check | Result |
|---|---|
| `npm run check` | Passed |
| `npm run verify:native` | Passed; Node-API 10 SQLite binding loaded |
| `npm test` | **22 passed, none skipped** |
| `npm run build` | Passed with Vite 8.3.4 |
| `npm run test:desktop` | Passed in actual Electron |
| `npm audit --omit=dev` | **0 runtime vulnerabilities reported** at verification time |
| Packaged Windows application directory | Created and statically inspected |
| Windows execution/install/uninstall | **Not verified** |

Tests cover migrations/seeding/reopen; clients/contacts/locations/communications; ownership and infrastructure relationships; money, payments/refunds/currencies/overpayments; financial separation/overflow; quotation revisions/attachments; import/link/paste/missing/move/search/collision behavior; authorized local paths; URL/path/symlink and SQL injection protections; reminders/renewals; backup/restore/corruption/traversal; scoped exports; and pagination.

The scale fixture used **128 clients, 128 projects, and 2,000 files**. Reconciliation plus search/pagination checks took approximately **112 ms** on this host. This is not a Windows or network-drive performance guarantee.

Desktop checks cover onboarding, renderer isolation, real client create/edit/list/global search, dark theme, invoice partial payment over IPC, generated PDF, import, backup, restart/data/theme persistence, and missing-drive recovery without creating a replacement folder. Native pickers are stubbed in the test process to select deterministic paths; IPC, SQLite, PDFs, and filesystem operations are real.

The full dependency audit reported 8 moderate development-tool-chain findings originating from `sprintf-js` through electron-builder download/logging dependencies, with no high or critical findings. These development dependencies are excluded from the application. Runtime audit results were clean. Audits are point-in-time checks, not a security guarantee.

## Windows delivery boundary

Electron-builder created a Windows x64 application directory. Static checks confirmed a Windows x64 PE executable, Windows x64 SQLite binding, and an ASAR containing the entry point, preload, core services, catalog, and compiled frontend.

The Windows ZIP delivers this **complete application folder**. Extract all files together and run `Windows-App/Control Room.exe`. No Node installation is needed to run that packaged application. This is a portable folder, not a verified one-file portable launcher or installer.

The NSIS installer cross-build failed because Wine is unavailable on this Linux host. Its incomplete output is excluded from the downloadable ZIP. An additional build retry was blocked by automatic approval-review capacity; packaging the existing application folder remained available. The Windows workflow and PowerShell script are supplied to build the installer and one-file portable EXE on Windows.

Cross-building does not establish successful Windows execution. Native Windows launch, SmartScreen/signing, install/uninstall, tray/toasts, Explorer/Recycle Bin, default-app links, and Windows drive behavior remain unverified. The cross-build skipped executable resource editing; normal Windows builds apply configured icon/metadata. No signed-release or successful Windows-execution status is claimed.

## Deliberate limitations and optional work remaining

- Single administrator; no staff authentication/permissions or concurrent multi-user editing.
- One primary project contact; other people are accessible through client contacts. No project/contact join-table editor.
- Logo URL registry only; no embedded logo preview/upload.
- No direct hosting/registrar/email/database/Google API integrations, OAuth, automatic cloud upload, or spreadsheet cell editing. All remote actions use user-entered links and normal permissions.
- No exchange-rate engine; currencies remain separate. This is an operations ledger, not double-entry accounting.
- No app lock, encrypted database/backups, archive signatures, or credential vault. Do not store secrets in notes.
- No closed-app scheduler. Reminders run while the app/tray is running and catch up on reopening; Windows OS delivery is untested here.
- Memory-backed ZIP processing with documented size/entry bounds; no streaming multi-gigabyte archives. External linked files are not copied. Externally edited managed files are not locked during backup.
- External renames create a new indexed path and mark the old path missing rather than guessing identity.
- Search/reference/related-view limits are in DATA-MODEL.md; no full-text extraction from document contents.
- Acknowledging an alert does not silently change the underlying business record; renewal requires confirmation.
- Migration 1 creation/reopen is tested; no older released schema exists for upgrade testing.
- GitHub workflow was authored but not pushed or executed remotely.

Implemented controls perform real local operations. The limitations above are not presented as completed integrations or Windows validation.
