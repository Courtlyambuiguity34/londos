# Control Room user guide

## Start your workspace

Run Control Room, choose a new empty folder, and keep that folder on a reliable local drive. Existing workspace folders can be reconnected. Control Room adds the eight named initial projects; these records are editable. Confirm every client's details, project status, URL, and renewal date before relying on them.

Use the theme button in the top bar for light/dark appearance. Settings contains business details for PDFs, the default currency, reminder intervals, and tray preferences. Ctrl+K focuses global search; Ctrl+N opens a new record in the current module. Escape closes a dialog, with a confirmation if its record form has unsaved edits.

## Clients, offices, contacts, and conversations

Open Clients → New client. Enter the organization, trading name, classification, status, website, notes, and next follow-up. For a family-company website restoration opportunity, choose **prospective** and record the opportunity in Communications or Tasks.

Use the Contacts and Offices & locations tabs for multiple people and locations. Reference fields are searchable: type a name and select the matching entry from the list. Two clients with the same name are distinguished by short IDs. Only one contact per client can be marked primary.

Open a contact to email, call, or use WhatsApp; Windows handles email/call links with your configured applications. Use international numbers for WhatsApp. Open a location's Google Maps URL to see it in your browser. Only links you enter are used.

Communications holds calls, meeting notes, requests, commitments, outcomes, and opportunities. Saving a dated communication updates that client's last contact and next follow-up when provided. Opening any client shows linked records and chronological activity. Add a contact or schedule a follow-up directly from the client detail dialog.

Custom fields currently support clients and projects. Copy the full record ID from the record detail subtitle, select the record type, and store one label/value per custom field. This is a basic extensibility tool, not a visual schema builder.

## Projects and infrastructure

Create a project and optionally associate it with a client. A client may have many projects, and either can exist alone. Choose the project status, priority, deadlines, and maintenance plan. Fill in live-site, GitHub, branch, hosting/admin/deployment, database/storage, and content-sheet links as applicable. Blank links remain blank. Project detail links open in your browser; Open folder opens the managed project directory.

Infrastructure has separate hosting-account and hosting-service tabs. Create the provider account first; then create individual frontend, backend, worker, database, or other services and link them to projects. Add costs and renewal dates at the correct billing level; do not duplicate the same shared bill as both an account cost and service cost if you want a clean registry. Infrastructure registry amounts do not automatically create invoices or expenses.

Service accounts registers platforms such as Cloudinary, GitHub, Google Drive, MongoDB Atlas, and PostgreSQL providers. Project service links establishes many-to-many relationships. Databases records engine, cluster, environment, region, and management URL. These are local registries and quick links; the app does not connect to production systems.

## Domains and email

Domains holds the registrar, DNS information, ownership, registration/expiry dates, renewal cost, and auto-renew flag. Auto-renew is informational; it does not perform a registrar payment or renewal.

After you verify a renewal at the registrar, open the domain → Record renewal. Enter the new expiry, amount/currency, and optional payment-evidence document. Confirm the native dialog. The app updates the expiry and appends a read-only renewal-history row. Merely receiving or dismissing an alert never marks a domain renewed.

For email, create the subscription first, including provider, domain, plan, mailbox count, billing and expiry. Create individual mailboxes linked to that subscription. Store the shared cost once on the subscription. Mailboxes contain no passwords.

## Spreadsheets and data sources

Add a Google Sheet, Excel workbook, CSV, Drive folder, or another resource. Supply its URL or choose a local file with the file picker. Record the purpose and relationship, for example: `Google Sheets → WordPress plugin/API → website`.

Open resource uses your browser or default Windows application. Local-file links take precedence if both a URL and local file exist. This version does not edit cells, authenticate to Google APIs, or bypass sharing permissions.

## Documents and Explorer

Documents → Add documents lets you choose the client/project/category, then select one or more files. Import copies files into the workspace. Enable Link external files to retain the files at their original location.

You may also paste files into managed folders using Explorer. The app reconciles on startup, watches changes, checks periodically, and has a Refresh folders button. Stable client/project IDs infer associations for files pasted into their folders. Add description/tags in Edit record. Filter by client, search names/tags/categories, and open a row for file actions.

- Open file launches its default Windows application.
- Reveal in Explorer shows the file in its directory.
- Rename / move changes a managed file's filename, category, and client/project folder after confirmation.
- Delete sends a managed file to the Recycle Bin. For an external file, Delete only removes the link. A missing file's index entry can be removed.
- Files attached to other records or quotation revisions cannot be deleted until those live links are removed; historical revision attachments stay protected.
- Archive hides the record from the normal list while preserving its file and history.

Files renamed externally are discovered as new files, while the old path is marked missing. The app does not guess that two different paths are the same document. Review/relink the new record and remove the obsolete missing record if it has no dependencies.

## Quotations, contracts, and finance

Create a quotation with a unique number, client/project, issue/validity dates, currency, and line items. Quantity accepts up to three decimals. Prices and discounts use currency units, not raw minor units. Enter tax in basis points (1800 = 18%). Draft quotations may be empty; issuing requires a line item. Save PDF generates a printable document using your business settings.

Editing a quotation creates a snapshot of the previous header, attachment reference, and line items. View these in Revisions. Accepted/rejected/expired statuses are explicit. Due reminders do not silently change a business status.

Contracts supports development, maintenance, hosting, SLA, and custom agreements. Link a signed document and contact. Leave end date empty for a contract without fixed expiry.

Create an invoice in Finance. Draft invoices become payable after you select **issued**. Choose revenue or pass-through and a charge category. From the invoice, choose Record payment for each installment. Use the invoice's currency. The balance and paid/partial status are calculated from all payments minus refunds. To return funds, enter a payment row with kind **refund**. Do not delete payments; the audit trail is retained.

Expenses are separate records with business, third-party, or pass-through classification. Reports separates each currency and fund type; no implicit exchange rate is used. Revenue in Reports is net payments received, distinct from invoice totals and outstanding amounts. Archive affects record visibility, not financial history.

## Tasks and notifications

Create tasks for calls, meetings, maintenance, milestones, requests, or opportunities. Link the relevant client/project/contact, assign a due date and priority, and update its status. Mark completed fills the completion date.

Notifications includes renewal dates, contract end dates, invoice due dates, follow-ups, project deadlines, task deadlines, data reviews, quotation validity, and optional backup reminders. Snooze postpones a reminder for one day. Done and Dismiss acknowledge the notification; they do not renew a domain, pay an invoice, or complete the underlying task.

To receive alerts while working elsewhere, keep Control Room running in the tray. Closing the window hides it when that option is enabled; choose Quit from the tray/menu to exit. An unsaved form remains in the hidden window. Alerts do not run when the app is quit or the computer is off; reopening checks missed due dates.

## Backups, exports, and moving PCs

Use Settings → Create backup. The app creates a consistent SQLite snapshot and a ZIP containing managed files plus an integrity manifest. Open Backups folder to copy the result to a separate drive or upload it to Google Drive manually. Set a Drive folder URL if useful. Click “I uploaded this” only after the upload really completes; the app records your confirmation, not an automated cloud verification.

Restore backup selects a ZIP and an empty destination. The app verifies it before opening the restored workspace. Your existing workspace remains intact. Linked external files are not bundled: copy/reconnect those separately. The backup does not include earlier backup ZIPs, exports, or the application installer.

To move PCs, copy a verified backup ZIP, install/build Control Room on the new PC, and choose Restore from a backup ZIP. To move locally, use Copy to new location; it snapshots the active workspace, restores to an empty folder, switches to it, and keeps the original. Reconnect/switch can reopen either workspace.

For sharing, use a client/project's Export ZIP action. Reports also exports all records, finance, or documents. ZIPs include JSON, CSV tables, and relevant managed documents. Exports are for review/sharing; use a **backup**, not an export, for restoring the application. Missing and external-linked document exclusions are listed in export-notes.txt. Exporting does not send files to anyone.
