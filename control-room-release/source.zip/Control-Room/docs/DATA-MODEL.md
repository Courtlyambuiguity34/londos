# Data model and operational boundaries

Migration 1 is implemented transactionally in `core/store.js`. Every business table has a UUID primary key, archived flag, and created/updated timestamps. Names and foreign-key/date fields are indexed. Foreign keys use RESTRICT for business records and CASCADE only for owned line items. The database uses WAL and a five-second busy timeout.

| Relationship | Representation |
|---|---|
| Client → offices, contacts, communications, projects | `client_id` foreign keys |
| Project → resources, domains, tasks, documents, finance | `project_id` foreign keys; client ownership checked when both are supplied |
| Hosting account → services | `hosting_services.account_id` |
| Email subscription → mailboxes | `mailboxes.subscription_id` |
| Service account ↔ projects | `project_services` with unique `(project_id, account_id)` |
| Service account → databases | `databases.account_id` |
| Quotation → items | `quotation_lines.parent_id` |
| Quotation → immutable historical versions | `quotation_revisions.quotation_id` and `quotation_revision_lines.revision_id` |
| Invoice → items → ledger balance | `invoice_lines.parent_id`; `payments.invoice_id` |
| Document attachments | Foreign keys from quotations, revisions, contracts, invoices, payments, expenses, and renewal evidence |
| Domain → confirmed renewals | `renewals.domain_id` |
| Reminder history | `notifications` with unique deduplication key, state, snooze deadline, and delivery flag |
| Settings | Small scalar/array values in `settings`; not a JSON business-record store |
| Audit and backup history | `activities` and `backups` |
| Optional client/project extra attributes | `custom_fields` label/value rows with validated record type/ID |

A reminder rule is derived from an existing date field; there is no second manually editable “reminders” table. This avoids competing due dates. The notification table stores each historical reminder occurrence. Line items and quotation revisions are normalized. The shared catalog generates ordinary SQL columns; individual records are not stored as opaque JSON blobs.

`id`, archive status, and timestamps are system-managed. The IPC layer accepts only known commands; the store accepts only catalog fields. Monetary calculations use BigInt intermediates and return bounded integer minor units. A selected project fills the client association when it is omitted and rejects a conflicting client. Contact references must match the associated client.

Client/project export selects owned rows and their needed parent/reference records. It does not recursively follow other clients through shared account or document links. JSON retains nested line items, while CSV also includes separate line-item tables. Activity and notification history are included in full workspace backups, not in client/project exports.

## Known design limits

- One local administrator and one primary project contact; client records can hold many contacts. Staff identities, role permissions, and contact-to-project join tables are future migrations.
- Custom fields support clients/projects and use a validated polymorphic record ID; the relationship cannot be expressed as a single SQLite foreign key.
- Dashboard/sidebar counts use active, nonarchived operational records. Financial reports retain historical transactions even when archived.
- Schema migration 1 is the first release. Its creation and reopen behavior is tested; upgrade migrations from future releases do not exist yet.
- Document lists paginate; global search returns up to 10 results per module and 120 overall. Reference selectors load up to 20,000 labels per table. Related-record detail displays up to 200 per relationship; full module views and exports remain available.
- Desktop notifications mark an alert delivered when Electron submits it to the OS. This is not proof that a user saw it. Google Drive upload confirmation is explicitly user-attested.
- The archive format is portable ZIP with SHA-256 corruption detection, not a cryptographic signature or encryption format.
