import js from '@eslint/js';
import globals from 'globals';
export default [{ignores: ['node_modules/**', 'dist/**', 'release/**', 'test-results/**']}, js.configs.recommended, {files: ['**/*.{js,cjs,mjs,jsx}'], languageOptions: {ecmaVersion: 'latest', sourceType: 'module', parserOptions: {ecmaFeatures: {jsx: true}}, globals: {...globals.node, ...globals.browser}}, rules: {'no-unused-vars': 'off', 'no-empty': ['error', {allowEmptyCatch: true}]}}];
