# Control Room

**Digital Operations Headquarters** — a local-first Electron application for a freelance web developer's clients, projects, infrastructure, files, quotations, contracts, finances, and follow-ups.

This ZIP contains the application source, a compiled frontend, tests, Windows development/build scripts, and a GitHub Actions workflow. **It does not contain a prebuilt Windows EXE.** Generate the installer and portable application on Windows, locally or with the included workflow. See [the verification report](docs/COMPLETION-REPORT.md) for what was actually tested.

## Start on Windows

1. Extract the entire ZIP to a normal folder, such as `C:\Projects\Control-Room`.
2. Install **Node.js 24 LTS (or Node 22.14+)** from https://nodejs.org. Node is only required for development/building, not for a packaged application.
3. Open PowerShell in the extracted `Control-Room` folder and run:

   ```powershell
   npm ci
   npm start
   ```

4. Choose an empty workspace folder, such as `D:\ControlRoom`, or reconnect an existing Control Room workspace.
5. Start adding your real details. The eight specified projects and their client records are already present; unconfirmed URLs, dates, contacts, and financial data remain blank.

You can also run `scripts\install-windows.ps1`, then double-click `scripts\start-windows.cmd`. If your PowerShell policy disallows scripts, use the npm commands above; changing system execution policy is unnecessary.

**Do not double-click `index.html`.** The renderer requires the secure Electron bridge and local SQLite services.

## Generate the Windows installer and portable EXE

On a Windows x64 computer:

```powershell
npm ci
npm run check
npm test
npm run build
npm run test:desktop
npm run dist:win -- --publish never
```

Or run `scripts\build-windows.ps1`. The `release` folder will contain an NSIS installer and a portable EXE. A packaged app includes Electron and SQLite, and needs no Node, Python, Docker, or backend server at runtime. better-sqlite3 13 ships Node-API binaries for Windows x64/ARM64, Linux, and macOS. Node-API 10 works in the supported Node/Electron versions without rebuilding against an Electron-specific ABI; the build deliberately disables unnecessary native rebuilds. The postinstall check loads SQLite on the development host, and desktop smoke tests load it inside Electron.

The workflow `.github/workflows/windows-build.yml` runs on Windows for pull requests, main/master pushes, manual dispatches, and `v*` tags. To download builds:

1. Put the extracted project at the root of your own GitHub repository, including `.github/workflows`.
2. Open **Actions → Windows desktop build → Run workflow**.
3. Wait for tests and packaging to pass.
4. Download **Control-Room-Windows-x64** from that run's Artifacts section.
5. Extract the artifact, then run the installer or portable EXE.

A `v1.0.0` tag creates a GitHub Release only after the Windows job succeeds. The workflow uses GitHub's scoped token; no embedded credential is required. Builds are unsigned unless you separately configure a signing certificate. Windows SmartScreen reputation and signing are deployment concerns, not verified by the Linux development checks.

## What is included

- Database-backed dashboard, activity history, quick add, global search, filtering, sorting, pagination, persisted light/dark themes, and a collapsible sidebar.
- Clients, multiple offices and contacts, communications and follow-up dates, project quick links, and client/project folders.
- Hosting accounts and services, domains and confirmed renewal history, email subscriptions and individual mailboxes, service accounts, project-service links, and database registries.
- Google Sheets, Excel, CSV, Drive folders, and other data source links, including plugin/integration descriptions.
- Managed document import, external links, Explorer discovery, file search, rename/move, Recycle Bin removal, and attachment links.
- Quotations with normalized line items and immutable previous revisions; printable quotation and invoice PDFs.
- Contracts, invoices, partial payments and refunds, expenses, per-currency reports, and separate revenue/pass-through classifications.
- Tasks and follow-ups, in-app reminder history, snooze/dismiss/complete, Windows notification calls, and tray operation.
- Consistent SQLite backup snapshots, checksummed ZIP archives, verified restore into an empty folder, client/project/finance/document exports, and manual Drive-upload confirmations.

## Workspace and persistence

Your chosen workspace is separate from the installed program. It contains:

```text
ControlRoom/
  Database/
    control-room.sqlite
    workspace.json
  Clients/
    <stable-client-uuid>-<original-name>/
      Business-Profile/  Quotations/  Contracts/  Invoices/  Receipts/
      Projects/  Content-and-Data/  Assets/  Correspondence/
  Projects/<stable-project-uuid>/
  Business-Profile/  Quotations/  Contracts/  Invoices/  Receipts/
  Content-and-Data/  Assets/  Correspondence/
  Backups/
  Exports/
```

Additional document category folders are supported. Renaming a client does not rename its existing stable-ID folder. Workspace location is remembered in Electron's per-user application data directory, typically `%APPDATA%\Control Room\workspace.json`; the exact application-data folder is chosen by Electron. Theme and business preferences live in SQLite and travel with backups.

Only one application instance per profile is allowed. This is a single-administrator desktop application, not a concurrent multi-user database. Avoid opening the same workspace from different computers or synchronizing a live database with a cloud sync tool. Upload a completed backup ZIP instead.

Folder changes are watched while the app runs, with a 30-second reconciliation fallback, startup reconciliation, and a manual Refresh action. Database/Backups/Exports are excluded from document indexing. Symlinks are excluded. Missing files remain indexed and visibly marked missing.

## Architecture

- `electron/main.cjs`: application lifecycle, native dialogs, strict command routing, URL/file opening, PDF generation, tray, and desktop notifications.
- `electron/preload.cjs`: one allowlisted request bridge and one change-event subscription. Node is not exposed to React.
- `shared/catalog.js`: field definitions, module relationships, exact integer-money conversion and line calculations.
- `core/store.js`: versioned migration 1, normalized SQLite tables, parameterized CRUD, relational validation, financial rules, revisions, search, activities, and reminders.
- `core/workspace.js`: managed paths, imports/reconciliation, scoped exports, SQLite backup API, archive checksums, and restore staging.
- `core/security.js`: safe URLs, Windows-safe names, real workspace scope, and traversal/symlink checks.
- `src/`: React UI, reusable forms, reference selectors, linked details, and module screens.
- `tests/`: isolated database/filesystem integration tests.
- `scripts/smoke.mjs`: actual Electron/Playwright workflows with native dialogs stubbed inside the test process.

Clients own projects, contacts, and offices. Hosting accounts own hosting services; projects reference services. Email subscriptions own mailboxes, so subscription costs are stored once. Service accounts connect to projects through a join table. Quotations/invoices own line items; quotation revisions own separate historical line items. Payments reference invoices. Documents serve as managed files or external links and can be attached to finance and contracts.

Schema versioning is recorded in `migrations`. Future schema changes must be new numbered, transactional migrations; do not alter a released migration in place. The app refuses a database with a newer migration version.

## Money and status rules

Amounts are integer minor units. UGX and RWF have zero decimal places; USD/EUR/GBP/KES/TZS have two. Quantities allow three decimal places; each line rounds to the nearest minor unit, half up. Tax is applied to subtotal minus discount and also rounds half up. Tax is entered in basis points: 1800 means 18%. Values and report totals beyond JavaScript's safe integer range are rejected.

Only issued invoices accept payments. Payment/refund currency must match the invoice. Overpayment and refunds exceeding received funds are blocked. Paid invoices cannot change currency, become draft/void, or drop below the net amount received. Payment rows are retained; record a refund instead of deleting a payment. Invoice payment status is computed from the ledger. Archiving does not remove transactions from financial reports.

Currencies are never converted or summed together. Reports separate invoice revenue and pass-through funds; expenses have business/third-party/pass-through classifications. This is an operations ledger, not full double-entry accounting or a tax filing system.

## Reminders and backups

The default intervals are 60/30/14/7/1/0 days, plus overdue. Intervals are editable; backup reminders are off until you choose a number of days. A reminder is deduplicated by record, date field, due date, and threshold. Snoozing carries into a later threshold for the same due date. Dismissed/completed reminders remain in history; a later threshold can create a new notification.

Windows alerts require the app to be running, including in the tray, and OS notification permission. Quitting stops background processing; reopening catches up. There is no Task Scheduler integration and no claim of alerts while the computer is off. Completing a notification acknowledges that alert; edit the underlying record or use a confirmed renewal action to change its actual due date/status.

Backups use `better-sqlite3`'s backup API, verify SQLite integrity, and bundle managed files with SHA-256 hashes. Restore validates paths, manifest entries, size bounds, hashes, SQLite integrity, and foreign keys before opening the new workspace. Restore will not overwrite a nonempty destination. Keep managed files unchanged during a backup; files edited externally are not locked by Electron. Linked external files are not copied into backups. ZIP backups/exports are not encrypted.

The current archive implementation is memory-backed: restore permits at most 25,000 entries, 512 MiB per file, and 2 GiB of declared uncompressed content. Large archives may require substantial memory. Treat this as a small-business document workspace; streaming multi-gigabyte archives are a future improvement.

## Security and local privacy

The renderer uses context isolation, disabled Node integration, sandboxing, a restrictive CSP, denied permissions, no remote content, blocked navigation/window creation, and origin-checked IPC. SQL identifiers come from the catalog and values use bound parameters. External URLs are restricted to http/https and explicit mailto/tel actions; file paths come from native pickers or scoped managed records. Imports refuse overwrite; deletion requires native confirmation and preserves linked history.

Do not put passwords, API tokens, or production credentials in free-text notes. The app provides no credential fields or remote authentication. Workspace files are protected by your Windows account permissions; app locking, SQLCipher, archive encryption, and staff permissions are not implemented.

## Development and checks

```sh
npm ci
npm run check
npm test
npm run build
npm run test:desktop
npm start
```

SQLite is a native dependency with stable Node-API 10 prebuilds. `npm run verify:native` checks the binding in Node; desktop smoke tests check the same platform's binding in Electron. `asarUnpack` keeps the native package accessible to the loader. No compiler or ABI switching is needed on the supported platforms. On a headless Linux CI host, run desktop tests under Xvfb, e.g. `xvfb-run -a npm run test:desktop`; Windows uses its desktop runner.

`npm run watch` rebuilds frontend files as you edit them; use Reload in the running app after saving changes. No Vite development server or local HTTP backend is needed.

## Troubleshooting

- **Workspace unavailable:** reconnect its drive, use Reconnect/switch, or restore a backup into a new empty folder. The app does not silently create a replacement at the missing path.
- **SQLite binding error:** verify Node is at least 22.14, run `npm ci`, then `npm run verify:native`. Do not replace the pinned SQLite package with an older ABI-specific version without updating the packaging strategy.
- **Foreign key/delete refusal:** archive the record or unlink dependent records. Payment and quotation-revision history is intentionally retained.
- **A pasted file is absent:** use Documents → Refresh folders. Files in Database/Backups/Exports, symlinks, and external unlinked folders are not indexed.
- **External file missing:** reconnect its original drive or import a managed copy, then update attachment links as needed.
- **Import collision:** rename the source or choose another category. Existing files are never silently overwritten.
- **No Windows alert:** check app/Windows notification settings and whether the app is running. All reminders remain in Notifications.
- **Unexpected error:** the UI displays the operation error. Preserve the workspace and take a backup before manually editing anything in Database.

For daily workflows, read [User Guide](docs/USER-GUIDE.md). Optional future work includes staff roles, app lock, encrypted/streaming backups, direct OAuth integrations, exchange-rate configuration, local logo preview, and closed-app scheduled reminders.
