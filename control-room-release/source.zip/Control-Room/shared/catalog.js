const field = (name, label, type = 'text', extra = {}) => ({name, label, type, ...extra});
const text = (n,l,extra={}) => field(n,l,'text',extra);
const req = (n,l) => text(n,l,{required:true});
const memo = (n='notes',l='Notes') => field(n,l,'textarea');
const date = (n,l) => field(n,l,'date');
const url = (n,l) => field(n,l,'url');
const ref = (n,l,target,required=false) => field(n,l,'ref',{target,required});
const sel = (n,l,options,def) => field(n,l,'select',{options:options.split('|'), default:def});
const num = (n,l,def=0) => field(n,l,'number',{default:def});
const money = (n,l) => field(n,l,'money',{default:0});
const bool = (n,l) => field(n,l,'boolean',{default:0});
const currency = () => sel('currency','Currency','UGX|USD|EUR|GBP|KES|TZS|RWF','UGX');
const client = (required=false) => ref('client_id','Client','clients',required);
const project = () => ref('project_id','Project','projects');
const status = (options,def) => sel('status','Status',options,def || options.split('|')[0]);
const billing = () => [currency(),money('cost_minor','Cost'),sel('billing_cycle','Billing cycle','monthly|quarterly|annually|one-time|custom'),date('renewal_date','Renewal date')];
const relation = () => [client(),project()];
const definition = (label,singular,fields,columns,extra={}) => ({label,singular,fields,columns:columns.split(','),...extra});
export const catalog = {
  clients: definition('Clients','Client',[req('name','Organization'),text('trading_name','Trading name'),text('category','Category'),memo('description','Description'),url('website','Website'),url('logo_url','Logo URL'),sel('classification','Classification','existing|previous|prospective|internal|partner|other','existing'),status('active|nurturing|on-hold|inactive','active'),date('date_added','Date added'),date('last_contact','Last contact'),date('next_followup','Next follow-up'),memo()], 'name,classification,status,next_followup'),
  locations: definition('Offices & locations','Location',[client(true),req('name','Office name'),text('country','Country'),text('region','Region'),text('district','District'),text('city','City'),text('address','Physical address'),text('building','Building / plot'),text('coordinates','Coordinates'),url('maps_url','Google Maps URL'),memo()], 'name,client_id,city,country'),
  contacts: definition('Contacts','Contact',[client(true),req('name','Full name'),text('title','Job title'),text('department','Department'),field('email','Email','email'),text('phone','Phone'),text('whatsapp','WhatsApp (international number)'),sel('preferred_channel','Preferred channel','email|phone|WhatsApp|meeting|other'),bool('is_primary','Primary contact'),memo()], 'name,client_id,title,email,phone'),
  communications: definition('Communications','Communication',[...relation(),ref('contact_id','Contact','contacts'),req('name','Subject'),sel('type','Type','call|email|WhatsApp|meeting|request|opportunity|commitment|other'),date('contact_date','Date'),memo('summary','Summary / meeting notes'),memo('outcome','Outcome'),date('next_followup','Next follow-up'),memo()], 'name,client_id,type,contact_date,next_followup'),
  projects: definition('Projects','Project',[req('name','Project name'),client(),memo('description','Description'),text('category','Category'),status('unconfirmed|planning|in-development|active|maintenance|on-hold|completed|cancelled','planning'),sel('priority','Priority','low|normal|high|urgent','normal'),date('start_date','Start date'),date('due_date','Due date'),date('completed_date','Completion date'),url('live_url','Live website'),url('github_url','GitHub repository'),text('branch','Branch'),url('admin_url','Admin URL'),url('deployment_url','Deployment dashboard'),text('hosting_provider','Hosting provider'),url('hosting_url','Hosting dashboard'),url('database_url','Database dashboard'),url('storage_url','Storage dashboard'),url('content_url','Content sheet'),text('maintenance_plan','Maintenance plan'),ref('contact_id','Contact','contacts'),memo('technical_notes','Technical notes'),memo()], 'name,client_id,status,hosting_provider,due_date'),
  hosting_accounts: definition('Hosting accounts','Hosting account',[req('name','Account label'),sel('provider','Provider','Render|Bluehost|Vercel|Netlify|Hostinger|AWS|DigitalOcean|custom'),field('email','Username / email'),url('dashboard_url','Dashboard URL'),text('owner','Owner'),...billing(),memo()], 'name,provider,cost_minor,currency,renewal_date'),
  hosting_services: definition('Hosting services','Hosting service',[req('name','Service name'),ref('account_id','Hosting account','hosting_accounts',true),project(),sel('type','Service type','frontend|backend|worker|database|static|storage|custom'),url('dashboard_url','Dashboard URL'),sel('environment','Environment','production|staging|development'),text('branch','Deployment branch'),url('public_url','Public URL'),status('unconfirmed|active|suspended|retired','unconfirmed'),...billing(),memo()], 'name,account_id,project_id,type,status,renewal_date'),
  domains: definition('Domains','Domain',[req('name','Domain'),...relation(),text('registrar','Registrar'),url('registrar_url','Registrar URL'),date('registration_date','Registration date'),date('expiry_date','Expiry date'),money('renewal_price_minor','Renewal price'),currency(),bool('auto_renew','Auto renew'),text('responsible_person','Responsible person'),status('unconfirmed|active|expired|transferring|retired','unconfirmed'),text('dns_provider','DNS provider'),url('dns_url','DNS dashboard'),memo()], 'name,client_id,project_id,expiry_date,status'),
  renewals: definition('Renewal history','Renewal',[req('name','Renewal reference'),ref('domain_id','Domain','domains',true),date('renewed_on','Renewed on'),date('previous_expiry','Previous expiry'),date('new_expiry','New expiry'),money('amount_minor','Amount'),currency(),ref('evidence_id','Payment evidence','documents'),memo()], 'name,domain_id,renewed_on,new_expiry', {readOnly:true}),
  email_subscriptions: definition('Email subscriptions','Email subscription',[req('name','Subscription label'),...relation(),sel('provider','Provider','Google Workspace|Microsoft 365|Bluehost Email|Zoho|cPanel|custom'),text('account','Account'),url('dashboard_url','Dashboard URL'),text('domain','Domain'),text('plan','Plan'),num('mailbox_count','Licensed mailbox count'),...billing(),date('expiry_date','Expiry date'),ref('contact_id','Contact','contacts'),memo()], 'name,client_id,provider,mailbox_count,expiry_date'),
  mailboxes: definition('Mailboxes','Mailbox',[req('name','Display name'),field('email','Email','email',{required:true}),text('purpose','Purpose'),ref('subscription_id','Subscription','email_subscriptions',true),status('active|suspended|closed','active'),memo()], 'name,email,subscription_id,status'),
  service_accounts: definition('Service accounts','Service account',[req('name','Account label'),sel('provider','Provider','MongoDB Atlas|PostgreSQL|Cloudinary|Google Drive|Google Sheets|GitHub|Render|Bluehost|custom'),field('email','Email','email'),url('dashboard_url','Dashboard URL'),text('owner','Owner'),text('plan','Plan'),...billing(),text('cloud_name','Cloudinary cloud name'),memo('usage_notes','Usage notes'),memo()], 'name,provider,owner,cost_minor,currency,renewal_date'),
  project_services: definition('Project service links','Project service link',[req('name','Link label'),ref('project_id','Project','projects',true),ref('account_id','Service account','service_accounts',true),memo()], 'name,project_id,account_id'),
  databases: definition('Databases','Database',[req('name','Database name'),ref('account_id','Service account','service_accounts',true),project(),text('engine','Engine'),text('instance','Cluster / instance'),sel('environment','Environment','production|staging|development'),text('region','Region'),url('management_url','Management URL'),memo()], 'name,account_id,project_id,engine,environment'),
  data_sources: definition('Spreadsheets & data sources','Data source',[req('name','Resource name'),...relation(),sel('type','Type','Google Sheets|Excel|CSV|Drive folder|other'),url('url','Resource URL'),field('local_path','Local file','file'),memo('description','Description'),text('purpose','Purpose'),text('integration_method','Integration method'),text('plugin','Plugin / add-in'),date('review_date','Review date'),memo()], 'name,client_id,project_id,type,review_date'),
  documents: definition('Documents','Document',[req('name','Filename'),...relation(),text('category','Category'),memo('description','Description'),text('tags','Tags (comma separated)'),text('extension','File type',{readonly:true}),text('relative_path','Managed path',{readonly:true}),text('external_path','Linked path',{readonly:true}),num('size','Bytes'),bool('missing','Missing file'),memo()], 'name,client_id,project_id,category,extension,missing', {managed:true}),
  quotations: definition('Quotations','Quotation',[req('name','Quotation number'),...relation(),date('issue_date','Issue date'),date('valid_until','Valid until'),memo('description','Description'),currency(),num('tax_bps','Tax (basis points: 1800 = 18%)'),money('discount_minor','Discount'),status('draft|issued|revised|accepted|rejected|expired','draft'),ref('attachment_id','Attachment','documents'),memo()], 'name,client_id,status,total_minor,currency,valid_until',{lines:true}),
  contracts: definition('Contracts','Contract',[req('name','Contract reference'),...relation(),sel('type','Type','development|maintenance|hosting|SLA|custom'),date('start_date','Start date'),date('end_date','End date (optional)'),money('value_minor','Value'),currency(),sel('billing_frequency','Billing frequency','monthly|quarterly|annually|one-time|custom'),status('draft|active|expired|terminated','draft'),memo('renewal_terms','Renewal terms'),ref('contact_id','Contact','contacts'),ref('attachment_id','Signed attachment','documents'),memo()], 'name,client_id,type,status,end_date'),
  invoices: definition('Invoices','Invoice',[req('name','Invoice number'),...relation(),date('issue_date','Issue date'),date('due_date','Due date'),currency(),num('tax_bps','Tax (basis points: 1800 = 18%)'),money('discount_minor','Discount'),status('draft|issued|void','draft'),sel('category','Charge category','development|maintenance|hosting|domain|email|storage|other'),sel('fund_type','Fund type','revenue|pass-through','revenue'),ref('attachment_id','Attachment','documents'),memo()], 'name,client_id,status,total_minor,currency,due_date',{lines:true}),
  payments: definition('Payments & refunds','Payment / refund',[req('name','Payment reference'),ref('invoice_id','Invoice','invoices',true),sel('kind','Kind','payment|refund','payment'),money('amount_minor','Amount'),currency(),date('payment_date','Payment date'),text('method','Method'),text('reference','Transaction reference'),ref('receipt_id','Receipt','documents'),memo()], 'name,invoice_id,kind,amount_minor,currency,payment_date'),
  expenses: definition('Expenses','Expense',[req('name','Expense description'),...relation(),sel('category','Category','development|maintenance|hosting|domain|email|storage|other'),sel('fund_type','Fund type','business|third-party|pass-through','business'),money('amount_minor','Amount'),currency(),date('expense_date','Expense date'),text('payee','Payee'),ref('receipt_id','Receipt','documents'),memo()], 'name,category,fund_type,amount_minor,currency,expense_date'),
  tasks: definition('Tasks & follow-ups','Task',[req('name','Title'),...relation(),ref('contact_id','Contact','contacts'),sel('type','Type','task|meeting|call|email|WhatsApp|maintenance|milestone|request|opportunity'),memo('description','Description'),date('due_date','Due date'),sel('priority','Priority','low|normal|high|urgent','normal'),status('pending|in-progress|completed|deferred|cancelled','pending'),date('completed_date','Completed on'),memo()], 'name,client_id,type,priority,status,due_date'),
  custom_fields: definition('Custom fields','Custom field',[req('name','Field label'),sel('entity','Record type','clients|projects'),text('record_id','Record ID'),text('value','Value'),memo()], 'name,entity,record_id,value'),
};
export const groups = [
  {id:'clients',label:'Clients',icon:'Users',tables:['clients','contacts','locations','communications','custom_fields']},
  {id:'projects',label:'Projects',icon:'Layers',tables:['projects']},
  {id:'infrastructure',label:'Infrastructure',icon:'Server',tables:['hosting_accounts','hosting_services']},
  {id:'domains',label:'Domains',icon:'Globe',tables:['domains','renewals']},
  {id:'email',label:'Email',icon:'Mail',tables:['email_subscriptions','mailboxes']},
  {id:'services',label:'Service accounts',icon:'Database',tables:['service_accounts','project_services','databases']},
  {id:'sources',label:'Data sources',icon:'Sheet',tables:['data_sources']},
  {id:'documents',label:'Documents',icon:'FolderOpen',tables:['documents']},
  {id:'quotations',label:'Quotations',icon:'FileText',tables:['quotations']},
  {id:'contracts',label:'Contracts',icon:'FileCheck2',tables:['contracts']},
  {id:'finance',label:'Finance',icon:'Wallet',tables:['invoices','payments','expenses']},
  {id:'tasks',label:'Tasks & follow-ups',icon:'ListTodo',tables:['tasks']},
];
export const categories = ['Business-Profile','Quotations','Contracts','Invoices','Receipts','Projects','Content-and-Data','Assets','Correspondence'];
export const currencyDigits = code => ['UGX','RWF'].includes(code) ? 0 : 2;
export function toMinor(value, currency='UGX') {
  const s=String(value).trim(); const digits=currencyDigits(currency);
  if (!new RegExp(`^\\d+(?:\\.\\d{1,${Math.max(digits,1)}})?$`).test(s) || (digits===0 && s.includes('.'))) throw new Error(`Enter a non-negative amount with ${digits} decimal places for ${currency}.`);
  const [whole,fraction='']=s.split('.'); const result=BigInt(whole)*10n**BigInt(digits)+BigInt((fraction+'0'.repeat(digits)).slice(0,digits)||'0');
  if (result>BigInt(Number.MAX_SAFE_INTEGER)) throw new Error('Amount is too large.');
  return Number(result);
}
export const fromMinor = (n=0,c='UGX') => (Number(n)/10**currencyDigits(c)).toFixed(currencyDigits(c));
export const moneyText = (n=0,c='UGX') => new Intl.NumberFormat('en-UG',{style:'currency',currency:c,maximumFractionDigits:currencyDigits(c)}).format(Number(n)/10**currencyDigits(c));
export function calculateLines(lines,tax=0,discount=0) {
  if (!Number.isSafeInteger(tax)||tax<0||tax>10000||!Number.isSafeInteger(discount)||discount<0) throw new Error('Invalid tax or discount.');
  let subtotal=0n;
  const calculated=lines.map(line=>{
    if (!line.description?.trim() || !Number.isSafeInteger(line.quantity_milli) || line.quantity_milli<=0 || !Number.isSafeInteger(line.unit_price_minor)||line.unit_price_minor<0) throw new Error('Each line needs a description, positive quantity, and valid price.');
    const total=(BigInt(line.quantity_milli)*BigInt(line.unit_price_minor)+500n)/1000n; subtotal+=total;
    if(total>BigInt(Number.MAX_SAFE_INTEGER)) throw new Error('Line total is too large.');
    return {...line,total_minor:Number(total)};
  });
  if(BigInt(discount)>subtotal) throw new Error('Discount exceeds subtotal.');
  const taxable=subtotal-BigInt(discount); const taxAmount=(taxable*BigInt(tax)+5000n)/10000n; const total=taxable+taxAmount;
  if(total>BigInt(Number.MAX_SAFE_INTEGER)) throw new Error('Total is too large.');
  return {lines:calculated,subtotal_minor:Number(subtotal),tax_minor:Number(taxAmount),total_minor:Number(total)};
}
