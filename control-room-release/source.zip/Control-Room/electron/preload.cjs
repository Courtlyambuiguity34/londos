const {contextBridge,ipcRenderer}=require('electron');
const commands=new Set(['state','chooseWorkspace','relocate','list','get','options','save','remove','related','search','dashboard','finance','revisions','settings','updateSettings','notifications','notificationAction','renewDomain','importDocuments','chooseLocalFile','openDocument','revealDocument','moveDocument','deleteDocument','refreshDocuments','openFolder','openUrl','backup','restore','export','backups','confirmUpload','printDocument']);
contextBridge.exposeInMainWorld('controlRoom',{
  request:async(command,payload={})=>{if(!commands.has(command))throw new Error('Unknown operation.');const result=await ipcRenderer.invoke('control-room',command,payload);if(!result.ok)throw new Error(result.error);return result.data;},
  onChange:callback=>{const listener=(_event,payload)=>callback(payload);ipcRenderer.on('workspace-changed',listener);return()=>ipcRenderer.removeListener('workspace-changed',listener);}
});
