const {app,BrowserWindow,ipcMain,dialog,shell,Notification,Tray,Menu,nativeImage}=require('electron');
const path=require('node:path');const fs=require('node:fs');const {pathToFileURL}=require('node:url');
if(!app.requestSingleInstanceLock()){app.quit();process.exit(0);}
app.on('second-instance',()=>{if(win){if(win.isMinimized())win.restore();win.show();win.focus();}});
let win,workspace,tray,watcher,quitting=false,busy=false,refreshTimer,pollTimer,core,security,catalog,quitApproved=false,shuttingDown=false;
if(!app.isPackaged&&process.env.CONTROL_ROOM_TEST_DATA)app.setPath('userData',process.env.CONTROL_ROOM_TEST_DATA);
if(process.argv.includes('--smoke-test'))app.disableHardwareAcceleration();
const configFile=()=>path.join(app.getPath('userData'),'workspace.json');
const readConfig=()=>{try{return JSON.parse(fs.readFileSync(configFile(),'utf8'));}catch{return {};}};
const persistRoot=root=>{fs.mkdirSync(app.getPath('userData'),{recursive:true});const tmp=configFile()+'.tmp';fs.writeFileSync(tmp,JSON.stringify({root}));fs.renameSync(tmp,configFile());};
const notifyChange=payload=>{if(win&&!win.isDestroyed())win.webContents.send('workspace-changed',payload||{});};
const confirm=async(message,detail='')=>(await dialog.showMessageBox(win,{type:'question',buttons:['Cancel','Continue'],defaultId:0,cancelId:0,noLink:true,message,detail})).response===1;
function setWorkspace(next) {
  watcher?.close();clearInterval(pollTimer);clearTimeout(refreshTimer);workspace?.close();workspace=next;persistRoot(next.root);
  const refresh=()=>{if(busy)return;try{const result=workspace.reconcile();workspace.store.refreshReminders();if(result.added)notifyChange({reason:'files'});deliverNotifications();}catch(e){notifyChange({error:e.message});}};
  try{watcher=fs.watch(workspace.root,{recursive:true},(_event,file)=>{if(!file||/^(Database|Backups|Exports)[/\\]/.test(file))return;clearTimeout(refreshTimer);refreshTimer=setTimeout(refresh,1200);});}catch{watcher=null;}
  pollTimer=setInterval(refresh,30000);workspace.store.refreshReminders();deliverNotifications();notifyChange({reason:'workspace'});
}
function deliverNotifications() {
  if(!workspace||!Notification.isSupported()||!workspace.store.setting('desktop_notifications',true))return;
  const rows=workspace.store.db.prepare("SELECT * FROM notifications WHERE state='pending' AND delivered=0 AND (snoozed_until IS NULL OR snoozed_until<=?) ORDER BY due_date LIMIT 3").all(new Date().toISOString());
  for(const row of rows){const n=new Notification({title:'Control Room',body:row.title});n.on('click',()=>{win.show();win.focus();notifyChange({open:row.entity,id:row.record_id});});n.show();workspace.store.db.prepare('UPDATE notifications SET delivered=1 WHERE id=?').run(row.id);}
}
function createWindow(){
  win=new BrowserWindow({width:1440,height:940,minWidth:960,minHeight:660,show:false,title:'Control Room',backgroundColor:'#f6f7f9',icon:path.join(__dirname,'../assets/icon.png'),webPreferences:{preload:path.join(__dirname,'preload.cjs'),contextIsolation:true,nodeIntegration:false,sandbox:true,webSecurity:true}});
  win.webContents.setWindowOpenHandler(()=>({action:'deny'}));win.webContents.on('will-navigate',event=>event.preventDefault());win.webContents.on('will-attach-webview',event=>event.preventDefault());
  win.webContents.session.setPermissionRequestHandler((_wc,_permission,callback)=>callback(false));
  win.loadFile(path.join(__dirname,'../dist/index.html'));win.once('ready-to-show',()=>win.show());
  win.on('close',event=>{if(!quitting&&workspace?.store.setting('close_to_tray',true)&&tray){event.preventDefault();win.webContents.executeJavaScript('window.__controlRoomDirty === true').then(async dirty=>{if(!dirty||await confirm('Hide Control Room with unsaved changes?', 'The form will remain open in the tray. Restore the window to continue editing.'))win.hide();}).catch(()=>win.hide());}});
  win.webContents.on('will-prevent-unload',event=>{if(dialog.showMessageBoxSync(win,{type:'question',buttons:['Keep editing','Discard changes'],defaultId:0,cancelId:0,message:'Discard unsaved changes?'})===1)event.preventDefault();});
  win.on('closed',()=>{win=null;});
  Menu.setApplicationMenu(Menu.buildFromTemplate([{label:'Control Room',submenu:[{label:'Show window',click:()=>win?.show()},{label:'Quit',accelerator:'CmdOrCtrl+Q',click:()=>{quitting=true;app.quit();}}]},{role:'editMenu'},{label:'View',submenu:[{role:'reload'},{role:'resetZoom'},{role:'zoomIn'},{role:'zoomOut'},{role:'togglefullscreen'}]}]));
  try{tray=new Tray(nativeImage.createFromPath(path.join(__dirname,'../assets/icon.png')).resize({width:20,height:20}));tray.setToolTip('Control Room · Digital Operations Headquarters');tray.setContextMenu(Menu.buildFromTemplate([{label:'Open Control Room',click:()=>win.show()},{label:'Quit',click:()=>{quitting=true;app.quit();}}]));tray.on('double-click',()=>win.show());}catch{tray=null;}
}
const settingsKeys=['theme','business_name','business_address','business_email','default_currency','reminder_days','backup_reminder_days','desktop_notifications','close_to_tray','drive_folder_url'];
function getSettings(){return Object.fromEntries(settingsKeys.map(k=>[k,workspace.store.setting(k,({theme:'light',business_name:'',business_address:'',business_email:'',default_currency:'UGX',reminder_days:[60,30,14,7,1,0],backup_reminder_days:0,desktop_notifications:true,close_to_tray:true,drive_folder_url:''})[k])]));}
const escapeHtml=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
async function printDocument(table,id) {
  if(!['invoices','quotations'].includes(table))throw new Error('Only invoices and quotations support printable generation.');
  const record=workspace.store.get(table,id),settings=getSettings(),client=record.client_id?workspace.store.get('clients',record.client_id):null;
  const money=n=>catalog.moneyText(n,record.currency);
  const html=`<!doctype html><html><head><meta charset="utf-8"><meta http-equiv="Content-Security-Policy" content="default-src 'none'; style-src 'unsafe-inline'"><style>body{font:14px Arial;color:#17252a;padding:48px}h1{font-size:32px}table{border-collapse:collapse;width:100%;margin:32px 0}td,th{text-align:left;padding:12px;border-bottom:1px solid #ddd}td:last-child,th:last-child{text-align:right}.totals{text-align:right;line-height:2}.notes{white-space:pre-wrap}</style></head><body><p>${escapeHtml(settings.business_name||'Control Room')}</p><p>${escapeHtml(settings.business_address)}<br>${escapeHtml(settings.business_email)}</p><h1>${table==='invoices'?'Invoice':'Quotation'} ${escapeHtml(record.name)}</h1><p>Prepared for ${escapeHtml(client?.name||'Unassigned client')}<br>Issued: ${escapeHtml(record.issue_date||'—')}<br>${table==='invoices'?'Due':'Valid until'}: ${escapeHtml(record.due_date||record.valid_until||'—')}</p><table><thead><tr><th>Description</th><th>Quantity</th><th>Unit price</th><th>Amount</th></tr></thead><tbody>${record.lines.map(l=>`<tr><td>${escapeHtml(l.description)}</td><td>${l.quantity_milli/1000}</td><td>${escapeHtml(money(l.unit_price_minor))}</td><td>${escapeHtml(money(l.total_minor))}</td></tr>`).join('')}</tbody></table><div class="totals">Subtotal: ${escapeHtml(money(record.subtotal_minor))}<br>Discount: ${escapeHtml(money(record.discount_minor||0))}<br>Tax: ${escapeHtml(money(record.tax_minor))}<br><strong>Total: ${escapeHtml(money(record.total_minor))}</strong>${table==='invoices'?`<br>Paid: ${escapeHtml(money(record.paid_minor))}<br>Balance: ${escapeHtml(money(record.balance_minor))}`:''}</div><p class="notes">${escapeHtml(record.notes)}</p></body></html>`;
  const result=await dialog.showSaveDialog(win,{title:'Save printable PDF',defaultPath:path.join(workspace.root,'Exports',record.name.replace(/[^a-z0-9-]/gi,'_')+'.pdf'),filters:[{name:'PDF',extensions:['pdf']}]});if(result.canceled)return null;
  const printWindow=new BrowserWindow({show:false,webPreferences:{sandbox:true,contextIsolation:true,nodeIntegration:false}});
  try{await printWindow.loadURL('data:text/html;charset=utf-8,'+encodeURIComponent(html));const pdf=await printWindow.webContents.printToPDF({printBackground:true,pageSize:'A4'});fs.writeFileSync(result.filePath,pdf);return {path:result.filePath};}finally{printWindow.destroy();}
}
async function handle(command,p={}) {
  security.assertPlain(p);
  if(command==='state')return {root:workspace?.root||null,missingRoot:workspace?null:readConfig().root||null,version:app.getVersion(),platform:process.platform};
  if(command==='chooseWorkspace') {
    const selected=await dialog.showOpenDialog(win,{title:'Select a new empty folder or an existing Control Room workspace',properties:['openDirectory','createDirectory']});if(selected.canceled)return null;
    const root=selected.filePaths[0];if(fs.readdirSync(root).length&&!fs.existsSync(path.join(root,'Database','control-room.sqlite')))throw new Error('Choose an empty folder or an existing Control Room workspace.');
    if(workspace&&path.resolve(root)===workspace.root)return {root};
    const next=new core.Workspace(root);setWorkspace(next);return {root};
  }
  if(command==='restore') {
    const selected=await dialog.showOpenDialog(win,{title:'Choose a Control Room backup',filters:[{name:'ZIP backup',extensions:['zip']}],properties:['openFile']});if(selected.canceled)return null;
    const dest=await dialog.showOpenDialog(win,{title:'Restore into an empty folder (current workspace is preserved)',properties:['openDirectory','createDirectory']});if(dest.canceled)return null;
    if(!await confirm('Restore and open this backup?',`Destination: ${dest.filePaths[0]}. The current workspace will be kept.`))return null;
    const next=core.Workspace.restore(selected.filePaths[0],dest.filePaths[0]);setWorkspace(next);return {root:next.root};
  }
  if(!workspace)throw new Error('Choose your workspace folder first.');
  const store=workspace.store;
  switch(command) {
    case 'list':return store.list(p.table,p.options);
    case 'get':return store.get(p.table,p.id);
    case 'options':return store.options();
    case 'save':{const r=store.save(p.table,p.record);if(['clients','projects'].includes(p.table))workspace.ensureFolders();store.refreshReminders();return r;}
    case 'remove':if(await confirm('Permanently delete this record?','Linked records prevent deletion. Archiving preserves history.')){store.remove(p.table,p.id);return true;}return false;
    case 'related':return store.related(p.table,p.id);
    case 'search':return store.search(p.query);
    case 'dashboard':store.refreshReminders();return store.dashboard();
    case 'finance':return store.finance();
    case 'revisions':return store.revisions(p.id);
    case 'settings':return getSettings();
    case 'updateSettings':{
      security.assertPlain(p.values);
      for(const [k,v]of Object.entries(p.values)){
        if(!settingsKeys.includes(k))throw new Error('Unknown setting.');
        if(['desktop_notifications','close_to_tray'].includes(k)&&typeof v!=='boolean')throw new Error('Invalid setting.');
        if(k==='theme'&&!['light','dark'].includes(v))throw new Error('Invalid theme.');
        if(k==='default_currency'&&!['UGX','USD','EUR','GBP','KES','TZS','RWF'].includes(v))throw new Error('Invalid currency.');
        if(k==='reminder_days'&&(!Array.isArray(v)||v.length>20||v.some(n=>!Number.isInteger(n)||n<0||n>365)))throw new Error('Reminder intervals must be 0–365 days.');
        if(k==='backup_reminder_days'&&(!Number.isInteger(v)||v<0||v>365))throw new Error('Backup interval must be 0–365 days.');
        if(['business_name','business_address','business_email','drive_folder_url'].includes(k)&&(typeof v!=='string'||v.length>2000))throw new Error('Setting is too long.');
        if(k==='drive_folder_url'&&v)security.safeUrl(v);
      }
      store.db.transaction(()=>Object.entries(p.values).forEach(([k,v])=>store.setSetting(k,v)))();return getSettings();
    }
    case 'notifications':store.refreshReminders();return store.notifications();
    case 'notificationAction':store.notificationAction(p.id,p.action,p.until);return true;
    case 'renewDomain':if(await confirm('Confirm that this domain was renewed?','Only continue after you have verified the registrar renewal.'))return store.renewDomain(p.id,p.expiry,p.amount,p.currency,p.evidence);return null;
    case 'importDocuments':{
      const result=await dialog.showOpenDialog(win,{title:p.external?'Link external files':'Import files into workspace',properties:['openFile','multiSelections']});if(result.canceled)return null;
      const imported=[],errors=[];for(const file of result.filePaths){try{imported.push(workspace.importFile(file,p));}catch(e){errors.push(`${path.basename(file)}: ${e.message}`);}}return {imported,errors};
    }
    case 'chooseLocalFile':{const r=await dialog.showOpenDialog(win,{title:'Link a local data source',properties:['openFile']});if(r.canceled)return null;store.approvedPaths.add(r.filePaths[0]);return r.filePaths[0];}
    case 'openDocument':{const err=await shell.openPath(workspace.resolveDocument(p.id));if(err)throw new Error(err);return true;}
    case 'revealDocument':shell.showItemInFolder(workspace.resolveDocument(p.id));return true;
    case 'moveDocument':if(await confirm('Rename or move this managed file?', 'The file will move within your workspace.'))return workspace.moveDocument(p.id,p.values);return null;
    case 'deleteDocument':{
      const doc=store.get('documents',p.id);
      if(store.db.prepare('SELECT id FROM quotation_revisions WHERE attachment_id=? LIMIT 1').get(doc.id))throw new Error('This file is retained by a quotation revision. Archive the document instead.');
      for(const [table,def]of Object.entries(catalog.catalog))for(const f of def.fields.filter(f=>f.type==='ref'&&f.target==='documents'))if(store.db.prepare(`SELECT id FROM ${table} WHERE ${f.name}=? LIMIT 1`).get(doc.id))throw new Error('This file is used as an attachment or receipt. Remove those links first.');
      if(!await confirm(doc.external_path?'Remove this external file link?':'Move this file to the Recycle Bin?',doc.external_path?'The original external file will be preserved.':'If the file is missing, only its index record will be removed.'))return false;
      if(doc.relative_path&&!doc.missing)await shell.trashItem(workspace.resolveDocument(doc.id));store.db.prepare('DELETE FROM documents WHERE id=?').run(doc.id);store.activity('documents',doc.id,'removed',doc.name);return true;
    }
    case 'refreshDocuments':return workspace.reconcile();
    case 'openFolder':{
      let folder;if(p.kind==='client')folder=security.inside(workspace.root,workspace.clientFolder(p.id));else if(p.kind==='project'){store.get('projects',p.id);workspace.ensureFolders();folder=security.inside(workspace.root,`Projects/${p.id}`);}else if(['Backups','Exports','Clients',''].includes(p.kind))folder=security.inside(workspace.root,p.kind);else throw new Error('Invalid folder.');
      const err=await shell.openPath(folder);if(err)throw new Error(err);return true;
    }
    case 'openUrl':{
      if(p.sourceId){const row=store.get('data_sources',p.sourceId);if(row.local_path){if(!fs.existsSync(row.local_path))throw new Error('The linked file is missing.');const err=await shell.openPath(row.local_path);if(err)throw new Error(err);return true;}p.url=row.url;}
      await shell.openExternal(security.safeUrl(p.url,true));return true;
    }
    case 'backup':workspace.reconcile();return await workspace.backup();
    case 'backups':return store.db.prepare('SELECT * FROM backups ORDER BY created_at DESC').all();
    case 'confirmUpload':if(await confirm('Confirm you uploaded this backup to Google Drive?','Control Room does not upload files automatically. Only confirm after your manual upload completes.')){store.db.prepare('UPDATE backups SET uploaded_at=? WHERE id=?').run(new Date().toISOString(),p.id);return true;}return false;
    case 'export':return workspace.exportBundle(p.scope,p.id);
    case 'relocate':{
      const dest=await dialog.showOpenDialog(win,{title:'Move workspace to a new empty folder (original is retained)',properties:['openDirectory','createDirectory']});if(dest.canceled)return null;
      if(fs.readdirSync(dest.filePaths[0]).length)throw new Error('Choose an empty destination.');
      if(!await confirm('Copy and switch to the new workspace?',`Your original workspace at ${workspace.root} will remain available.`))return null;
      const archive=await workspace.backup(),next=core.Workspace.restore(archive.path,dest.filePaths[0]);setWorkspace(next);return {root:next.root};
    }
    case 'printDocument':return await printDocument(p.table,p.id);
    default:throw new Error('Unknown operation.');
  }
}
app.whenReady().then(async()=>{
  app.setAppUserModelId('com.controlroom.desktop');
  core=await import(pathToFileURL(path.join(__dirname,'../core/workspace.js')).href);security=await import(pathToFileURL(path.join(__dirname,'../core/security.js')).href);catalog=await import(pathToFileURL(path.join(__dirname,'../shared/catalog.js')).href);
  createWindow();
  const root=readConfig().root;
  if(root&&fs.existsSync(path.join(root,'Database','control-room.sqlite')))try{setWorkspace(new core.Workspace(root));}catch(e){dialog.showErrorBox('Workspace could not be opened',e.message);}
  const reads=new Set(['state','list','get','options','related','search','finance','revisions','settings','backups']);
  ipcMain.handle('control-room',async(event,command,payload)=>{
    try {
      if(event.sender!==win?.webContents||event.senderFrame!==win.webContents.mainFrame||event.senderFrame.url!==pathToFileURL(path.join(__dirname,'../dist/index.html')).href)throw new Error('Untrusted IPC sender.');
      if(typeof command!=='string')throw new Error('Invalid operation.');
      if(busy)throw new Error('A workspace operation is in progress. Please wait.');
      const write=!reads.has(command);if(write)busy=true;
      try{return {ok:true,data:await handle(command,payload)};}finally{if(write)busy=false;}
    }catch(e){return {ok:false,error:e.message||'Operation failed.'};}
  });
});
app.on('activate',()=>{if(!win)createWindow();else win.show();});
app.on('before-quit',event=>{
  if(quitApproved||!win)return;
  event.preventDefault();if(shuttingDown)return;shuttingDown=true;
  win.webContents.executeJavaScript('window.__controlRoomDirty === true').then(async dirty=>{
    if(dirty&&!await confirm('Quit and discard unsaved changes?','Save the open form first if you want to keep your edits.')){shuttingDown=false;quitting=false;return;}
    quitApproved=true;quitting=true;win?.destroy();app.quit();
  }).catch(()=>{shuttingDown=false;quitting=false;});
});
app.on('will-quit',()=>{watcher?.close();clearInterval(pollTimer);clearTimeout(refreshTimer);workspace?.close();workspace=null;});
app.on('window-all-closed',()=>{if(process.platform!=='darwin')app.quit();});
