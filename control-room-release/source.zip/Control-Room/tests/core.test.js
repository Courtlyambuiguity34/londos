import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import AdmZip from 'adm-zip';
import {Workspace} from '../core/workspace.js';
import {catalog,toMinor,fromMinor,calculateLines} from '../shared/catalog.js';
import {inside,safeName,safeUrl} from '../core/security.js';
function setup(t){const root=fs.mkdtempSync(path.join(os.tmpdir(),'cr-test-'));const workspace=new Workspace(root);t.after(()=>{try{workspace.close();}catch{}fs.rmSync(root,{recursive:true,force:true});});return workspace;}
const line=(amount=1000,quantity=1000)=>({description:'Website development',quantity_milli:quantity,unit_price_minor:amount});
const invoice=(store,extra={})=>store.save('invoices',{name:'INV-'+Math.random(),currency:'UGX',status:'issued',lines:[line()],...extra});
const payment=(store,inv,amount,extra={})=>store.save('payments',{name:'Payment',invoice_id:inv.id,currency:inv.currency,amount_minor:amount,kind:'payment',...extra});

test('workspace creates normalized tables, migrations, folders, and idempotent editable seed',t=>{
  const w=setup(t),s=w.store;
  assert.equal(s.list('clients').total,8);assert.equal(s.list('projects').total,8);
  assert.equal(s.db.pragma('foreign_keys',{simple:true}),1);assert.equal(s.db.prepare('SELECT COUNT(*) n FROM migrations').get().n,1);
  assert.equal(s.list('projects',{query:'Techco'}).rows[0].hosting_provider,'Bluehost');
  assert.equal(s.list('projects',{query:'ReGreenEdu'}).rows[0].hosting_provider,'unconfirmed');
  assert.ok(s.list('projects').rows.every(p=>p.live_url===null&&p.due_date===null));
  s.seed();assert.equal(s.list('clients').total,8);
  const client=s.list('clients').rows[0];assert.ok(fs.existsSync(inside(w.root,w.clientFolder(client.id)+'/Quotations')));
  for(const table of Object.keys(catalog))assert.ok(s.db.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name=?").get(table));
});
test('client CRUD, multiple contacts, one primary contact, offices, follow-up communication, and safe deletion',t=>{
  const s=setup(t).store,c=s.save('clients',{name:'Family company',classification:'prospective'});
  const a=s.save('contacts',{name:'First',client_id:c.id,is_primary:1,email:'first@example.com'});
  const b=s.save('contacts',{name:'Second',client_id:c.id,is_primary:1});assert.equal(s.get('contacts',a.id).is_primary,0);assert.equal(b.is_primary,1);
  const location=s.save('locations',{name:'Kampala office',client_id:c.id,country:'Uganda',city:'Kampala',maps_url:'https://maps.google.com/?q=Kampala'});
  s.save('communications',{name:'Restoration opportunity',client_id:c.id,type:'opportunity',contact_date:'2026-01-01',next_followup:'2026-02-01'});
  assert.equal(s.get('clients',c.id).next_followup,'2026-02-01');assert.equal(s.related('clients',c.id).contacts.length,2);
  assert.throws(()=>s.remove('clients',c.id),/linked/);s.save('clients',{id:c.id,archived:1});assert.equal(s.list('clients',{archived:true}).total,1);
  s.remove('locations',location.id);assert.throws(()=>s.get('locations',location.id),/not found/);
  const free=s.save('clients',{name:'Disposable'});s.remove('clients',free.id);assert.throws(()=>s.get('clients',free.id),/not found/);
});
test('all infrastructure modules persist real relationships, and bad references fail',t=>{
  const s=setup(t).store,p=s.list('projects').rows[0],c=p.client_id;
  const host=s.save('hosting_accounts',{name:'Render account',provider:'Render',renewal_date:'2026-12-01'});
  const service=s.save('hosting_services',{name:'API',account_id:host.id,project_id:p.id,type:'backend',environment:'production'});
  const account=s.save('service_accounts',{name:'Cloudinary media',provider:'Cloudinary',cloud_name:'example'});
  s.save('project_services',{name:'Media link',account_id:account.id,project_id:p.id});
  assert.throws(()=>s.save('project_services',{name:'Duplicate',account_id:account.id,project_id:p.id}),/UNIQUE/);
  s.save('databases',{name:'Records',account_id:account.id,project_id:p.id,engine:'PostgreSQL'});
  const sub=s.save('email_subscriptions',{name:'Email plan',client_id:c,provider:'Google Workspace',cost_minor:12000,currency:'UGX',mailbox_count:3});
  s.save('mailboxes',{name:'Office',email:'office@example.com',subscription_id:sub.id});
  s.save('mailboxes',{name:'Info',email:'info@example.com',subscription_id:sub.id});
  assert.equal(s.get('email_subscriptions',sub.id).cost_minor,12000);assert.equal(s.get('hosting_services',service.id).project_id,p.id);
  s.save('data_sources',{name:'Content sheet',client_id:c,project_id:p.id,type:'Google Sheets',url:'https://docs.google.com/spreadsheets/d/example',integration_method:'Plugin/API -> Website'});
  assert.throws(()=>s.save('hosting_services',{name:'Invalid',account_id:'missing'}),/FOREIGN KEY/);
  assert.throws(()=>s.remove('hosting_accounts',host.id),/linked/);
});
test('money parsing is exact and integer calculations handle fractional quantities',()=>{
  assert.equal(toMinor('0.29','USD'),29);assert.equal(toMinor('250000','UGX'),250000);assert.equal(fromMinor(109,'USD'),'1.09');
  assert.throws(()=>toMinor('1.2','UGX'));assert.throws(()=>toMinor('-1','USD'));assert.throws(()=>toMinor('1.234','USD'));assert.throws(()=>toMinor('9007199254740992','UGX'));
  const total=calculateLines([line(999,1500)],1800,100);assert.equal(total.subtotal_minor,1499);assert.equal(total.tax_minor,252);assert.equal(total.total_minor,1651);
  assert.throws(()=>calculateLines([line()],0,1001),/Discount/);assert.throws(()=>calculateLines([line(1,0)]),/quantity/);
});
test('invoice partial payments, multiple payments, refunds, currency rules, and audit retention',t=>{
  const s=setup(t).store,i=invoice(s);
  const p=payment(s,i,400);assert.equal(s.get('invoices',i.id).balance_minor,600);assert.equal(s.get('invoices',i.id).payment_status,'partial');
  payment(s,i,600);assert.equal(s.get('invoices',i.id).payment_status,'paid');
  assert.throws(()=>payment(s,i,1),/exceeds/);assert.throws(()=>payment(s,i,1,{currency:'USD'}),/currency/);
  payment(s,i,100,{kind:'refund'});assert.equal(s.get('invoices',i.id).balance_minor,100);
  assert.throws(()=>payment(s,i,901,{kind:'refund'}),/exceeds/);
  assert.throws(()=>s.save('invoices',{id:i.id,currency:'USD'}),/currency/);
  assert.throws(()=>s.save('invoices',{id:i.id,lines:[line(500)]}),/balance/);
  assert.throws(()=>s.save('invoices',{id:i.id,status:'void'}),/remain issued/);
  assert.throws(()=>s.remove('payments',p.id),/retained/);
  assert.throws(()=>s.remove('invoices',i.id),/linked/);
});
test('reports keep currencies, revenue, expenses and pass-through funds separate',t=>{
  const s=setup(t).store;
  const ugx=invoice(s),usd=invoice(s,{currency:'USD',fund_type:'pass-through'});payment(s,ugx,500);payment(s,usd,200);
  s.save('expenses',{name:'Domain charge',currency:'USD',amount_minor:300,fund_type:'third-party'});
  s.save('expenses',{name:'Office',currency:'UGX',amount_minor:100,fund_type:'business'});
  const f=s.finance();assert.equal(f.invoices.length,2);assert.equal(f.payments.find(p=>p.currency==='USD').fund_type,'pass-through');assert.equal(f.payments.find(p=>p.currency==='UGX').received,500);assert.equal(f.expenses.length,2);
});
test('quotation edits preserve immutable revisions and normalized lines',t=>{
  const s=setup(t).store,q=s.save('quotations',{name:'Q-001',status:'issued',currency:'USD',lines:[line(999)],notes:'Original terms'});
  s.save('quotations',{id:q.id,lines:[line(1999)],status:'revised',notes:'Updated terms'});
  const revisions=s.revisions(q.id);assert.equal(revisions.length,1);assert.equal(revisions[0].total_minor,999);assert.equal(revisions[0].lines[0].unit_price_minor,999);assert.equal(revisions[0].notes,'Original terms');assert.equal(s.get('quotations',q.id).total_minor,1999);
  assert.throws(()=>s.remove('quotations',q.id),/linked/);
});
test('document import, external link, folder paste discovery, missing files, search, moves and collision protection',t=>{
  const w=setup(t),s=w.store,source=path.join(w.root,'Exports','source.txt');fs.writeFileSync(source,'Client brief');
  const c=s.list('clients').rows[0];const doc=w.importFile(source,{client_id:c.id,category:'Business-Profile'});
  assert.equal(fs.readFileSync(w.resolveDocument(doc.id),'utf8'),'Client brief');assert.throws(()=>w.importFile(source,{client_id:c.id,category:'Business-Profile'}),/exist/i);
  const pasted=inside(w.root,`${w.clientFolder(c.id)}/Contracts/Pasted.txt`);fs.writeFileSync(pasted,'Contract');assert.equal(w.reconcile().added,1);
  assert.equal(s.list('documents',{query:'Pasted'}).rows[0].client_id,c.id);
  const moved=w.moveDocument(doc.id,{name:'Renamed.txt',category:'Quotations',client_id:c.id});assert.match(moved.relative_path,/Quotations\/Renamed/);
  s.save('documents',{id:doc.id,tags:'strategy, kickoff',description:'Requirements'});assert.equal(s.search('kickoff')[0].id,doc.id);
  fs.unlinkSync(w.resolveDocument(doc.id));w.reconcile();assert.equal(s.get('documents',doc.id).missing,1);assert.throws(()=>w.resolveDocument(doc.id),/missing/);
  const external=w.importFile(source,{external:true});assert.equal(external.external_path,source);assert.equal(external.relative_path,null);
  assert.throws(()=>w.moveDocument(external.id,{name:'Other.txt'}),/external/);
  assert.throws(()=>s.save('documents',{id:doc.id,relative_path:'../outside'}),/not editable/);
});
test('data source local file paths require picker authorization',t=>{
  const s=setup(t).store;assert.throws(()=>s.save('data_sources',{name:'Unsafe',local_path:'/etc/passwd'}),/picker/);
  s.approvedPaths.add('/chosen/example.xlsx');const source=s.save('data_sources',{name:'Excel',type:'Excel',local_path:'/chosen/example.xlsx'});assert.equal(source.local_path,'/chosen/example.xlsx');s.save('data_sources',{id:source.id,notes:'Updated'});
});
test('URL, filename, traversal and symlink validation',t=>{
  const w=setup(t);for(const u of ['javascript:alert(1)','file:///etc/passwd','https://user:password@example.com','data:text/html,hello'])assert.throws(()=>safeUrl(u));
  assert.equal(safeUrl('https://example.com/path'),'https://example.com/path');assert.equal(safeUrl('mailto:person@example.com',true),'mailto:person@example.com');
  for(const n of ['..','../x','CON','COM1.txt','bad:name','bad.','a/b'])assert.throws(()=>safeName(n));
  for(const p of ['../outside','/etc/passwd','C:/Windows/system.ini','Clients/../../escape','Clients/file:secret'])assert.throws(()=>inside(w.root,p));
  const target=path.join(w.root,'Exports','target');fs.mkdirSync(target);
  try {fs.symlinkSync(target,path.join(w.root,'Assets','link'),'dir');assert.throws(()=>inside(w.root,'Assets/link/secret'),/Symbolic/);}catch(e){if(e.code!=='EPERM')throw e;}
});
test('parameterized queries and validation reject injected identifiers and invalid dates',t=>{
  const s=setup(t).store;s.save('clients',{name:"Robert'); DROP TABLE clients;--"});assert.equal(s.list('clients').total,9);
  assert.equal(s.list('clients',{query:"' OR 1=1 --"}).total,0);assert.throws(()=>s.list('clients; DROP TABLE projects'),/Unknown/);assert.throws(()=>s.list('clients',{sort:'name; DELETE FROM clients'}),/sort/);
  assert.throws(()=>s.save('clients',{name:'Bad',password:'plaintext'}),/not editable/);assert.throws(()=>s.save('clients',{name:'Bad',next_followup:'2026-02-30'}),/calendar/);assert.throws(()=>s.save('clients',{name:' '}),/required/);
});
test('reminders are deduplicated, snoozeable, dismissible, and resolved when deadlines change',t=>{
  const s=setup(t).store;const d=s.save('domains',{name:'example.com',expiry_date:'2026-11-01',status:'active'});
  const first=s.refreshReminders('2026-10-18').filter(n=>n.record_id===d.id);assert.equal(first.length,1);assert.equal(s.refreshReminders('2026-10-18').filter(n=>n.record_id===d.id).length,1);
  const until=new Date(Date.now()+86400000).toISOString();s.notificationAction(first[0].id,'snooze',until);s.refreshReminders('2026-10-18');assert.equal(s.notifications().find(n=>n.id===first[0].id).snoozed_until,until);
  s.notificationAction(first[0].id,'dismiss');s.refreshReminders('2026-10-18');assert.equal(s.notifications().find(n=>n.id===first[0].id).state,'dismissed');
  s.save('domains',{id:d.id,expiry_date:'2028-11-01'});s.refreshReminders('2026-10-18');assert.equal(s.notifications().filter(n=>n.state==='pending'&&n.record_id===d.id).length,0);
});
test('renewal evidence and task completion persist; contracts may have no fixed expiry',t=>{
  const s=setup(t).store,d=s.save('domains',{name:'renew.example',expiry_date:'2026-11-01',currency:'UGX'});
  s.renewDomain(d.id,'2027-11-01',50000,'UGX',null);assert.equal(s.get('domains',d.id).expiry_date,'2027-11-01');assert.equal(s.list('renewals').rows[0].amount_minor,50000);assert.throws(()=>s.renewDomain(d.id,'2026-11-01',0,'UGX'),/follow/);
  const task=s.save('tasks',{name:'Follow-up',status:'pending',due_date:'2026-10-20'});s.save('tasks',{id:task.id,status:'completed'});assert.ok(s.get('tasks',task.id).completed_date);assert.equal(s.refreshReminders('2026-10-18').filter(n=>n.record_id===task.id).length,0);
  const contract=s.save('contracts',{name:'Ongoing maintenance',status:'active',end_date:null});assert.equal(s.get('contracts',contract.id).end_date,null);
});
test('consistent backup, manifest verification, restore, restart and preferences',async t=>{
  const w=setup(t);w.store.setSetting('theme','dark');const p=path.join(w.root,'Assets','logo.txt');fs.writeFileSync(p,'A real document');w.reconcile();
  const client=w.store.save('clients',{name:'Backup customer'});w.ensureFolders();const backup=await w.backup();assert.ok(fs.existsSync(backup.path));assert.equal(w.store.db.prepare('SELECT COUNT(*) n FROM backups').get().n,1);
  const manifest=Workspace.verifyArchive(backup.path).manifest;assert.ok(manifest.files.some(f=>f.path==='Assets/logo.txt'));
  const dest=fs.mkdtempSync(path.join(os.tmpdir(),'cr-restore-'));let restored;
  try{restored=Workspace.restore(backup.path,dest);assert.equal(restored.store.get('clients',client.id).name,'Backup customer');assert.equal(restored.store.setting('theme'),'dark');assert.equal(fs.readFileSync(path.join(dest,'Assets','logo.txt'),'utf8'),'A real document');assert.equal(restored.store.db.pragma('integrity_check',{simple:true}),'ok');restored.close();restored=new Workspace(dest);assert.equal(restored.store.list('clients').total,9);assert.equal(restored.store.setting('theme'),'dark');assert.throws(()=>Workspace.restore(backup.path,dest),/empty/);}finally{restored?.close();fs.rmSync(dest,{recursive:true,force:true});}
});
test('backup verification rejects tampered and traversal entries without touching existing data',async t=>{
  const w=setup(t),backup=await w.backup();
  const zip=new AdmZip(backup.path);zip.updateFile('Database/control-room.sqlite',Buffer.from('corruption'));const bad=path.join(w.root,'Exports','tampered.zip');zip.writeZip(bad);assert.throws(()=>Workspace.verifyArchive(bad),/integrity/);
  const traversal=new AdmZip();traversal.addFile('safe.txt',Buffer.from('x'));const entry=traversal.getEntry('safe.txt');entry.entryName='../escape.txt';const malicious=path.join(w.root,'Exports','unsafe.zip');traversal.writeZip(malicious);assert.throws(()=>Workspace.verifyArchive(malicious),/Unsafe/);
  assert.equal(w.store.db.pragma('integrity_check',{simple:true}),'ok');
});
test('client/project exports include linked records and managed documents but exclude unrelated clients',t=>{
  const w=setup(t),s=w.store,c=s.save('clients',{name:'Export client'}),other=s.save('clients',{name:'Unrelated'}),p=s.save('projects',{name:'Export project',client_id:c.id});
  const i=invoice(s,{project_id:p.id,client_id:c.id});payment(s,i,500);const source=path.join(w.root,'Exports','source.txt');fs.writeFileSync(source,'Export me');w.importFile(source,{client_id:c.id,project_id:p.id});
  const exported=w.exportBundle('clients',c.id);const zip=new AdmZip(exported.path);const data=JSON.parse(zip.readAsText('records.json')).data;
  assert.equal(data.clients.length,1);assert.notEqual(data.clients[0].id,other.id);assert.equal(data.projects.length,1);assert.equal(data.payments.length,1);assert.equal(data.invoices[0].lines.length,1);assert.ok(zip.getEntries().some(e=>e.entryName.startsWith('documents/')));assert.ok(zip.readAsText('csv/clients.csv').includes('Export client'));
});
test('dashboard is calculated from records and supports pagination/filtering',t=>{
  const s=setup(t).store;const before=s.dashboard();assert.equal(before.counts.clients,8);assert.equal(before.counts.websites,0);
  const p=s.list('projects').rows[0];s.save('projects',{id:p.id,status:'active',live_url:'https://example.com'});s.save('clients',{name:'New client'});
  assert.equal(s.dashboard().counts.clients,9);assert.equal(s.dashboard().counts.websites,1);
  const one=s.list('clients',{page:1,pageSize:5,sort:'name',direction:'ASC'}),two=s.list('clients',{page:2,pageSize:5,sort:'name',direction:'ASC'});assert.equal(one.rows.length,5);assert.equal(two.rows.length,4);assert.ok(!one.rows.some(a=>two.rows.some(b=>a.id===b.id)));
  assert.equal(s.list('projects',{filters:{status:'active'}}).total,1);
});
test('exports do not pull another client invoice through a shared attachment',t=>{
  const w=setup(t),s=w.store,a=s.save('clients',{name:'Client A'}),b=s.save('clients',{name:'Client B'}),source=path.join(w.root,'Exports','shared.txt');fs.writeFileSync(source,'Shared terms');
  const doc=w.importFile(source,{client_id:a.id});const aInvoice=invoice(s,{client_id:a.id,attachment_id:doc.id});invoice(s,{client_id:b.id,attachment_id:doc.id});
  const data=JSON.parse(new AdmZip(w.exportBundle('clients',a.id).path).readAsText('records.json')).data;assert.deepEqual(data.invoices.map(r=>r.id),[aInvoice.id]);assert.equal(data.invoice_lines.length,1);
});
test('client and contact associations cannot contradict the project owner',t=>{
  const s=setup(t).store,a=s.save('clients',{name:'Owner'}),b=s.save('clients',{name:'Another owner'}),p=s.save('projects',{name:'Owned project',client_id:a.id}),contact=s.save('contacts',{name:'Contact',client_id:b.id});
  assert.throws(()=>s.save('tasks',{name:'Mixed',project_id:p.id,client_id:b.id}),/different client/);
  assert.throws(()=>s.save('tasks',{name:'Mixed contact',project_id:p.id,contact_id:contact.id}),/different client/);
  assert.equal(s.save('domains',{name:'linked.example',project_id:p.id}).client_id,a.id);
});
test('financial report overflow is detected instead of silently rounded',t=>{
  const s=setup(t).store;invoice(s,{lines:[line(Number.MAX_SAFE_INTEGER)]});invoice(s,{lines:[line(2)]});assert.throws(()=>s.finance(),/safe integer/);
});
test('quotation revisions retain their attachment reference',t=>{
  const w=setup(t),source=path.join(w.root,'Exports','signed.txt');fs.writeFileSync(source,'Original attachment');const doc=w.importFile(source);
  const q=w.store.save('quotations',{name:'Q-attachment',attachment_id:doc.id,lines:[line()]});w.store.save('quotations',{id:q.id,attachment_id:null});
  assert.equal(w.store.revisions(q.id)[0].attachment_id,doc.id);assert.throws(()=>w.store.db.prepare('DELETE FROM documents WHERE id=?').run(doc.id),/FOREIGN KEY/);
});
test('workspace supports 100+ clients and thousands of indexed files with paginated search',t=>{
  const w=setup(t),s=w.store;
  s.db.transaction(()=>{for(let n=0;n<120;n++){const c=s.save('clients',{name:`Scale client ${String(n).padStart(3,'0')}`});s.save('projects',{name:`Scale project ${n}`,client_id:c.id});}})();
  const folder=path.join(w.root,'Assets','Scale');fs.mkdirSync(folder);
  for(let n=0;n<2000;n++)fs.writeFileSync(path.join(folder,`document-${String(n).padStart(4,'0')}.txt`),'Indexable content');
  const begin=performance.now(),result=w.reconcile();assert.equal(result.added,2000);assert.equal(s.list('clients').total,128);
  const list=s.list('documents',{query:'document-',page:60,pageSize:30});assert.equal(list.total,2000);assert.equal(list.rows.length,30);
  assert.ok(s.search('document-1999').some(r=>r.table==='documents'));assert.equal(s.list('clients',{before:{field:'created_at',value:'2099-01-01'}}).total,128);
  console.log(`Scale check: 128 clients, 128 projects, 2,000 files; reconcile and search ${Math.round(performance.now()-begin)} ms.`);
});
