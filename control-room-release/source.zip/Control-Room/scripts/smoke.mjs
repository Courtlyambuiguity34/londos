import {_electron as electron,expect} from '@playwright/test';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import assert from 'node:assert/strict';
const temp=fs.mkdtempSync(path.join(os.tmpdir(),'control-room-desktop-'));
const userData=path.join(temp,'profile'),root=path.join(temp,'workspace');fs.mkdirSync(root);fs.mkdirSync('test-results',{recursive:true});
let application;const errors=[];
async function launch(){
  application=await electron.launch({args:[process.cwd(),'--smoke-test',...(process.platform==='linux'?['--no-sandbox']:[])],env:{...process.env,CONTROL_ROOM_TEST_DATA:userData},timeout:30000});
  const page=await application.firstWindow();page.on('pageerror',error=>errors.push(error.message));
  await page.waitForLoadState('domcontentloaded');return page;
}
try{
  let page=await launch();
  await expect(page.getByRole('button',{name:'Choose workspace folder'})).toBeVisible();
  await page.screenshot({path:'test-results/first-run.png'});
  await application.evaluate(({dialog},folder)=>{dialog.showOpenDialog=async()=>({canceled:false,filePaths:[folder]});},root);
  await page.getByRole('button',{name:'Choose workspace folder'}).click();
  await expect(page.getByRole('heading',{name:'Operations overview'})).toBeVisible({timeout:20000});
  assert.equal(await page.evaluate(async()=> (await window.controlRoom.request('list',{table:'projects',options:{query:'Techco'}})).total),1);
  const isolation=await page.evaluate(()=>({node:typeof window.require,api:typeof window.controlRoom?.request}));assert.deepEqual(isolation,{node:'undefined',api:'function'});
  const security=await application.evaluate(({BrowserWindow})=>{const p=BrowserWindow.getAllWindows()[0].webContents.getLastWebPreferences();return {contextIsolation:p.contextIsolation,nodeIntegration:p.nodeIntegration,sandbox:p.sandbox};});assert.deepEqual(security,{contextIsolation:true,nodeIntegration:false,sandbox:true});
  await page.screenshot({path:'test-results/dashboard.png',fullPage:true});
  await page.locator('aside nav').getByRole('button',{name:'Clients',exact:true}).click();
  await page.getByRole('button',{name:'New client',exact:true}).click();
  await page.getByLabel('Organization').fill('Desktop Test Client');
  await page.getByRole('button',{name:'Save record',exact:true}).click();
  await expect(page.getByRole('dialog').getByRole('heading',{name:'Desktop Test Client',exact:true})).toBeVisible();
  await page.getByRole('button',{name:'Close dialog',exact:true}).click();
  await page.getByLabel('Search records').fill('Desktop Test Client');
  await expect(page.locator('table tbody tr')).toHaveCount(1);
  await expect(page.locator('table tbody tr')).toContainText('Desktop Test Client');
  const clientId=await page.evaluate(async()=>{const r=await window.controlRoom.request('list',{table:'clients',options:{query:'Desktop Test Client'}});return r.rows[0].id;});
  await page.getByLabel('Global search').fill('Desktop Test');
  await page.locator('.search-results').getByRole('button').filter({hasText:'Desktop Test Client'}).click();
  await expect(page.getByRole('dialog')).toBeVisible();
  await page.getByRole('button',{name:'Edit record',exact:true}).click();
  await page.getByLabel('Trading name').fill('Test Trading');
  await page.getByRole('button',{name:'Save record',exact:true}).click();
  await expect(page.getByRole('dialog').getByText('Test Trading',{exact:true})).toBeVisible();
  await page.getByRole('button',{name:'Close dialog',exact:true}).click();
  await page.getByRole('button',{name:'Toggle theme'}).click();
  await expect(page.locator('html')).toHaveAttribute('data-theme','dark');
  await page.screenshot({path:'test-results/dark-theme.png',fullPage:true});
  // Exercise real main-process IPC, including invoice math and PDF printing.
  const invoice=await page.evaluate(async client=>window.controlRoom.request('save',{table:'invoices',record:{name:'SMOKE-INV-001',client_id:client,currency:'UGX',status:'issued',lines:[{description:'Development',quantity_milli:1000,unit_price_minor:500000}]}}),clientId);
  await page.evaluate(async invoice=>window.controlRoom.request('save',{table:'payments',record:{name:'Deposit',invoice_id:invoice.id,currency:'UGX',kind:'payment',amount_minor:125000}}),invoice);
  const paid=await page.evaluate(id=>window.controlRoom.request('get',{table:'invoices',id}),invoice.id);assert.equal(paid.balance_minor,375000);
  const pdf=path.join(temp,'invoice.pdf');await application.evaluate(({dialog},file)=>{dialog.showSaveDialog=async()=>({canceled:false,filePath:file});},pdf);
  await page.evaluate(id=>window.controlRoom.request('printDocument',{table:'invoices',id}),invoice.id);assert.equal(fs.readFileSync(pdf).subarray(0,4).toString(),'%PDF');
  const source=path.join(temp,'brief.txt');fs.writeFileSync(source,'Desktop document import.');await application.evaluate(({dialog},file)=>{dialog.showOpenDialog=async()=>({canceled:false,filePaths:[file]});},source);
  const imported=await page.evaluate(client=>window.controlRoom.request('importDocuments',{client_id:client,category:'Business-Profile'}),clientId);assert.equal(imported.imported.length,1);
  const backup=await page.evaluate(()=>window.controlRoom.request('backup'));assert.ok(fs.existsSync(backup.path));
  const settings=await page.evaluate(()=>window.controlRoom.request('settings'));assert.equal(settings.theme,'dark');
  // Quit through app.quit so tray-close behavior does not hide a live test process.
  await application.evaluate(({app})=>app.quit());await application.close();application=null;
  page=await launch();await expect(page.getByRole('heading',{name:'Operations overview'})).toBeVisible({timeout:20000});await expect(page.locator('html')).toHaveAttribute('data-theme','dark');
  const restored=await page.evaluate(id=>window.controlRoom.request('get',{table:'clients',id}),clientId);assert.equal(restored.trading_name,'Test Trading');
  await application.evaluate(({app})=>app.quit());await application.close();application=null;
  // Missing drive recovery must not create an empty replacement at the old location.
  fs.renameSync(root,root+'-offline');page=await launch();await expect(page.getByText(/Your previous workspace is unavailable/)).toBeVisible();assert.equal(fs.existsSync(root),false);
  assert.deepEqual(errors,[]);
  console.log('PASS: first run, secure preload, real client create/edit/search, themes, invoice partial payment, PDF, document import, backup, restart persistence, and missing-drive recovery.');
}finally{if(application){try{await application.evaluate(({app})=>app.quit());await application.close();}catch{}}fs.rmSync(temp,{recursive:true,force:true});}
