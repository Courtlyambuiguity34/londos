import fs from 'node:fs';
import path from 'node:path';
import {createHash} from 'node:crypto';
import AdmZip from 'adm-zip';
const root=process.cwd(),target=process.argv[2]||path.join(path.dirname(root),'Control-Room-Source.zip');
const excluded=new Set(['node_modules','release','.git','test-results','.env','.DS_Store']);
const zip=new AdmZip();let count=0;
function walk(dir,relative=''){for(const item of fs.readdirSync(dir,{withFileTypes:true})){if(excluded.has(item.name)||item.name.startsWith('.env')||item.isSymbolicLink())continue;const rel=relative?`${relative}/${item.name}`:item.name,full=path.join(dir,item.name);if(item.isDirectory())walk(full,rel);else if(item.isFile()){zip.addFile(`Control-Room/${rel}`,fs.readFileSync(full));count++;}}}
walk(root);fs.mkdirSync(path.dirname(target),{recursive:true});zip.writeZip(target);
const verify=new AdmZip(target);if(verify.getEntries().length!==count||!verify.test())throw new Error('ZIP verification failed.');
const checksum=createHash('sha256').update(fs.readFileSync(target)).digest('hex');fs.writeFileSync(target+'.sha256',`${checksum}  ${path.basename(target)}\n`);
console.log(JSON.stringify({path:target,files:count,bytes:fs.statSync(target).size,sha256:checksum},null,2));
