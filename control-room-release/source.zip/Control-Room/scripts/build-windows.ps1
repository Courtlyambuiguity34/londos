$ErrorActionPreference = 'Stop'
Set-Location (Split-Path $PSScriptRoot -Parent)
npm ci
if ($LASTEXITCODE -ne 0) { throw 'Dependency installation failed.' }
npm run check
if ($LASTEXITCODE -ne 0) { throw 'Lint failed.' }
npm test
if ($LASTEXITCODE -ne 0) { throw 'Core tests failed.' }
npm run build
if ($LASTEXITCODE -ne 0) { throw 'UI build failed.' }
npm run test:desktop
if ($LASTEXITCODE -ne 0) { throw 'Desktop smoke tests failed.' }
npm run dist:win -- --publish never
if ($LASTEXITCODE -ne 0) { throw 'Windows packaging failed.' }
Write-Host 'Installer and portable EXE are in release\.'
