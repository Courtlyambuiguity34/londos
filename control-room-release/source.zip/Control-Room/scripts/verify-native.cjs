const Database=require('better-sqlite3');
const db=new Database(':memory:');
try {
  db.exec('CREATE TABLE verification(value INTEGER NOT NULL)');
  db.prepare('INSERT INTO verification VALUES(?)').run(42);
  if(db.prepare('SELECT value FROM verification').get().value!==42)throw new Error('SQLite native verification failed.');
  console.log(`SQLite native binding verified (${process.platform}/${process.arch}, Node-API ${process.versions.napi}).`);
}finally{db.close();}
